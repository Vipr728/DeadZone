# ControlPlane

Filesystem-backed hosted control plane scaffold for local development.

## Endpoints
- `GET /health`
- `POST /projects`
- `POST /runners/register`
- `POST /runs`
- `POST /runs/:id/events`
- `POST /runs/:id/artifacts`
- `POST /runs/:id/approvals`
- `GET /projects/:id/instructions`
- `GET /projects/:id/policies`

## Environment
- `PORT` default: `8787`
- `AGENT_CONTROL_PLANE_TOKEN` optional bearer token
- `ARK_REQUIRE_AUTH` or `AGENT_CONTROL_PLANE_REQUIRE_AUTH` requires bearer-token auth when set to `1`, `true`, `yes`, or `on`
- `NODE_ENV=production` also requires `AGENT_CONTROL_PLANE_TOKEN`
- `CONTROL_PLANE_DATA_DIR` default: `./data`

## Storage
- Projects, runs, and append-only event streams are stored as JSON files under the data directory.
- This is intentionally simple and local. It is a scaffold for a future database-backed service, not the final production design.

## Production Note
- The local control plane now fails closed when production auth is required but no token is configured.
- This service still needs real database storage, tenant/project authorization, audit logging, rate limits, and billing integration before it can be hosted as a monetized product.
