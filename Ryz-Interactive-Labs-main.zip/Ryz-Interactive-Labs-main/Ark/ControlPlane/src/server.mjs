import fs from "node:fs/promises";
import http from "node:http";
import path from "node:path";
import process from "node:process";
import crypto from "node:crypto";

const version = "0.1.0";
const port = Number(process.env.PORT || 8787);
const token = process.env.AGENT_CONTROL_PLANE_TOKEN || "";
const requireAuth = isEnabled(process.env.ARK_REQUIRE_AUTH) ||
  isEnabled(process.env.AGENT_CONTROL_PLANE_REQUIRE_AUTH) ||
  process.env.NODE_ENV === "production";
const dataDir = path.resolve(process.env.CONTROL_PLANE_DATA_DIR || "./data");

if (requireAuth && !token) {
  throw new Error("Ark ControlPlane requires AGENT_CONTROL_PLANE_TOKEN when auth is required.");
}

await ensureDir(dataDir);
await ensureDir(path.join(dataDir, "projects"));
await ensureDir(path.join(dataDir, "runs"));
await ensureDir(path.join(dataDir, "runners"));

const server = http.createServer(async (req, res) => {
  try {
    const url = new URL(req.url || "/", `http://${req.headers.host || "127.0.0.1"}`);
    if (req.method === "GET" && url.pathname === "/health") {
      return sendJson(res, 200, {
        ok: true,
        result: "Ark control plane is running.",
        version,
        production_ready: {
          mode: process.env.NODE_ENV === "production" ? "production" : "development",
          auth_required: requireAuth,
          auth_configured: Boolean(token),
          data_dir: dataDir
        }
      });
    }

    if (!authorize(req)) {
      return sendJson(res, 401, { error: "Unauthorized" });
    }

    if (req.method === "POST" && url.pathname === "/projects") {
      return sendJson(res, 200, await createProject(await readJson(req)));
    }

    if (req.method === "POST" && url.pathname === "/runners/register") {
      return sendJson(res, 200, await registerRunner(await readJson(req)));
    }

    if (req.method === "POST" && url.pathname === "/runs") {
      return sendJson(res, 200, await createRun(await readJson(req)));
    }

    const runMatch = url.pathname.match(/^\/runs\/([^/]+)\/(events|artifacts|approvals)$/);
    if (req.method === "POST" && runMatch) {
      const [, runId, collection] = runMatch;
      return sendJson(res, 200, await appendRunRecord(runId, collection, await readJson(req)));
    }

    const projectMatch = url.pathname.match(/^\/projects\/([^/]+)\/(instructions|policies)$/);
    if (req.method === "GET" && projectMatch) {
      const [, projectId, kind] = projectMatch;
      return sendJson(res, 200, await readProjectDocument(projectId, kind));
    }

    return sendJson(res, 404, { error: `Unknown route ${req.method} ${url.pathname}` });
  } catch (error) {
    return sendJson(res, 500, { error: error.message });
  }
});

server.listen(port, () => {
  process.stdout.write(`Ark control plane listening on http://127.0.0.1:${port}\n`);
});

function authorize(req) {
  if (!token) {
    return !requireAuth;
  }

  const authorization = req.headers.authorization || "";
  return authorization === `Bearer ${token}`;
}

function isEnabled(value) {
  return ["1", "true", "yes", "on"].includes(String(value || "").trim().toLowerCase());
}

async function createProject(body) {
  const projectId = body.projectId || crypto.randomUUID();
  const project = {
    projectId,
    name: body.name || projectId,
    repoRoot: body.repoRoot || "",
    createdAt: new Date().toISOString()
  };
  await writeJsonFile(path.join(dataDir, "projects", `${projectId}.json`), project);
  await writeJsonFile(path.join(dataDir, "projects", `${projectId}.instructions.json`), {
    projectId,
    source: [
      "Agent/UNITY_AGENT.md",
      "Agent/GAME_DESIGN.md",
      "Agent/TECHNICAL_ARCHITECTURE.md"
    ]
  });
  await writeJsonFile(path.join(dataDir, "projects", `${projectId}.policies.json`), {
    projectId,
    approvals: [
      "package_changes",
      "project_settings",
      "destructive_asset_delete",
      "invoke_editor_method"
    ]
  });
  return project;
}

async function registerRunner(body) {
  const runnerId = crypto.randomUUID();
  const record = {
    runnerId,
    projectId: body.projectId || "",
    host: body.host || "local",
    capabilities: body.capabilities || [],
    registeredAt: new Date().toISOString()
  };
  await writeJsonFile(path.join(dataDir, "runners", `${runnerId}.json`), record);
  return record;
}

async function createRun(body) {
  const runId = crypto.randomUUID();
  const record = {
    runId,
    projectId: body.projectId || "",
    title: body.title || "Untitled run",
    prompt: body.prompt || "",
    createdAt: new Date().toISOString()
  };
  const runDir = path.join(dataDir, "runs", runId);
  await ensureDir(runDir);
  await writeJsonFile(path.join(runDir, "run.json"), record);
  await writeJsonFile(path.join(runDir, "events.json"), []);
  await writeJsonFile(path.join(runDir, "artifacts.json"), []);
  await writeJsonFile(path.join(runDir, "approvals.json"), []);
  return record;
}

async function appendRunRecord(runId, collection, body) {
  const file = path.join(dataDir, "runs", runId, `${collection}.json`);
  const records = await readJsonFile(file, []);
  records.push({
    ...body,
    receivedAt: new Date().toISOString()
  });
  await writeJsonFile(file, records);
  return { ok: true, runId, collection, count: records.length };
}

async function readProjectDocument(projectId, kind) {
  const suffix = kind === "instructions" ? "instructions" : "policies";
  return readJsonFile(path.join(dataDir, "projects", `${projectId}.${suffix}.json`), {
    projectId,
    missing: true
  });
}

async function readJson(req) {
  const chunks = [];
  for await (const chunk of req) {
    chunks.push(chunk);
  }

  const text = Buffer.concat(chunks).toString("utf8");
  return text ? JSON.parse(text) : {};
}

async function readJsonFile(file, fallback) {
  try {
    const text = await fs.readFile(file, "utf8");
    return JSON.parse(text);
  } catch (error) {
    if (error.code === "ENOENT") {
      return fallback;
    }

    throw error;
  }
}

async function writeJsonFile(file, value) {
  await ensureDir(path.dirname(file));
  await fs.writeFile(file, JSON.stringify(value, null, 2), "utf8");
}

async function ensureDir(dir) {
  await fs.mkdir(dir, { recursive: true });
}

function sendJson(res, status, value) {
  const body = JSON.stringify(value, null, 2);
  res.writeHead(status, {
    "Content-Type": "application/json",
    "Content-Length": Buffer.byteLength(body)
  });
  res.end(body);
}
