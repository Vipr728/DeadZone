# TECHNICAL_ARCHITECTURE

## Components

### Unity Editor Package
- Embedded package path: `Packages/com.ark.agentic-gamedev`
- Typed localhost bridge
- Main-thread execution queue
- Scene/asset inspection and mutation
- Compile diagnostics
- Play mode control
- Runtime contracts assembly: `Ark.Runtime`
- Editor tooling assembly: `Ark.Editor`

### OpenClaw Adapter
- Long-lived HTTP server at `http://127.0.0.1:47391`
- Unity-compatible `/agent` backend endpoint
- Async `/v1/runs` lifecycle endpoints
- OpenClaw-owned orchestration loop outside the Unity editor process
- Repo access
- Narrow OpenClaw-to-Unity bridge CLI
- Run event emission
- Local run persistence under `Library/AgenticGamedev/AgentDaemonRuns`
- Production-mode daemon auth via `ARK_DAEMON_TOKEN` or `AGENT_DAEMON_TOKEN`

### Hosted Control Plane
- Project registration
- Runner registration
- Run storage
- Policies and instructions
- Artifact and approval logs
- Production-mode bearer auth via `AGENT_CONTROL_PLANE_TOKEN`

## Protocol
- Versioned command envelope
- Versioned result envelope
- Session id + revision on every result
- Idempotency key support for retried commands

## Runtime Boundary
- Unity owns scene, asset, compiler, and play-mode mutations only.
- OpenClaw owns model requests, planning, tool use, agent sessions, and the autonomous loop.
- OpenClaw Gateway receives each Ark run on an explicit `agent:ark-unity:ark-run:<run-id>` session key so runs do not share the main-session transcript or lock.
- AgentDaemon is a compatibility adapter only: it owns the Unity-facing HTTP lifecycle, run persistence, cancellation, progress forwarding, proportional context shaping, and the narrow Unity bridge CLI.
- AgentDaemon applies deterministic resource profiles (`atomic`, `focused`, or `complex`) before dispatch. These profiles only set OpenClaw thinking, bootstrap context, initial context limits, and tool-turn guidance; they do not plan or execute the task outside OpenClaw.
- Atomic editor operations use semantic bridge CLI commands such as `create-scene`, which batch the mutation and required validation/save work into one OpenClaw tool call.
- Focused and complex work use progressive disclosure. Project memory, detailed Unity context, and the full action schema are retrieved only when the task needs them instead of being injected into every turn.
- Compiler errors enter a same-session OpenClaw repair loop. Editable `Assets/` and embedded Ark package sources must be inspected, patched, rebuilt, and rechecked automatically (up to four focused or five complex continuations). Only concrete credential, external/read-only dependency, or approval-gated blockers may terminate with an actionable user handoff.
- The Unity chat window sends prompts to OpenClaw through AgentDaemon; it must not start the in-editor direct OpenAI tool loop.
- OpenClaw is the sole executor of user-requested game-content mutations. Supervising assistants may maintain Ark infrastructure and inspect project state, but must dispatch gameplay scripts, scenes, prefabs, and asset changes through AgentDaemon rather than editing that content directly.
- The default local path is Tools > Ark > Agent Backend > Settings > Use Local Endpoint with `npm run server` in `AgentDaemon`.
- Run `npm run setup:openclaw` once to register the `ark-unity` OpenClaw agent, configure the loopback Gateway, and install/start its user service.
- OpenClaw receives compact Ark safety/tool rules on every run. Workspace instructions and project memory use OpenClaw bootstrap or targeted file reads only when the selected task scale needs them.
- Production readiness status and remaining release gates are tracked in `Agent/PRODUCTION_READINESS.md`.

## Identity
- Assets: GUID
- Persisted objects: `GlobalObjectId`
- Runtime objects: session-scoped runtime ids

## Verification
- Compile diagnostics are blocking
- Scene validation is required after structural changes
- Smoke playtest and Game view capture are required for runtime/visual changes
