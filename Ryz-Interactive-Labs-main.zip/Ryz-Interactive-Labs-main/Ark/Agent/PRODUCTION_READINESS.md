# Ark Production Readiness

This document tracks what must change before Ark is treated as a production product rather than a local Unity prototype.

## Implemented Baseline

- Backend model orchestration runs in OpenClaw, outside the Unity editor process.
- `AgentDaemon` preserves the Unity-facing backend API and delegates each run to a dedicated `ark-unity` OpenClaw agent.
- OpenClaw uses the repo-local `openclaw-unity.mjs` command surface to execute typed Unity bridge actions.
- Unity is a narrow UI and command executor through the localhost bridge.
- Async daemon runs are exposed through `POST /v1/runs`, `GET /v1/runs/{id}`, and `POST /v1/runs/{id}/stop`.
- Daemon run snapshots and event trails are persisted under `Library/AgenticGamedev/AgentDaemonRuns`.
- On daemon restart, unfinished persisted runs are recovered as failed instead of disappearing.
- Daemon auth can be enabled with `ARK_DAEMON_TOKEN` or `AGENT_DAEMON_TOKEN`; auth is required when `ARK_REQUIRE_AUTH`, `AGENT_DAEMON_REQUIRE_AUTH`, or `NODE_ENV=production` is set.
- Control-plane auth is required when `ARK_REQUIRE_AUTH`, `AGENT_CONTROL_PLANE_REQUIRE_AUTH`, or `NODE_ENV=production` is set.
- `/health` endpoints expose Unity and OpenClaw readiness diagnostics.
- Agent project memory is loaded from `Agent/PROJECT_STATE.md`, `Agent/TECHNICAL_ARCHITECTURE.md`, and `Agent/UNITY_AGENT.md` on each run.
- Compiler diagnostics remain a blocking validation gate after generated code changes.

## Production Gaps

- Replace filesystem JSON control-plane storage with a real database and migrations.
- Add tenant, user, organization, and project authorization boundaries.
- Add billing, licensing, plan limits, seat management, and entitlement checks.
- Package the Unity side as a versioned UPM package with upgrade and rollback handling.
- Add signed releases, update channels, and compatibility checks for Unity versions and package dependencies.
- Add structured telemetry, crash reporting, latency metrics, model-cost tracking, and redaction.
- Add an evaluation suite for compiler repair, prefab edits, scene validation, and common Unity workflows.
- Add contract tests against the supported OpenClaw release range and Gateway mode.
- Add sandboxing and policy enforcement for filesystem writes, destructive asset operations, package installs, and editor callbacks.
- Add resumable cloud-backed runs for long jobs instead of local-only daemon state.
- Add queueing, backpressure, rate limits, and user-visible retry semantics.
- Add end-to-end tests that start the daemon, call Unity bridge endpoints, run a compile, and verify chat UI state.
- Complete a security review for localhost auth, model prompt injection, project-file exfiltration, and bridge command authorization.

## Local Production Mode Smoke Test

```bash
cd AgentDaemon
ARK_DAEMON_TOKEN=dev-token ARK_REQUIRE_AUTH=1 npm run server
curl http://127.0.0.1:47391/health
curl -H 'x-ark-daemon-token: dev-token' http://127.0.0.1:47391/v1/runs/example
```

```bash
cd ControlPlane
AGENT_CONTROL_PLANE_TOKEN=dev-token ARK_REQUIRE_AUTH=1 npm run server
curl http://127.0.0.1:8787/health
```

## Release Gate

A release candidate should not ship until these checks pass:

- `node --check AgentDaemon/src/server.mjs`
- `node --check AgentDaemon/src/openclaw-client.mjs`
- `node --check AgentDaemon/src/openclaw-unity.mjs`
- `npm test --prefix AgentDaemon`
- `node --check ControlPlane/src/server.mjs`
- Unity C# compile diagnostics are clean.
- Existing Ark chat UI can start an OpenClaw-backed run, stream bridge progress, cancel it, and show the final response.
- A daemon restart preserves completed run history and marks interrupted runs failed.
- Auth-required mode rejects unauthenticated mutating requests.
