﻿# PROJECT_STATE

## Purpose
- This file is the current project map for Ark runs.
- Use it before broad `search_project` sweeps when the task is about existing gameplay code, scene contracts, camera shake, spawning, roguelike dungeon generation, or simple bugfixes.
- Treat live Unity state, compiler diagnostics, and direct file reads as authoritative if they disagree with this summary.

## Project Snapshot
- Unity version: `6000.3.6f1`
- Render pipeline: `URP`
- Input path: new Input System is supported in player code with legacy fallback guards
- Current prototype: top-down roguelike arena combat with procedural rooms
- Ark Unity editor tooling is packaged as embedded UPM package `Packages/com.ark.agentic-gamedev`.
- Runtime/gameplay prototype scripts remain in `Assets/Scripts` and are not part of the Ark package.
- Backend agent turns run through the dedicated OpenClaw agent `ark-unity`; `AgentDaemon` only adapts the unchanged Unity HTTP contract and exposes the typed Unity bridge CLI.

## Package Layout
- `Packages/com.ark.agentic-gamedev/package.json`: embedded Unity package manifest.
- `Packages/com.ark.agentic-gamedev/Editor`: Ark editor UI, Unity bridge, project-memory stores, diagnostics, and editor actions.
- `Packages/com.ark.agentic-gamedev/Runtime`: lightweight runtime contracts for custom agent action/state providers.
- `AgentDaemon/src/openclaw-client.mjs`: OpenClaw CLI adapter, readiness probing, session isolation, and cancellation.
- `AgentDaemon/src/openclaw-unity.mjs`: narrow command-line surface OpenClaw uses for typed Unity bridge operations.
- `AgentDaemon/src/task-profile.mjs`: proportional OpenClaw resource profiles and compact run prompts. Atomic work uses lightweight bootstrap and semantic bridge commands; broader work progressively retrieves more context.
- `Assets/AgenticGamedev/Generated`: generated project/sample assets, not package source.

## Gameplay Loop
- The player moves in a top-down dungeon and fires bullets.
- At Play Mode start, `ArenaCombatGameManager` asks `RoguelikeDungeonGenerator` to generate a random room graph similar in spirit to Enter the Gungeon: connected rooms, corridors, doors, a start room, and an exit room.
- Entering a non-start room through `RoguelikeRoomTrigger` starts a room encounter.
- The manager spawns enemy prefabs inside the active room; clearing all active enemies marks the room cleared.
- Clearing the exit room calls `Win()` and generates the next floor with more rooms/enemies.
- Player health is tracked separately and can trigger game over through `ArenaCombatGameManager.PlayerDied()` / `Lose()`.
- Camera feedback uses a Cinemachine impulse source via `ScreenShakeService`.
- Bullet impacts spawn short-lived Unity ParticleSystem prefab instances.

## Scene Contracts
- Main camera should exist and be tagged `MainCamera`.
- Camera shake currently expects a `Unity.Cinemachine.CinemachineImpulseSource` that can be resolved at runtime.
- `ArenaCombatManager` should have both `ArenaCombatGameManager` and `RoguelikeDungeonGenerator`.
- `ArenaCombatGameManager.dungeonGenerator` should reference the same scene object/component.
- Old `EnemySpawn_` scene markers are no longer required for the default roguelike mode; the manager keeps legacy spawn-prefix support only when `useRoguelikeDungeon` is disabled.
- Bullet spawning expects a `PlayerBullet` prefab or resource fallback.

## Script Map

## `Assets/Scripts/ArenaCombatGameManager.cs`
- Central runtime manager for the roguelike arena loop.
- Owns floor number, generated room count scaling, active room encounters, enemy prefab selection, room clearing, floor completion, and game-over state.
- Preserves legacy public APIs: `Instance`, `Lose()`, `PlayerDied()`, and `Win()`.
- `EnterRoom(int roomIndex)` is called by room trigger colliders.
- In roguelike mode, spawns enemies at random positions within the active generated room rather than from scene `EnemySpawn_` markers.
- Keeps legacy spawn-prefix loop behind `useRoguelikeDungeon = false`.

## `Assets/Scripts/RoguelikeDungeonGenerator.cs`
- Runtime procedural dungeon builder.
- Generates a random connected graph of rectangular rooms on a grid, corridors between connected rooms, wall colliders, door gaps, floor sprites, and trigger colliders.
- Exposes generated room data, start room, exit room, random spawn positions, and room-cleared tinting.
- Creates generated geometry under a `Generated Roguelike Dungeon` child at runtime.

## `Assets/Scripts/RoguelikeRoomTrigger.cs`
- Trigger component generated inside each room.
- Calls `ArenaCombatGameManager.Instance.EnterRoom(roomIndex)` when the Player enters.

## `Assets/Scripts/ArenaCombatEnemy.cs`
- Enemy health/damage script.
- Holds `maxHealth`, `hitShakeIntensity`, and `hitShakeDuration`/shake settings depending on current source.
- Public damage entry point is `TakeDamage(int damage)`.
- On hit, it calls `ScreenShakeService.Shake(...)` and destroys itself at zero health.

## `Assets/Scripts/ArenaEnemyBehavior.cs`
- Enemy movement/AI behavior for chasing the player in top-down combat.

## `Assets/Scripts/TopDownBullet.cs`
- Projectile hit script.
- Uses `OnTriggerEnter2D(Collider2D other)`.
- Looks for `ArenaCombatEnemy` on the collider and applies `TakeDamage(damage)` when present.
- Destroys the bullet on any trigger contact after the impact hook has had a chance to run.

## `Assets/Scripts/BulletImpactParticles.cs`
- Bullet-attached impact VFX spawner.
- Uses `OnTriggerEnter2D(Collider2D other)` before `TopDownBullet` destroys the projectile.
- Instantiates the assigned impact prefab at the collision closest point.
- Does not create ParticleSystem GameObjects procedurally during gameplay.
- Current prefab reference should point to `Assets/Prefabs/BulletImpactParticles.prefab`.

## `Assets/Prefabs/BulletImpactParticles.prefab`
- Short-lived bullet-impact VFX prefab.
- Contains a Unity `ParticleSystem` configured as a non-looping burst.
- Uses `ParticleSystemStopAction.Destroy`; the bullet spawner also destroys the instance after the computed animation length plus padding.

## `Assets/Scripts/ScreenShakeService.cs`
- Static runtime helper for camera shake.
- Uses `Unity.Cinemachine.CinemachineImpulseSource`.
- Public API currently exposes `Shake(float intensity)` and `Shake(float intensity, float duration)`.
- If spawned enemies cannot find the shake source, this file is the first place to patch.

## `Assets/Scripts/ScreenShakeProfile.cs`
- ScriptableObject configuration for shake intensity tuning.
- Defines base intensity, duration, frequency, and per-shake-type multipliers.
- Current runtime `ScreenShakeService` does not appear to consume this profile directly.

## `Assets/Scripts/TopDownCameraShake.cs`
- Thin wrapper around `ScreenShakeService.Shake(float intensity)`.

## `Assets/Scripts/CameraTargetShake.cs`
- Thin wrapper component with serialized `shakeIntensity`.
- Calls `ScreenShakeService.Shake(shakeIntensity)`.

## `Assets/Scripts/ArenaCombatPlayerHealth.cs`
- Player damage/health component.
- Tracks `maxHealth`, cooldown between contact hits, and current health.
- Broadcasts `onHealthChanged`.
- Calls `ArenaCombatGameManager.Instance.PlayerDied()`/loss flow when health reaches zero.

## `Assets/Scripts/TopDownPlayerController.cs`
- Main player controller.
- Uses `Rigidbody2D`.
- Handles movement, aim, shooting cadence, bullet prefab resolution, recoil, and muzzle pulse.
- Uses Input System when enabled and a legacy-style fallback block otherwise.
- Resolves the bullet prefab through `Resources.Load` and then loaded project prefabs.

## `Assets/Scripts/TopDownCameraFollow.cs`
- Simple follow camera behavior using `LateUpdate()`.
- Follows a target transform with smoothing and z-offset.

## `Assets/Scripts/TopDownPlayerLightController.cs`
- Optional utility that instantiates a light/glow prefab on start.

## `Assets/Scripts/TopDownShooterSetup.cs`
- Editor/runtime scene bootstrap helper.
- Ensures basic arena objects, player, walls, dummy target, light, and camera exist.
- Creates procedural square and circle sprites in code.
- Sets up `TopDownCameraFollow` on the main camera.

## Known Issues
- `ScreenShakeService` may ignore the `duration` parameter depending on current source.
- `ScreenShakeProfile` exists, but the current shake service does not appear to use it in the active code path.
- Procedural dungeon geometry is runtime-generated and intentionally not saved as scene child objects.

## Minimal-Fix Guidance
- For roguelike generation bugs, read `ArenaCombatGameManager.cs`, `RoguelikeDungeonGenerator.cs`, and `RoguelikeRoomTrigger.cs` first.
- For room encounter bugs, inspect Play Mode runtime state for `Generated Roguelike Dungeon`, `RoomTrigger`, `activeRoomIndex`, and spawned enemy instances.
- For enemy damage or bullet hit bugs, read `ArenaCombatEnemy.cs`, `TopDownBullet.cs`, and `BulletImpactParticles.cs`.
- For screen shake not firing, prefer patching `ScreenShakeService` lookup first.
- Preserve existing public APIs where possible. If fixing compile issues around death/game-over, keep `ArenaCombatGameManager.PlayerDied()` and `Lose()` available.
- For particles, impulse particles, muzzle flashes, impact bursts, ambient particles, and similar VFX, always use Unity `ParticleSystem` unless the user explicitly specifies otherwise.
- Short-lived VFX must be prefab GameObjects instantiated at the use-site and destroyed after the particle animation. Long-lived scene VFX should be separate scene GameObjects, not components hidden on unrelated gameplay objects.

## First Files To Read For Common Requests
- Roguelike generation or room progression:
  `Assets/Scripts/ArenaCombatGameManager.cs`
  `Assets/Scripts/RoguelikeDungeonGenerator.cs`
  `Assets/Scripts/RoguelikeRoomTrigger.cs`
- Enemy damage or bullet hit bugs:
  `Assets/Scripts/ArenaCombatEnemy.cs`
  `Assets/Scripts/TopDownBullet.cs`
  `Assets/Scripts/BulletImpactParticles.cs`
- Screen shake not firing:
  `Assets/Scripts/ScreenShakeService.cs`
  `Assets/Scripts/TopDownCameraShake.cs`
  `Assets/Scripts/CameraTargetShake.cs`
- Player shooting or movement:
  `Assets/Scripts/TopDownPlayerController.cs`
