# GAME_DESIGN

## Current Prototype Direction
- Top-down action prototype
- Fast iteration over movement, combat feel, encounter setup, and readability

## V1 Agent Priorities
- Repair compile/runtime issues autonomously
- Author and wire scene content semantically
- Run a minimal smoke playtest and capture evidence

## Evaluation Focus
- Player can move and act
- Encounter state is reachable and understandable
- Camera/render state matches the authored setup
- No hidden validation regressions in touched scenes
