# UNITY_AGENT

## Project
- Unity version: `6000.3.6f1`
- Render pipeline: `URP`
- Input: `Input System package installed`
- Primary current prototype: 2D/top-down workflow

## Architecture
- Keep orchestration outside Unity when possible.
- Treat Unity as the authoritative source for scene, asset, and play mode state.
- Use semantic editor/runtime APIs before generated editor scripts.
- Generated editor scripts belong under `Assets/Editor` and are an escape hatch, not the default path.

## Scene and Asset Rules
- Prefer editing through typed bridge commands rather than ad hoc menu automation.
- Use `GlobalObjectId` for persisted Unity object identity when storing references outside the editor session.
- Save scenes and assets only after validation succeeds.

## Verification
- After non-trivial scene edits, run scene validation.
- After visual/render changes, capture the actual Game view.
- After code changes, wait for compile diagnostics before declaring success.

## Safety
- Package changes, project settings changes, destructive deletes, and arbitrary editor method invocation are approval-gated operations.
- Bridge clients should send `expected_revision` for mutating commands when coordinating multi-step edits.
