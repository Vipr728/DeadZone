# Ark

## Project

- Unity version: `6000.3.6f1`
- Render pipeline: `URP`
- Input: `Input System`
- Current prototype direction: 2D / top-down gameplay

## Skill routing

- Use the `ark` skill for work in this repo involving Unity scenes, prefabs, assets, gameplay scripts, Play Mode, the Unity bridge, `mcp/unity-mcp-server.js`, `AgentDaemon`, or `ControlPlane`.
- The skill lives at `.codex/skills/agentic-gamedev/SKILL.md`.
- Use the gstack `/browse` skill for all web browsing. Do not use Chrome MCP browser tools directly.

## Repo instructions

- Treat Unity as the authoritative source for scene state, asset wiring, selection, and Play Mode state.
- Keep orchestration outside Unity when possible.
- Prefer typed bridge commands and direct project reads over ad hoc menu automation.
- Generated editor scripts belong under `Assets/Editor` and are an escape hatch, not the default path.
- Prefer semantic editor/runtime actions before custom Editor automation.

## Mutation ownership

- The supervising coding assistant may directly edit only Ark infrastructure: `AgentDaemon/`, `Packages/com.ark.agentic-gamedev/`, `mcp/`, `Agent/`, Ark-specific documentation/configuration, and this instruction file.
- User game content—including gameplay scripts, scenes, prefabs, art, and other project assets—must be created or changed by the configured OpenClaw `ark-unity` agent through AgentDaemon and Ark’s Unity tools.
- To implement or verify a game-content request, dispatch the request to AgentDaemon and monitor the resulting run. Do not replace the agent by applying direct filesystem patches or direct Unity mutations from the supervising assistant.
- The supervising assistant may inspect game content and live Unity state read-only to diagnose Ark itself.

## Unity workflow

- For scene, prefab, and asset work, prefer the Unity bridge and semantic actions over guessing serialized fields.
- For code-driven behavior, read the relevant scripts and linked prefabs/assets before changing code.
- For runtime-only bugs or behaviors, inspect live Unity state in Play Mode instead of reasoning from source alone.
- Use `GlobalObjectId` for persisted Unity object identity when storing references across editor sessions.
- Save scenes and assets only after validation succeeds.

## Unity API verification

When the task involves Unity/package APIs, compiler errors, missing members, read-only properties, ambiguous overloads, serialized fields, Inspector labels, or Editor utilities:

1. Read the exact compiler diagnostic or request carefully.
2. Identify the exact type and member names involved.
3. Search installed Unity/package API source.
4. Read the returned source file.
5. Use only members that are actually public and assignable in the installed source.
6. Patch the code.
7. Let Unity compile.
8. Read compiler diagnostics.
9. Repeat until diagnostics are clean for editable files.

Do not trust guessed member names, Inspector labels, serialized field names, or changelog wording as proof of public API.

Primary reference: `Assets/Docs/Unity/ApiVerification.md`

## Verification

- After non-trivial scene edits, run scene validation.
- After structural scene changes, treat validation as required before claiming success.
- After visual or render changes, capture the actual Game view.
- After gameplay or runtime behavior changes, run a smoke Play Mode verification.
- After code changes, wait for compile diagnostics before declaring success.
- Compile diagnostics are blocking.

## Safety

- Package changes are approval-gated.
- Project settings changes are approval-gated.
- Destructive deletes are approval-gated.
- Arbitrary editor method invocation is approval-gated.
- If a safer direct bridge action exists, use it instead of custom Editor scripting.
- Bridge clients coordinating multi-step mutating edits should send `expected_revision` when supported.

## Key docs

- `Agent/UNITY_AGENT.md`
- `Agent/TECHNICAL_ARCHITECTURE.md`
- `mcp/README.md`
- `Assets/Docs/Unity/ApiVerification.md`
