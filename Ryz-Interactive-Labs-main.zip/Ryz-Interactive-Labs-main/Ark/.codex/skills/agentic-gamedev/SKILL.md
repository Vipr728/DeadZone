---
name: ark
description: Work on the Ark Unity package using its local bridge, docs, and verification workflow. Use this whenever the user asks to change Unity scenes, prefabs, assets, scripts, play mode behavior, the Unity MCP bridge, the local runner, or the control plane in this repo, even if they do not explicitly mention the skill.
---

# Ark

Use this skill for work inside the `AgenticGamedev` repository. Ark is a Unity 6 URP agentic game-development package with a local editor bridge and an MCP server under `mcp/`.

## Read first

Before substantial work, read the project docs that match the task:

- `Agent/UNITY_AGENT.md` for project-wide Unity rules and verification requirements.
- `Agent/TECHNICAL_ARCHITECTURE.md` for bridge, runner, and control-plane responsibilities.
- `mcp/README.md` for the Unity MCP server and available bridge tools.
- `Assets/Docs/Unity/ApiVerification.md` when the task touches Unity/package APIs, compiler errors, missing members, or Editor utility code.

Do not assume stale memory is correct when the live Unity state or project source can be read directly.

## Core operating model

Follow these defaults:

1. Treat Unity as the source of truth for scene state, asset wiring, selection, play mode state, and validation.
2. Keep orchestration outside Unity when possible.
3. Prefer typed bridge actions and direct project reads over ad hoc menu automation or one-off editor scripts.
4. Use generated editor scripts under `Assets/Editor` only as an escape hatch for UnityEditor areas not covered by the bridge.
5. Save scenes and assets only after validation succeeds.

## Task flow

Start with the lightest path that can prove the answer.

### For investigation or bug fixing

1. Read the relevant local source files first.
2. If the task depends on current Unity state, inspect bridge context or scene state before proposing a fix.
3. If runtime-only behavior matters, enter Play Mode, inspect runtime state, capture the Game view if visuals matter, then exit Play Mode.
4. If code changes are required, patch the code, let Unity compile, and read compiler diagnostics before declaring success.

### For scene, prefab, or asset changes

1. Prefer bridge actions that create or mutate objects, components, properties, scenes, and assets directly.
2. For composite Unity workflows, prefer the semantic bridge workflows before guessing raw serialized property paths.
3. Validate the scene after structural edits.
4. Capture the Game view after visual, lighting, camera, or rendering changes.
5. Save only after validation passes.

### For code changes

1. Read the relevant script, prefab, and any linked runtime setup code before editing.
2. If the API shape is uncertain, follow the API verification loop below before writing code.
3. After edits, let Unity compile and read diagnostics.
4. If the change affects gameplay or visuals, run the matching Play Mode or Game view verification loop.

## Unity API verification loop

Use this whenever a task involves Unity/package APIs, compiler errors, missing members, read-only properties, ambiguous overloads, serialized fields, Inspector labels, or Editor utilities.

1. Identify the exact type and member names involved.
2. Search installed Unity/package API source for those names.
3. Read the returned source file.
4. Use only members that are actually public and assignable in the installed source.
5. Patch the code.
6. Let Unity compile.
7. Read compiler diagnostics.
8. Repeat until diagnostics are clean for editable files.

Do not trust Inspector labels, serialized field names, changelog wording, or guessed member casing as proof of public API.

## Safety and escalation

Treat these as higher-risk operations that need explicit user intent:

- Package changes
- Project settings changes
- Destructive deletes
- Arbitrary editor method invocation

If a safer direct bridge action exists, use it instead of custom Editor automation.

## Completion bar

Do not claim completion until the task-specific verification is done:

- Scene or hierarchy changes: validation completed
- Visual or render changes: Game view captured or equivalent visual proof collected
- Code changes: Unity compile diagnostics checked
- Runtime behavior changes: Play Mode reproduction or smoke verification completed

When reporting back, include what changed, how it was verified, and any remaining gaps.
