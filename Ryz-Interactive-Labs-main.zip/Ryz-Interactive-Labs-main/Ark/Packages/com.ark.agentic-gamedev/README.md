# Ark Agentic Gamedev

Ark is a Unity editor package for OpenClaw-powered game-development workflows.

## Contents

- `Editor/`: Ark chat UI, Unity bridge, project-memory stores, compiler diagnostics, and editor actions.
- `Runtime/`: lightweight runtime contracts for projects that expose custom agent actions or state.

## Local Backend

The Unity package is only the editor UI and Unity command surface. OpenClaw owns the scripting/model loop outside Unity; `AgentDaemon` is the compatibility adapter for the existing Unity API.

Default local endpoints:

- Ark daemon: `http://127.0.0.1:47391`
- Unity bridge: `http://127.0.0.1:47392`

Start the local backend from the repository root:

```bash
cd AgentDaemon
npm run setup:openclaw
npm run server
```

Then open Unity:

```text
Tools > Ark
```

## Packaging Notes

This is currently an embedded development package under `Packages/com.ark.agentic-gamedev`.

Project gameplay assets, generated sprites, prefabs, scenes, and prototype scripts intentionally remain outside the package under `Assets/`.
