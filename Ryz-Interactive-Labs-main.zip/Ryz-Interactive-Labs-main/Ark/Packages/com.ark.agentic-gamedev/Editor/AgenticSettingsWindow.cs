using UnityEditor;
using UnityEngine;

namespace AgenticGamedev.EditorTools
{
    internal sealed class AgenticSettingsWindow : EditorWindow
    {
        private string endpoint;
        private string apiKey;
        private string tavilyApiKey;
        private string model;
        private bool showApiKey;
        private bool showTavilyApiKey;
        private bool autoRunActions;
        private bool developerMode;

        [MenuItem("Tools/Ark/Agent Backend/Settings")]
        public static void Open()
        {
            AgenticSettingsWindow window = GetWindow<AgenticSettingsWindow>(true, "Ark Settings");
            window.minSize = new Vector2(540f, 390f);
            window.LoadValues();
            window.Show();
        }

        private void OnEnable()
        {
            LoadValues();
        }

        private void OnGUI()
        {
            EditorGUILayout.Space(10f);
            EditorGUILayout.LabelField("Agent Backend", EditorStyles.boldLabel);
            EditorGUILayout.Space(4f);

            model = EditorGUILayout.TextField("OpenAI Model", model);
            endpoint = EditorGUILayout.TextField("Endpoint", endpoint);

            EditorGUILayout.BeginHorizontal();
            if (showApiKey)
            {
                apiKey = EditorGUILayout.TextField("OpenAI API Key", apiKey);
            }
            else
            {
                apiKey = EditorGUILayout.PasswordField("OpenAI API Key", apiKey);
            }

            showApiKey = GUILayout.Toggle(showApiKey, "Show", EditorStyles.miniButton, GUILayout.Width(54f));
            EditorGUILayout.EndHorizontal();

            EditorGUILayout.BeginHorizontal();
            if (showTavilyApiKey)
            {
                tavilyApiKey = EditorGUILayout.TextField("Tavily API Key", tavilyApiKey);
            }
            else
            {
                tavilyApiKey = EditorGUILayout.PasswordField("Tavily API Key", tavilyApiKey);
            }

            showTavilyApiKey = GUILayout.Toggle(showTavilyApiKey, "Show", EditorStyles.miniButton, GUILayout.Width(54f));
            EditorGUILayout.EndHorizontal();

            EditorGUILayout.HelpBox("Unity is only the Ark chat UI and Unity-command executor. Backend scripting agents run outside Unity through AgentDaemon or another compatible backend.", MessageType.Info);
            EditorGUILayout.HelpBox($"Leave Endpoint blank to use the local backend: {AgenticAgentBridge.DefaultEndpoint}. Use Start Local Daemon to launch it for the currently open Unity project.", MessageType.None);
            EditorGUILayout.HelpBox("API keys are stored in Unity EditorPrefs only so Unity can forward them to the backend request. Prefer configuring keys in the backend process environment.", MessageType.None);

            EditorGUILayout.Space(8f);
            EditorGUILayout.LabelField("Local Daemon", EditorStyles.boldLabel);
            EditorGUILayout.BeginHorizontal();
            if (GUILayout.Button("Start Local Daemon", GUILayout.Height(28f)))
            {
                SaveValues();
                AgenticAgentDaemonLauncher.StartLocalDaemon(showDialog: true);
                endpoint = AgenticAgentBridge.DefaultEndpoint;
            }

            if (GUILayout.Button("Check", GUILayout.Height(28f), GUILayout.Width(72f)))
            {
                AgenticAgentDaemonLauncher.CheckLocalDaemonFromMenu();
            }

            if (GUILayout.Button("Stop", GUILayout.Height(28f), GUILayout.Width(72f)))
            {
                AgenticAgentDaemonLauncher.StopLaunchedDaemon(showDialog: true);
            }
            EditorGUILayout.EndHorizontal();

            EditorGUILayout.Space(8f);
            autoRunActions = EditorGUILayout.ToggleLeft("Run Unity actions without asking for approval", autoRunActions);
            if (autoRunActions)
            {
                EditorGUILayout.HelpBox("When enabled, executable actions returned by the LLM run immediately. Keep this off if you want to review scene, asset, and code changes first.", MessageType.Warning);
            }

            EditorGUILayout.Space(8f);
            developerMode = EditorGUILayout.ToggleLeft("Developer Mode", developerMode);
            if (developerMode)
            {
                EditorGUILayout.HelpBox("Shows task plans, context checked, validation details, and remaining issues in final agent responses. When off, the agent still uses those internally but keeps responses concise.", MessageType.Info);
            }

            EditorGUILayout.Space(8f);
            EditorGUILayout.BeginHorizontal();
            if (GUILayout.Button("Save", GUILayout.Height(28f)))
            {
                SaveValues();
                Close();
            }

            if (GUILayout.Button("Use Local Endpoint", GUILayout.Height(28f)))
            {
                endpoint = AgenticAgentBridge.DefaultEndpoint;
            }

            if (GUILayout.Button("Clear Keys", GUILayout.Height(28f)))
            {
                apiKey = string.Empty;
                tavilyApiKey = string.Empty;
                AgenticAgentBridge.ClearApiKey();
                AgenticAgentBridge.ClearTavilyApiKey();
            }
            EditorGUILayout.EndHorizontal();
        }

        private void LoadValues()
        {
            endpoint = AgenticAgentBridge.GetConfiguredEndpoint();
            if (string.IsNullOrWhiteSpace(endpoint))
            {
                endpoint = AgenticAgentBridge.DefaultEndpoint;
            }
            apiKey = AgenticAgentBridge.GetConfiguredApiKey();
            tavilyApiKey = AgenticAgentBridge.GetConfiguredTavilyApiKey();
            model = AgenticAgentBridge.GetConfiguredModel();
            autoRunActions = AgenticAgentBridge.GetAutoRunActions();
            developerMode = AgenticAgentBridge.GetDeveloperMode();
        }

        private void SaveValues()
        {
            AgenticAgentBridge.SetCustomEndpoint(string.IsNullOrWhiteSpace(endpoint)
                ? AgenticAgentBridge.DefaultEndpoint
                : endpoint);

            AgenticAgentBridge.SetApiKey(apiKey);
            AgenticAgentBridge.SetTavilyApiKey(tavilyApiKey);
            AgenticAgentBridge.SetModel(model);
            AgenticAgentBridge.SetAutoRunActions(autoRunActions);
            AgenticAgentBridge.SetDeveloperMode(developerMode);
        }
    }
}
