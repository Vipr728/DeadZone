using System;
using System.Collections.Generic;
using System.IO;
using System.Globalization;
using System.Net;
using System.Reflection;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading;
using UnityEditor.PackageManager;
using UnityEditor;
using UnityEditor.SceneManagement;
using UnityEditorInternal;
using UnityEngine;
using UnityEngine.Rendering;
#if ARK_HAS_URP
using UnityEngine.Rendering.Universal;
#endif
using UnityEngine.SceneManagement;
using UnityEngine.Tilemaps;
using Object = UnityEngine.Object;

namespace AgenticGamedev.EditorTools
{
    [InitializeOnLoad]
    internal static class AgenticAgentBridge
    {
        private const string EndpointPrefsKey = "AgenticGamedev.AgentEndpoint";
        private const string EndpointModePrefsKey = "AgenticGamedev.EndpointMode";
        private const string ApiKeyPrefsKey = "AgenticGamedev.ApiKey";
        private const string TavilyApiKeyPrefsKey = "AgenticGamedev.TavilyApiKey";
        private const string ModelPrefsKey = "AgenticGamedev.OpenAIModel";
        private const string AutoRunActionsPrefsKey = "AgenticGamedev.AutoRunActions";
        private const string DeveloperModePrefsKey = "AgenticGamedev.DeveloperMode";
        private const string PendingScriptAttachmentsPrefsKey = "AgenticGamedev.PendingScriptAttachments";
        private const int MaxPendingScriptAttachmentAttempts = 120;
        private const string CustomEndpointMode = "custom";
        private const string EndpointEnvironmentKey = "AGENTIC_UNITY_AGENT_ENDPOINT";
        private const string ApiKeyEnvironmentKey = "AGENTIC_UNITY_AGENT_API_KEY";
        private const string TavilyApiKeyEnvironmentKey = "AGENTIC_UNITY_TAVILY_API_KEY";
        private const string TavilyApiKeyEnvironmentKeyShort = "TAVILY_API_KEY";
        private const string ModelEnvironmentKey = "AGENTIC_UNITY_OPENAI_MODEL";
        private const string OpenAIChatCompletionsEndpoint = "https://api.openai.com/v1/chat/completions";
        private const string TavilySearchEndpoint = "https://api.tavily.com/search";
        private const int DiagnosticRenderWidth = 320;
        private const int DiagnosticRenderHeight = 180;
        private const int ResumableToolLoopVersion = 1;
        private const string AgentRoleManager = "manager";
        private const string AgentRoleDefault = "default";
        private const string AgentRoleWorker = "worker";
        private const string AgentRoleExplorer = "explorer";
        private const string AgentRoleMonitor = "monitor";
        private const string AgentRoleSceneSetup = "scene_setup";
        private const string AgentRoleAssetManagement = "asset_management";
        private const string HandoffToolName = "handoff_to_agent";
        private const int InstructionMemoryMaxChars = 7000;
        private const int InstructionMemoryMaxDirectiveCount = 80;
        private const int MaxActiveToolLoopMessageChars = 60000;
        private const int MaxActiveToolLoopMessagesBeforeCompaction = 20;
        private const int MaxToolResultMessageChars = 18000;
        private const int MaxUpdatedContextInToolResultChars = 5000;
        private const int MaxToolLoopRequestsPerRun = 16;
        private const double MaxToolLoopWallClockMinutes = 5d;
        private const int MaxStrictCompletionRetries = 8;
        private const int MaxStrictCompletionRetriesWithoutMutation = 4;
        private const int MaxStrictCompletionRecoveryEscalations = 2;
        private const int MaxRepeatedCompilerFailureBeforeFocusedRepairEscalation = 2;
        private const int MaxRepeatedCompilerFailureAutoContinuations = 3;
        private const int MaxFocusedRepairCodeWritesBeforeCleanCompile = 4;
        private const int MaxFocusedRepairRebuildsBeforeCleanCompile = 3;
        private const int MaxConsecutiveWritesToSamePathBeforeEvidenceReset = 3;
        private const int FocusedContextMaxProjectSearchesBeforeMutation = 2;
        private const int FocusedContextMaxTextReadsBeforeMutation = 5;
        private const int FocusedContextMaxDocsApiLookupsBeforeMutation = 2;
        private const int FocusedContextMaxWebSearchesBeforeMutation = 1;
        private const int OpenAIRequestTimeoutMs = 45000;
        private const int MaxPostJsonAttempts = 1;
        private const int MaxLocalDaemonStartAttempts = 20;
        private const int LocalDaemonStartRetryDelayMs = 250;
        private const int MaxTransientOpenAIRetries = 2;
        private const double MaxResumableToolLoopAgeHours = 6d;
        private const string FeatureCompletionInstruction =
            "Completion contract: for any feature/workflow request, do not stop after creating only a named container, root GameObject, empty asset, package, profile, controller, prefab, or placeholder component. A feature is complete only when the required linked resources and meaningful settings are also created/configured: component values, object references, profiles/sub-assets/overrides, controller states, input/action assets, materials/shaders, audio clips/mixers, render/camera/project settings, and validation. validate_scene checks relational wiring too: serialized references, important arrays, scene object name/tag/prefix lookup contracts, Resources fallbacks, package-backed scene dependencies, and cross-object system makeup must connect. Code that uses package or engine scene systems such as Cinemachine, URP volumes/post-processing, Animator controllers, Input System action assets, AudioMixers, NavMesh, Timeline, or physics triggers is not complete just because it compiles; the matching scene objects/components/assets/listeners/sources must exist and be wired. If validation reports empty or unassigned serialized references, missing matching scene objects/assets, missing profile overrides, unset prefab/controller/clip/material fields, missing package-backed components, or a lookup contract with no matching scene/project object, keep creating and assigning the required resources instead of treating the warning as a note. For prefab or asset component-value changes, use inspect_prefab or a direct asset read after editing to verify the actual value Unity will instantiate; validate_scene alone does not prove prefab color, scale, collider, script field, or renderer values changed. For runtime or gameplay requests, enter Play Mode when appropriate, inspect_runtime_state after Play Mode starts, capture the Game view for visible gameplay, exit Play Mode before finishing, and report runtime exceptions or missing observable behavior as blockers. For URP post-processing requests, completion requires a global Volume with an assigned VolumeProfile containing active requested overrides such as Bloom and Vignette, and an enabled camera with URP post-processing turned on. Prefer direct actions whenever the action schema covers the operation; for scene assets and Build Settings use create_scene/open_scene/save_scene and set_editor_build_scenes, not an Editor utility script. If direct actions cannot create or configure a required sub-resource or UnityEditor-only setting, write a scoped Editor utility under Assets/Editor, let it compile, then invoke it. Finish only after validate_scene and, for visual/render/camera/material/lighting/post-processing work, capture_game_view show the feature is actually wired.";
        private const string SceneFirstInstruction =
            "Scene-first contract: when a request explicitly requires new or changed scene objects, component references, prefabs, assets, UI, cameras, hierarchy, Build Settings, render-visible scene setup, or Play Mode proof, scene_setup or asset_management must establish that in-editor state before worker programming depends on it. Focused runtime/code requests for reusable methods, services, components, event hooks, or script-level behavior should go explorer/worker first unless source inspection proves a missing scene or asset reference blocks the implementation. Never treat a newly written script as proof that the live scene changed; verify the live scene or prefab directly when the requested outcome depends on scene or asset state.";
        private const string PlayableSceneSetupInstruction =
            "Playable scene setup contract: when the user asks to set up a gameplay scene, test room, encounter room, playable scene, or says the scene should include player, enemies, or rooms, baseline camera/light/root setup is not enough. Create and verify the concrete requested gameplay objects: a visible Player GameObject with collider/Rigidbody and available player combat components, room floor/bounds/walls or door blockers, spawn points named EnemySpawn_, at least one enemy prefab or live enemy GameObject wired to available enemy/health scripts, and room controller/spawner references. Save the scene after wiring. Before the final response, inspect scene roots, validate_scene, inspect_runtime_state, or capture_game_view and name the actual Player, room, spawn point, enemy, and controller objects observed. If any requested element is absent, report it as incomplete instead of claiming scene setup is done.";
        private const string EnemyArchetypeInstruction =
            "Enemy archetype fidelity contract: when a GDD, roadmap phase, or user prompt asks for enemy types, enemy archetypes, Stage 1 enemies, bosses, or named enemies, do not satisfy it with one generic chase-and-health enemy duplicated under different names. Each requested enemy type must have a distinct runtime behavior, data/profile, tuning, and verification tied to the design text. For Project Rock Stage 1, Lab Member/Intern, Janitor, Half-Rock Half-Human Mutation, Nerdy Short Intern, Ghost Rock, Police Guard, Nervous Tall Lab Intern, and Fat Manager must not all share the same controller: Janitor needs mop-radius pressure and cooldown breaks, Half-Rock needs faster chase/standoff rock shots with explosion chance, Nerdy Intern needs stationary bottle throws/effects, Ghost Rock needs swarm duplication/knockback wind, Police Guard needs patrol/vision/fire behavior, Nervous Tall Intern needs flee-and-random panic fire, and Fat Manager needs a two-phase weighted attack scheduler. If only a base enemy, spawner, or placeholder prefab exists, call it an enemy foundation, not completed enemy types.";
        private const string WorkingMemoryInstruction =
            "Working-memory contract: the pinned user instruction memory is authoritative for the whole run. Re-read it before every tool choice and final response. Specialist delegated tasks narrow the immediate work but never replace the original user request, constraints, verification requirements, or later follow-ups. If a later follow-up conflicts with an older instruction, follow the later instruction and preserve all non-conflicting requirements.";
        private const string SemanticWorkflowInstruction =
            "Semantic workflow contract: for connected Unity features, prefer semantic workflow actions over raw serialized-property guessing. Use ensure_unity_workflow, repair_scene_relationships, or setup_urp_post_processing for systems that require multiple linked objects/assets/references/settings. Low-level actions are escape hatches for precise edits, not the default path for composite workflows.";
        private const string PromptDepthInstruction =
            "Prompt-depth contract: scale interpretation effort to the request. literal mode means treat the request narrowly and do not invent broad surrounding work; expanded mode means infer obvious nearby prerequisites and validation; spec mode means first derive the real acceptance criteria, dependencies, missing prerequisites, and completion gates before acting. Do not over-plan trivial edits, and do not under-specify broad feature requests.";
        private const string ModularImplementationInstruction =
            "Modular implementation contract: every implementation should be reusable, scoped, and applicable beyond the immediate prompt. Inspect the existing source and extension points first, then add the smallest coherent module, data/profile object when tuning is useful, and one clear integration point. Prefer public methods, events, interfaces, or serialized configuration over hard-coded values in unrelated managers. Keep scene, asset, and runtime validation proportional to the requested operation; do not escalate focused code work into broad scene rebuilds or repeated Play Mode loops unless the user asks for an end-to-end feature or runtime smoke test.";
        private const string FocusedImplementationInstruction =
            "Focused implementation contract: for focused code requests that do not explicitly ask for scene layout, prefab creation, UI, asset setup, package setup, Play Mode proof, or full-game wiring, use the short path: one research pass when local docs/source do not outline the pattern, search/read the relevant project source, write the minimal reusable module or hook, rebuild, read compiler diagnostics, and stop with a concise result. Before the first write, keep context tight: at most two project searches, at most five text/source file reads, and no repeated reads of the same path/query. Keep one hypothesis per compile cycle: do not rewrite the same file with multiple alternative architectures, service shapes, or namespace/package strategies unless new local evidence forces the change. After the focused directive is complete, stop instead of expanding into adjacent cleanup work. If the written code uses a package-backed scene dependency such as Cinemachine impulse/camera components, URP Volume components, Animator controllers, Input System assets, AudioMixers, NavMesh agents/surfaces, or Timeline directors, immediately run validate_scene and use repair_scene_relationships or direct scene actions to add the required scene/package objects before finishing. Do not add task-plan churn, scene_setup, asset_management, repeated monitor checks, or strict completion recovery unless validation identifies a concrete missing scene/asset dependency.";
        private const string ImplementationResearchInstruction =
            "Implementation research contract: when the implementation approach remains uncertain after local inspection, architecture-sensitive, package-specific, or likely supported by an installed engine/package feature, research before writing. Start with local project source, search_unity_docs, and search_unity_api. Call Tavily-backed search_web only when the inspected local docs/source still do not outline the required implementation pattern, or when the agent would otherwise invent a custom architecture/algorithm/tooling workflow. Prefer official Unity/package docs, maintainer documentation, and reputable implementation references over tutorials. Do not use web search for narrow concrete edits, trivial value exposure, or when the inspected project source already shows the exact pattern to follow. If search_web is unavailable because Tavily is not configured, continue with the smallest local source-backed/compiler-validated implementation instead of blocking the task or guessing a broad architecture. Treat web results as advisory: current project source, installed package APIs, compiler diagnostics, and Unity validation override stale external guidance.";
        private const string ResponsivenessInstruction =
            "Responsiveness contract: finish the most valuable concrete change path quickly. Avoid broad exploratory loops, repeated validation with the same blocker, and status-only handoffs. Prefer semantic workflow tools for composite Unity work and make a direct mutating action as soon as enough context exists. If the remaining work is large, leave a concise checkpoint rather than trying to complete an unbounded multi-hour task in one prompt.";
        private const string TaskPlanningInstruction =
            "Task-DAG contract: for broad, multi-system, scene+asset, full-game, or explicitly end-to-end change requests, the Orchestrator should call set_task_plan before specialist handoffs. Do not create a task plan for narrow questions, focused code hooks, small component changes, simple value edits, or one-file repairs; those should use the focused implementation path. When a task plan is used, include concrete task ids, dependencies, assignees, acceptance criteria, and verification evidence required before completion. After each specialist result, call update_task_status for the relevant task before delegating the next task or finishing. Unfinished, failed, or blocked task-plan items are completion blockers.";
        private const string DocsFallbackInstruction =
            "Docs fallback contract: if the clear solution is not already present in current Unity context, inspected source, or prior tool results, search local Unity docs with search_unity_docs before answering, implementing, or writing an Editor utility. This searches project docs, package docs, package READMEs/changelogs, and curated local notes. For exact C# API names, members, overloads, accessors, or compiler errors, search installed package/source APIs with search_unity_api and read the returned source with read_unity_api or read_text_file before relying on it. This is required for uncertain Unity APIs, serialized property names, package-specific setup, physics behavior, post-processing, render pipeline settings, importers, build settings, animation, input, shaders, and editor automation. When those local docs and installed sources do not outline the implementation approach, call search_web before choosing or coding the approach.";
        private const string CompilerRepairInstruction =
            "Compiler repair contract: if Compiler diagnostics reports C# errors, script compilation failure, missing members, ambiguous types, read-only members, namespace/type resolution failures, assembly-reference failures, or an editor utility that is not available after a script write, treat that as blocking. Read the exact affected source file. For namespace/type or assembly-reference failures such as CS0246, inspect the failing source and gather local evidence before another rewrite: verify installed Unity/package APIs with search_unity_api and read_unity_api, and inspect relevant asmdef/asmref/package manifest files with search_project and read_text_file when assembly boundaries may be involved. For Unity/package API mismatches such as CS1061, CS0200, missing members, wrong casing, read-only properties, or ambiguous overloads, call search_unity_api with the exact type/member names, read the installed source that declares the type, and only write members that are public and assignable in that source. Do not infer public C# API from Inspector labels, serialized field names, changelogs, or memory. Choose one namespace/reference strategy from that local evidence, patch once, let Unity recompile, then use read_compiler_diagnostics and validation before finishing. Do not claim completion while compiler diagnostics still show unresolved errors.";
        private const string FinalResponseInstruction =
            "Final responses must be user-facing summaries, not raw model/tool transcripts. Do not paste full search results, docs, compiler logs, or file contents into the final message. Summarize the reasoning at a high level without hidden chain-of-thought, explain what was achieved, include validation results, mention remaining blockers plainly, and cite only the important files/docs inspected. When code was written, cite the file and describe the important snippet; the UI will also show captured snippets from write actions, compact references from read/search actions, and validation results.";

        public const string DefaultEndpoint = "http://127.0.0.1:47391/agent";
        public const string DefaultOpenAIModel = "gpt-5.5";

        private static bool pendingDeferredScriptRefresh;
        private static bool deferredScriptRefreshScheduled;

        static AgenticAgentBridge()
        {
            EditorApplication.delayCall += ApplyPendingScriptAttachments;
        }

        [MenuItem("Tools/Ark/Agent Backend/Use Local Endpoint")]
        private static void UseLocalEndpoint()
        {
            SetCustomEndpoint(DefaultEndpoint);
            Debug.Log($"Ark endpoint set to {DefaultEndpoint}");
        }

        [MenuItem("Tools/Ark/Agent Backend/Clear Endpoint")]
        private static void ClearEndpoint()
        {
            ClearConfiguredEndpoint();
            Debug.Log("Ark endpoint cleared.");
        }

        public static string GetConfiguredEndpoint()
        {
            return EditorPrefs.GetString(EndpointPrefsKey, string.Empty);
        }

        public static string GetEffectiveBackendEndpoint()
        {
            string endpoint = GetEndpoint();
            return string.IsNullOrWhiteSpace(endpoint) ? DefaultEndpoint : endpoint.Trim();
        }

        public static void SetEndpoint(string endpoint)
        {
            if (string.IsNullOrWhiteSpace(endpoint))
            {
                ClearConfiguredEndpoint();
                return;
            }

            endpoint = endpoint.Trim();
            EditorPrefs.SetString(EndpointPrefsKey, endpoint);
            if (string.Equals(endpoint.TrimEnd('/'), DefaultEndpoint.TrimEnd('/'), StringComparison.OrdinalIgnoreCase))
            {
                EditorPrefs.DeleteKey(EndpointModePrefsKey);
            }
            else
            {
                EditorPrefs.SetString(EndpointModePrefsKey, CustomEndpointMode);
            }
        }

        public static void SetCustomEndpoint(string endpoint)
        {
            if (string.IsNullOrWhiteSpace(endpoint))
            {
                ClearConfiguredEndpoint();
                return;
            }

            EditorPrefs.SetString(EndpointPrefsKey, endpoint.Trim());
            EditorPrefs.SetString(EndpointModePrefsKey, CustomEndpointMode);
        }

        public static void ClearConfiguredEndpoint()
        {
            EditorPrefs.DeleteKey(EndpointPrefsKey);
            EditorPrefs.DeleteKey(EndpointModePrefsKey);
        }

        public static string GetConfiguredApiKey()
        {
            return EditorPrefs.GetString(ApiKeyPrefsKey, string.Empty);
        }

        public static void SetApiKey(string apiKey)
        {
            if (string.IsNullOrWhiteSpace(apiKey))
            {
                ClearApiKey();
                return;
            }

            EditorPrefs.SetString(ApiKeyPrefsKey, apiKey.Trim());
        }

        public static void ClearApiKey()
        {
            EditorPrefs.DeleteKey(ApiKeyPrefsKey);
        }

        public static string GetConfiguredTavilyApiKey()
        {
            return EditorPrefs.GetString(TavilyApiKeyPrefsKey, string.Empty);
        }

        public static void SetTavilyApiKey(string apiKey)
        {
            if (string.IsNullOrWhiteSpace(apiKey))
            {
                ClearTavilyApiKey();
                return;
            }

            EditorPrefs.SetString(TavilyApiKeyPrefsKey, apiKey.Trim());
        }

        public static void ClearTavilyApiKey()
        {
            EditorPrefs.DeleteKey(TavilyApiKeyPrefsKey);
        }

        public static string GetConfiguredModel()
        {
            return EditorPrefs.GetString(ModelPrefsKey, DefaultOpenAIModel);
        }

        public static void SetModel(string model)
        {
            if (string.IsNullOrWhiteSpace(model))
            {
                EditorPrefs.DeleteKey(ModelPrefsKey);
                return;
            }

            EditorPrefs.SetString(ModelPrefsKey, model.Trim());
        }

        public static bool GetAutoRunActions()
        {
            return EditorPrefs.GetBool(AutoRunActionsPrefsKey, false);
        }

        public static void SetAutoRunActions(bool enabled)
        {
            EditorPrefs.SetBool(AutoRunActionsPrefsKey, enabled);
        }

        public static bool GetDeveloperMode()
        {
            return EditorPrefs.GetBool(DeveloperModePrefsKey, false);
        }

        public static void SetDeveloperMode(bool enabled)
        {
            EditorPrefs.SetBool(DeveloperModePrefsKey, enabled);
        }

        public static string GetConnectionModeLabel()
        {
            return "BACKEND";
        }

        public static bool IsCustomBackendConfigured()
        {
            return ShouldUseCustomBackend(GetEndpoint());
        }

        public static string GetActionSchemaForTools()
        {
            return GetActionSchema();
        }

        public static string ExecuteActionJson(string json)
        {
            return ExecuteResponseJson(json);
        }

        public static string PreviewActionJson(string json)
        {
            return PreviewResponseJson(json);
        }

        public static string ExecuteReadOnlyActionJson(string json)
        {
            return ExecuteReadOnlyResponseJson(json);
        }

        public sealed class PreparedRequest
        {
            public string DisplayName;
            public string Endpoint;
            public string RequestJson;
            public string ApiKey;
            public bool IncludeApiKeyHeader;
            public PreparedRequestKind Kind;
            public string OriginalPrompt;
        }

        [Serializable]
        internal sealed class BackendRunStatus
        {
            public bool ok;
            public string run_id;
            public string status;
            public string title;
            public string created_at;
            public string updated_at;
            public BackendRunEvent[] events;
            public BackendResponse result;
            public string error;

            public bool IsTerminal =>
                string.Equals(status, "complete", StringComparison.OrdinalIgnoreCase) ||
                string.Equals(status, "failed", StringComparison.OrdinalIgnoreCase) ||
                string.Equals(status, "canceled", StringComparison.OrdinalIgnoreCase);
        }

        [Serializable]
        internal sealed class BackendRunEvent
        {
            public int sequence;
            public string type;
            public string summary;
            public string timestamp;
            public BackendRunEventPayload payload;
        }

        [Serializable]
        internal sealed class BackendRunEventPayload
        {
            public string command;
            public string action_type;
            public int action_index;
            public string target;
            public string path;
            public string component;
            public string property;
            public int revision;
        }

        public enum PreparedRequestKind
        {
            BackendJson,
            OpenAIChat,
            OpenAIAnswer,
            OpenAIPlanReview,
            OpenAIApprovedExecution,
            OpenAIToolLoop
        }

        public sealed class PlanReviewResult
        {
            public string Prompt;
            public string Message;
            public string[] Plan;
            public string[] Progress;
            public string[] ActionSummaries;
            public int ProposedActionCount;
            public string ProposedActionJson;
            public bool IsValid;
            public string Error;

            public string ToApprovedPlanText()
            {
                StringBuilder builder = new StringBuilder();
                if (!string.IsNullOrWhiteSpace(Message))
                {
                    builder.AppendLine(Message.Trim());
                }

                AppendApprovedList(builder, "Plan", Plan);
                AppendApprovedList(builder, "Progress", Progress);
                return builder.ToString().Trim();
            }

            public string ToAnswerText()
            {
                StringBuilder builder = new StringBuilder();
                if (!string.IsNullOrWhiteSpace(Message))
                {
                    builder.AppendLine(Message.Trim());
                }

                AppendApprovedList(builder, "Plan", Plan);
                AppendApprovedList(builder, "Notes", Progress);
                string answer = builder.ToString().Trim();
                return string.IsNullOrWhiteSpace(answer) ? "The agent returned an empty response." : answer;
            }

            public static PlanReviewResult Failed(string prompt, string error)
            {
                return new PlanReviewResult
                {
                    Prompt = prompt,
                    Error = error,
                    IsValid = false
                };
            }

            private static void AppendApprovedList(StringBuilder builder, string title, string[] values)
            {
                if (values == null || values.Length == 0)
                {
                    return;
                }

                builder.AppendLine(title + ":");
                foreach (string value in values)
                {
                    if (!string.IsNullOrWhiteSpace(value))
                    {
                        builder.AppendLine("- " + value.Trim());
                    }
                }
            }
        }

        [Serializable]
        public sealed class AgentTaskRecord
        {
            public string id;
            public string title;
            public string description;
            public string assignee;
            public string status;
            public string verification;
            public string[] dependsOn;
            public string[] acceptanceCriteria;
            public long updatedAtUtcTicks;
        }

        public sealed class ToolLoopState
        {
            public string RunId;
            public string Prompt;
            public string ApiKey;
            public string Model;
            public string InstructionMemory;
            public string ActiveAgentRole = AgentRoleManager;
            public string PromptInterpretationMode = PromptInterpretationModeExpanded;
            public string PromptInterpretationSummary;
            public long StartedAtUtcTicks;
            public int RequestCount;
            public int AutomaticBudgetContinuationCount;
            public int AppliedActions;
            public int LoggedToolCalls;
            public int HandoffCount;
            public int StrictCompletionRetryCount;
            public int LastStrictGateAppliedActions;
            public int RepeatedStrictGateWithoutMutationCount;
            public int StrictCompletionRecoveryEscalationCount;
            public int ConsecutiveRequestFailureCount;
            public string FinalMessage;
            public string LastToolSignature;
            public int RepeatedToolCallCount;
            public string LastCompilerFailureSummary;
            public int RepeatedCompilerFailureCount;
            public bool CompilerFailureRepairEscalated;
            public int FocusedRepairCodeWriteCount;
            public int FocusedRepairRebuildCount;
            public string LastFocusedRepairWritePath;
            public int ConsecutiveWritesToSamePath;
            public string CachedToolLoopSelectionContext;
            public int CachedToolLoopSelectionHash;
            public string CachedToolLoopSceneRootContext;
            public string CachedToolLoopSceneRootKey;
            public string CachedToolLoopRuntimeInspectionContext;
            public string CachedToolLoopRuntimeInspectionKey;
            public string CachedToolLoopValidationSummary;
            public string CachedToolLoopValidationKey;
            public string CachedToolLoopGameViewContext;
            public string CachedToolLoopGameViewKey;
            public bool SceneOrAssetSetupCompleted;
            public bool ExternalImplementationResearchAttempted;
            public readonly List<string> ContextPolicyKeys = new List<string>();
            public readonly List<string> CompletedHandoffEntries = new List<string>();
            public readonly StringBuilder ActionLog = new StringBuilder();
            public readonly StringBuilder AgentLog = new StringBuilder();
            public readonly StringBuilder AchievementLog = new StringBuilder();
            public readonly StringBuilder ContextLog = new StringBuilder();
            public readonly StringBuilder CodeSnippetLog = new StringBuilder();
            public readonly StringBuilder ValidationLog = new StringBuilder();
            public readonly StringBuilder IssueLog = new StringBuilder();
            public readonly List<AgentTaskRecord> TaskPlan = new List<AgentTaskRecord>();
            public int CheckpointSequence;
            internal readonly List<OpenAIToolChatMessage> messages = new List<OpenAIToolChatMessage>();
            internal readonly Dictionary<string, List<OpenAIToolChatMessage>> specialistMessages = new Dictionary<string, List<OpenAIToolChatMessage>>();
            internal OpenAIToolCall pendingHandoffToolCall;
            internal string pendingHandoffRole;
            internal string pendingHandoffTask;

            internal ToolLoopState()
            {
            }
        }

        public sealed class ToolLoopTurnResult
        {
            public bool IsComplete;
            public string FinalResponse;
            public string ToolName;
            public string ToolResult;
            public string AgentRole;
            public bool ExecutedTool;
        }

        private const string PromptInterpretationModeLiteral = "literal";
        private const string PromptInterpretationModeExpanded = "expanded";
        private const string PromptInterpretationModeSpec = "spec";

        private readonly struct PromptInterpretation
        {
            public readonly string Mode;
            public readonly string Summary;

            public PromptInterpretation(string mode, string summary)
            {
                Mode = mode;
                Summary = summary;
            }
        }

        public static bool HasResumableToolLoopState()
        {
            string path = GetResumableToolLoopStorePath();
            if (!File.Exists(path))
            {
                return false;
            }

            if (!TryReadResumableSnapshot(path, out ResumableToolLoopState snapshot, out _))
            {
                ClearResumableToolLoopState();
                return false;
            }

            if (IsResumableSnapshotStale(snapshot))
            {
                ClearResumableToolLoopState();
                return false;
            }

            return true;
        }

        public static void SaveResumableToolLoopState(ToolLoopState state)
        {
            if (state == null)
            {
                return;
            }

            try
            {
                AgenticProjectMemoryStore.ObserveToolLoopState(state);
                string path = GetResumableToolLoopStorePath();
                Directory.CreateDirectory(Path.GetDirectoryName(path) ?? string.Empty);
                ResumableToolLoopState snapshot = CreateResumableSnapshot(state);
                SaveRunCheckpoint(state, snapshot);
                File.WriteAllText(path, JsonUtility.ToJson(snapshot, true), Encoding.UTF8);
            }
            catch (Exception exception)
            {
                Debug.LogWarning($"Could not save Agentic tool-loop resume state: {exception.Message}");
            }
        }

        public static bool TryLoadResumableToolLoopState(out ToolLoopState state, out string error)
        {
            state = null;
            error = string.Empty;
            string path = GetResumableToolLoopStorePath();
            if (!File.Exists(path))
            {
                error = "No resumable tool-loop state exists.";
                return false;
            }

            if (!HasApiKey())
            {
                error = "Cannot resume the agent because no OpenAI API key is configured.";
                return false;
            }

            try
            {
                if (!TryReadResumableSnapshot(path, out ResumableToolLoopState snapshot, out string readError))
                {
                    error = readError;
                    ClearResumableToolLoopState();
                    return false;
                }

                if (snapshot == null || snapshot.version != ResumableToolLoopVersion)
                {
                    error = "The saved agent resume state is missing or incompatible.";
                    ClearResumableToolLoopState();
                    return false;
                }

                if (IsResumableSnapshotStale(snapshot))
                {
                    error = "The saved agent resume state is stale, so it was discarded instead of auto-resuming.";
                    ClearResumableToolLoopState();
                    return false;
                }

                ToolLoopState restored = new ToolLoopState
                {
                    RunId = string.IsNullOrWhiteSpace(snapshot.runId) ? CreateRunId() : snapshot.runId,
                    Prompt = snapshot.prompt ?? string.Empty,
                    ApiKey = GetApiKey(),
                    Model = string.IsNullOrWhiteSpace(snapshot.model) ? GetModel() : snapshot.model,
                    InstructionMemory = string.IsNullOrWhiteSpace(snapshot.instructionMemory)
                        ? BuildInstructionMemory(snapshot.prompt ?? string.Empty)
                        : snapshot.instructionMemory,
                    ActiveAgentRole = string.IsNullOrWhiteSpace(snapshot.activeAgentRole) ? AgentRoleManager : snapshot.activeAgentRole,
                    PromptInterpretationMode = NormalizePromptInterpretationMode(snapshot.promptInterpretationMode),
                    PromptInterpretationSummary = snapshot.promptInterpretationSummary ?? string.Empty,
                    StartedAtUtcTicks = snapshot.startedAtUtcTicks == 0 ? DateTime.UtcNow.Ticks : snapshot.startedAtUtcTicks,
                    RequestCount = snapshot.requestCount,
                    AutomaticBudgetContinuationCount = snapshot.automaticBudgetContinuationCount,
                    AppliedActions = snapshot.appliedActions,
                    LoggedToolCalls = snapshot.loggedToolCalls,
                    HandoffCount = snapshot.handoffCount,
                    StrictCompletionRetryCount = snapshot.strictCompletionRetryCount,
                    LastStrictGateAppliedActions = snapshot.lastStrictGateAppliedActions,
                    RepeatedStrictGateWithoutMutationCount = snapshot.repeatedStrictGateWithoutMutationCount,
                    StrictCompletionRecoveryEscalationCount = snapshot.strictCompletionRecoveryEscalationCount,
                    ConsecutiveRequestFailureCount = snapshot.consecutiveRequestFailureCount,
                    CheckpointSequence = Math.Max(0, snapshot.checkpointSequence),
                    FinalMessage = snapshot.finalMessage,
                    LastToolSignature = snapshot.lastToolSignature,
                    RepeatedToolCallCount = snapshot.repeatedToolCallCount,
                    LastCompilerFailureSummary = snapshot.lastCompilerFailureSummary ?? string.Empty,
                    RepeatedCompilerFailureCount = snapshot.repeatedCompilerFailureCount,
                    CompilerFailureRepairEscalated = snapshot.compilerFailureRepairEscalated,
                    FocusedRepairCodeWriteCount = snapshot.focusedRepairCodeWriteCount,
                    FocusedRepairRebuildCount = snapshot.focusedRepairRebuildCount,
                    LastFocusedRepairWritePath = snapshot.lastFocusedRepairWritePath ?? string.Empty,
                    ConsecutiveWritesToSamePath = snapshot.consecutiveWritesToSamePath,
                    SceneOrAssetSetupCompleted = snapshot.sceneOrAssetSetupCompleted,
                    ExternalImplementationResearchAttempted = snapshot.externalImplementationResearchAttempted
                };

                restored.ActionLog.Append(snapshot.actionLog ?? string.Empty);
                restored.AgentLog.Append(snapshot.agentLog ?? string.Empty);
                restored.AchievementLog.Append(snapshot.achievementLog ?? string.Empty);
                restored.ContextLog.Append(snapshot.contextLog ?? string.Empty);
                restored.CodeSnippetLog.Append(snapshot.codeSnippetLog ?? string.Empty);
                restored.ValidationLog.Append(snapshot.validationLog ?? string.Empty);
                restored.IssueLog.Append(snapshot.issueLog ?? string.Empty);
                if (!restored.ExternalImplementationResearchAttempted)
                {
                    restored.ExternalImplementationResearchAttempted = ToolLogContains(restored.ActionLog, "search_web");
                }
                if (snapshot.taskPlan != null)
                {
                    foreach (AgentTaskRecord task in snapshot.taskPlan)
                    {
                        if (task != null)
                        {
                            restored.TaskPlan.Add(CloneTaskRecord(task));
                        }
                    }
                }

                if (snapshot.contextPolicyKeys != null)
                {
                    foreach (string key in snapshot.contextPolicyKeys)
                    {
                        if (!string.IsNullOrWhiteSpace(key) &&
                            !restored.ContextPolicyKeys.Contains(key))
                        {
                            restored.ContextPolicyKeys.Add(key);
                        }
                    }
                }

                if (snapshot.completedHandoffEntries != null)
                {
                    foreach (string entry in snapshot.completedHandoffEntries)
                    {
                        if (!string.IsNullOrWhiteSpace(entry) &&
                            !restored.CompletedHandoffEntries.Contains(entry))
                        {
                            restored.CompletedHandoffEntries.Add(entry);
                        }
                    }
                }

                if (snapshot.messages != null)
                {
                    restored.messages.AddRange(snapshot.messages);
                }

                if (snapshot.specialistConversations != null)
                {
                    foreach (ResumableSpecialistConversation conversation in snapshot.specialistConversations)
                    {
                        if (conversation == null || string.IsNullOrWhiteSpace(conversation.role))
                        {
                            continue;
                        }

                        restored.specialistMessages[NormalizeAgentRole(conversation.role)] =
                            conversation.messages == null
                                ? new List<OpenAIToolChatMessage>()
                                : new List<OpenAIToolChatMessage>(conversation.messages);
                    }
                }

                restored.pendingHandoffToolCall = snapshot.pendingHandoffToolCall;
                restored.pendingHandoffRole = snapshot.pendingHandoffRole;
                restored.pendingHandoffTask = snapshot.pendingHandoffTask;

                if (restored.messages.Count == 0)
                {
                    error = "The saved agent resume state has no manager message history.";
                    return false;
                }

                state = restored;
                return true;
            }
            catch (Exception exception)
            {
                error = exception.Message;
                return false;
            }
        }

        public static void ClearResumableToolLoopState()
        {
            try
            {
                string path = GetResumableToolLoopStorePath();
                if (File.Exists(path))
                {
                    File.Delete(path);
                }
            }
            catch (Exception exception)
            {
                Debug.LogWarning($"Could not clear Agentic tool-loop resume state: {exception.Message}");
            }
        }

        public static bool IsScriptRefreshOrCompilationPending()
        {
            if (pendingDeferredScriptRefresh && !deferredScriptRefreshScheduled)
            {
                ScheduleDeferredScriptRefresh();
            }

            return pendingDeferredScriptRefresh || EditorApplication.isCompiling || EditorApplication.isUpdating;
        }

        public static bool TryInjectCompilerFailureObservation(ToolLoopState state, out string summary)
        {
            summary = string.Empty;
            if (state == null)
            {
                return false;
            }

            string diagnostics = ReadRecentCompilerDiagnostics(60, 12000, out string logPath);
            if (string.IsNullOrWhiteSpace(diagnostics))
            {
                return false;
            }

            string compilerSummary = SummarizeCompilerDiagnostics(
                "Compiler diagnostics\nSource: " + logPath + "\n" + diagnostics,
                out bool hasCompilerError);
            if (!hasCompilerError)
            {
                ResetCompilerFailureTracking(state);
                return false;
            }

            pendingDeferredScriptRefresh = false;
            deferredScriptRefreshScheduled = false;
            bool repeated = string.Equals(
                state.LastCompilerFailureSummary,
                compilerSummary,
                StringComparison.Ordinal);
            if (repeated)
            {
                state.RepeatedCompilerFailureCount++;
            }
            else
            {
                state.LastCompilerFailureSummary = compilerSummary;
                state.RepeatedCompilerFailureCount = 1;
                state.CompilerFailureRepairEscalated = false;
            }

            summary = state.RepeatedCompilerFailureCount >= MaxRepeatedCompilerFailureBeforeFocusedRepairEscalation
                ? $"{compilerSummary} (repeated {state.RepeatedCompilerFailureCount} times)"
                : compilerSummary;

            string observation =
                "Unity script compilation failed, so no script reload will complete until the compiler errors are repaired. " +
                "Do not keep waiting for compilation. Read the affected source, patch the error, rebuild, then read_compiler_diagnostics.\n\n" +
                "Compiler diagnostics:\n" + diagnostics;
            bool shouldEscalateRepair =
                state.RepeatedCompilerFailureCount >= MaxRepeatedCompilerFailureBeforeFocusedRepairEscalation &&
                !state.CompilerFailureRepairEscalated;
            string repairEscalation =
                "Focused compiler repair required. The same compiler blocker has repeated without being resolved. " +
                "The next assistant response must do compiler repair only: read the affected source file named in the diagnostic, patch the missing type/member/API usage, rebuild once, then read_compiler_diagnostics once. " +
                "Do not do scene exploration, validation loops, or repeated rebuild/read_compiler_diagnostics cycles before making a concrete source edit.\n\n" +
                "Current compiler blocker:\n" + compilerSummary;

            List<OpenAIToolChatMessage> activeMessages = GetActiveToolLoopMessages(state);
            bool addedObservation = false;
            if (activeMessages != null && !HasRecentCompilerFailureObservation(activeMessages, compilerSummary))
            {
                activeMessages.Add(new OpenAIToolChatMessage
                {
                    role = "user",
                    content = observation
                });
                addedObservation = true;
            }

            if (activeMessages != null && shouldEscalateRepair)
            {
                activeMessages.Add(new OpenAIToolChatMessage
                {
                    role = "user",
                    content = repairEscalation
                });
                state.CompilerFailureRepairEscalated = true;
                addedObservation = true;
            }

            if (state.RepeatedCompilerFailureCount == 1 || shouldEscalateRepair || addedObservation)
            {
                AppendUserFacingLine(state.IssueLog, summary);
                AppendToolLogLine(
                    state.ActionLog,
                    ++state.LoggedToolCalls,
                    shouldEscalateRepair ? "compiler_guard_escalation" : "compiler_guard",
                    summary);
            }

            SaveResumableToolLoopState(state);
            return true;
        }

        public static bool TryGetRepeatedCompilerFailureStopMessage(ToolLoopState state, out string message)
        {
            message = string.Empty;
            if (state == null ||
                state.RepeatedCompilerFailureCount < MaxRepeatedCompilerFailureAutoContinuations ||
                string.IsNullOrWhiteSpace(state.LastCompilerFailureSummary))
            {
                return false;
            }

            message =
                "Stopped automatic compiler repair after the same compiler blocker repeated " +
                state.RepeatedCompilerFailureCount +
                " times without being resolved.\n\n" +
                state.LastCompilerFailureSummary +
                "\n\n" +
                "Next required action: read the affected source file, patch the missing symbol or API usage, rebuild once, then read compiler diagnostics again. " +
                "The run was stopped to avoid another unbounded loop on the Unity editor main thread.";
            return true;
        }

        private static void ResetCompilerFailureTracking(ToolLoopState state)
        {
            if (state == null)
            {
                return;
            }

            state.LastCompilerFailureSummary = string.Empty;
            state.RepeatedCompilerFailureCount = 0;
            state.CompilerFailureRepairEscalated = false;
            ResetFocusedRepairMutationBudget(state);
        }

        private static void ResetFocusedRepairMutationBudget(ToolLoopState state)
        {
            if (state == null)
            {
                return;
            }

            state.FocusedRepairCodeWriteCount = 0;
            state.FocusedRepairRebuildCount = 0;
            state.LastFocusedRepairWritePath = string.Empty;
            state.ConsecutiveWritesToSamePath = 0;
        }

        private static bool HasRecentCompilerFailureObservation(List<OpenAIToolChatMessage> messages, string compilerSummary)
        {
            if (messages == null || string.IsNullOrWhiteSpace(compilerSummary))
            {
                return false;
            }

            int first = Math.Max(0, messages.Count - 6);
            for (int i = first; i < messages.Count; i++)
            {
                string content = messages[i]?.content ?? string.Empty;
                if (content.IndexOf("Unity script compilation failed", StringComparison.OrdinalIgnoreCase) >= 0 &&
                    content.IndexOf(compilerSummary, StringComparison.OrdinalIgnoreCase) >= 0)
                {
                    return true;
                }
            }

            return false;
        }

        private static ResumableToolLoopState CreateResumableSnapshot(ToolLoopState state)
        {
            List<ResumableSpecialistConversation> specialistConversations = new List<ResumableSpecialistConversation>();
            foreach (KeyValuePair<string, List<OpenAIToolChatMessage>> pair in state.specialistMessages)
            {
                specialistConversations.Add(new ResumableSpecialistConversation
                {
                    role = pair.Key,
                    messages = pair.Value == null ? new OpenAIToolChatMessage[0] : pair.Value.ToArray()
                });
            }

            return new ResumableToolLoopState
            {
                version = ResumableToolLoopVersion,
                runId = string.IsNullOrWhiteSpace(state.RunId) ? CreateRunId() : state.RunId,
                prompt = state.Prompt,
                model = string.IsNullOrWhiteSpace(state.Model) ? DefaultOpenAIModel : state.Model,
                instructionMemory = string.IsNullOrWhiteSpace(state.InstructionMemory)
                    ? BuildInstructionMemory(state.Prompt)
                    : state.InstructionMemory,
                activeAgentRole = state.ActiveAgentRole,
                promptInterpretationMode = NormalizePromptInterpretationMode(state.PromptInterpretationMode),
                promptInterpretationSummary = state.PromptInterpretationSummary ?? string.Empty,
                startedAtUtcTicks = state.StartedAtUtcTicks == 0 ? DateTime.UtcNow.Ticks : state.StartedAtUtcTicks,
                requestCount = state.RequestCount,
                automaticBudgetContinuationCount = state.AutomaticBudgetContinuationCount,
                appliedActions = state.AppliedActions,
                loggedToolCalls = state.LoggedToolCalls,
                handoffCount = state.HandoffCount,
                strictCompletionRetryCount = state.StrictCompletionRetryCount,
                lastStrictGateAppliedActions = state.LastStrictGateAppliedActions,
                repeatedStrictGateWithoutMutationCount = state.RepeatedStrictGateWithoutMutationCount,
                strictCompletionRecoveryEscalationCount = state.StrictCompletionRecoveryEscalationCount,
                consecutiveRequestFailureCount = state.ConsecutiveRequestFailureCount,
                checkpointSequence = state.CheckpointSequence,
                finalMessage = state.FinalMessage,
                lastToolSignature = state.LastToolSignature,
                repeatedToolCallCount = state.RepeatedToolCallCount,
                lastCompilerFailureSummary = state.LastCompilerFailureSummary ?? string.Empty,
                repeatedCompilerFailureCount = state.RepeatedCompilerFailureCount,
                compilerFailureRepairEscalated = state.CompilerFailureRepairEscalated,
                focusedRepairCodeWriteCount = state.FocusedRepairCodeWriteCount,
                focusedRepairRebuildCount = state.FocusedRepairRebuildCount,
                lastFocusedRepairWritePath = state.LastFocusedRepairWritePath ?? string.Empty,
                consecutiveWritesToSamePath = state.ConsecutiveWritesToSamePath,
                sceneOrAssetSetupCompleted = state.SceneOrAssetSetupCompleted,
                externalImplementationResearchAttempted = state.ExternalImplementationResearchAttempted ||
                    ToolLogContains(state.ActionLog, "search_web"),
                actionLog = state.ActionLog.ToString(),
                agentLog = state.AgentLog.ToString(),
                achievementLog = state.AchievementLog.ToString(),
                contextLog = state.ContextLog.ToString(),
                codeSnippetLog = state.CodeSnippetLog.ToString(),
                validationLog = state.ValidationLog.ToString(),
                issueLog = state.IssueLog.ToString(),
                taskPlan = state.TaskPlan.ToArray(),
                contextPolicyKeys = state.ContextPolicyKeys.ToArray(),
                completedHandoffEntries = state.CompletedHandoffEntries.ToArray(),
                messages = state.messages.ToArray(),
                specialistConversations = specialistConversations.ToArray(),
                pendingHandoffToolCall = state.pendingHandoffToolCall,
                pendingHandoffRole = state.pendingHandoffRole,
                pendingHandoffTask = state.pendingHandoffTask,
                savedAtUtcTicks = DateTime.UtcNow.Ticks
            };
        }

        private static bool TryReadResumableSnapshot(string path, out ResumableToolLoopState snapshot, out string error)
        {
            snapshot = null;
            error = string.Empty;
            try
            {
                snapshot = JsonUtility.FromJson<ResumableToolLoopState>(File.ReadAllText(path, Encoding.UTF8));
                if (snapshot == null)
                {
                    error = "The saved agent resume state is empty.";
                    return false;
                }

                return true;
            }
            catch (Exception exception)
            {
                error = "Could not read saved agent resume state: " + exception.Message;
                return false;
            }
        }

        private static bool IsResumableSnapshotStale(ResumableToolLoopState snapshot)
        {
            if (snapshot == null || snapshot.savedAtUtcTicks <= 0)
            {
                return true;
            }

            TimeSpan age = DateTime.UtcNow - new DateTime(snapshot.savedAtUtcTicks, DateTimeKind.Utc);
            return age.TotalHours > MaxResumableToolLoopAgeHours;
        }

        private static string GetResumableToolLoopStorePath()
        {
            string projectRoot = Path.GetDirectoryName(Application.dataPath) ?? Directory.GetCurrentDirectory();
            return Path.Combine(projectRoot, "Library", "AgenticGamedev", "tool-loop-resume.json");
        }

        private static string CreateRunId()
        {
            return DateTime.UtcNow.ToString("yyyyMMdd-HHmmss", CultureInfo.InvariantCulture) + "-" +
                Guid.NewGuid().ToString("N").Substring(0, 8);
        }

        private static string GetRunCheckpointDirectory(string runId)
        {
            string projectRoot = Path.GetDirectoryName(Application.dataPath) ?? Directory.GetCurrentDirectory();
            string safeRunId = SanitizeFileName(string.IsNullOrWhiteSpace(runId) ? "run" : runId);
            return Path.Combine(projectRoot, "Library", "AgenticGamedev", "Runs", safeRunId);
        }

        private static void SaveRunCheckpoint(ToolLoopState state, ResumableToolLoopState snapshot)
        {
            if (state == null || snapshot == null)
            {
                return;
            }

            try
            {
                if (string.IsNullOrWhiteSpace(state.RunId))
                {
                    state.RunId = CreateRunId();
                    snapshot.runId = state.RunId;
                }

                state.CheckpointSequence++;
                snapshot.checkpointSequence = state.CheckpointSequence;
                string directory = GetRunCheckpointDirectory(state.RunId);
                Directory.CreateDirectory(directory);
                string json = JsonUtility.ToJson(snapshot, true);
                File.WriteAllText(Path.Combine(directory, "latest.json"), json, Encoding.UTF8);
                File.WriteAllText(Path.Combine(directory, $"checkpoint-{state.CheckpointSequence:0000}.json"), json, Encoding.UTF8);
            }
            catch (Exception exception)
            {
                Debug.LogWarning($"Could not save Agentic run checkpoint: {exception.Message}");
            }
        }

        private static AgentTaskRecord CloneTaskRecord(AgentTaskRecord source)
        {
            if (source == null)
            {
                return null;
            }

            return new AgentTaskRecord
            {
                id = source.id,
                title = source.title,
                description = source.description,
                assignee = source.assignee,
                status = NormalizeTaskStatus(source.status),
                verification = source.verification,
                dependsOn = source.dependsOn == null ? new string[0] : (string[])source.dependsOn.Clone(),
                acceptanceCriteria = source.acceptanceCriteria == null ? new string[0] : (string[])source.acceptanceCriteria.Clone(),
                updatedAtUtcTicks = source.updatedAtUtcTicks == 0 ? DateTime.UtcNow.Ticks : source.updatedAtUtcTicks
            };
        }

        private static string ExecuteTaskPlanAction(ToolLoopState state, AgentAction action)
        {
            string normalized = NormalizeActionType(action?.type);
            if (string.Equals(normalized, "set_task_plan", StringComparison.Ordinal))
            {
                return SetTaskPlan(state, action);
            }

            if (string.Equals(normalized, "update_task_status", StringComparison.Ordinal))
            {
                return UpdateTaskStatus(state, action);
            }

            return "unknown task-plan action";
        }

        private static bool IsTaskPlanAction(string actionType)
        {
            string normalized = NormalizeActionType(actionType);
            return string.Equals(normalized, "set_task_plan", StringComparison.Ordinal) ||
                string.Equals(normalized, "update_task_status", StringComparison.Ordinal);
        }

        private static bool TryDetectRepeatedToolCall(ToolLoopState state, OpenAIToolCall toolCall, out string message)
        {
            message = string.Empty;
            if (state == null || toolCall == null || toolCall.function == null)
            {
                return false;
            }

            string signature = NormalizeActionType(toolCall.function.name) + ":" + CompactToolArguments(toolCall.function.arguments);
            if (string.Equals(signature, state.LastToolSignature, StringComparison.Ordinal))
            {
                state.RepeatedToolCallCount++;
            }
            else
            {
                state.LastToolSignature = signature;
                state.RepeatedToolCallCount = 1;
            }

            if (state.RepeatedToolCallCount < 3)
            {
                return false;
            }

            message =
                $"Tool blocked: identical tool call repeated {state.RepeatedToolCallCount} times. " +
                "Inspect the previous tool result, choose a different action, or report the concrete blocker instead of repeating the same call.";
            return true;
        }

        private static string CompactToolArguments(string arguments)
        {
            if (string.IsNullOrWhiteSpace(arguments))
            {
                return "{}";
            }

            string compact = arguments.Replace("\r", " ").Replace("\n", " ").Trim();
            while (compact.IndexOf("  ", StringComparison.Ordinal) >= 0)
            {
                compact = compact.Replace("  ", " ");
            }

            return compact.Length <= 600 ? compact : compact.Substring(0, 600);
        }

        private static string SetTaskPlan(ToolLoopState state, AgentAction action)
        {
            if (state == null)
            {
                return "set_task_plan failed: no active tool-loop state";
            }

            AgentTaskRecord[] tasks = action?.tasks;
            if ((tasks == null || tasks.Length == 0) && !string.IsNullOrWhiteSpace(action?.content))
            {
                tasks = ParseTaskPlanFromContent(action.content);
            }

            if (tasks == null || tasks.Length == 0)
            {
                string title = FirstNonEmpty(action?.title, action?.name, action?.query, action?.content, "Complete request");
                tasks = new[]
                {
                    new AgentTaskRecord
                    {
                        id = FirstNonEmpty(action?.id, "task-1"),
                        title = title,
                        description = FirstNonEmpty(action?.description, action?.content, title),
                        assignee = NormalizeAgentRole(action?.assignee ?? action?.role),
                        status = "pending",
                        verification = action?.verification,
                        dependsOn = action?.dependsOn,
                        acceptanceCriteria = action?.acceptanceCriteria
                    }
                };
            }

            state.TaskPlan.Clear();
            int index = 1;
            foreach (AgentTaskRecord rawTask in tasks)
            {
                AgentTaskRecord task = CloneTaskRecord(rawTask);
                if (task == null)
                {
                    continue;
                }

                task.id = NormalizeTaskId(FirstNonEmpty(task.id, $"task-{index}"));
                task.title = FirstNonEmpty(task.title, task.description, task.id);
                task.description = FirstNonEmpty(task.description, task.title);
                task.assignee = NormalizeOptionalAgentRole(task.assignee);
                task.status = NormalizeTaskStatus(task.status);
                task.updatedAtUtcTicks = DateTime.UtcNow.Ticks;
                if (task.dependsOn == null)
                {
                    task.dependsOn = new string[0];
                }

                if (task.acceptanceCriteria == null)
                {
                    task.acceptanceCriteria = new string[0];
                }

                state.TaskPlan.Add(task);
                index++;
            }

            if (state.TaskPlan.Count == 0)
            {
                return "set_task_plan failed: no valid tasks were supplied";
            }

            return $"Task plan set: {state.TaskPlan.Count} task(s)\n{FormatTaskPlanForContext(state)}";
        }

        private static AgentTaskRecord[] ParseTaskPlanFromContent(string content)
        {
            if (string.IsNullOrWhiteSpace(content))
            {
                return new AgentTaskRecord[0];
            }

            try
            {
                string json = content.Trim();
                if (TryExtractJson(content, out string extractedJson))
                {
                    json = extractedJson;
                }

                if (json.StartsWith("[", StringComparison.Ordinal))
                {
                    json = "{\"tasks\":" + json + "}";
                }

                TaskPlanEnvelope envelope = JsonUtility.FromJson<TaskPlanEnvelope>(json);
                return envelope?.tasks ?? new AgentTaskRecord[0];
            }
            catch (Exception)
            {
                return new AgentTaskRecord[0];
            }
        }

        private static string UpdateTaskStatus(ToolLoopState state, AgentAction action)
        {
            if (state == null)
            {
                return "update_task_status failed: no active tool-loop state";
            }

            if (state.TaskPlan.Count == 0)
            {
                return "update_task_status failed: no task plan has been set";
            }

            string id = NormalizeTaskId(FirstNonEmpty(action?.id, action?.name, action?.target, action?.query));
            AgentTaskRecord task = FindTaskRecord(state, id);
            if (task == null)
            {
                return string.IsNullOrWhiteSpace(id)
                    ? "update_task_status failed: missing task id"
                    : $"update_task_status failed: task '{id}' was not found";
            }

            string previous = NormalizeTaskStatus(task.status);
            task.status = NormalizeTaskStatus(action?.status ?? action?.value);
            task.assignee = NormalizeOptionalAgentRole(FirstNonEmpty(action?.assignee, action?.role, task.assignee));
            task.verification = FirstNonEmpty(action?.verification, action?.content, task.verification);
            if (!string.IsNullOrWhiteSpace(action?.title))
            {
                task.title = action.title.Trim();
            }

            if (!string.IsNullOrWhiteSpace(action?.description))
            {
                task.description = action.description.Trim();
            }

            task.updatedAtUtcTicks = DateTime.UtcNow.Ticks;
            return $"Task {task.id} status changed {previous} -> {task.status}: {task.title}";
        }

        private static AgentTaskRecord FindTaskRecord(ToolLoopState state, string id)
        {
            if (state == null || string.IsNullOrWhiteSpace(id))
            {
                return null;
            }

            foreach (AgentTaskRecord task in state.TaskPlan)
            {
                if (task == null)
                {
                    continue;
                }

                if (string.Equals(NormalizeTaskId(task.id), id, StringComparison.OrdinalIgnoreCase))
                {
                    return task;
                }
            }

            return null;
        }

        private static string NormalizeTaskId(string id)
        {
            if (string.IsNullOrWhiteSpace(id))
            {
                return string.Empty;
            }

            string trimmed = id.Trim();
            StringBuilder builder = new StringBuilder(trimmed.Length);
            foreach (char character in trimmed)
            {
                if (char.IsLetterOrDigit(character) || character == '-' || character == '_' || character == '.')
                {
                    builder.Append(char.ToLowerInvariant(character));
                }
                else if (char.IsWhiteSpace(character))
                {
                    builder.Append('-');
                }
            }

            string normalized = builder.ToString().Trim('-');
            return string.IsNullOrWhiteSpace(normalized) ? trimmed : normalized;
        }

        private static string NormalizeTaskStatus(string status)
        {
            if (string.IsNullOrWhiteSpace(status))
            {
                return "pending";
            }

            switch (status.Trim().ToLowerInvariant().Replace(" ", "_").Replace("-", "_"))
            {
                case "done":
                case "complete":
                case "completed":
                case "passed":
                case "verified":
                    return "completed";
                case "doing":
                case "running":
                case "inprogress":
                case "in_progress":
                    return "in_progress";
                case "blocked":
                case "waiting":
                    return "blocked";
                case "failed":
                case "failure":
                case "error":
                    return "failed";
                case "skipped":
                case "skip":
                    return "skipped";
                case "pending":
                case "todo":
                default:
                    return "pending";
            }
        }

        private static string NormalizeOptionalAgentRole(string role)
        {
            if (string.IsNullOrWhiteSpace(role))
            {
                return string.Empty;
            }

            return NormalizeAgentRole(role);
        }

        private static bool IsTerminalTaskStatus(string status)
        {
            string normalized = NormalizeTaskStatus(status);
            return string.Equals(normalized, "completed", StringComparison.Ordinal) ||
                string.Equals(normalized, "skipped", StringComparison.Ordinal);
        }

        private static string FormatTaskPlanForContext(ToolLoopState state)
        {
            if (state == null || state.TaskPlan.Count == 0)
            {
                return "Task plan: none";
            }

            StringBuilder builder = new StringBuilder();
            builder.AppendLine("Task plan:");
            foreach (AgentTaskRecord task in state.TaskPlan)
            {
                if (task == null)
                {
                    continue;
                }

                builder.Append("- ");
                builder.Append(NormalizeTaskStatus(task.status));
                builder.Append(" ");
                builder.Append(string.IsNullOrWhiteSpace(task.id) ? "task" : task.id.Trim());
                builder.Append(": ");
                builder.Append(CompactOneLine(FirstNonEmpty(task.title, task.description), 140));
                if (!string.IsNullOrWhiteSpace(task.assignee))
                {
                    builder.Append(" [");
                    builder.Append(GetAgentDisplayName(task.assignee));
                    builder.Append("]");
                }

                if (task.dependsOn != null && task.dependsOn.Length > 0)
                {
                    builder.Append(" dependsOn=");
                    builder.Append(string.Join(",", task.dependsOn));
                }

                builder.AppendLine();

                if (task.acceptanceCriteria != null && task.acceptanceCriteria.Length > 0)
                {
                    int maxCriteria = Math.Min(task.acceptanceCriteria.Length, 4);
                    for (int i = 0; i < maxCriteria; i++)
                    {
                        if (!string.IsNullOrWhiteSpace(task.acceptanceCriteria[i]))
                        {
                            builder.AppendLine("  acceptance: " + CompactOneLine(task.acceptanceCriteria[i], 160));
                        }
                    }
                }

                if (!string.IsNullOrWhiteSpace(task.verification))
                {
                    builder.AppendLine("  verification: " + CompactOneLine(task.verification, 180));
                }
            }

            return builder.ToString().TrimEnd();
        }

        private static void AppendTaskPlanContext(StringBuilder builder, ToolLoopState state)
        {
            if (builder == null || state == null || state.TaskPlan.Count == 0)
            {
                return;
            }

            builder.AppendLine(FormatTaskPlanForContext(state));
            builder.AppendLine();
        }

        private static string GetInstructionMemoryForContext(ToolLoopState state, string currentPrompt)
        {
            if (state != null)
            {
                if (string.IsNullOrWhiteSpace(state.InstructionMemory))
                {
                    RefreshInstructionMemory(state);
                }

                if (!string.IsNullOrWhiteSpace(state.InstructionMemory))
                {
                    return state.InstructionMemory.Trim();
                }
            }

            return BuildInstructionMemory(currentPrompt);
        }

        private static void AppendInstructionMemoryContext(StringBuilder builder, ToolLoopState state, string currentPrompt)
        {
            if (builder == null)
            {
                return;
            }

            string memory = GetInstructionMemoryForContext(state, currentPrompt);
            if (string.IsNullOrWhiteSpace(memory))
            {
                return;
            }

            builder.AppendLine(memory);
            builder.AppendLine();
        }

        private static string BuildInstructionMemory(string prompt)
        {
            if (string.IsNullOrWhiteSpace(prompt))
            {
                return string.Empty;
            }

            string trimmedPrompt = prompt.Trim();
            StringBuilder builder = new StringBuilder();
            builder.AppendLine("Pinned user instruction memory:");
            builder.AppendLine("- priority: latest user follow-ups override older conflicting instructions; preserve every non-conflicting requirement.");
            builder.AppendLine("- scope: delegated specialist tasks narrow the next step only; they do not replace this source request.");
            builder.AppendLine("- completion: do not finish until these instructions and their verification gates are satisfied or a concrete external blocker is hit.");

            string[] directives = ExtractPromptInstructionLines(trimmedPrompt, InstructionMemoryMaxDirectiveCount);
            if (directives.Length > 0)
            {
                builder.AppendLine("- extracted requirements:");
                foreach (string directive in directives)
                {
                    builder.AppendLine("  - " + directive);
                }
            }

            string checklist = BuildRequestSpecificCompletionChecklist(trimmedPrompt);
            if (!string.IsNullOrWhiteSpace(checklist))
            {
                builder.AppendLine("- inferred acceptance checks:");
                foreach (string line in checklist.Replace("\r\n", "\n").Replace('\r', '\n').Split('\n'))
                {
                    string cleaned = CleanPromptInstructionLine(line);
                    if (!string.IsNullOrWhiteSpace(cleaned))
                    {
                        builder.AppendLine("  - " + cleaned);
                    }
                }
            }

            builder.AppendLine("- source request:");
            builder.AppendLine(IndentInstructionMemorySource(CompactInstructionMemorySource(trimmedPrompt)));

            string memory = builder.ToString().TrimEnd();
            if (memory.Length <= InstructionMemoryMaxChars)
            {
                return memory;
            }

            return memory.Substring(0, InstructionMemoryMaxChars - 96).TrimEnd() +
                "\n  ... source request compacted; extracted requirements above remain authoritative.";
        }

        private static string[] ExtractPromptInstructionLines(string prompt, int maxCount)
        {
            if (string.IsNullOrWhiteSpace(prompt) || maxCount <= 0)
            {
                return Array.Empty<string>();
            }

            List<string> lines = new List<string>();
            string[] rawLines = prompt.Replace("\r\n", "\n").Replace('\r', '\n').Split('\n');
            string activeHeading = string.Empty;
            foreach (string rawLine in rawLines)
            {
                string trimmed = (rawLine ?? string.Empty).Trim();
                if (string.IsNullOrWhiteSpace(trimmed))
                {
                    continue;
                }

                string cleaned = CleanPromptInstructionLine(trimmed);
                if (string.IsNullOrWhiteSpace(cleaned))
                {
                    continue;
                }

                if (LooksLikeInstructionHeading(cleaned))
                {
                    activeHeading = cleaned.TrimEnd(':');
                    continue;
                }

                bool include = !string.IsNullOrWhiteSpace(activeHeading) ||
                    IsPromptBulletLine(trimmed) ||
                    LooksLikeInstructionLine(cleaned);
                if (!include)
                {
                    continue;
                }

                string line = string.IsNullOrWhiteSpace(activeHeading)
                    ? cleaned
                    : $"{activeHeading}: {cleaned}";
                line = CompactOneLine(line, 240);
                if (!lines.Contains(line))
                {
                    lines.Add(line);
                }

                if (lines.Count >= maxCount)
                {
                    break;
                }
            }

            return lines.ToArray();
        }

        private static bool LooksLikeInstructionHeading(string line)
        {
            if (string.IsNullOrWhiteSpace(line) || !line.EndsWith(":", StringComparison.Ordinal))
            {
                return false;
            }

            string normalized = NormalizeIntentText(line);
            return ContainsAny(
                normalized,
                "goal", "goals", "constraint", "constraints", "verify", "verification",
                "requirements", "acceptance", "must", "should", "notes", "workflow");
        }

        private static bool IsPromptBulletLine(string line)
        {
            if (string.IsNullOrWhiteSpace(line))
            {
                return false;
            }

            string trimmed = line.TrimStart();
            if (trimmed.StartsWith("- ", StringComparison.Ordinal) ||
                trimmed.StartsWith("* ", StringComparison.Ordinal) ||
                trimmed.StartsWith("• ", StringComparison.Ordinal))
            {
                return true;
            }

            int index = 0;
            while (index < trimmed.Length && char.IsDigit(trimmed[index]))
            {
                index++;
            }

            return index > 0 && index + 1 < trimmed.Length && trimmed[index] == '.' && char.IsWhiteSpace(trimmed[index + 1]);
        }

        private static bool LooksLikeInstructionLine(string line)
        {
            string normalized = NormalizeIntentText(line);
            if (string.IsNullOrWhiteSpace(normalized))
            {
                return false;
            }

            return StartsWithAny(
                    normalized,
                    "add ", "create ", "make ", "set ", "set up ", "setup ", "change ",
                    "fix ", "implement ", "prefer ", "reuse ", "keep ", "do not ",
                    "dont ", "don't ", "if ", "after ", "enter ", "return ", "verify ",
                    "specifically verify ", "compile ", "repair ", "validate ", "capture ") ||
                ContainsAny(
                    normalized,
                    " should ", " shouldn't ", " shouldnt ", " must ", " must not ",
                    " have to ", " shouldn't forget ", " don't forget ", " without stopping",
                    " play mode", " runtime", " validation", " constraints");
        }

        private static string CleanPromptInstructionLine(string line)
        {
            if (string.IsNullOrWhiteSpace(line))
            {
                return string.Empty;
            }

            string cleaned = line.Trim();
            while (cleaned.StartsWith("-", StringComparison.Ordinal) ||
                   cleaned.StartsWith("*", StringComparison.Ordinal) ||
                   cleaned.StartsWith("•", StringComparison.Ordinal))
            {
                cleaned = cleaned.Substring(1).TrimStart();
            }

            int dotIndex = cleaned.IndexOf('.');
            if (dotIndex > 0 && dotIndex < 4)
            {
                bool allDigits = true;
                for (int i = 0; i < dotIndex; i++)
                {
                    if (!char.IsDigit(cleaned[i]))
                    {
                        allDigits = false;
                        break;
                    }
                }

                if (allDigits)
                {
                    cleaned = cleaned.Substring(dotIndex + 1).TrimStart();
                }
            }

            return cleaned.Trim();
        }

        private static string CompactInstructionMemorySource(string prompt)
        {
            if (string.IsNullOrWhiteSpace(prompt))
            {
                return string.Empty;
            }

            string compact = prompt.Trim();
            int maxSourceChars = Mathf.Max(1000, InstructionMemoryMaxChars / 2);
            if (compact.Length <= maxSourceChars)
            {
                return compact;
            }

            int headLength = maxSourceChars / 2;
            int tailLength = maxSourceChars - headLength - 80;
            return compact.Substring(0, headLength).TrimEnd() +
                "\n...\n" +
                compact.Substring(compact.Length - tailLength).TrimStart();
        }

        private static string IndentInstructionMemorySource(string source)
        {
            if (string.IsNullOrWhiteSpace(source))
            {
                return "  (empty)";
            }

            StringBuilder builder = new StringBuilder();
            foreach (string line in source.Replace("\r\n", "\n").Replace('\r', '\n').Split('\n'))
            {
                builder.Append("  ");
                builder.AppendLine(line);
            }

            return builder.ToString().TrimEnd();
        }

        [MenuItem("Tools/Ark/Copy Scene Context")]
        private static void CopySceneContext()
        {
            EditorGUIUtility.systemCopyBuffer = BuildContext();
            Debug.Log("Copied Ark scene context.");
        }

        public static bool TryRunPrompt(string prompt, out string response)
        {
            if (!TryPreparePromptRequest(prompt, null, out PreparedRequest request, out string immediateResponse))
            {
                response = string.Empty;
                return false;
            }

            if (request == null)
            {
                response = immediateResponse;
                return true;
            }

            try
            {
                string responseJson = SendPreparedRequest(request);
                response = CompletePreparedRequest(request, responseJson);
                return true;
            }
            catch (Exception exception)
            {
                response = $"{request.DisplayName} request failed: {FormatRequestException(exception)}";
                return true;
            }
        }

        public static bool TryPreparePromptRequest(
            string prompt,
            Action<string> progress,
            out PreparedRequest request,
            out string immediateResponse)
        {
            request = null;
            immediateResponse = string.Empty;

            progress?.Invoke("Preparing backend agent request");
            request = new PreparedRequest
            {
                DisplayName = "Backend scripting agent",
                Endpoint = GetEffectiveBackendEndpoint(),
                RequestJson = JsonUtility.ToJson(new BackendRequest
                {
                    prompt = prompt ?? string.Empty,
                    context = string.Empty,
                    action_schema = string.Empty
                }),
                ApiKey = GetApiKey(),
                IncludeApiKeyHeader = true,
                Kind = PreparedRequestKind.BackendJson,
                OriginalPrompt = prompt
            };
            return true;
        }

        private static bool TryBuildImmediateLocalActionResponse(string prompt, out string response)
        {
            response = string.Empty;
            string normalized = NormalizeIntentText(prompt);
            if (IsClearSceneIntent(normalized))
            {
                response = ExecuteResponseJson(JsonUtility.ToJson(new BackendResponse
                {
                    message = "Cleared the current scene.",
                    plan = new[] { "Delete all root objects from the active scene.", "Save the open scene." },
                    progress = new[] { "Using local clear_scene action." },
                    actions = new[]
                    {
                        new AgentAction { type = "clear_scene" },
                        new AgentAction { type = "save_scene" }
                    }
                }), requireActions: true);
                return true;
            }

            return false;
        }

        private static bool IsQuestionPrompt(string prompt)
        {
            string normalized = NormalizeIntentText(prompt);
            if (string.IsNullOrWhiteSpace(normalized))
            {
                return false;
            }

            if (LooksLikeDirectChangeRequest(normalized))
            {
                return false;
            }

            return normalized.IndexOf("?", StringComparison.Ordinal) >= 0 ||
                StartsWithAny(normalized,
                    "what ", "why ", "how ", "where ", "which ", "who ", "when ",
                    "is ", "are ", "does ", "do ", "did ", "can ", "could ", "should ", "would ",
                    "explain ", "describe ", "summarize ", "tell me ", "list ", "show me ",
                    "analyze ", "review ");
        }

        private static PromptInterpretation AnalyzePromptInterpretation(string prompt)
        {
            string normalized = NormalizeIntentText(prompt);
            if (string.IsNullOrWhiteSpace(normalized))
            {
                return new PromptInterpretation(
                    PromptInterpretationModeLiteral,
                    "Empty or minimal request; respond narrowly.");
            }

            int tokenCount = ExtractSearchTokens(prompt).Count;
            bool questionOnly = IsQuestionPrompt(prompt);
            bool directChange = LooksLikeDirectChangeRequest(normalized);
            bool focusedCodeImplementation = IsFocusedCodeImplementationRequest(prompt);
            bool mentionsFeatureBreadth = !IsPrefabOrAssetOnlyEditRequest(prompt) && HasBroadFeatureIntent(normalized);
            bool multiStepCue =
                ContainsAny(normalized,
                    "end to end", "from scratch", "set up everything", "wire up",
                    "hook up", "make it work", "implement the plan", "upgrade",
                    "overhaul", "full flow");

            if (questionOnly && !directChange && tokenCount <= 12 && !mentionsFeatureBreadth)
            {
                return new PromptInterpretation(
                    PromptInterpretationModeLiteral,
                    "Simple question or narrow request; answer or act directly without broad decomposition.");
            }

            if (focusedCodeImplementation && !multiStepCue)
            {
                return new PromptInterpretation(
                    PromptInterpretationModeExpanded,
                    "Focused code implementation request; use the short inspect/research/write/compile path without broad scene or task-plan decomposition.");
            }

            if (tokenCount >= 20 || mentionsFeatureBreadth || multiStepCue)
            {
                return new PromptInterpretation(
                    PromptInterpretationModeSpec,
                    "Broad or ambiguous feature request; derive acceptance criteria, prerequisites, and completion gates before execution.");
            }

            return new PromptInterpretation(
                PromptInterpretationModeExpanded,
                "Moderate request; infer obvious prerequisites, nearby wiring, and focused validation without full spec work.");
        }

        private static PromptInterpretation GetPromptInterpretation(ToolLoopState state)
        {
            if (state == null)
            {
                return AnalyzePromptInterpretation(string.Empty);
            }

            string mode = NormalizePromptInterpretationMode(state.PromptInterpretationMode);
            string summary = string.IsNullOrWhiteSpace(state.PromptInterpretationSummary)
                ? AnalyzePromptInterpretation(state.Prompt).Summary
                : state.PromptInterpretationSummary.Trim();
            return new PromptInterpretation(mode, summary);
        }

        private static string NormalizePromptInterpretationMode(string mode)
        {
            if (string.IsNullOrWhiteSpace(mode))
            {
                return PromptInterpretationModeExpanded;
            }

            switch (mode.Trim().ToLowerInvariant())
            {
                case PromptInterpretationModeLiteral:
                case PromptInterpretationModeExpanded:
                case PromptInterpretationModeSpec:
                    return mode.Trim().ToLowerInvariant();
                default:
                    return PromptInterpretationModeExpanded;
            }
        }

        private static string BuildPromptWithInterpretation(string prompt, PromptInterpretation interpretation)
        {
            StringBuilder builder = new StringBuilder();
            builder.AppendLine("Interpretation mode: " + NormalizePromptInterpretationMode(interpretation.Mode));
            builder.AppendLine("Interpretation guidance: " + (string.IsNullOrWhiteSpace(interpretation.Summary) ? "Use best judgment." : interpretation.Summary));
            builder.AppendLine();
            builder.Append(prompt ?? string.Empty);
            return builder.ToString();
        }

        private static string BuildPromptDepthBehavior(PromptInterpretation interpretation)
        {
            string mode = NormalizePromptInterpretationMode(interpretation.Mode);
            switch (mode)
            {
                case PromptInterpretationModeLiteral:
                    return "Current interpretation mode is literal. Stay close to the user's exact wording. Avoid broad extra work unless a missing prerequisite blocks the request directly.";
                case PromptInterpretationModeSpec:
                    return "Current interpretation mode is spec. Before acting, identify the real acceptance criteria, required scene/asset/code prerequisites, and explicit completion gates. Do not stop at compile-clean or placeholder setup.";
                default:
                    return "Current interpretation mode is expanded. Infer obvious prerequisites, direct dependencies, and suitable validation, but keep scope disciplined.";
            }
        }

        private static bool ContainsAny(string value, params string[] needles)
        {
            if (string.IsNullOrWhiteSpace(value) || needles == null)
            {
                return false;
            }

            foreach (string needle in needles)
            {
                if (!string.IsNullOrWhiteSpace(needle) &&
                    value.IndexOf(needle, StringComparison.Ordinal) >= 0)
                {
                    return true;
                }
            }

            return false;
        }

        private static bool LooksLikeDirectChangeRequest(string normalized)
        {
            if (StartsWithAny(normalized,
                    "add ", "create ", "make ", "build ", "set up ", "setup ", "clear ",
                    "delete ", "remove ", "change ", "modify ", "fix ", "implement ", "write ",
                    "generate ", "attach ", "give ", "put ", "apply ", "move ", "resize ",
                    "save ", "open "))
            {
                return true;
            }

            return normalized.IndexOf(" can you add ", StringComparison.Ordinal) >= 0 ||
                normalized.IndexOf(" can you create ", StringComparison.Ordinal) >= 0 ||
                normalized.IndexOf(" can you make ", StringComparison.Ordinal) >= 0 ||
                normalized.IndexOf(" can you build ", StringComparison.Ordinal) >= 0 ||
                normalized.IndexOf(" please add ", StringComparison.Ordinal) >= 0 ||
                normalized.IndexOf(" please create ", StringComparison.Ordinal) >= 0 ||
                normalized.IndexOf(" please make ", StringComparison.Ordinal) >= 0 ||
                normalized.IndexOf(" i want you to ", StringComparison.Ordinal) >= 0;
        }

        private static bool StartsWithAny(string value, params string[] prefixes)
        {
            foreach (string prefix in prefixes)
            {
                if (value.StartsWith(prefix, StringComparison.Ordinal))
                {
                    return true;
                }
            }

            return false;
        }

        public static string SendPreparedRequest(PreparedRequest request)
        {
            if (request == null)
            {
                throw new ArgumentNullException(nameof(request));
            }

            return PostJson(request.Endpoint, request.RequestJson, request.IncludeApiKeyHeader, request.ApiKey);
        }

        internal static BackendRunStatus StartBackendRun(PreparedRequest request)
        {
            if (request == null)
            {
                throw new ArgumentNullException(nameof(request));
            }

            string runsEndpoint = GetBackendRunsEndpoint(request.Endpoint);
            int maxAttempts = IsLoopbackEndpoint(runsEndpoint) ? MaxLocalDaemonStartAttempts : 1;
            string responseJson = string.Empty;
            for (int attempt = 1; attempt <= maxAttempts; attempt++)
            {
                try
                {
                    responseJson = PostJson(runsEndpoint, request.RequestJson, request.IncludeApiKeyHeader, request.ApiKey);
                    break;
                }
                catch (InvalidOperationException exception) when (
                    attempt < maxAttempts &&
                    IsTransientOpenAIRequestFailure(exception))
                {
                    Thread.Sleep(LocalDaemonStartRetryDelayMs);
                }
            }

            BackendRunStatus run = JsonUtility.FromJson<BackendRunStatus>(responseJson);
            if (run == null || string.IsNullOrWhiteSpace(run.run_id))
            {
                throw new InvalidOperationException("Backend run start returned no run id.");
            }

            return run;
        }

        internal static BackendRunStatus GetBackendRunStatus(PreparedRequest request, string runId)
        {
            if (request == null)
            {
                throw new ArgumentNullException(nameof(request));
            }

            if (string.IsNullOrWhiteSpace(runId))
            {
                throw new ArgumentException("Backend run id is required.", nameof(runId));
            }

            string endpoint = GetBackendRunsEndpoint(request.Endpoint).TrimEnd('/') + "/" + Uri.EscapeDataString(runId.Trim());
            string responseJson = GetJson(endpoint, request.IncludeApiKeyHeader, request.ApiKey);
            BackendRunStatus run = JsonUtility.FromJson<BackendRunStatus>(responseJson);
            if (run == null)
            {
                throw new InvalidOperationException("Backend run status returned an empty response.");
            }

            return run;
        }

        internal static BackendRunStatus GetBackendRunReplay(PreparedRequest request, string runId)
        {
            if (request == null)
            {
                throw new ArgumentNullException(nameof(request));
            }

            if (string.IsNullOrWhiteSpace(runId))
            {
                throw new ArgumentException("Backend run id is required.", nameof(runId));
            }

            string endpoint = GetBackendRunsEndpoint(request.Endpoint).TrimEnd('/') + "/" +
                Uri.EscapeDataString(runId.Trim()) + "/replay";
            string responseJson = GetJson(endpoint, request.IncludeApiKeyHeader, request.ApiKey);
            BackendRunStatus run = JsonUtility.FromJson<BackendRunStatus>(responseJson);
            if (run == null)
            {
                throw new InvalidOperationException("Backend run replay returned an empty response.");
            }

            return run;
        }

        internal static string CompleteBackendRunResult(BackendRunStatus run)
        {
            if (run == null)
            {
                return "Backend run returned an empty response.";
            }

            if (string.Equals(run.status, "failed", StringComparison.OrdinalIgnoreCase))
            {
                return string.IsNullOrWhiteSpace(run.error)
                    ? "Backend run failed."
                    : $"Backend run failed: {run.error}";
            }

            if (string.Equals(run.status, "canceled", StringComparison.OrdinalIgnoreCase))
            {
                return "Backend run was canceled.";
            }

            return FormatBackendAgentResult(JsonUtility.ToJson(run.result ?? new BackendResponse
            {
                message = "Backend agent finished without a result payload.",
                actions = Array.Empty<AgentAction>()
            }));
        }

        internal static string GetBackendRunSummary(BackendRunStatus run)
        {
            if (run == null)
            {
                return "Starting backend run.";
            }

            string latest = string.Empty;
            if (run.events != null)
            {
                for (int i = run.events.Length - 1; i >= 0; i--)
                {
                    if (!string.IsNullOrWhiteSpace(run.events[i]?.summary))
                    {
                        latest = run.events[i].summary.Trim();
                        break;
                    }
                }
            }

            if (!string.IsNullOrWhiteSpace(latest))
            {
                return latest;
            }

            return string.IsNullOrWhiteSpace(run.status)
                ? "Backend agent is running."
                : $"Backend run status: {run.status}.";
        }

        public static string CompletePreparedRequest(PreparedRequest request, string responseJson)
        {
            if (request == null)
            {
                throw new ArgumentNullException(nameof(request));
            }

            if (request.Kind == PreparedRequestKind.OpenAIAnswer)
            {
                string content = ExtractOpenAIMessageContent(responseJson);
                return ExtractAnswerText(content);
            }

            if (request.Kind == PreparedRequestKind.OpenAIChat ||
                request.Kind == PreparedRequestKind.OpenAIPlanReview ||
                request.Kind == PreparedRequestKind.OpenAIApprovedExecution)
            {
                string content = ExtractOpenAIMessageContent(responseJson);
                if (string.IsNullOrWhiteSpace(content))
                {
                    return "OpenAI returned an empty message.";
                }

                if (TryExtractJson(content, out string actionJson))
                {
                    return ExecuteResponseJson(actionJson, request.Kind == PreparedRequestKind.OpenAIApprovedExecution);
                }

                return content.Trim();
            }

            if (request.Kind == PreparedRequestKind.BackendJson)
            {
                return FormatBackendAgentResult(responseJson);
            }

            return ExecuteResponseJson(responseJson);
        }

        public static bool TryBuildApprovedExecutionRequest(PlanReviewResult plan, out PreparedRequest request, out string error)
        {
            request = null;
            error = string.Empty;
            if (!HasApiKey())
            {
                error = GetBackendRequiredMessage();
                return false;
            }

            string prompt = plan?.Prompt ?? string.Empty;
            string context = BuildContext(prompt);
            PromptInterpretation interpretation = AnalyzePromptInterpretation(prompt);
            request = new PreparedRequest
            {
                DisplayName = "OpenAI execution",
                Endpoint = OpenAIChatCompletionsEndpoint,
                RequestJson = JsonUtility.ToJson(new OpenAIChatRequest
                {
                    model = GetModel(),
                    response_format = OpenAIResponseFormat.JsonObject(),
                    messages = new[]
                    {
                        new OpenAIRequestMessage
                        {
                            role = "developer",
                            content = BuildOpenAIApprovedExecutionPrompt(context, interpretation)
                        },
                        new OpenAIRequestMessage
                        {
                            role = "user",
                            content = BuildApprovedExecutionUserPrompt(prompt, plan, interpretation)
                        }
                    }
                }),
                ApiKey = GetApiKey(),
                IncludeApiKeyHeader = false,
                Kind = PreparedRequestKind.OpenAIApprovedExecution,
                OriginalPrompt = prompt
            };
            return true;
        }

        public static bool CanExecuteApprovedPlanLocally(PlanReviewResult plan)
        {
            return plan != null &&
                plan.ProposedActionCount > 0 &&
                !string.IsNullOrWhiteSpace(plan.ProposedActionJson);
        }

        public static string ExecuteApprovedPlan(PlanReviewResult plan)
        {
            if (!CanExecuteApprovedPlanLocally(plan))
            {
                return "No executable actions were stored with this plan. Ask for the change again so the agent can propose concrete Unity actions before approval.\n\nApplied actions: 0";
            }

            return ExecuteResponseJson(plan.ProposedActionJson, requireActions: true);
        }

        public static ToolLoopState BeginOpenAIToolLoop(string prompt, Action<string> progress)
        {
            throw new InvalidOperationException(GetBackendRequiredMessage());
        }

        public static string BuildOpenAIToolLoopRequestJson(ToolLoopState state)
        {
            if (state == null)
            {
                throw new ArgumentNullException(nameof(state));
            }

            state.RequestCount++;
            RefreshInstructionMemory(state);
            RepairActiveToolLoopMessages(state);
            CompactActiveToolLoopMessagesIfNeeded(state);
            SaveResumableToolLoopState(state);
            return BuildOpenAIToolRequestJson(GetActiveToolLoopMessages(state), state.ActiveAgentRole, state.Model);
        }

        public static bool TryPrepareAutomaticToolLoopBudgetContinuation(ToolLoopState state, out string summary)
        {
            summary = string.Empty;
            if (state == null)
            {
                return false;
            }

            TimeSpan elapsed = GetToolLoopElapsed(state);
            bool requestBudgetExceeded = state.RequestCount >= MaxToolLoopRequestsPerRun;
            bool timeBudgetExceeded = elapsed.TotalMinutes >= MaxToolLoopWallClockMinutes;
            if (!requestBudgetExceeded && !timeBudgetExceeded)
            {
                return false;
            }

            state.AutomaticBudgetContinuationCount++;
            string reason = requestBudgetExceeded
                ? $"{MaxToolLoopRequestsPerRun} model/tool turns"
                : $"{MaxToolLoopWallClockMinutes:0} minutes";
            ForceCompactActiveToolLoopMessages(state, "Automatic responsiveness checkpoint after " + reason + ".");
            ResetToolLoopResponsivenessBudget(state, resetContinuationCount: false);
            summary = $"Responsiveness checkpoint {state.AutomaticBudgetContinuationCount}; compacted progress and continuing automatically.";
            SaveResumableToolLoopState(state);
            return true;
        }

        public static void ResetToolLoopResponsivenessBudget(ToolLoopState state)
        {
            ResetToolLoopResponsivenessBudget(state, resetContinuationCount: true);
        }

        private static void ResetToolLoopResponsivenessBudget(ToolLoopState state, bool resetContinuationCount)
        {
            if (state == null)
            {
                return;
            }

            state.StartedAtUtcTicks = DateTime.UtcNow.Ticks;
            state.RequestCount = 0;
            state.ConsecutiveRequestFailureCount = 0;
            if (resetContinuationCount)
            {
                state.AutomaticBudgetContinuationCount = 0;
            }

            SaveResumableToolLoopState(state);
        }

        private static TimeSpan GetToolLoopElapsed(ToolLoopState state)
        {
            if (state == null || state.StartedAtUtcTicks <= 0)
            {
                return TimeSpan.Zero;
            }

            long elapsedTicks = DateTime.UtcNow.Ticks - state.StartedAtUtcTicks;
            return elapsedTicks <= 0 ? TimeSpan.Zero : TimeSpan.FromTicks(elapsedTicks);
        }

        private static void CompactActiveToolLoopMessagesIfNeeded(ToolLoopState state)
        {
            CompactActiveToolLoopMessages(state, force: false, reason: null);
        }

        private static void ForceCompactActiveToolLoopMessages(ToolLoopState state, string reason)
        {
            CompactActiveToolLoopMessages(state, force: true, reason: reason);
        }

        private static void CompactActiveToolLoopMessages(ToolLoopState state, bool force, string reason)
        {
            if (state == null)
            {
                return;
            }

            List<OpenAIToolChatMessage> messages = GetActiveToolLoopMessages(state);
            if (messages == null)
            {
                return;
            }

            int characterCount = EstimateMessageCharacters(messages);
            if (!force &&
                messages.Count <= MaxActiveToolLoopMessagesBeforeCompaction &&
                characterCount <= MaxActiveToolLoopMessageChars)
            {
                return;
            }

            PromptInterpretation interpretation = GetPromptInterpretation(state);
            string summary = BuildCompactedToolLoopProgressSummary(state, messages.Count, characterCount);
            if (!string.IsNullOrWhiteSpace(reason))
            {
                summary += "\n\nCompaction reason: " + reason.Trim();
            }

            if (IsManagerAgentRole(state.ActiveAgentRole))
            {
                state.messages.Clear();
                state.messages.Add(new OpenAIToolChatMessage
                {
                    role = "developer",
                    content = BuildOpenAIManagerPrompt(BuildToolLoopContext(state, state.Prompt, null, AgentRoleManager), interpretation)
                });
                state.messages.Add(new OpenAIToolChatMessage
                {
                    role = "user",
                    content = BuildPromptWithInterpretation(state.Prompt, interpretation)
                });
                state.messages.Add(new OpenAIToolChatMessage
                {
                    role = "user",
                    content = summary
                });
                return;
            }

            string role = NormalizeAgentRole(state.ActiveAgentRole);
            state.specialistMessages[role] = CreateSpecialistMessages(state, role, state.pendingHandoffTask);
            state.specialistMessages[role].Add(new OpenAIToolChatMessage
            {
                role = "user",
                content = summary
            });
        }

        private static int EstimateMessageCharacters(List<OpenAIToolChatMessage> messages)
        {
            if (messages == null)
            {
                return 0;
            }

            int count = 0;
            foreach (OpenAIToolChatMessage message in messages)
            {
                if (message == null)
                {
                    continue;
                }

                count += string.IsNullOrEmpty(message.content) ? 0 : message.content.Length;
                count += string.IsNullOrEmpty(message.role) ? 0 : message.role.Length;
                count += string.IsNullOrEmpty(message.tool_call_id) ? 0 : message.tool_call_id.Length;
                if (message.tool_calls == null)
                {
                    continue;
                }

                foreach (OpenAIToolCall toolCall in message.tool_calls)
                {
                    count += string.IsNullOrEmpty(toolCall?.id) ? 0 : toolCall.id.Length;
                    count += string.IsNullOrEmpty(toolCall?.function?.name) ? 0 : toolCall.function.name.Length;
                    count += string.IsNullOrEmpty(toolCall?.function?.arguments) ? 0 : toolCall.function.arguments.Length;
                }
            }

            return count;
        }

        private static string BuildCompactedToolLoopProgressSummary(ToolLoopState state, int previousMessageCount, int previousCharacterCount)
        {
            StringBuilder builder = new StringBuilder();
            builder.AppendLine("Conversation history was compacted to keep the request within the model context limit.");
            builder.AppendLine($"Previous active message count: {previousMessageCount}; approximate characters: {previousCharacterCount}.");
            builder.AppendLine("Redundant tool chatter, repeated validation, repeated strict-gate messages, and duplicate searches were condensed. Do not repeat old searches or validation loops just because detailed old messages were compacted.");
            builder.AppendLine();
            builder.AppendLine("Preserved non-droppable context:");
            builder.AppendLine("- Original request: " + CompactOneLine(state?.Prompt, 1200));
            builder.AppendLine("- Active role: " + GetAgentDisplayName(state?.ActiveAgentRole));
            if (!string.IsNullOrWhiteSpace(state?.pendingHandoffTask))
            {
                builder.AppendLine("- Current delegated task: " + CompactOneLine(state.pendingHandoffTask, 1200));
            }

            if (!string.IsNullOrWhiteSpace(state?.PromptInterpretationSummary))
            {
                builder.AppendLine("- Prompt interpretation: " + CompactOneLine(state.PromptInterpretationSummary, 700));
            }

            builder.AppendLine("Progress counters:");
            builder.AppendLine($"- requestCount={state.RequestCount}, appliedActions={state.AppliedActions}, toolCalls={state.LoggedToolCalls}, handoffs={state.HandoffCount}, strictGateRetries={state.StrictCompletionRetryCount}, autoContinuations={state.AutomaticBudgetContinuationCount}");
            if (state.TaskPlan.Count > 0)
            {
                builder.AppendLine();
                builder.AppendLine("Current task plan:");
                builder.AppendLine(ClampText(FormatTaskPlanForContext(state), 5000));
            }

            AppendCompactLogTail(builder, "Open blockers and unresolved issues", state.IssueLog, 12, 3500, CompactionLogMode.Important);
            AppendCompactLogTail(builder, "Changed actions already applied", state.AchievementLog, 14, 3500, CompactionLogMode.Important);
            AppendCompactLogTail(builder, "Recent validation state", state.ValidationLog, 8, 2500, CompactionLogMode.Validation);
            AppendCompactLogTail(builder, "Written code/file snippets and references", state.CodeSnippetLog, 8, 3500, CompactionLogMode.Important);
            AppendCompactLogTail(builder, "Relevant context checked", state.ContextLog, 8, 2500, CompactionLogMode.Context);
            AppendCompactLogTail(builder, "Recent meaningful tool results", state.ActionLog, 12, 4000, CompactionLogMode.ToolResults);
            builder.AppendLine();
            builder.AppendLine("Continue from this summary and the current Unity context. Treat preserved blockers, changed actions, task plan, and original request as authoritative.");
            return builder.ToString().TrimEnd();
        }

        private enum CompactionLogMode
        {
            Important,
            Validation,
            Context,
            ToolResults
        }

        private static void AppendCompactLogTail(
            StringBuilder builder,
            string title,
            StringBuilder log,
            int maxLines,
            int maxChars,
            CompactionLogMode mode)
        {
            if (builder == null || log == null || log.Length == 0)
            {
                return;
            }

            string compacted = BuildCompactedLogTail(log.ToString(), maxLines, maxChars, mode);
            if (string.IsNullOrWhiteSpace(compacted))
            {
                return;
            }

            builder.AppendLine();
            builder.AppendLine(title + ":");
            builder.AppendLine(compacted);
        }

        private static string BuildCompactedLogTail(string value, int maxLines, int maxChars, CompactionLogMode mode)
        {
            if (string.IsNullOrWhiteSpace(value) || maxLines <= 0)
            {
                return string.Empty;
            }

            List<string> entries = mode == CompactionLogMode.ToolResults
                ? ExtractToolLogEntries(value)
                : ExtractNonBlankLines(value);
            List<string> compacted = new List<string>();
            HashSet<string> seen = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
            for (int i = entries.Count - 1; i >= 0; i--)
            {
                string entry = CompactLogEntry(entries[i], mode);
                if (string.IsNullOrWhiteSpace(entry) || IsRedundantCompactionEntry(entry, mode))
                {
                    continue;
                }

                string key = BuildCompactionDedupeKey(entry, mode);
                if (!seen.Add(key))
                {
                    continue;
                }

                compacted.Insert(0, entry);
                if (compacted.Count >= maxLines)
                {
                    break;
                }
            }

            StringBuilder builder = new StringBuilder();
            foreach (string entry in compacted)
            {
                if (entry.StartsWith("- ", StringComparison.Ordinal))
                {
                    builder.AppendLine(entry);
                }
                else
                {
                    builder.AppendLine("- " + entry);
                }
            }

            return ClampText(builder.ToString().TrimEnd(), maxChars);
        }

        private static List<string> ExtractNonBlankLines(string value)
        {
            List<string> lines = new List<string>();
            if (string.IsNullOrWhiteSpace(value))
            {
                return lines;
            }

            foreach (string rawLine in value.Replace("\r\n", "\n").Replace('\r', '\n').Split('\n'))
            {
                string line = rawLine.Trim();
                if (!string.IsNullOrWhiteSpace(line))
                {
                    lines.Add(line);
                }
            }

            return lines;
        }

        private static List<string> ExtractToolLogEntries(string value)
        {
            List<string> entries = new List<string>();
            if (string.IsNullOrWhiteSpace(value))
            {
                return entries;
            }

            StringBuilder current = new StringBuilder();
            foreach (string rawLine in value.Replace("\r\n", "\n").Replace('\r', '\n').Split('\n'))
            {
                string line = rawLine.TrimEnd();
                if (Regex.IsMatch(line.TrimStart(), @"^\d+\. "))
                {
                    if (current.Length > 0)
                    {
                        entries.Add(current.ToString().Trim());
                        current.Clear();
                    }

                    current.AppendLine(line.Trim());
                }
                else if (!string.IsNullOrWhiteSpace(line) && current.Length > 0)
                {
                    current.Append(' ');
                    current.Append(line.Trim());
                }
            }

            if (current.Length > 0)
            {
                entries.Add(current.ToString().Trim());
            }

            return entries;
        }

        private static string CompactLogEntry(string entry, CompactionLogMode mode)
        {
            if (string.IsNullOrWhiteSpace(entry))
            {
                return string.Empty;
            }

            string compact = CompactOneLine(entry.Trim(), mode == CompactionLogMode.ToolResults ? 360 : 260);
            if (mode == CompactionLogMode.ToolResults)
            {
                compact = Regex.Replace(compact, @"^\d+\.\s*", string.Empty);
            }

            return compact;
        }

        private static bool IsRedundantCompactionEntry(string entry, CompactionLogMode mode)
        {
            if (string.IsNullOrWhiteSpace(entry))
            {
                return true;
            }

            string lower = entry.ToLowerInvariant();
            if (ContainsAny(
                    lower,
                    "received tool response",
                    "inspecting updated unity state",
                    "completed tool:",
                    "calling orchestrator for next tool",
                    "calling manager for next tool",
                    "responsiveness checkpoint"))
            {
                return true;
            }

            if (mode == CompactionLogMode.ToolResults &&
                ContainsAny(
                    lower,
                    "strict_completion_gate",
                    "set_task_plan",
                    "update_task_status",
                    "handoff_to_agent",
                    "worker returned to manager",
                    "explorer returned to manager",
                    "scene setup returned to manager",
                    "asset management returned to manager",
                    "monitor returned to manager"))
            {
                return true;
            }

            if (mode == CompactionLogMode.Context &&
                ContainsAny(lower, "searched project for", "searched local unity docs for") &&
                lower.IndexOf("top matches:", StringComparison.Ordinal) < 0 &&
                lower.IndexOf("top docs:", StringComparison.Ordinal) < 0)
            {
                return true;
            }

            return false;
        }

        private static string BuildCompactionDedupeKey(string entry, CompactionLogMode mode)
        {
            string key = (entry ?? string.Empty).Trim().ToLowerInvariant();
            key = Regex.Replace(key, @"^\d+\.\s*", string.Empty);
            key = Regex.Replace(key, @"\s+", " ");
            if (mode == CompactionLogMode.Validation)
            {
                key = Regex.Replace(key, @"rendered .*? at \d+x\d+", "rendered camera");
                key = Regex.Replace(key, @"avgLuminance=[0-9.]+", "avgLuminance=*");
                key = Regex.Replace(key, @"nonBlackPixels=[0-9.]+%", "nonBlackPixels=*");
                key = Regex.Replace(key, @"brightPixels=[0-9.]+%", "brightPixels=*");
            }

            return key.Length <= 180 ? key : key.Substring(0, 180);
        }

        private static string ClampText(string value, int maxChars)
        {
            if (string.IsNullOrEmpty(value) || maxChars <= 0 || value.Length <= maxChars)
            {
                return value ?? string.Empty;
            }

            int head = Mathf.Max(0, maxChars / 2);
            int tail = Mathf.Max(0, maxChars - head - 40);
            return value.Substring(0, head).TrimEnd() +
                "\n... compacted ...\n" +
                value.Substring(value.Length - tail).TrimStart();
        }

        private static void RepairActiveToolLoopMessages(ToolLoopState state)
        {
            if (state == null)
            {
                return;
            }

            List<OpenAIToolChatMessage> messages = GetActiveToolLoopMessages(state);
            if (messages == null)
            {
                return;
            }

            for (int i = messages.Count - 1; i >= 0; i--)
            {
                if (messages[i] == null)
                {
                    messages.RemoveAt(i);
                }
            }

            if (messages.Count == 0 || IsAssistantOrToolRole(messages[0].role))
            {
                ResetActiveToolLoopMessages(state);
                messages = GetActiveToolLoopMessages(state);
            }

            foreach (OpenAIToolChatMessage message in messages)
            {
                if (message == null)
                {
                    continue;
                }

                string role = NormalizeOpenAIMessageRole(message.role);
                message.role = role;
                if (!string.Equals(role, "assistant", StringComparison.Ordinal))
                {
                    message.tool_calls = null;
                }

                if (!string.Equals(role, "tool", StringComparison.Ordinal))
                {
                    message.tool_call_id = null;
                }
                else if (string.IsNullOrWhiteSpace(message.tool_call_id))
                {
                    message.role = "user";
                    message.tool_call_id = null;
                    message.tool_calls = null;
                    message.content = "A prior tool result had no tool_call_id and was converted into a user-visible observation:\n" + (message.content ?? string.Empty);
                }
            }
        }

        private static void ResetActiveToolLoopMessages(ToolLoopState state)
        {
            PromptInterpretation interpretation = GetPromptInterpretation(state);
            if (IsManagerAgentRole(state.ActiveAgentRole))
            {
                state.messages.Clear();
                state.messages.Add(new OpenAIToolChatMessage
                {
                    role = "developer",
                    content = BuildOpenAIManagerPrompt(BuildToolLoopContext(state, state.Prompt, null, AgentRoleManager), interpretation)
                });
                state.messages.Add(new OpenAIToolChatMessage
                {
                    role = "user",
                    content = BuildPromptWithInterpretation(state.Prompt, interpretation)
                });
                return;
            }

            string role = NormalizeAgentRole(state.ActiveAgentRole);
            state.specialistMessages[role] = CreateSpecialistMessages(state, role, state.pendingHandoffTask);
        }

        private static void RefreshInstructionMemory(ToolLoopState state)
        {
            if (state == null)
            {
                return;
            }

            string next = BuildInstructionMemory(state.Prompt);
            if (!string.IsNullOrWhiteSpace(next))
            {
                state.InstructionMemory = next;
            }
        }

        private static bool IsAssistantOrToolRole(string role)
        {
            string normalized = NormalizeOpenAIMessageRole(role);
            return string.Equals(normalized, "assistant", StringComparison.Ordinal) ||
                string.Equals(normalized, "tool", StringComparison.Ordinal);
        }

        private static string NormalizeOpenAIMessageRole(string role)
        {
            if (string.IsNullOrWhiteSpace(role))
            {
                return "user";
            }

            string normalized = role.Trim().ToLowerInvariant();
            switch (normalized)
            {
                case "developer":
                case "system":
                case "user":
                case "assistant":
                case "tool":
                    return normalized;
                default:
                    return "user";
            }
        }

        public static string SendOpenAIToolLoopRequest(ToolLoopState state, string requestJson)
        {
            if (state == null)
            {
                throw new ArgumentNullException(nameof(state));
            }

            return PostJson(OpenAIChatCompletionsEndpoint, requestJson, includeApiKeyHeader: false, apiKey: state.ApiKey);
        }

        public static void AddUserFollowUpToToolLoop(ToolLoopState state, string prompt)
        {
            if (state == null)
            {
                throw new ArgumentNullException(nameof(state));
            }

            if (string.IsNullOrWhiteSpace(prompt))
            {
                return;
            }

            string followUp = prompt.Trim();
            state.Prompt = string.IsNullOrWhiteSpace(state.Prompt)
                ? followUp
                : $"{state.Prompt}\n\nUser follow-up while the agent was working:\n{followUp}";
            state.InstructionMemory = BuildInstructionMemory(state.Prompt);
            PromptInterpretation interpretation = AnalyzePromptInterpretation(state.Prompt);
            state.PromptInterpretationMode = interpretation.Mode;
            state.PromptInterpretationSummary = interpretation.Summary;
            OpenAIToolChatMessage followUpMessage = new OpenAIToolChatMessage
            {
                role = "user",
                content = "User follow-up while you were working. Treat this as the latest user instruction. If it conflicts with older instructions, follow this newer message:\n\n" + BuildPromptWithInterpretation(followUp, interpretation)
            };

            GetActiveToolLoopMessages(state).Add(followUpMessage);
            if (!IsManagerAgentRole(state.ActiveAgentRole))
            {
                state.messages.Add(new OpenAIToolChatMessage
                {
                    role = "user",
                    content = "User follow-up received while a specialist was working. Review it after the specialist returns. If it conflicts with older instructions, follow this newer message:\n\n" + BuildPromptWithInterpretation(followUp, interpretation)
                });
            }

            SaveResumableToolLoopState(state);
        }

        public static ToolLoopTurnResult ApplyOpenAIToolLoopResponse(
            ToolLoopState state,
            string responseJson,
            Action<string> progress)
        {
            if (state == null)
            {
                throw new ArgumentNullException(nameof(state));
            }

            OpenAIChatResponse response = JsonUtility.FromJson<OpenAIChatResponse>(responseJson);
            OpenAIChatMessage assistant = response?.choices == null || response.choices.Length == 0
                ? null
                : response.choices[0]?.message;

            if (assistant == null)
            {
                OpenAIErrorEnvelope error = JsonUtility.FromJson<OpenAIErrorEnvelope>(responseJson);
                string message = error?.error == null
                    ? "OpenAI returned an empty tool-loop response."
                    : $"OpenAI request failed: {error.error.message}";
                state.FinalMessage = message;
                ClearResumableToolLoopState();
                return new ToolLoopTurnResult
                {
                    IsComplete = true,
                    FinalResponse = FormatToolLoopFinalResponse(state)
                };
            }

            OpenAIToolCall[] toolCalls = assistant.tool_calls;
            if (toolCalls == null || toolCalls.Length == 0)
            {
                string finalMessage = ExtractToolLoopFinalMessage(assistant.content);
                if (!IsManagerAgentRole(state.ActiveAgentRole))
                {
                    return CompleteSpecialistHandoff(state, finalMessage, progress);
                }

                state.FinalMessage = finalMessage;
                if (TryEnforceStrictCompletionLoop(state, finalMessage, progress, out ToolLoopTurnResult deferredResult))
                {
                    return deferredResult;
                }

                ClearResumableToolLoopState();
                return new ToolLoopTurnResult
                {
                    IsComplete = true,
                    FinalResponse = FormatToolLoopFinalResponse(state),
                    AgentRole = state.ActiveAgentRole
                };
            }

            List<OpenAIToolChatMessage> activeMessages = GetActiveToolLoopMessages(state);
            activeMessages.Add(new OpenAIToolChatMessage
            {
                role = "assistant",
                content = string.IsNullOrWhiteSpace(assistant.content) ? string.Empty : assistant.content,
                tool_calls = toolCalls
            });

            OpenAIToolCall toolCall = toolCalls[0];
            string toolName = toolCall?.function?.name ?? "unknown_tool";
            AgentAction executedAction = null;
            string toolResult;
            progress?.Invoke($"Tool: {toolName}");

            try
            {
                AgentAction action = BuildActionFromToolCall(toolCall);
                executedAction = action;
                string normalizedToolName = NormalizeActionType(action.type);
                if (TryDetectRepeatedToolCall(state, toolCall, out string repeatedToolMessage))
                {
                    toolResult = repeatedToolMessage;
                }
                else if (!IsToolAllowedForRole(state.ActiveAgentRole, normalizedToolName))
                {
                    toolResult = $"Tool blocked: {GetAgentDisplayName(state.ActiveAgentRole)} is not allowed to call {normalizedToolName}. Allowed tools: {BuildAllowedToolList(state.ActiveAgentRole)}";
                }
                else if (TryBuildFocusedRepairBudgetBlocker(state, action, normalizedToolName, out string focusedRepairBudgetBlocker))
                {
                    toolResult = focusedRepairBudgetBlocker;
                    activeMessages.Add(BuildToolResultMessage(toolCall, toolResult));
                    for (int i = 1; i < toolCalls.Length; i++)
                    {
                        string skipped = "Skipped. Focused repair convergence budget was exceeded for this turn.";
                        activeMessages.Add(BuildToolResultMessage(toolCalls[i], skipped));
                    }

                    AppendToolLogLine(state.ActionLog, ++state.LoggedToolCalls, FormatAgentToolName(state.ActiveAgentRole, toolName), toolResult);
                    RecordUserFacingToolResult(state, executedAction, toolName, toolResult);
                    SaveResumableToolLoopState(state);
                    return new ToolLoopTurnResult
                    {
                        IsComplete = false,
                        ToolName = toolName,
                        ToolResult = toolResult,
                        AgentRole = state.ActiveAgentRole,
                        ExecutedTool = false
                    };
                }
                else if (TryBuildCompilerNamespaceRepairBlocker(state, action, normalizedToolName, out string compilerRepairBlocker))
                {
                    toolResult = compilerRepairBlocker;
                    activeMessages.Add(BuildToolResultMessage(toolCall, toolResult));
                    for (int i = 1; i < toolCalls.Length; i++)
                    {
                        string skipped = "Skipped. Namespace or assembly-reference repair evidence is required before another code rewrite.";
                        activeMessages.Add(BuildToolResultMessage(toolCalls[i], skipped));
                    }

                    AppendToolLogLine(state.ActionLog, ++state.LoggedToolCalls, FormatAgentToolName(state.ActiveAgentRole, toolName), toolResult);
                    RecordUserFacingToolResult(state, executedAction, toolName, toolResult);
                    SaveResumableToolLoopState(state);
                    return new ToolLoopTurnResult
                    {
                        IsComplete = false,
                        ToolName = toolName,
                        ToolResult = toolResult,
                        AgentRole = state.ActiveAgentRole,
                        ExecutedTool = false
                    };
                }
                else if (TryBuildImplementationResearchBlocker(state, action, normalizedToolName, out string researchBlocker))
                {
                    toolResult = researchBlocker;
                    activeMessages.Add(BuildToolResultMessage(toolCall, toolResult));
                    for (int i = 1; i < toolCalls.Length; i++)
                    {
                        string skipped = "Skipped. Implementation research was required before writing code.";
                        activeMessages.Add(BuildToolResultMessage(toolCalls[i], skipped));
                    }

                    AppendToolLogLine(state.ActionLog, ++state.LoggedToolCalls, FormatAgentToolName(state.ActiveAgentRole, toolName), toolResult);
                    RecordUserFacingToolResult(state, executedAction, toolName, toolResult);
                    SaveResumableToolLoopState(state);
                    return new ToolLoopTurnResult
                    {
                        IsComplete = false,
                        ToolName = toolName,
                        ToolResult = toolResult,
                        AgentRole = state.ActiveAgentRole,
                        ExecutedTool = false
                    };
                }
                else if (TryBuildContextPolicyBlocker(state, action, normalizedToolName, out string contextPolicyBlocker))
                {
                    toolResult = contextPolicyBlocker;
                    activeMessages.Add(BuildToolResultMessage(toolCall, toolResult));
                    for (int i = 1; i < toolCalls.Length; i++)
                    {
                        string skipped = "Skipped. Context policy blocked extra exploration for this turn.";
                        activeMessages.Add(BuildToolResultMessage(toolCalls[i], skipped));
                    }

                    AppendToolLogLine(state.ActionLog, ++state.LoggedToolCalls, FormatAgentToolName(state.ActiveAgentRole, toolName), toolResult);
                    RecordUserFacingToolResult(state, executedAction, toolName, toolResult);
                    SaveResumableToolLoopState(state);
                    return new ToolLoopTurnResult
                    {
                        IsComplete = false,
                        ToolName = toolName,
                        ToolResult = toolResult,
                        AgentRole = state.ActiveAgentRole,
                        ExecutedTool = false
                    };
                }
                else if (IsManagerAgentRole(state.ActiveAgentRole) &&
                         string.Equals(normalizedToolName, HandoffToolName, StringComparison.Ordinal))
                {
                    if (TryBuildRedundantHandoffBlocker(state, action, out string redundantHandoffBlocker))
                    {
                        toolResult = redundantHandoffBlocker;
                        activeMessages.Add(BuildToolResultMessage(toolCall, toolResult));
                        for (int i = 1; i < toolCalls.Length; i++)
                        {
                            string skipped = "Skipped. The manager must use the previous specialist result instead of repeating the handoff.";
                            activeMessages.Add(BuildToolResultMessage(toolCalls[i], skipped));
                        }

                        AppendToolLogLine(state.AgentLog, state.HandoffCount + 1, toolName, toolResult);
                        SaveResumableToolLoopState(state);
                        return new ToolLoopTurnResult
                        {
                            IsComplete = false,
                            ToolName = toolName,
                            ToolResult = toolResult,
                            AgentRole = state.ActiveAgentRole,
                            ExecutedTool = false
                        };
                    }

                    if (TryBuildSceneFirstHandoffBlocker(state, action, out string sceneFirstBlocker))
                    {
                        toolResult = sceneFirstBlocker;
                        activeMessages.Add(BuildToolResultMessage(toolCall, toolResult));
                        for (int i = 1; i < toolCalls.Length; i++)
                        {
                            string skipped = "Skipped. The manager must correct the scene-first handoff order before issuing more work.";
                            activeMessages.Add(BuildToolResultMessage(toolCalls[i], skipped));
                        }

                        AppendToolLogLine(state.AgentLog, state.HandoffCount + 1, toolName, toolResult);
                        SaveResumableToolLoopState(state);
                        return new ToolLoopTurnResult
                        {
                            IsComplete = false,
                            ToolName = toolName,
                            ToolResult = toolResult,
                            AgentRole = state.ActiveAgentRole,
                            ExecutedTool = false
                        };
                    }

                    toolResult = BeginAgentHandoff(state, toolCall, action);
                    for (int i = 1; i < toolCalls.Length; i++)
                    {
                        string skipped = "Skipped. The manager delegated one specialist task and will review the result before issuing more work.";
                        activeMessages.Add(BuildToolResultMessage(toolCalls[i], skipped));
                    }

                    AppendToolLogLine(state.AgentLog, ++state.HandoffCount, toolName, toolResult);
                    SaveResumableToolLoopState(state);
                    return new ToolLoopTurnResult
                    {
                        IsComplete = false,
                        ToolName = toolName,
                        ToolResult = toolResult,
                        AgentRole = state.ActiveAgentRole,
                        ExecutedTool = true
                    };
                }
                else
                {
                    if (IsTaskPlanAction(normalizedToolName))
                    {
                        toolResult = ExecuteTaskPlanAction(state, action);
                    }
                    else
                    {
                        toolResult = ExecuteAction(action);
                    }

                    if (string.Equals(normalizedToolName, "search_web", StringComparison.Ordinal))
                    {
                        state.ExternalImplementationResearchAttempted = true;
                    }

                    RecordFocusedRepairToolProgress(state, action, normalizedToolName, toolResult);
                    RecordContextPolicyTool(state, action, normalizedToolName, toolResult);

                    if (!IsReadOnlyAction(action.type) && !IsIssueToolResult(toolResult))
                    {
                        state.AppliedActions++;
                    }
                }

                AppendToolLogLine(state.ActionLog, ++state.LoggedToolCalls, FormatAgentToolName(state.ActiveAgentRole, toolName), toolResult);
                RecordUserFacingToolResult(state, executedAction, toolName, toolResult);
            }
            catch (Exception exception)
            {
                toolResult = $"Tool failed: {exception.GetType().Name}: {exception.Message}";
                AppendToolLogLine(state.ActionLog, ++state.LoggedToolCalls, FormatAgentToolName(state.ActiveAgentRole, toolName), toolResult);
                RecordUserFacingToolResult(state, executedAction, toolName, toolResult);
            }

            for (int i = 1; i < toolCalls.Length; i++)
            {
                string skipped = "Skipped. Auto-run mode executes one Unity tool per model turn so the agent can inspect the updated scene before choosing the next tool.";
                activeMessages.Add(BuildToolResultMessage(toolCalls[i], skipped));
            }

            string toolResultMessage = BuildToolResultMessageContent(state, executedAction, toolName, toolResult, progress);
            activeMessages.Add(BuildToolResultMessage(toolCall, toolResultMessage));
            SaveResumableToolLoopState(state);

            return new ToolLoopTurnResult
            {
                IsComplete = false,
                ToolName = toolName,
                ToolResult = toolResult,
                AgentRole = state.ActiveAgentRole,
                ExecutedTool = true
            };
        }

        private static string BuildToolResultMessageContent(
            ToolLoopState state,
            AgentAction executedAction,
            string toolName,
            string toolResult,
            Action<string> progress)
        {
            string normalizedTool = NormalizeActionType(executedAction?.type ?? toolName);
            if (ShouldSkipUpdatedUnityContextAfterTool(normalizedTool))
            {
                return $"{toolResult}\n\nUpdated Unity context was skipped for this low-impact tool to keep the editor responsive. Treat the tool result above as the current observation and request an explicit validation, runtime inspection, or scene query if more state is needed.";
            }

            progress?.Invoke("Inspecting updated Unity state");
            string updatedContext = ClampText(
                BuildToolLoopContext(state, executedAction, state.ActiveAgentRole),
                MaxUpdatedContextInToolResultChars);
            return $"{toolResult}\n\nUpdated Unity context for {GetAgentDisplayName(state.ActiveAgentRole)} after this tool call:\n{updatedContext}";
        }

        private static bool ShouldSkipUpdatedUnityContextAfterTool(string normalizedTool)
        {
            normalizedTool = NormalizeActionType(normalizedTool);
            if (IsTaskPlanAction(normalizedTool) || IsReferenceTool(normalizedTool))
            {
                return true;
            }

            switch (normalizedTool)
            {
                case "capture_game_view":
                case "capture_game_view_diagnostics":
                case "read_compiler_diagnostics":
                case "rebuild_unity":
                case "save_assets":
                case "save_scene":
                case "search_web":
                case "select":
                case "validate_scene":
                    return true;
                default:
                    return false;
            }
        }

        public static string GetActiveToolLoopAgentLabel(ToolLoopState state)
        {
            return state == null ? "Agent" : GetAgentDisplayName(state.ActiveAgentRole);
        }

        private static List<OpenAIToolChatMessage> GetActiveToolLoopMessages(ToolLoopState state)
        {
            if (state == null || IsManagerAgentRole(state.ActiveAgentRole))
            {
                return state == null ? null : state.messages;
            }

            string role = NormalizeAgentRole(state.ActiveAgentRole);
            if (!state.specialistMessages.TryGetValue(role, out List<OpenAIToolChatMessage> messages) || messages == null)
            {
                messages = CreateSpecialistMessages(state, role, state.pendingHandoffTask);
                state.specialistMessages[role] = messages;
            }

            return messages;
        }

        private static List<OpenAIToolChatMessage> CreateSpecialistMessages(ToolLoopState state, string role, string task)
        {
            string specialistTask = string.IsNullOrWhiteSpace(task) ? state?.Prompt ?? string.Empty : task.Trim();
            PromptInterpretation interpretation = GetPromptInterpretation(state);
            List<OpenAIToolChatMessage> messages = new List<OpenAIToolChatMessage>
            {
                new OpenAIToolChatMessage
                {
                    role = "developer",
                    content = BuildOpenAISpecialistPrompt(role, BuildToolLoopContext(state, specialistTask, null, role), specialistTask, interpretation)
                },
                new OpenAIToolChatMessage
                {
                    role = "user",
                    content = BuildSpecialistUserPrompt(
                        role,
                        specialistTask,
                        state?.Prompt ?? string.Empty,
                        GetInstructionMemoryForContext(state, state?.Prompt ?? string.Empty),
                        interpretation)
                }
            };
            return messages;
        }

        private static bool TryBuildImplementationResearchBlocker(
            ToolLoopState state,
            AgentAction action,
            string normalizedToolName,
            out string blocker)
        {
            blocker = string.Empty;
            if (state == null || action == null || !IsImplementationCodeWriteAction(action, normalizedToolName))
            {
                return false;
            }

            if (!ShouldRequireExternalImplementationResearch(state, action))
            {
                return false;
            }

            blocker =
                "Tool blocked: unresolved implementation-approach uncertainty still requires external research before writing custom code for this request. " +
                "Call search_web next with a focused query like \"" +
                BuildImplementationResearchQuery(state, action) +
                "\". After that, inspect the relevant project source and retry the smallest compile-safe implementation. " +
                "Do not route into scene setup or Play Mode unless the researched/source-backed solution requires concrete scene or asset wiring.";
            return true;
        }

        private static bool TryBuildCompilerNamespaceRepairBlocker(
            ToolLoopState state,
            AgentAction action,
            string normalizedToolName,
            out string blocker)
        {
            blocker = string.Empty;
            if (state == null || action == null || !IsImplementationCodeWriteAction(action, normalizedToolName))
            {
                return false;
            }

            if (!HasNamespaceOrAssemblyCompilerBlocker(state) || HasNamespaceRepairEvidence(state))
            {
                return false;
            }

            blocker =
                "Tool blocked: compiler diagnostics still indicate an unresolved namespace/type or assembly-reference mismatch. " +
                "Before writing another code variant, inspect the failing source file and gather local evidence with search_unity_api/read_unity_api for the unresolved symbol and search_project/read_text_file for relevant asmdef, asmref, or package manifest files. " +
                "Then choose one namespace/reference strategy, patch once, rebuild once, and read_compiler_diagnostics once.";
            return true;
        }

        private static bool TryBuildFocusedRepairBudgetBlocker(
            ToolLoopState state,
            AgentAction action,
            string normalizedToolName,
            out string blocker)
        {
            blocker = string.Empty;
            if (state == null || action == null || !IsFocusedRepairBudgetedMode(state))
            {
                return false;
            }

            if (IsImplementationCodeWriteAction(action, normalizedToolName))
            {
                string writePath = NormalizeAssetPath(FirstNonEmpty(action.path, action.asset_path));
                bool samePathRewrite =
                    !string.IsNullOrWhiteSpace(writePath) &&
                    string.Equals(writePath, state.LastFocusedRepairWritePath, StringComparison.OrdinalIgnoreCase);
                if (samePathRewrite && state.ConsecutiveWritesToSamePath >= MaxConsecutiveWritesToSamePathBeforeEvidenceReset)
                {
                    blocker =
                        $"Tool blocked: {writePath} has already been rewritten {state.ConsecutiveWritesToSamePath} times in this focused repair loop. " +
                        "Stop generating another variant. Gather new local evidence first or report the concrete blocker instead of changing the same file again.";
                    return true;
                }

                if (state.FocusedRepairCodeWriteCount >= MaxFocusedRepairCodeWritesBeforeCleanCompile)
                {
                    blocker =
                        $"Tool blocked: focused repair already used {state.FocusedRepairCodeWriteCount} code writes without reaching a clean compile. " +
                        "Do not keep editing speculatively. Summarize the exact blocker or gather missing local evidence before any further rewrite.";
                    return true;
                }
            }

            if (string.Equals(normalizedToolName, "rebuild_unity", StringComparison.Ordinal) &&
                state.FocusedRepairRebuildCount >= MaxFocusedRepairRebuildsBeforeCleanCompile)
            {
                blocker =
                    $"Tool blocked: focused repair already used {state.FocusedRepairRebuildCount} rebuilds without converging. " +
                    "Do not rebuild again until you either change the code based on new evidence or report the remaining blocker.";
                return true;
            }

            return false;
        }

        private static bool ShouldRequireExternalImplementationResearch(ToolLoopState state, AgentAction action)
        {
            if (state == null || action == null)
            {
                return false;
            }

            if (HasExternalImplementationResearch(state) || IsCompilerRepairPrompt(state.Prompt))
            {
                return false;
            }

            if (!LooksLikeImplementationRequest(state.Prompt, action))
            {
                return false;
            }

            if (!IsExternalImplementationResearchAvailable())
            {
                return false;
            }

            if (!HasLocalImplementationResearch(state))
            {
                return false;
            }

            if (HasConcreteApiOrCompilerNeed(state, action))
            {
                return false;
            }

            return HasUnresolvedImplementationApproachUncertainty(state, action);
        }

        private static bool TryBuildContextPolicyBlocker(
            ToolLoopState state,
            AgentAction action,
            string normalizedToolName,
            out string blocker)
        {
            blocker = string.Empty;
            if (state == null || action == null)
            {
                return false;
            }

            string normalizedTool = NormalizeActionType(normalizedToolName);
            if (!IsContextPolicyTool(normalizedTool))
            {
                return false;
            }

            string key = BuildContextPolicyKey(normalizedTool, action);
            if (!string.IsNullOrWhiteSpace(key) && state.ContextPolicyKeys.Contains(key))
            {
                blocker =
                    "Context policy blocked duplicate context collection. " +
                    DescribeContextPolicyKey(key) +
                    " was already checked in this run. Use the existing context summary, then make the smallest relevant edit, read compiler diagnostics after a rebuild, or state the exact missing evidence.";
                return true;
            }

            if (!IsFocusedCodeImplementationRequest(state.Prompt) || state.AppliedActions > 0)
            {
                return false;
            }

            if (IsPackageOrApiSourceRead(normalizedTool, action) && !HasConcreteApiOrCompilerNeed(state, action))
            {
                blocker =
                    "Context policy blocked broad package/API source reading for this focused implementation. " +
                    "Read package/API source only after a compiler diagnostic, exact Unity/package member uncertainty, or a concrete source reference proves it is needed. " +
                    "Use the relevant project source already found, make the focused implementation, then let compiler diagnostics guide any API lookup.";
                return true;
            }

            if (string.Equals(normalizedTool, "search_project", StringComparison.Ordinal))
            {
                int count = CountContextPolicyKeys(state, "search_project:");
                if (count >= FocusedContextMaxProjectSearchesBeforeMutation)
                {
                    blocker = BuildFocusedContextBudgetBlocker("project searches", count, FocusedContextMaxProjectSearchesBeforeMutation);
                    return true;
                }
            }
            else if (string.Equals(normalizedTool, "read_text_file", StringComparison.Ordinal))
            {
                int count = CountContextPolicyKeys(state, "read_text_file:");
                if (count >= FocusedContextMaxTextReadsBeforeMutation)
                {
                    blocker = BuildFocusedContextBudgetBlocker("text/source file reads", count, FocusedContextMaxTextReadsBeforeMutation);
                    return true;
                }
            }
            else if (IsDocsOrApiTool(normalizedTool))
            {
                int count = CountContextPolicyKeys(
                    state,
                    "search_unity_docs:",
                    "read_unity_doc:",
                    "search_unity_api:",
                    "read_unity_api:");
                if (count >= FocusedContextMaxDocsApiLookupsBeforeMutation && !HasConcreteApiOrCompilerNeed(state, action))
                {
                    blocker = BuildFocusedContextBudgetBlocker("docs/API lookups", count, FocusedContextMaxDocsApiLookupsBeforeMutation);
                    return true;
                }
            }
            else if (string.Equals(normalizedTool, "search_web", StringComparison.Ordinal))
            {
                int count = CountContextPolicyKeys(state, "search_web:");
                if (count >= FocusedContextMaxWebSearchesBeforeMutation)
                {
                    blocker = BuildFocusedContextBudgetBlocker("web searches", count, FocusedContextMaxWebSearchesBeforeMutation);
                    return true;
                }
            }

            return false;
        }

        private static void RecordContextPolicyTool(
            ToolLoopState state,
            AgentAction action,
            string normalizedToolName,
            string toolResult)
        {
            if (state == null || action == null || IsIssueToolResult(toolResult))
            {
                return;
            }

            string normalizedTool = NormalizeActionType(normalizedToolName);
            if (!IsContextPolicyTool(normalizedTool) || IsReferenceToolFailure(normalizedTool, toolResult))
            {
                return;
            }

            string key = BuildContextPolicyKey(normalizedTool, action);
            if (!string.IsNullOrWhiteSpace(key) && !state.ContextPolicyKeys.Contains(key))
            {
                state.ContextPolicyKeys.Add(key);
            }
        }

        private static bool IsContextPolicyTool(string normalizedTool)
        {
            return string.Equals(normalizedTool, "search_project", StringComparison.Ordinal) ||
                string.Equals(normalizedTool, "read_text_file", StringComparison.Ordinal) ||
                string.Equals(normalizedTool, "inspect_prefab", StringComparison.Ordinal) ||
                string.Equals(normalizedTool, "inspect_runtime_state", StringComparison.Ordinal) ||
                string.Equals(normalizedTool, "search_unity_docs", StringComparison.Ordinal) ||
                string.Equals(normalizedTool, "read_unity_doc", StringComparison.Ordinal) ||
                string.Equals(normalizedTool, "search_unity_api", StringComparison.Ordinal) ||
                string.Equals(normalizedTool, "read_unity_api", StringComparison.Ordinal) ||
                string.Equals(normalizedTool, "search_web", StringComparison.Ordinal);
        }

        private static bool IsDocsOrApiTool(string normalizedTool)
        {
            return string.Equals(normalizedTool, "search_unity_docs", StringComparison.Ordinal) ||
                string.Equals(normalizedTool, "read_unity_doc", StringComparison.Ordinal) ||
                string.Equals(normalizedTool, "search_unity_api", StringComparison.Ordinal) ||
                string.Equals(normalizedTool, "read_unity_api", StringComparison.Ordinal);
        }

        private static bool IsPackageOrApiSourceRead(string normalizedTool, AgentAction action)
        {
            if (string.Equals(normalizedTool, "read_unity_api", StringComparison.Ordinal) ||
                string.Equals(normalizedTool, "search_unity_api", StringComparison.Ordinal))
            {
                return true;
            }

            if (!string.Equals(normalizedTool, "read_text_file", StringComparison.Ordinal))
            {
                return false;
            }

            string path = NormalizeContextPolicyToken(FirstNonEmpty(action?.path, action?.asset_path, action?.value));
            return path.StartsWith("library/packagecache/", StringComparison.Ordinal) ||
                path.StartsWith("packages/", StringComparison.Ordinal);
        }

        private static bool HasConcreteApiOrCompilerNeed(ToolLoopState state, AgentAction action)
        {
            string value = JoinNonEmpty(
                " ",
                state?.Prompt,
                action?.query,
                action?.value,
                action?.path,
                action?.content,
                state?.IssueLog.ToString(),
                state?.ValidationLog.ToString(),
                state?.ActionLog.ToString());
            string normalized = value.ToLowerInvariant();
            return IsCompilerRepairPrompt(value) ||
                ContainsAny(
                    normalized,
                    "compiler diagnostic", "compile diagnostic", "compiler blocker",
                    "script compilation", "tundra build failed", "error cs", "warning cs",
                    "cs0103", "cs0104", "cs0019", "cs0246", "cs0618", "cs1003", "cs1061",
                    "does not contain a definition", "ambiguous reference", "missing member",
                    "read-only", "setter", "overload", "public member", "exact type",
                    "exact api", "unityengine.", "unityeditor.", "unity.", "package api");
        }

        private static string BuildContextPolicyKey(string normalizedTool, AgentAction action)
        {
            string value;
            switch (normalizedTool)
            {
                case "read_text_file":
                case "read_unity_doc":
                case "read_unity_api":
                    value = FirstNonEmpty(action?.path, action?.asset_path, action?.value, action?.query);
                    break;
                case "inspect_prefab":
                    value = FirstNonEmpty(action?.path, action?.asset_path, action?.target, action?.name);
                    break;
                case "inspect_runtime_state":
                    value = JoinNonEmpty(" ", action?.query, action?.target, action?.name, action?.component);
                    break;
                default:
                    value = FirstNonEmpty(action?.query, action?.value, action?.content, action?.name, action?.target);
                    break;
            }

            value = NormalizeContextPolicyToken(value);
            if (string.IsNullOrWhiteSpace(value))
            {
                return string.Empty;
            }

            return normalizedTool + ":" + value;
        }

        private static string NormalizeContextPolicyToken(string value)
        {
            if (string.IsNullOrWhiteSpace(value))
            {
                return string.Empty;
            }

            string normalized = value.Trim().Replace('\\', '/').ToLowerInvariant();
            normalized = Regex.Replace(normalized, @"\s+", " ");
            return normalized.Length <= 220 ? normalized : normalized.Substring(0, 220);
        }

        private static int CountContextPolicyKeys(ToolLoopState state, params string[] prefixes)
        {
            if (state == null || prefixes == null || prefixes.Length == 0)
            {
                return 0;
            }

            int count = 0;
            foreach (string key in state.ContextPolicyKeys)
            {
                if (string.IsNullOrWhiteSpace(key))
                {
                    continue;
                }

                foreach (string prefix in prefixes)
                {
                    if (!string.IsNullOrWhiteSpace(prefix) &&
                        key.StartsWith(prefix, StringComparison.OrdinalIgnoreCase))
                    {
                        count++;
                        break;
                    }
                }
            }

            return count;
        }

        private static string BuildFocusedContextBudgetBlocker(string category, int currentCount, int maxCount)
        {
            return "Context policy blocked extra exploration for this focused implementation. " +
                $"The run already used {currentCount} {category} before the first edit; the budget is {maxCount}. " +
                "Stop gathering broad context and either make the smallest scoped code change using the existing context, read compiler diagnostics after a rebuild, or return the exact missing evidence that prevents an edit.";
        }

        private static string DescribeContextPolicyKey(string key)
        {
            if (string.IsNullOrWhiteSpace(key))
            {
                return "This context item";
            }

            int colon = key.IndexOf(':');
            if (colon <= 0 || colon >= key.Length - 1)
            {
                return "Context item " + key;
            }

            string tool = key.Substring(0, colon);
            string value = key.Substring(colon + 1);
            return tool + " " + CompactOneLine(value, 120);
        }

        private static bool HasExternalImplementationResearch(ToolLoopState state)
        {
            if (state == null)
            {
                return false;
            }

            return state.ExternalImplementationResearchAttempted ||
                ToolLogContains(state.ActionLog, "search_web") ||
                ToolLogContains(state.ContextLog, "External web search:");
        }

        private static bool IsFocusedRepairBudgetedMode(ToolLoopState state)
        {
            if (state == null)
            {
                return false;
            }

            return IsCompilerRepairPrompt(state.Prompt) ||
                !string.IsNullOrWhiteSpace(state.LastCompilerFailureSummary) ||
                state.RepeatedCompilerFailureCount > 0;
        }

        private static void RecordFocusedRepairToolProgress(
            ToolLoopState state,
            AgentAction action,
            string normalizedToolName,
            string toolResult)
        {
            if (state == null || string.IsNullOrWhiteSpace(normalizedToolName) || IsIssueToolResult(toolResult))
            {
                return;
            }

            if (string.Equals(normalizedToolName, "read_compiler_diagnostics", StringComparison.Ordinal))
            {
                string compilerSummary = SummarizeCompilerDiagnostics(toolResult, out bool hasCompilerError);
                if (!hasCompilerError)
                {
                    ResetFocusedRepairMutationBudget(state);
                }

                return;
            }

            if (IsReferenceTool(normalizedToolName) || IsDocsOrApiTool(normalizedToolName))
            {
                state.LastFocusedRepairWritePath = string.Empty;
                state.ConsecutiveWritesToSamePath = 0;
                return;
            }

            if (!IsFocusedRepairBudgetedMode(state))
            {
                return;
            }

            if (IsImplementationCodeWriteAction(action, normalizedToolName))
            {
                state.FocusedRepairCodeWriteCount++;
                string writePath = NormalizeAssetPath(FirstNonEmpty(action.path, action.asset_path));
                if (!string.IsNullOrWhiteSpace(writePath) &&
                    string.Equals(writePath, state.LastFocusedRepairWritePath, StringComparison.OrdinalIgnoreCase))
                {
                    state.ConsecutiveWritesToSamePath++;
                }
                else
                {
                    state.LastFocusedRepairWritePath = writePath;
                    state.ConsecutiveWritesToSamePath = 1;
                }

                return;
            }

            if (string.Equals(normalizedToolName, "rebuild_unity", StringComparison.Ordinal))
            {
                state.FocusedRepairRebuildCount++;
            }
        }

        private static bool HasNamespaceOrAssemblyCompilerBlocker(ToolLoopState state)
        {
            string value = JoinNonEmpty(
                " ",
                state?.LastCompilerFailureSummary,
                state?.IssueLog.ToString(),
                state?.ValidationLog.ToString());
            string normalized = value.ToLowerInvariant();
            if (string.IsNullOrWhiteSpace(normalized))
            {
                return false;
            }

            return ContainsAny(
                normalized,
                "error cs0246",
                "type or namespace name",
                "namespace name",
                "assembly reference",
                "are you missing a using directive");
        }

        private static bool HasNamespaceRepairEvidence(ToolLoopState state)
        {
            if (state == null)
            {
                return false;
            }

            if (CountContextPolicyKeys(state, "search_unity_api:", "read_unity_api:") > 0)
            {
                return true;
            }

            foreach (string key in state.ContextPolicyKeys)
            {
                if (string.IsNullOrWhiteSpace(key) ||
                    !key.StartsWith("read_text_file:", StringComparison.OrdinalIgnoreCase))
                {
                    continue;
                }

                if (ContainsAny(
                        key,
                        ".asmdef",
                        ".asmref",
                        "packages/manifest.json",
                        "packages/packages-lock.json",
                        "library/packagecache/",
                        "/package.json"))
                {
                    return true;
                }
            }

            return ToolLogContains(state.ActionLog, "search_unity_api") ||
                ToolLogContains(state.ActionLog, "read_unity_api") ||
                ToolLogContains(state.ActionLog, ".asmdef") ||
                ToolLogContains(state.ActionLog, ".asmref") ||
                ToolLogContains(state.ActionLog, "Packages/manifest.json") ||
                ToolLogContains(state.ActionLog, "Packages/packages-lock.json") ||
                ToolLogContains(state.ActionLog, "Library/PackageCache/");
        }

        private static bool IsExternalImplementationResearchAvailable()
        {
            return !string.IsNullOrWhiteSpace(GetTavilyApiKey());
        }

        private static bool HasLocalImplementationResearch(ToolLoopState state)
        {
            if (state == null)
            {
                return false;
            }

            return CountContextPolicyKeys(
                       state,
                       "search_project:",
                       "read_text_file:",
                       "search_unity_docs:",
                       "read_unity_doc:",
                       "search_unity_api:",
                       "read_unity_api:",
                       "inspect_prefab:") > 0 ||
                ToolLogContains(state.ActionLog, "search_project") ||
                ToolLogContains(state.ActionLog, "read_text_file") ||
                ToolLogContains(state.ActionLog, "search_unity_docs") ||
                ToolLogContains(state.ActionLog, "read_unity_doc") ||
                ToolLogContains(state.ActionLog, "search_unity_api") ||
                ToolLogContains(state.ActionLog, "read_unity_api");
        }

        private static bool HasUnresolvedImplementationApproachUncertainty(ToolLoopState state, AgentAction action)
        {
            string value = JoinNonEmpty(
                " ",
                state?.Prompt,
                action?.query,
                action?.value,
                action?.content,
                action?.path,
                action?.component,
                state?.PromptInterpretationSummary);
            string normalized = value.ToLowerInvariant();
            if (string.IsNullOrWhiteSpace(normalized))
            {
                return false;
            }

            return ContainsAny(
                normalized,
                "best way", "best approach", "best practice", "recommended", "recommendation",
                "architecture", "architectural", "approach", "pattern", "design",
                "framework", "pipeline", "strategy", "scalable", "robust",
                "production-ready", "from scratch", "generic", "portable",
                "package", "plugin", "third-party", "asset store",
                "compatibility", "migration", "upgrade", "interop", "integrate", "integration");
        }

        private static bool IsImplementationCodeWriteAction(AgentAction action, string normalizedToolName)
        {
            normalizedToolName = NormalizeActionType(normalizedToolName);
            if (string.Equals(normalizedToolName, "write_csharp_script", StringComparison.Ordinal))
            {
                return true;
            }

            if (!string.Equals(normalizedToolName, "write_text_file", StringComparison.Ordinal))
            {
                return false;
            }

            string path = FirstNonEmpty(action?.path, action?.asset_path);
            string extension = string.IsNullOrWhiteSpace(path)
                ? string.Empty
                : Path.GetExtension(path).ToLowerInvariant();
            switch (extension)
            {
                case ".cs":
                case ".shader":
                case ".hlsl":
                case ".compute":
                case ".cginc":
                case ".asmdef":
                case ".asmref":
                case ".uxml":
                case ".uss":
                    return true;
                default:
                    string content = action?.content ?? string.Empty;
                    return content.IndexOf("using UnityEngine", StringComparison.OrdinalIgnoreCase) >= 0 ||
                        content.IndexOf("class ", StringComparison.OrdinalIgnoreCase) >= 0;
            }
        }

        private static bool LooksLikeImplementationRequest(string prompt, AgentAction action)
        {
            string value = (prompt ?? string.Empty) + " " +
                FirstNonEmpty(action?.query, action?.value, action?.name, action?.content, action?.path, action?.component);
            string normalized = value.ToLowerInvariant();
            if (string.IsNullOrWhiteSpace(normalized))
            {
                return false;
            }

            if (ContainsAny(normalized, "trivial", "typo", "rename", "formatting only", "comment only"))
            {
                return false;
            }

            return LooksLikeDirectChangeRequest(normalized) ||
                ContainsAny(
                    normalized,
                    "implement", "implementation", "feature", "mechanic", "system", "effect",
                    "behavior", "behaviour", "workflow", "module", "service", "manager",
                    "component", "controller", "runtime", "play mode", "animation", "physics",
                    "input", "camera", "shader", "post processing");
        }

        private static bool IsCompilerRepairPrompt(string prompt)
        {
            string normalized = (prompt ?? string.Empty).ToLowerInvariant();
            return ContainsAny(
                normalized,
                "compiler error", "compile error", "compilation error", "script compilation",
                "error cs", "warning cs", "cs0103", "cs0104", "cs0019", "cs0246", "cs0618", "cs1061",
                "does not contain a definition", "ambiguous reference", "missing using directive",
                "fix compile", "fix compiler", "project recompiles");
        }

        private static string BuildImplementationResearchQuery(ToolLoopState state, AgentAction action)
        {
            string prompt = CompactOneLine(state?.Prompt ?? string.Empty, 190);
            string target = CompactOneLine(
                FirstNonEmpty(action?.name, action?.component, action?.target, action?.path, action?.query, action?.value),
                80);
            string query = JoinNonEmpty(
                " ",
                "Unity",
                prompt,
                target,
                "modular implementation best practices");
            return CompactOneLine(query, 260);
        }

        private static string BeginAgentHandoff(ToolLoopState state, OpenAIToolCall toolCall, AgentAction action)
        {
            string role = NormalizeAgentRole(FirstNonEmpty(action.role, action.target, action.name, action.value));
            if (IsManagerAgentRole(role))
            {
                role = AgentRoleDefault;
            }

            string task = FirstNonEmpty(action.content, action.query, action.value, action.path, state.Prompt);
            if (string.IsNullOrWhiteSpace(task))
            {
                task = state.Prompt ?? string.Empty;
            }

            state.pendingHandoffToolCall = toolCall;
            state.pendingHandoffRole = role;
            state.pendingHandoffTask = task.Trim();
            state.specialistMessages[role] = CreateSpecialistMessages(state, role, state.pendingHandoffTask);
            state.ActiveAgentRole = role;
            return $"Delegated to {GetAgentDisplayName(role)}:\n{state.pendingHandoffTask}";
        }

        private static bool TryBuildSceneFirstHandoffBlocker(ToolLoopState state, AgentAction action, out string blocker)
        {
            blocker = string.Empty;
            if (state == null || action == null)
            {
                return false;
            }

            string requestedRole = NormalizeAgentRole(FirstNonEmpty(action.role, action.target, action.name, action.value));
            if (!string.Equals(requestedRole, AgentRoleWorker, StringComparison.Ordinal))
            {
                return false;
            }

            if (!RequiresSceneOrAssetSetupBeforeWorker(state))
            {
                return false;
            }

            if (state.SceneOrAssetSetupCompleted)
            {
                return false;
            }

            blocker =
                "Tool blocked: scene or asset setup is required before this worker task. " +
                "Delegate to scene_setup or asset_management only for the concrete in-editor objects, prefabs, references, cameras, UI, or asset wiring that this request explicitly depends on. " +
                "For focused reusable code/module work, use worker first after source inspection instead of forcing scene setup.";
            return true;
        }

        private static bool TryBuildRedundantHandoffBlocker(ToolLoopState state, AgentAction action, out string blocker)
        {
            blocker = string.Empty;
            if (state == null || action == null)
            {
                return false;
            }

            if (!TryGetHandoffRoleAndTask(state, action, out string role, out string task))
            {
                return false;
            }

            if (TryFindMatchingCompletedHandoff(state, role, task, out string previousTask))
            {
                blocker =
                    "Tool blocked: redundant specialist handoff. " +
                    $"{GetAgentDisplayName(role)} already returned for a matching task and the project has not changed since that result. " +
                    "Use the previous specialist result instead of delegating the same work again. " +
                    "Only hand off again if the next task is materially different or a concrete mutation/validation changed the project state first. " +
                    $"Previous matching task: {CompactOneLine(previousTask, 220)}";
                return true;
            }

            return false;
        }

        private static bool TryGetHandoffRoleAndTask(ToolLoopState state, AgentAction action, out string role, out string task)
        {
            role = NormalizeAgentRole(FirstNonEmpty(action?.role, action?.target, action?.name, action?.value));
            if (IsManagerAgentRole(role))
            {
                role = AgentRoleDefault;
            }

            task = FirstNonEmpty(action?.content, action?.query, action?.value, action?.path, state?.Prompt);
            if (string.IsNullOrWhiteSpace(task))
            {
                task = state?.Prompt ?? string.Empty;
            }

            task = task.Trim();
            return !string.IsNullOrWhiteSpace(role) && !string.IsNullOrWhiteSpace(task);
        }

        private static void RecordCompletedHandoff(ToolLoopState state, string role, string task)
        {
            if (state == null || string.IsNullOrWhiteSpace(role) || string.IsNullOrWhiteSpace(task))
            {
                return;
            }

            string entry = BuildCompletedHandoffEntry(state.AppliedActions, NormalizeAgentRole(role), task);
            if (!string.IsNullOrWhiteSpace(entry) && !state.CompletedHandoffEntries.Contains(entry))
            {
                state.CompletedHandoffEntries.Add(entry);
            }
        }

        private static bool TryFindMatchingCompletedHandoff(
            ToolLoopState state,
            string role,
            string task,
            out string previousTask)
        {
            previousTask = string.Empty;
            if (state == null || state.CompletedHandoffEntries.Count == 0)
            {
                return false;
            }

            role = NormalizeAgentRole(role);
            foreach (string entry in state.CompletedHandoffEntries)
            {
                if (!TryParseCompletedHandoffEntry(entry, out int appliedActions, out string entryRole, out string entryTask))
                {
                    continue;
                }

                if (appliedActions != state.AppliedActions ||
                    !string.Equals(entryRole, role, StringComparison.Ordinal))
                {
                    continue;
                }

                if (HandoffTasksAreSimilar(entryTask, task))
                {
                    previousTask = entryTask;
                    return true;
                }
            }

            return false;
        }

        private static string BuildCompletedHandoffEntry(int appliedActions, string role, string task)
        {
            string normalizedRole = NormalizeAgentRole(role);
            string normalizedTask = NormalizeHandoffTaskText(task);
            if (string.IsNullOrWhiteSpace(normalizedRole) || string.IsNullOrWhiteSpace(normalizedTask))
            {
                return string.Empty;
            }

            return appliedActions.ToString(CultureInfo.InvariantCulture) + "|" + normalizedRole + "|" + normalizedTask;
        }

        private static bool TryParseCompletedHandoffEntry(string entry, out int appliedActions, out string role, out string task)
        {
            appliedActions = 0;
            role = string.Empty;
            task = string.Empty;
            if (string.IsNullOrWhiteSpace(entry))
            {
                return false;
            }

            string[] parts = entry.Split(new[] { '|' }, 3);
            if (parts.Length != 3 ||
                !int.TryParse(parts[0], NumberStyles.Integer, CultureInfo.InvariantCulture, out appliedActions))
            {
                return false;
            }

            role = NormalizeAgentRole(parts[1]);
            task = parts[2] ?? string.Empty;
            return !string.IsNullOrWhiteSpace(role) && !string.IsNullOrWhiteSpace(task);
        }

        private static string NormalizeHandoffTaskText(string task)
        {
            if (string.IsNullOrWhiteSpace(task))
            {
                return string.Empty;
            }

            string compact = NormalizeIntentText(task);
            compact = Regex.Replace(compact, @"\s+", " ").Trim();
            return compact.Length <= 600 ? compact : compact.Substring(0, 600);
        }

        private static bool HandoffTasksAreSimilar(string previousTask, string nextTask)
        {
            string previous = NormalizeHandoffTaskText(previousTask);
            string next = NormalizeHandoffTaskText(nextTask);
            if (string.IsNullOrWhiteSpace(previous) || string.IsNullOrWhiteSpace(next))
            {
                return false;
            }

            if (string.Equals(previous, next, StringComparison.Ordinal))
            {
                return true;
            }

            List<string> previousTokens = ExtractSearchTokens(previous);
            List<string> nextTokens = ExtractSearchTokens(next);
            if (previousTokens.Count == 0 || nextTokens.Count == 0)
            {
                return false;
            }

            int intersection = 0;
            foreach (string token in previousTokens)
            {
                if (nextTokens.Contains(token))
                {
                    intersection++;
                }
            }

            int union = previousTokens.Count + nextTokens.Count - intersection;
            if (union <= 0)
            {
                return false;
            }

            float similarity = intersection / (float)union;
            return intersection >= 5 && similarity >= 0.72f;
        }

        private static bool RequiresSceneOrAssetSetupBeforeWorker(ToolLoopState state)
        {
            if (state == null)
            {
                return false;
            }

            string prompt = state.Prompt ?? string.Empty;
            if (string.IsNullOrWhiteSpace(prompt))
            {
                return false;
            }

            if (!LooksLikeChangeOrFeatureRequest(prompt))
            {
                return false;
            }

            if (IsFocusedCodeImplementationRequest(prompt))
            {
                return false;
            }

            string normalized = NormalizeIntentText(prompt);
            return IsPrefabOrAssetWorkflowRequest(normalized) ||
                IsSceneCompositionRequest(normalized) ||
                IsVisualOrSceneBearingRequest(prompt) ||
                IsRuntimeVerificationRequest(prompt);
        }

        private static ToolLoopTurnResult CompleteSpecialistHandoff(ToolLoopState state, string specialistMessage, Action<string> progress)
        {
            string role = NormalizeAgentRole(state.ActiveAgentRole);
            string result = string.IsNullOrWhiteSpace(specialistMessage)
                ? $"{GetAgentDisplayName(role)} completed without a final message."
                : specialistMessage.Trim();

            progress?.Invoke($"{GetAgentDisplayName(role)} returned to manager");
            if (state.pendingHandoffToolCall != null)
            {
                string updatedContext = ClampText(
                    BuildToolLoopContext(state, null, AgentRoleManager),
                    MaxUpdatedContextInToolResultChars);
                state.messages.Add(BuildToolResultMessage(
                    state.pendingHandoffToolCall,
                    $"{GetAgentDisplayName(role)} result:\n{result}\n\nUpdated Unity context for manager review:\n{updatedContext}"));
            }
            else
            {
                state.messages.Add(new OpenAIToolChatMessage
                {
                    role = "user",
                    content = $"{GetAgentDisplayName(role)} result:\n{result}"
                });
            }

            AppendToolLogLine(state.AgentLog, state.HandoffCount, role, $"{GetAgentDisplayName(role)} completed:\n{result}");
            RecordCompletedHandoff(state, role, state.pendingHandoffTask);
            if (string.Equals(role, AgentRoleSceneSetup, StringComparison.Ordinal) ||
                string.Equals(role, AgentRoleAssetManagement, StringComparison.Ordinal))
            {
                state.SceneOrAssetSetupCompleted = true;
            }

            state.ActiveAgentRole = AgentRoleManager;
            state.pendingHandoffToolCall = null;
            state.pendingHandoffRole = string.Empty;
            state.pendingHandoffTask = string.Empty;
            SaveResumableToolLoopState(state);

            return new ToolLoopTurnResult
            {
                IsComplete = false,
                ToolName = role,
                ToolResult = result,
                AgentRole = AgentRoleManager,
                ExecutedTool = false
            };
        }

        private static bool IsManagerAgentRole(string role)
        {
            return string.IsNullOrWhiteSpace(role) ||
                string.Equals(role.Trim(), AgentRoleManager, StringComparison.OrdinalIgnoreCase) ||
                string.Equals(role.Trim(), "orchestrator", StringComparison.OrdinalIgnoreCase);
        }

        private static bool TryEnforceStrictCompletionLoop(
            ToolLoopState state,
            string proposedFinalMessage,
            Action<string> progress,
            out ToolLoopTurnResult deferredResult)
        {
            deferredResult = null;
            if (state == null)
            {
                return false;
            }

            AppendAutomaticVerificationIssues(state);
            string[] blockers = GetStrictCompletionBlockers(state, proposedFinalMessage);
            if (blockers.Length == 0)
            {
                state.StrictCompletionRetryCount = 0;
                state.RepeatedStrictGateWithoutMutationCount = 0;
                state.StrictCompletionRecoveryEscalationCount = 0;
                state.LastStrictGateAppliedActions = state.AppliedActions;
                return false;
            }

            int nextRetryCount = state.StrictCompletionRetryCount + 1;
            if (state.AppliedActions <= state.LastStrictGateAppliedActions)
            {
                state.RepeatedStrictGateWithoutMutationCount++;
            }
            else
            {
                state.RepeatedStrictGateWithoutMutationCount = 0;
            }

            state.LastStrictGateAppliedActions = state.AppliedActions;
            bool retryLimitReached = nextRetryCount > MaxStrictCompletionRetries;
            bool mutationStalled = state.RepeatedStrictGateWithoutMutationCount > MaxStrictCompletionRetriesWithoutMutation;
            if (retryLimitReached || mutationStalled)
            {
                string reason = mutationStalled
                    ? "Strict completion recovery: the agent repeatedly tried to finish without a verified mutating Unity action."
                    : "Strict completion recovery: the agent repeatedly tried to finish before all completion gates were satisfied.";
                if (TryEscalateStrictCompletionRecovery(state, blockers, reason, mutationStalled, progress, out deferredResult))
                {
                    return true;
                }

                state.FinalMessage = BuildStrictCompletionStoppedMessage(blockers);
                AppendUserFacingLine(state.IssueLog, "Strict completion gate exhausted recovery attempts without enough progress.");
                SaveResumableToolLoopState(state);
                return false;
            }

            state.StrictCompletionRetryCount = nextRetryCount;
            progress?.Invoke($"Strict completion gate triggered ({state.StrictCompletionRetryCount})");
            List<OpenAIToolChatMessage> activeMessages = GetActiveToolLoopMessages(state);
            activeMessages.Add(new OpenAIToolChatMessage
            {
                role = "user",
                content = BuildStrictCompletionContinuationMessage(state, blockers)
            });
            SaveResumableToolLoopState(state);
            deferredResult = new ToolLoopTurnResult
            {
                IsComplete = false,
                ToolName = "strict_completion_gate",
                ToolResult = string.Join(" | ", blockers),
                AgentRole = state.ActiveAgentRole,
                ExecutedTool = false
            };
            return true;
        }

        private static bool TryEscalateStrictCompletionRecovery(
            ToolLoopState state,
            string[] blockers,
            string reason,
            bool requireMutatingTool,
            Action<string> progress,
            out ToolLoopTurnResult deferredResult)
        {
            deferredResult = null;
            if (state == null || state.StrictCompletionRecoveryEscalationCount >= MaxStrictCompletionRecoveryEscalations)
            {
                return false;
            }

            state.StrictCompletionRecoveryEscalationCount++;
            state.StrictCompletionRetryCount = 0;
            state.RepeatedStrictGateWithoutMutationCount = 0;
            state.LastStrictGateAppliedActions = state.AppliedActions;

            progress?.Invoke($"Strict completion gate escalated recovery ({state.StrictCompletionRecoveryEscalationCount})");
            ForceCompactActiveToolLoopMessages(state, reason);
            List<OpenAIToolChatMessage> activeMessages = GetActiveToolLoopMessages(state);
            activeMessages.Add(new OpenAIToolChatMessage
            {
                role = "user",
                content = BuildStrictCompletionRecoveryMessage(state, blockers, reason, requireMutatingTool)
            });

            SaveResumableToolLoopState(state);
            deferredResult = new ToolLoopTurnResult
            {
                IsComplete = false,
                ToolName = "strict_completion_gate",
                ToolResult = "Escalated recovery: " + string.Join(" | ", blockers ?? Array.Empty<string>()),
                AgentRole = state.ActiveAgentRole,
                ExecutedTool = false
            };
            return true;
        }

        private static string BuildStrictCompletionStoppedMessage(string[] blockers)
        {
            StringBuilder builder = new StringBuilder();
            builder.AppendLine("Incomplete. I exhausted the recovery attempts for the completion gate.");
            if (blockers != null && blockers.Length > 0)
            {
                builder.AppendLine();
                builder.AppendLine("Still blocking:");
                foreach (string blocker in blockers)
                {
                    if (!string.IsNullOrWhiteSpace(blocker))
                    {
                        builder.AppendLine("- " + blocker.Trim());
                    }
                }
            }

            return builder.ToString().TrimEnd();
        }

        private static string BuildStrictCompletionRecoveryMessage(
            ToolLoopState state,
            string[] blockers,
            string reason,
            bool requireMutatingTool)
        {
            StringBuilder builder = new StringBuilder();
            builder.AppendLine("Recovery mode. Do not finish, do not summarize, and do not mark tasks blocked yet.");
            if (!string.IsNullOrWhiteSpace(reason))
            {
                builder.AppendLine(reason.Trim());
            }

            builder.AppendLine();
            builder.AppendLine("Blocking conditions:");
            foreach (string blocker in blockers ?? Array.Empty<string>())
            {
                if (!string.IsNullOrWhiteSpace(blocker))
                {
                    builder.AppendLine("- " + blocker.Trim());
                }
            }

            builder.AppendLine();
            string checklist = BuildRequestSpecificCompletionChecklist(state?.Prompt);
            if (!string.IsNullOrWhiteSpace(checklist))
            {
                builder.AppendLine("Request-specific acceptance checklist:");
                builder.Append(checklist);
                builder.AppendLine();
                builder.AppendLine();
            }

            if (state != null && state.TaskPlan.Count > 0)
            {
                builder.AppendLine("Current structured task plan:");
                builder.AppendLine(FormatTaskPlanForContext(state));
                builder.AppendLine();
            }

            if (requireMutatingTool)
            {
                builder.AppendLine("The next assistant response must call one concrete mutating Unity tool. Do not call search/read/validate/select/handoff/update_task_status next unless a compiler error or unavailable API makes mutation impossible.");
                builder.AppendLine("Prefer a semantic mutating workflow for composite work: ensure_unity_workflow, repair_scene_relationships, or setup_urp_post_processing. For precise work, use create_object, set_component_property, set_object_property, set_transform, create_sprite_asset, create_unity_asset, instantiate_prefab, add_component, save_scene, or save_assets.");
            }
            else
            {
                builder.AppendLine("The next assistant response must call the one tool that directly closes the highest-priority blocker. Avoid another broad search or status-only handoff unless the blocker specifically requires it.");
            }

            builder.AppendLine("After the mutating or repair action, inspect the affected scene/prefab/runtime state and validate before finishing.");
            return builder.ToString().TrimEnd();
        }

        private static string[] GetStrictCompletionBlockers(ToolLoopState state, string proposedFinalMessage)
        {
            List<string> blockers = new List<string>();
            if (state == null)
            {
                return blockers.ToArray();
            }

            bool isChangeRequest = LooksLikeChangeOrFeatureRequest(state.Prompt);
            bool hasMutations = state.AppliedActions > 0;
            bool hasValidation = state.ValidationLog.Length > 0 || ToolLogContains(state.ActionLog, "validate_scene");
            bool hasVisualValidation = ToolLogContains(state.ActionLog, "capture_game_view") || ToolLogContains(state.ActionLog, "capture_game_view_diagnostics");
            bool visualRequest = IsVisualOrSceneBearingRequest(state.Prompt);
            bool runtimeRequest = IsRuntimeVerificationRequest(state.Prompt);
            bool hasPlayMode = ToolLogContains(state.ActionLog, "enter_play_mode");
            bool hasRuntimeInspection = ToolLogContains(state.ActionLog, "inspect_runtime_state");
            bool hasExitedPlayMode = ToolLogContains(state.ActionLog, "exit_play_mode");
            bool prefabOrAssetOnlyEdit = IsPrefabOrAssetOnlyEditRequest(state.Prompt);
            bool focusedCodeRequest = IsFocusedCodeImplementationRequest(state.Prompt);
            bool hasCompileDiagnostics = ToolLogContains(state.ActionLog, "read_compiler_diagnostics") ||
                state.ValidationLog.ToString().IndexOf("Compiler diagnostics", StringComparison.OrdinalIgnoreCase) >= 0;

            if (HasCriticalBlockingIssues(state))
            {
                blockers.Add("Critical compiler, tool, or request issues are still recorded.");
            }

            AppendTaskPlanBlockers(state, blockers);

            if (isChangeRequest && !hasMutations)
            {
                blockers.Add("This change request has not produced any verified mutating Unity action yet.");
            }

            if (isChangeRequest &&
                hasMutations &&
                !hasValidation &&
                !(focusedCodeRequest && hasCompileDiagnostics))
            {
                blockers.Add("Non-trivial project changes ran without final validation.");
            }

            if (visualRequest && hasMutations && !hasVisualValidation && !prefabOrAssetOnlyEdit)
            {
                blockers.Add("Visual or scene-bearing work ran without Game view verification.");
            }

            if (runtimeRequest && hasMutations && !hasPlayMode && !prefabOrAssetOnlyEdit)
            {
                blockers.Add("Runtime/gameplay work ran without entering Play Mode.");
            }

            if (runtimeRequest && hasPlayMode && !hasRuntimeInspection && !prefabOrAssetOnlyEdit)
            {
                blockers.Add("Play Mode ran without inspect_runtime_state, so runtime objects and wiring were not verified.");
            }

            if (LooksLikeSmokePlaytestRequest(state.Prompt) && hasPlayMode && !hasExitedPlayMode)
            {
                blockers.Add("Play Mode was entered for a smoke test but not exited before finishing.");
            }

            if (StartsWithCompletionWord(proposedFinalMessage) && blockers.Count > 0)
            {
                blockers.Insert(0, "The agent attempted to finish before the completion gates were satisfied.");
            }

            return blockers.ToArray();
        }

        private static void AppendTaskPlanBlockers(ToolLoopState state, List<string> blockers)
        {
            if (state == null || blockers == null)
            {
                return;
            }

            if (IsFocusedCodeImplementationRequest(state.Prompt))
            {
                return;
            }

            if (state.TaskPlan.Count == 0)
            {
                if (LooksLikeChangeOrFeatureRequest(state.Prompt) && state.HandoffCount > 0)
                {
                    blockers.Add("The manager delegated specialist work without recording a structured task plan.");
                }

                return;
            }

            foreach (AgentTaskRecord task in state.TaskPlan)
            {
                if (task == null)
                {
                    continue;
                }

                string status = NormalizeTaskStatus(task.status);
                if (IsTerminalTaskStatus(status))
                {
                    continue;
                }

                string label = FirstNonEmpty(task.id, task.title, "task");
                blockers.Add($"Task plan item '{label}' is still {status}.");
            }
        }

        private static bool HasCriticalBlockingIssues(ToolLoopState state)
        {
            if (state == null || state.IssueLog.Length == 0)
            {
                return false;
            }

            string issues = state.IssueLog.ToString().ToLowerInvariant();
            return issues.IndexOf("compiler blocker", StringComparison.Ordinal) >= 0 ||
                issues.IndexOf("script compilation error", StringComparison.Ordinal) >= 0 ||
                issues.IndexOf("tundra build failed", StringComparison.Ordinal) >= 0 ||
                issues.IndexOf("tool failed:", StringComparison.Ordinal) >= 0 ||
                issues.IndexOf("openai request failed", StringComparison.Ordinal) >= 0 ||
                issues.IndexOf("authentication failed", StringComparison.Ordinal) >= 0;
        }

        private static string BuildStrictCompletionContinuationMessage(ToolLoopState state, string[] blockers)
        {
            StringBuilder builder = new StringBuilder();
            builder.AppendLine("Do not finish yet. Strict completion gates are not satisfied.");
            builder.AppendLine();
            builder.AppendLine("Blocking conditions:");
            foreach (string blocker in blockers)
            {
                if (!string.IsNullOrWhiteSpace(blocker))
                {
                    builder.AppendLine("- " + blocker.Trim());
                }
            }

            builder.AppendLine();
            string checklist = BuildRequestSpecificCompletionChecklist(state?.Prompt);
            if (!string.IsNullOrWhiteSpace(checklist))
            {
                builder.AppendLine("Request-specific acceptance checklist:");
                builder.Append(checklist);
                builder.AppendLine();
                builder.AppendLine();
            }

            if (state != null && state.TaskPlan.Count > 0)
            {
                builder.AppendLine("Current structured task plan:");
                builder.AppendLine(FormatTaskPlanForContext(state));
                builder.AppendLine();
            }

            builder.AppendLine("Continue working until the blockers are resolved with concrete Unity actions and verification. Do not just summarize, restate the plan, mark tasks blocked, or return a final/status-only message.");
            builder.AppendLine("The next assistant response must call a tool. Choose the tool that directly closes the blocker: create or wire scene objects, set component references, create/inspect prefabs/assets, enable render settings, enter Play Mode, inspect runtime state, capture Game view, or validate again.");
            builder.AppendLine("For repeated composite-workflow blockers, prefer ensure_unity_workflow, repair_scene_relationships, or setup_urp_post_processing over more searching or raw serialized-property guessing.");
            builder.AppendLine("Validation warnings about empty arrays, unassigned object references, missing matching assets, missing matching scene objects, inactive post-processing, or runtime verification gaps require creating/finding/assigning/verifying the missing resource before finishing.");
            builder.AppendLine("Only report a blocker to the user after a concrete tool attempt fails for an external reason such as authentication, unavailable Unity API, missing permission, or repeated identical tool-call rejection.");
            builder.AppendLine("Re-run validation before finishing. For scene or visual work, capture the Game view before finishing. For runtime/gameplay work, use inspect_runtime_state after Play Mode starts.");
            if (state != null && state.StrictCompletionRetryCount >= 3)
            {
                builder.AppendLine("You have already tried to finish multiple times. Escalate effort now: call a semantic mutating workflow tool or delegate to the exact specialist needed, then verify the result.");
            }

            if (state != null && state.RepeatedStrictGateWithoutMutationCount >= 2)
            {
                builder.AppendLine("No verified mutating Unity action has happened since the recent strict-gate attempts. If the request is a change request, the next useful step should be a concrete mutating Unity tool, not another final summary.");
            }

            return builder.ToString().TrimEnd();
        }

        private static bool LooksLikeChangeOrFeatureRequest(string prompt)
        {
            string normalized = NormalizeIntentText(prompt);
            if (string.IsNullOrWhiteSpace(normalized))
            {
                return false;
            }

            return LooksLikeDirectChangeRequest(normalized) ||
                HasBroadFeatureIntent(normalized) ||
                IsPrefabOrAssetWorkflowRequest(normalized) ||
                IsSceneCompositionRequest(normalized) ||
                IsRuntimeBehaviorRequest(normalized) ||
                IsVisualRenderRequest(normalized);
        }

        private static bool IsFocusedCodeImplementationRequest(string prompt)
        {
            string normalized = NormalizeIntentText(prompt);
            if (string.IsNullOrWhiteSpace(normalized))
            {
                return false;
            }

            if (!LooksLikeDirectChangeRequest(normalized))
            {
                return false;
            }

            if (IsPrefabOrAssetWorkflowRequest(normalized) ||
                IsSceneCompositionRequest(normalized) ||
                IsVisualRenderRequest(normalized) ||
                IsRuntimeVerificationRequest(prompt) ||
                LooksLikeWholeGameRequest(normalized))
            {
                return false;
            }

            bool codeShape = ContainsAny(
                normalized,
                "method", "function", "script", "component", "service", "module",
                "class", "helper", "api", "event", "hook", "callback", "interface",
                "reusable", "universal", "define", "parameter", "parameters",
                "call ", "called ", "trigger ", "triggered ", "every time", "when ");
            bool codeVerb = ContainsAny(
                normalized,
                "add", "create", "make", "build", "implement", "write", "fix",
                "refactor", "replace", "extract", "integrate");
            return codeShape && codeVerb;
        }

        private static bool IsVisualOrSceneBearingRequest(string prompt)
        {
            string normalized = NormalizeIntentText(prompt);
            if (string.IsNullOrWhiteSpace(normalized))
            {
                return false;
            }

            return IsSceneCompositionRequest(normalized) || IsVisualRenderRequest(normalized);
        }

        private static bool IsRuntimeVerificationRequest(string prompt)
        {
            string normalized = NormalizeIntentText(prompt);
            if (string.IsNullOrWhiteSpace(normalized))
            {
                return false;
            }

            if (ContainsAny(
                    normalized,
                    "play mode", "playmode", "play test", "playtest", "smoke test",
                    "runtime verification", "verify runtime", "runtime state",
                    "enter play", "run the game", "test in play"))
            {
                return true;
            }

            return HasBroadFeatureIntent(normalized) &&
                ContainsAny(normalized, "game", "playable", "gameplay", "gameplay loop");
        }

        private static bool IsPrefabOrAssetOnlyEditRequest(string prompt)
        {
            string normalized = NormalizeIntentText(prompt);
            if (string.IsNullOrWhiteSpace(normalized))
            {
                return false;
            }

            return IsPrefabOrAssetWorkflowRequest(normalized) &&
                IsAssetValueEditOperation(normalized) &&
                !IsRuntimeBehaviorRequest(normalized) &&
                !IsSceneCompositionRequest(normalized);
        }

        private static bool HasBroadFeatureIntent(string normalized)
        {
            if (string.IsNullOrWhiteSpace(normalized))
            {
                return false;
            }

            return ContainsAny(
                    normalized,
                    "prototype", "feature", "system", "workflow", "full flow",
                    "complete flow", "playable", "end to end", "from scratch",
                    "set up everything", "whole game", "game mode", "upgrade") ||
                LooksLikeWholeGameRequest(normalized) ||
                (ContainsAny(normalized, "build", "create", "make", "implement", "set up", "setup") &&
                 ContainsAny(normalized, "level", "scene setup", "gameplay loop"));
        }

        private static bool LooksLikeWholeGameRequest(string normalized)
        {
            if (string.IsNullOrWhiteSpace(normalized))
            {
                return false;
            }

            return Regex.IsMatch(
                normalized,
                @"\b(make|create|build|implement|setup|set up)\s+(a|an|the)?\s*[a-z0-9 _-]{0,48}\bgame\b",
                RegexOptions.CultureInvariant);
        }

        private static bool IsPrefabOrAssetWorkflowRequest(string normalized)
        {
            if (string.IsNullOrWhiteSpace(normalized))
            {
                return false;
            }

            return ContainsAny(
                normalized,
                "prefab", "prefabs", ".prefab", "asset", "assets", "material",
                "sprite", "texture", "model", "mesh", "animation clip", "audio clip",
                "volume profile", "scriptable object");
        }

        private static bool IsAssetValueEditOperation(string normalized)
        {
            if (string.IsNullOrWhiteSpace(normalized))
            {
                return false;
            }

            return ContainsAny(
                normalized,
                "smaller", "larger", "bigger", "red", "blue", "green", "yellow",
                "black", "white", "color", "colour", "tint", "scale", "size",
                "resize", "assign", "set ", "change", "make ", "material",
                "sprite", "collider", "radius", "sorting", "layer");
        }

        private static bool IsSceneCompositionRequest(string normalized)
        {
            if (string.IsNullOrWhiteSpace(normalized))
            {
                return false;
            }

            bool compositionVerb = ContainsAny(
                normalized,
                "add", "create", "place", "position", "move", "spread", "wire",
                "hook up", "assign", "set up", "setup", "instantiate", "spawn point",
                "spawn points", "gameobject", "game object", "scene object");
            bool sceneTarget = ContainsAny(
                normalized,
                "scene", "hierarchy", "gameobject", "game object", "camera", "light",
                "canvas", "ui", "button", "overlay", "spawn point", "spawn points",
                "arena", "level", "room");
            return compositionVerb && sceneTarget;
        }

        private static bool IsVisualRenderRequest(string normalized)
        {
            if (string.IsNullOrWhiteSpace(normalized))
            {
                return false;
            }

            bool visualOperation = ContainsAny(
                normalized,
                "color", "colour", "tint", "lighting", "light", "bloom", "vignette",
                "post processing", "post-processing", "postprocess", "background",
                "camera background", "render", "visual", "material", "shader");
            bool visualTarget = ContainsAny(
                normalized,
                "camera", "light", "lighting", "material", "sprite", "renderer",
                "volume", "background", "post processing", "post-processing",
                "bloom", "vignette", "scene", "game view");
            return visualOperation && visualTarget;
        }

        private static bool IsRuntimeBehaviorRequest(string normalized)
        {
            if (string.IsNullOrWhiteSpace(normalized))
            {
                return false;
            }

            return ContainsAny(
                    normalized,
                    "play mode", "playmode", "play test", "playtest", "smoke test",
                    "runtime", "gameplay", "gameplay loop") ||
                ContainsAny(
                    normalized,
                    "spawn", "instantiate", "move", "follow", "attack", "shoot",
                    "fire", "damage", "collision", "health", "win", "lose",
                    "restart", "ai behavior", "pathfinding", "patrol");
        }

        private static bool LooksLikeSmokePlaytestRequest(string prompt)
        {
            string normalized = NormalizeIntentText(prompt);
            if (string.IsNullOrWhiteSpace(normalized))
            {
                return false;
            }

            return ContainsAny(normalized, "play mode", "playmode", "playtest", "play test", "smoke test");
        }

        private static string BuildRequestSpecificCompletionChecklist(string prompt)
        {
            string normalized = NormalizeIntentText(prompt);
            if (string.IsNullOrWhiteSpace(normalized))
            {
                return string.Empty;
            }

            List<string> items = new List<string>();
            if (IsPrefabOrAssetOnlyEditRequest(prompt) || ContainsAny(normalized, "prefab", ".prefab"))
            {
                items.Add("prefab asset was inspected after the final edit");
                items.Add("requested prefab component values match the final inspection");
            }
            else if (ContainsAny(normalized, "ui", "button", "overlay", "restart"))
            {
                items.Add("UI objects are present in the scene hierarchy");
                items.Add("required button/object references are assigned");
                items.Add("UI state is verified in Play Mode when runtime behavior is involved");
            }

            if (ContainsAny(normalized, "post processing", "post-processing", "postprocess", "bloom", "vignette"))
            {
                items.Add("a global Volume has an assigned profile with active requested overrides");
                if (ContainsAny(normalized, "bloom"))
                {
                    items.Add("Bloom override exists, is active, and has non-default visible values");
                }
                if (ContainsAny(normalized, "vignette"))
                {
                    items.Add("Vignette override exists, is active, and has non-default visible values");
                }
                items.Add("the gameplay camera has URP post-processing enabled");
                items.Add("the Game view capture confirms the visual/render setup");
            }

            if (ContainsAny(normalized, "background color", "camera background", "black background") ||
                (ContainsAny(normalized, "background") && ContainsAny(normalized, "black")))
            {
                items.Add("the camera clear flags use a solid color background");
                items.Add("the gameplay camera background color is black");
            }

            if (ContainsAny(normalized, "cinemachine", "screen shake", "screenshake", "camera shake", "impulse"))
            {
                items.Add("package-backed camera/shake dependencies are present in the scene, not just in code");
                if (ContainsAny(normalized, "cinemachine"))
                {
                    items.Add("an active gameplay camera has CinemachineBrain when Cinemachine drives the view");
                }
                if (ContainsAny(normalized, "screen shake", "screenshake", "camera shake", "impulse"))
                {
                    items.Add("Cinemachine impulse shake has both a source/emitter and a listener on the camera rig");
                }
                items.Add("validate_scene passes after the camera/shake scene setup");
            }

            if (IsRuntimeBehaviorRequest(normalized) && !IsRuntimeVerificationRequest(prompt))
            {
                items.Add("runtime behavior is implemented through a reusable module or existing extension point");
                items.Add("the triggering source path calls the new behavior through one focused integration point");
                items.Add("configuration/tuning is serialized or data-driven instead of hard-coded into unrelated managers");
                items.Add("compiler diagnostics are clean after the integration");
            }

            if (items.Count == 0)
            {
                return string.Empty;
            }

            StringBuilder builder = new StringBuilder();
            foreach (string item in items)
            {
                builder.AppendLine("- " + item);
            }

            return builder.ToString();
        }

        private static bool ToolLogContains(StringBuilder builder, string toolName)
        {
            if (builder == null || builder.Length == 0 || string.IsNullOrWhiteSpace(toolName))
            {
                return false;
            }

            return builder.ToString().IndexOf(toolName, StringComparison.OrdinalIgnoreCase) >= 0;
        }

        private static string NormalizeAgentRole(string role)
        {
            string normalized = string.IsNullOrWhiteSpace(role)
                ? AgentRoleDefault
                : role.Trim().ToLowerInvariant().Replace("-", "_");

            switch (normalized)
            {
                case AgentRoleManager:
                case "orchestrator":
                    return AgentRoleManager;
                case AgentRoleWorker:
                case "implementation":
                case "implementer":
                case "fixer":
                    return AgentRoleWorker;
                case AgentRoleExplorer:
                case "reader":
                case "researcher":
                case "investigator":
                    return AgentRoleExplorer;
                case AgentRoleMonitor:
                case "poller":
                case "watcher":
                    return AgentRoleMonitor;
                case AgentRoleSceneSetup:
                case "scene":
                case "scene_builder":
                case "scene_designer":
                case "level_designer":
                    return AgentRoleSceneSetup;
                case AgentRoleAssetManagement:
                case "asset":
                case "assets":
                case "asset_manager":
                case "prefab_manager":
                case "prefab_editor":
                    return AgentRoleAssetManagement;
                case AgentRoleDefault:
                case "general":
                case "generalist":
                default:
                    return AgentRoleDefault;
            }
        }

        private static string NormalizeActionType(string actionType)
        {
            return string.IsNullOrWhiteSpace(actionType) ? string.Empty : actionType.Trim().ToLowerInvariant();
        }

        private static string GetAgentDisplayName(string role)
        {
            switch (NormalizeAgentRole(role))
            {
                case AgentRoleManager:
                    return "Orchestrator";
                case AgentRoleWorker:
                    return "Worker";
                case AgentRoleExplorer:
                    return "Explorer";
                case AgentRoleMonitor:
                    return "Monitor";
                case AgentRoleSceneSetup:
                    return "Scene Setup";
                case AgentRoleAssetManagement:
                    return "Asset Management";
                default:
                    return "Default agent";
            }
        }

        private static string FormatAgentToolName(string role, string toolName)
        {
            string agent = GetAgentDisplayName(role);
            string tool = string.IsNullOrWhiteSpace(toolName) ? "tool" : toolName.Trim();
            return $"{agent}/{tool}";
        }

        private static string CompactOneLine(string value, int maxLength)
        {
            if (string.IsNullOrWhiteSpace(value))
            {
                return string.Empty;
            }

            string compact = value.Replace("\r", " ").Replace("\n", " ").Trim();
            while (compact.IndexOf("  ", StringComparison.Ordinal) >= 0)
            {
                compact = compact.Replace("  ", " ");
            }

            if (maxLength <= 3 || compact.Length <= maxLength)
            {
                return compact;
            }

            return compact.Substring(0, maxLength - 3).TrimEnd() + "...";
        }

        private static bool IsToolAllowedForRole(string role, string toolName)
        {
            if (string.IsNullOrWhiteSpace(toolName))
            {
                return false;
            }

            string normalizedRole = NormalizeAgentRole(role);
            string normalizedTool = NormalizeActionType(toolName);
            if (string.Equals(normalizedRole, AgentRoleManager, StringComparison.Ordinal))
            {
                return string.Equals(normalizedTool, HandoffToolName, StringComparison.Ordinal) ||
                    string.Equals(normalizedTool, "set_task_plan", StringComparison.Ordinal) ||
                    string.Equals(normalizedTool, "update_task_status", StringComparison.Ordinal) ||
                    string.Equals(normalizedTool, "search_project", StringComparison.Ordinal) ||
                    string.Equals(normalizedTool, "read_text_file", StringComparison.Ordinal) ||
                    string.Equals(normalizedTool, "inspect_prefab", StringComparison.Ordinal) ||
                    string.Equals(normalizedTool, "read_compiler_diagnostics", StringComparison.Ordinal) ||
                    string.Equals(normalizedTool, "search_web", StringComparison.Ordinal) ||
                    string.Equals(normalizedTool, "search_unity_docs", StringComparison.Ordinal) ||
                    string.Equals(normalizedTool, "read_unity_doc", StringComparison.Ordinal) ||
                    string.Equals(normalizedTool, "search_unity_api", StringComparison.Ordinal) ||
                    string.Equals(normalizedTool, "read_unity_api", StringComparison.Ordinal) ||
                    string.Equals(normalizedTool, "rebuild_unity", StringComparison.Ordinal) ||
                    string.Equals(normalizedTool, "select", StringComparison.Ordinal) ||
                    string.Equals(normalizedTool, "inspect_runtime_state", StringComparison.Ordinal) ||
                    string.Equals(normalizedTool, "validate_scene", StringComparison.Ordinal) ||
                    string.Equals(normalizedTool, "capture_game_view", StringComparison.Ordinal);
            }

            if (string.Equals(normalizedRole, AgentRoleExplorer, StringComparison.Ordinal))
            {
                return string.Equals(normalizedTool, "search_project", StringComparison.Ordinal) ||
                    string.Equals(normalizedTool, "read_text_file", StringComparison.Ordinal) ||
                    string.Equals(normalizedTool, "inspect_prefab", StringComparison.Ordinal) ||
                    string.Equals(normalizedTool, "read_compiler_diagnostics", StringComparison.Ordinal) ||
                    string.Equals(normalizedTool, "search_web", StringComparison.Ordinal) ||
                    string.Equals(normalizedTool, "search_unity_docs", StringComparison.Ordinal) ||
                    string.Equals(normalizedTool, "read_unity_doc", StringComparison.Ordinal) ||
                    string.Equals(normalizedTool, "search_unity_api", StringComparison.Ordinal) ||
                    string.Equals(normalizedTool, "read_unity_api", StringComparison.Ordinal) ||
                    string.Equals(normalizedTool, "rebuild_unity", StringComparison.Ordinal) ||
                    string.Equals(normalizedTool, "select", StringComparison.Ordinal) ||
                    string.Equals(normalizedTool, "inspect_runtime_state", StringComparison.Ordinal) ||
                    string.Equals(normalizedTool, "validate_scene", StringComparison.Ordinal) ||
                    string.Equals(normalizedTool, "capture_game_view", StringComparison.Ordinal);
            }

            if (string.Equals(normalizedRole, AgentRoleMonitor, StringComparison.Ordinal))
            {
                return string.Equals(normalizedTool, "search_project", StringComparison.Ordinal) ||
                    string.Equals(normalizedTool, "read_text_file", StringComparison.Ordinal) ||
                    string.Equals(normalizedTool, "inspect_prefab", StringComparison.Ordinal) ||
                    string.Equals(normalizedTool, "read_compiler_diagnostics", StringComparison.Ordinal) ||
                    string.Equals(normalizedTool, "search_web", StringComparison.Ordinal) ||
                    string.Equals(normalizedTool, "search_unity_docs", StringComparison.Ordinal) ||
                    string.Equals(normalizedTool, "read_unity_doc", StringComparison.Ordinal) ||
                    string.Equals(normalizedTool, "search_unity_api", StringComparison.Ordinal) ||
                    string.Equals(normalizedTool, "read_unity_api", StringComparison.Ordinal) ||
                    string.Equals(normalizedTool, "rebuild_unity", StringComparison.Ordinal) ||
                    string.Equals(normalizedTool, "select", StringComparison.Ordinal) ||
                    string.Equals(normalizedTool, "inspect_runtime_state", StringComparison.Ordinal) ||
                    string.Equals(normalizedTool, "validate_scene", StringComparison.Ordinal) ||
                    string.Equals(normalizedTool, "capture_game_view", StringComparison.Ordinal) ||
                    string.Equals(normalizedTool, "enter_play_mode", StringComparison.Ordinal) ||
                    string.Equals(normalizedTool, "exit_play_mode", StringComparison.Ordinal);
            }

            if (string.Equals(normalizedRole, AgentRoleSceneSetup, StringComparison.Ordinal))
            {
                return string.Equals(normalizedTool, "search_project", StringComparison.Ordinal) ||
                    string.Equals(normalizedTool, "read_text_file", StringComparison.Ordinal) ||
                    string.Equals(normalizedTool, "read_compiler_diagnostics", StringComparison.Ordinal) ||
                    string.Equals(normalizedTool, "search_web", StringComparison.Ordinal) ||
                    string.Equals(normalizedTool, "search_unity_docs", StringComparison.Ordinal) ||
                    string.Equals(normalizedTool, "read_unity_doc", StringComparison.Ordinal) ||
                    string.Equals(normalizedTool, "search_unity_api", StringComparison.Ordinal) ||
                    string.Equals(normalizedTool, "read_unity_api", StringComparison.Ordinal) ||
                    string.Equals(normalizedTool, "rebuild_unity", StringComparison.Ordinal) ||
                    string.Equals(normalizedTool, "select", StringComparison.Ordinal) ||
                    string.Equals(normalizedTool, "ensure_unity_workflow", StringComparison.Ordinal) ||
                    string.Equals(normalizedTool, "repair_scene_relationships", StringComparison.Ordinal) ||
                    string.Equals(normalizedTool, "setup_urp_post_processing", StringComparison.Ordinal) ||
                    string.Equals(normalizedTool, "inspect_runtime_state", StringComparison.Ordinal) ||
                    string.Equals(normalizedTool, "create_object", StringComparison.Ordinal) ||
                    string.Equals(normalizedTool, "ensure_components", StringComparison.Ordinal) ||
                    string.Equals(normalizedTool, "delete_game_object", StringComparison.Ordinal) ||
                    string.Equals(normalizedTool, "clear_scene", StringComparison.Ordinal) ||
                    string.Equals(normalizedTool, "set_object_property", StringComparison.Ordinal) ||
                    string.Equals(normalizedTool, "set_transform", StringComparison.Ordinal) ||
                    string.Equals(normalizedTool, "set_component_property", StringComparison.Ordinal) ||
                    string.Equals(normalizedTool, "add_component", StringComparison.Ordinal) ||
                    string.Equals(normalizedTool, "remove_component", StringComparison.Ordinal) ||
                    string.Equals(normalizedTool, "instantiate_prefab", StringComparison.Ordinal) ||
                    string.Equals(normalizedTool, "create_scene", StringComparison.Ordinal) ||
                    string.Equals(normalizedTool, "open_scene", StringComparison.Ordinal) ||
                    string.Equals(normalizedTool, "enter_play_mode", StringComparison.Ordinal) ||
                    string.Equals(normalizedTool, "exit_play_mode", StringComparison.Ordinal) ||
                    string.Equals(normalizedTool, "validate_scene", StringComparison.Ordinal) ||
                    string.Equals(normalizedTool, "capture_game_view", StringComparison.Ordinal) ||
                    string.Equals(normalizedTool, "save_scene", StringComparison.Ordinal);
            }

            if (string.Equals(normalizedRole, AgentRoleAssetManagement, StringComparison.Ordinal))
            {
                return string.Equals(normalizedTool, "search_project", StringComparison.Ordinal) ||
                    string.Equals(normalizedTool, "read_text_file", StringComparison.Ordinal) ||
                    string.Equals(normalizedTool, "inspect_prefab", StringComparison.Ordinal) ||
                    string.Equals(normalizedTool, "read_compiler_diagnostics", StringComparison.Ordinal) ||
                    string.Equals(normalizedTool, "search_web", StringComparison.Ordinal) ||
                    string.Equals(normalizedTool, "search_unity_docs", StringComparison.Ordinal) ||
                    string.Equals(normalizedTool, "read_unity_doc", StringComparison.Ordinal) ||
                    string.Equals(normalizedTool, "search_unity_api", StringComparison.Ordinal) ||
                    string.Equals(normalizedTool, "read_unity_api", StringComparison.Ordinal) ||
                    string.Equals(normalizedTool, "rebuild_unity", StringComparison.Ordinal) ||
                    string.Equals(normalizedTool, "inspect_runtime_state", StringComparison.Ordinal) ||
                    string.Equals(normalizedTool, "ensure_unity_workflow", StringComparison.Ordinal) ||
                    string.Equals(normalizedTool, "repair_scene_relationships", StringComparison.Ordinal) ||
                    string.Equals(normalizedTool, "setup_urp_post_processing", StringComparison.Ordinal) ||
                    string.Equals(normalizedTool, "create_folder", StringComparison.Ordinal) ||
                    string.Equals(normalizedTool, "write_text_file", StringComparison.Ordinal) ||
                    string.Equals(normalizedTool, "create_sprite_asset", StringComparison.Ordinal) ||
                    string.Equals(normalizedTool, "create_unity_asset", StringComparison.Ordinal) ||
                    string.Equals(normalizedTool, "apply_default_sprite", StringComparison.Ordinal) ||
                    string.Equals(normalizedTool, "set_component_property", StringComparison.Ordinal) ||
                    string.Equals(normalizedTool, "add_component", StringComparison.Ordinal) ||
                    string.Equals(normalizedTool, "remove_component", StringComparison.Ordinal) ||
                    string.Equals(normalizedTool, "create_prefab_from_selected", StringComparison.Ordinal) ||
                    string.Equals(normalizedTool, "instantiate_prefab", StringComparison.Ordinal) ||
                    string.Equals(normalizedTool, "set_asset_property", StringComparison.Ordinal) ||
                    string.Equals(normalizedTool, "set_editor_build_scenes", StringComparison.Ordinal) ||
                    string.Equals(normalizedTool, "invoke_editor_method", StringComparison.Ordinal) ||
                    string.Equals(normalizedTool, "save_assets", StringComparison.Ordinal) ||
                    string.Equals(normalizedTool, "validate_scene", StringComparison.Ordinal);
            }

            if (string.Equals(normalizedRole, AgentRoleWorker, StringComparison.Ordinal))
            {
                return !string.Equals(normalizedTool, HandoffToolName, StringComparison.Ordinal) &&
                    !string.Equals(normalizedTool, "clear_scene", StringComparison.Ordinal) &&
                    !string.Equals(normalizedTool, "add_package", StringComparison.Ordinal) &&
                    !string.Equals(normalizedTool, "remove_package", StringComparison.Ordinal) &&
                    !string.Equals(normalizedTool, "set_player_setting", StringComparison.Ordinal) &&
                    !string.Equals(normalizedTool, "set_project_setting", StringComparison.Ordinal);
            }

            return !string.Equals(normalizedTool, HandoffToolName, StringComparison.Ordinal);
        }

        private static string BuildAllowedToolList(string role)
        {
            string[] names = BuildOpenAIToolNames(role);
            return string.Join(", ", names);
        }

        public static string FormatToolLoopFinalResponse(ToolLoopState state)
        {
            if (state == null)
            {
                return "Tool loop did not start.";
            }

            AppendAutomaticVerificationIssues(state);

            string finalMessage = string.IsNullOrWhiteSpace(state.FinalMessage)
                ? "The tool loop ended without a final message."
                : state.FinalMessage.Trim();
            if (!GetDeveloperMode())
            {
                finalMessage = StripDeveloperResponseSections(finalMessage);
            }

            StringBuilder result = new StringBuilder();
            AppendCodexStyleLead(result, finalMessage, state);
            AppendUserFacingOutcomeSections(result, state.AppliedActions, state);

            return result.ToString().TrimEnd();
        }

        private static void AppendUserFacingOutcomeSections(StringBuilder result, int appliedActions, ToolLoopState state)
        {
            if (result == null)
            {
                return;
            }

            bool developerMode = GetDeveloperMode();

            if (state != null && state.AchievementLog.Length > 0)
            {
                AppendCodexStyleLogSection(result, "Changed:", state.AchievementLog);
            }
            else if (appliedActions > 0)
            {
                AppendCodexStyleLogSection(result, "Changed:", $"- Applied {appliedActions} Unity action(s).");
            }

            if (state != null && state.CodeSnippetLog.Length > 0)
            {
                result.AppendLine();
                result.AppendLine("Code snippets:");
                result.AppendLine();
                result.Append(state.CodeSnippetLog);
            }

            if (developerMode && state != null && state.TaskPlan.Count > 0)
            {
                AppendCodexStyleLogSection(result, "Task plan:", FormatTaskPlanForContext(state).Replace("Task plan:\n", string.Empty));
            }

            if (developerMode && state != null && state.ContextLog.Length > 0)
            {
                AppendCodexStyleLogSection(result, "Context checked:", state.ContextLog);
            }

            if (developerMode && state != null && state.ValidationLog.Length > 0)
            {
                AppendCodexStyleLogSection(
                    result,
                    state.IssueLog.Length > 0 ? "Validation:" : "Validation passed:",
                    state.ValidationLog);
            }

            if (developerMode && state != null && state.IssueLog.Length > 0)
            {
                AppendCodexStyleLogSection(result, "Remaining issues:", state.IssueLog);
            }
        }

        private static void AppendCodexStyleLead(StringBuilder result, string finalMessage, ToolLoopState state)
        {
            if (result == null)
            {
                return;
            }

            string lead = FormatFinalLead(finalMessage, state);
            string[] lines = lead.Replace("\r\n", "\n").Replace('\r', '\n').Split('\n');
            bool wroteFirst = false;
            foreach (string rawLine in lines)
            {
                string line = rawLine.TrimEnd();
                if (!wroteFirst)
                {
                    if (string.IsNullOrWhiteSpace(line))
                    {
                        continue;
                    }

                    result.Append("• ");
                    result.AppendLine(line.Trim());
                    wroteFirst = true;
                    continue;
                }

                if (string.IsNullOrWhiteSpace(line))
                {
                    result.AppendLine();
                    continue;
                }

                result.Append("  ");
                result.AppendLine(line.Trim());
            }

            if (!wroteFirst)
            {
                result.AppendLine("• Finished.");
            }
        }

        private static string FormatFinalLead(string finalMessage, ToolLoopState state)
        {
            string lead = string.IsNullOrWhiteSpace(finalMessage)
                ? "Finished."
                : finalMessage.Trim();

            lead = lead.Replace("\r\n", "\n").Replace('\r', '\n');

            if (string.IsNullOrWhiteSpace(lead))
            {
                lead = "Finished.";
            }

            if (state != null && state.IssueLog.Length > 0 && StartsWithCompletionWord(lead))
            {
                lead = "Incomplete. Unity actions ran, but validation or issues remain.";
            }

            if (!lead.EndsWith(".", StringComparison.Ordinal) &&
                !lead.EndsWith("!", StringComparison.Ordinal) &&
                !lead.EndsWith("?", StringComparison.Ordinal))
            {
                lead += ".";
            }

            return lead;
        }

        private static string StripDeveloperResponseSections(string text)
        {
            if (string.IsNullOrWhiteSpace(text))
            {
                return text ?? string.Empty;
            }

            string[] lines = text.Replace("\r\n", "\n").Replace('\r', '\n').Split('\n');
            StringBuilder builder = new StringBuilder();
            bool skipping = false;
            foreach (string rawLine in lines)
            {
                string trimmed = (rawLine ?? string.Empty).Trim();
                if (IsDeveloperResponseSectionHeader(trimmed))
                {
                    skipping = true;
                    continue;
                }

                if (skipping && IsNonDeveloperResponseSectionHeader(trimmed))
                {
                    skipping = false;
                }

                if (!skipping)
                {
                    builder.AppendLine(rawLine);
                }
            }

            string stripped = builder.ToString().Trim();
            return string.IsNullOrWhiteSpace(stripped) ? "Finished." : stripped;
        }

        private static bool IsDeveloperResponseSectionHeader(string line)
        {
            string normalized = NormalizeResponseSectionHeader(line);
            return string.Equals(normalized, "task plan", StringComparison.OrdinalIgnoreCase) ||
                string.Equals(normalized, "context checked", StringComparison.OrdinalIgnoreCase) ||
                string.Equals(normalized, "validation", StringComparison.OrdinalIgnoreCase) ||
                string.Equals(normalized, "validation passed", StringComparison.OrdinalIgnoreCase) ||
                string.Equals(normalized, "remaining issues", StringComparison.OrdinalIgnoreCase) ||
                string.Equals(normalized, "issues", StringComparison.OrdinalIgnoreCase);
        }

        private static bool IsNonDeveloperResponseSectionHeader(string line)
        {
            string normalized = NormalizeResponseSectionHeader(line);
            return string.Equals(normalized, "summary", StringComparison.OrdinalIgnoreCase) ||
                string.Equals(normalized, "changed", StringComparison.OrdinalIgnoreCase) ||
                string.Equals(normalized, "what changed", StringComparison.OrdinalIgnoreCase) ||
                string.Equals(normalized, "code snippets", StringComparison.OrdinalIgnoreCase) ||
                string.Equals(normalized, "notes", StringComparison.OrdinalIgnoreCase) ||
                string.Equals(normalized, "actions", StringComparison.OrdinalIgnoreCase);
        }

        private static string NormalizeResponseSectionHeader(string line)
        {
            if (string.IsNullOrWhiteSpace(line))
            {
                return string.Empty;
            }

            string trimmed = line.Trim();
            if (trimmed.StartsWith("•", StringComparison.Ordinal))
            {
                trimmed = trimmed.Substring(1).TrimStart();
            }

            if (trimmed.StartsWith("- ", StringComparison.Ordinal))
            {
                trimmed = trimmed.Substring(2).TrimStart();
            }

            if (trimmed.EndsWith(":", StringComparison.Ordinal))
            {
                trimmed = trimmed.Substring(0, trimmed.Length - 1).TrimEnd();
            }

            return trimmed;
        }

        private static void AppendAutomaticVerificationIssues(ToolLoopState state)
        {
            if (state == null || string.IsNullOrWhiteSpace(state.Prompt))
            {
                return;
            }

            AppendRuntimeFinalMessageIssues(state);
            AppendVisualWorkflowVerificationIssues(state);

            string achievements = state.AchievementLog.ToString();
            string context = state.ContextLog.ToString();
            string actionLog = state.ActionLog.ToString();
            string requestText = state.Prompt ?? string.Empty;
            if (!MentionsPrefabWorkflow(requestText) || !MentionsPrefabChangeIntent(requestText))
            {
                return;
            }

            bool wrotePrefabBuilder = achievements.IndexOf("PrefabBuilder.cs", StringComparison.OrdinalIgnoreCase) >= 0 ||
                achievements.IndexOf("prefab builder", StringComparison.OrdinalIgnoreCase) >= 0;
            bool directPrefabMutation = HasDirectPrefabMutation(achievements) || HasDirectPrefabMutation(actionLog);
            bool prefabMutationAfterInspection = HasPrefabMutationAfterLatestInspection(actionLog);

            if (wrotePrefabBuilder && !directPrefabMutation)
            {
                AppendVerificationIssue(
                    state,
                    "Prefab asset was not verified as changed; only a prefab builder script was written. Use direct prefab edit tools against the prefab asset and inspect_prefab after the edit.");
            }

            string lastInspection = GetLastPrefabInspectionLine(context);
            if (string.IsNullOrWhiteSpace(lastInspection))
            {
                if (directPrefabMutation)
                {
                    AppendVerificationIssue(
                        state,
                        "Prefab asset was edited but not verified afterward with inspect_prefab.");
                }
                else if (state.AchievementLog.Length > 0)
                {
                    AppendVerificationIssue(
                        state,
                        "No verified direct prefab asset mutation was observed for this prefab change request.");
                }

                return;
            }

            if (prefabMutationAfterInspection)
            {
                AppendVerificationIssue(
                    state,
                    "Prefab asset was edited after the latest inspect_prefab result, so the final prefab values were not verified after the write.");
            }

            if (PromptContainsWord(requestText, "red") &&
                TryExtractInspectedColor(lastInspection, out string colorHex) &&
                !IsRedColorHex(colorHex))
            {
                AppendVerificationIssue(
                    state,
                    $"Last prefab inspection still shows SpriteRenderer color {colorHex}, not a verified red tint.");
            }

            if ((PromptContainsWord(requestText, "smaller") ||
                 PromptContainsWord(requestText, "scale") ||
                 PromptContainsWord(requestText, "size")) &&
                LastInspectionShowsUnitScale(lastInspection))
            {
                AppendVerificationIssue(
                    state,
                    "Last prefab inspection still shows localScale=(1,1,1), so the prefab was not verified as smaller.");
            }
        }

        private static void AppendRuntimeFinalMessageIssues(ToolLoopState state)
        {
            if (state == null ||
                string.IsNullOrWhiteSpace(state.FinalMessage) ||
                !IsRuntimeVerificationRequest(state.Prompt))
            {
                return;
            }

            string final = state.FinalMessage.ToLowerInvariant();
            if (!ContainsAny(
                    final,
                    "not visibly",
                    "not visible",
                    "not yet",
                    "unverified",
                    "not verified",
                    "could not verify",
                    "could not confirm",
                    "did not show",
                    "didn't show",
                    "does not show",
                    "no spawned",
                    "not spawning",
                    "not spawned",
                    "main blocker",
                    "remaining blocker",
                    "still the blocker",
                    "remains the blocker"))
            {
                return;
            }

            AppendVerificationIssue(
                state,
                "Runtime/gameplay behavior remains unverified or failing; Play Mode evidence did not satisfy the requested behavior.");
        }

        private static void AppendVisualWorkflowVerificationIssues(ToolLoopState state)
        {
            if (state == null)
            {
                return;
            }

            string prompt = state.Prompt ?? string.Empty;
            bool needsBlackBackground = MentionsBlackCameraBackground(prompt);
            bool needsPostProcessing = MentionsPostProcessingWorkflow(prompt);
            if (!needsBlackBackground && !needsPostProcessing)
            {
                return;
            }

            RemoveIssueLinesContaining(
                state.IssueLog,
                "Camera background was not verified as black",
                "Post-processing request has no active global Volume overrides",
                "Post-processing request has no active Bloom override",
                "Post-processing request has no active Vignette override",
                "Post-processing request has active Volume overrides but no camera with URP post-processing enabled",
                "Visual/render request still needs Game view verification");

            if (needsBlackBackground && !SceneHasBlackSolidColorCameraBackground())
            {
                AppendVerificationIssue(
                    state,
                    "Camera background was not verified as black; set the camera clear flags to SolidColor and background color to black.");
            }

            if (needsPostProcessing)
            {
                if (!SceneHasActiveGlobalVolumeOverrides())
                {
                    AppendVerificationIssue(
                        state,
                        "Post-processing request has no active global Volume overrides; create/assign a VolumeProfile with active override components.");
                }

                if (PromptContainsWord(prompt, "bloom") && !SceneHasActiveGlobalVolumeOverrideType("Bloom"))
                {
                    AppendVerificationIssue(
                        state,
                        "Post-processing request has no active Bloom override in a global Volume profile.");
                }

                if (PromptContainsWord(prompt, "vignette") && !SceneHasActiveGlobalVolumeOverrideType("Vignette"))
                {
                    AppendVerificationIssue(
                        state,
                        "Post-processing request has no active Vignette override in a global Volume profile.");
                }

                if (SceneHasActiveGlobalVolumeOverrides() && !SceneHasCameraWithEnabledUrpPostProcessing())
                {
                    AppendVerificationIssue(
                        state,
                        "Post-processing request has active Volume overrides but no camera with URP post-processing enabled.");
                }
            }

            if ((needsBlackBackground || needsPostProcessing) &&
                state.AppliedActions > 0 &&
                !ToolLogContains(state.ActionLog, "capture_game_view") &&
                !ToolLogContains(state.ActionLog, "capture_game_view_diagnostics"))
            {
                AppendVerificationIssue(
                    state,
                    "Visual/render request still needs Game view verification after the final camera/post-processing changes.");
            }
        }

        private static bool MentionsPrefabWorkflow(string text)
        {
            if (string.IsNullOrWhiteSpace(text))
            {
                return false;
            }

            return PromptContainsWord(text, "prefab") ||
                text.IndexOf(".prefab", StringComparison.OrdinalIgnoreCase) >= 0 ||
                text.IndexOf("inspect_prefab", StringComparison.OrdinalIgnoreCase) >= 0 ||
                text.IndexOf(" on prefab ", StringComparison.OrdinalIgnoreCase) >= 0;
        }

        private static bool MentionsPrefabChangeIntent(string prompt)
        {
            if (string.IsNullOrWhiteSpace(prompt))
            {
                return false;
            }

            return PromptContainsWord(prompt, "make") ||
                PromptContainsWord(prompt, "set") ||
                PromptContainsWord(prompt, "change") ||
                PromptContainsWord(prompt, "update") ||
                PromptContainsWord(prompt, "edit") ||
                PromptContainsWord(prompt, "fixed") ||
                PromptContainsWord(prompt, "smaller") ||
                PromptContainsWord(prompt, "larger") ||
                PromptContainsWord(prompt, "red") ||
                PromptContainsWord(prompt, "yellow") ||
                PromptContainsWord(prompt, "color") ||
                PromptContainsWord(prompt, "scale") ||
                PromptContainsWord(prompt, "size");
        }

        private static bool HasDirectPrefabMutation(string log)
        {
            if (string.IsNullOrWhiteSpace(log))
            {
                return false;
            }

            return log.IndexOf(" on prefab ", StringComparison.OrdinalIgnoreCase) >= 0 ||
                log.IndexOf("updated transform for prefab", StringComparison.OrdinalIgnoreCase) >= 0 ||
                log.IndexOf("created prefab ", StringComparison.OrdinalIgnoreCase) >= 0 ||
                log.IndexOf("set asset property Assets/", StringComparison.OrdinalIgnoreCase) >= 0;
        }

        private static bool HasPrefabMutationAfterLatestInspection(string actionLog)
        {
            if (string.IsNullOrWhiteSpace(actionLog))
            {
                return false;
            }

            int lastInspect = LastIndexOfAny(actionLog, new[]
            {
                "inspect_prefab",
                "Prefab: Assets/",
                "Inspected prefab "
            });
            int lastMutation = LastIndexOfAny(actionLog, new[]
            {
                " on prefab ",
                "updated transform for prefab",
                "created prefab ",
                "set asset property Assets/"
            });

            return lastMutation >= 0 && (lastInspect < 0 || lastMutation > lastInspect);
        }

        private static int LastIndexOfAny(string value, string[] needles)
        {
            if (string.IsNullOrWhiteSpace(value) || needles == null)
            {
                return -1;
            }

            int last = -1;
            foreach (string needle in needles)
            {
                if (string.IsNullOrWhiteSpace(needle))
                {
                    continue;
                }

                last = Mathf.Max(last, value.LastIndexOf(needle, StringComparison.OrdinalIgnoreCase));
            }

            return last;
        }

        private static bool PromptContainsWord(string prompt, string word)
        {
            if (string.IsNullOrWhiteSpace(prompt) || string.IsNullOrWhiteSpace(word))
            {
                return false;
            }

            string normalizedWord = NormalizeSettingKey(word);
            if (string.IsNullOrWhiteSpace(normalizedWord))
            {
                return false;
            }

            StringBuilder token = new StringBuilder();
            foreach (char character in prompt)
            {
                if (char.IsLetterOrDigit(character))
                {
                    token.Append(char.ToLowerInvariant(character));
                    continue;
                }

                if (TokenMatches(token, normalizedWord))
                {
                    return true;
                }

                token.Length = 0;
            }

            return TokenMatches(token, normalizedWord);
        }

        private static bool TokenMatches(StringBuilder token, string normalizedWord)
        {
            return token != null &&
                token.Length > 0 &&
                string.Equals(token.ToString(), normalizedWord, StringComparison.OrdinalIgnoreCase);
        }

        private static string GetLastPrefabInspectionLine(string context)
        {
            if (string.IsNullOrWhiteSpace(context))
            {
                return string.Empty;
            }

            string last = string.Empty;
            string[] lines = context.Replace("\r\n", "\n").Replace('\r', '\n').Split('\n');
            foreach (string line in lines)
            {
                if (line.IndexOf("Inspected prefab ", StringComparison.OrdinalIgnoreCase) >= 0)
                {
                    last = line.Trim();
                }
            }

            return last;
        }

        private static bool TryExtractInspectedColor(string inspection, out string colorHex)
        {
            colorHex = string.Empty;
            if (string.IsNullOrWhiteSpace(inspection))
            {
                return false;
            }

            const string marker = "color=#";
            int markerIndex = inspection.IndexOf(marker, StringComparison.OrdinalIgnoreCase);
            if (markerIndex < 0)
            {
                return false;
            }

            int start = markerIndex + "color=".Length;
            int length = 0;
            while (start + length < inspection.Length &&
                   length < 9 &&
                   IsHexColorCharacter(inspection[start + length]))
            {
                length++;
            }

            if (length != 7 && length != 9)
            {
                return false;
            }

            colorHex = inspection.Substring(start, length).ToUpperInvariant();
            return true;
        }

        private static bool IsHexColorCharacter(char character)
        {
            return character == '#' ||
                (character >= '0' && character <= '9') ||
                (character >= 'a' && character <= 'f') ||
                (character >= 'A' && character <= 'F');
        }

        private static bool IsRedColorHex(string colorHex)
        {
            if (string.IsNullOrWhiteSpace(colorHex) || colorHex.Length < 7 || colorHex[0] != '#')
            {
                return false;
            }

            if (!int.TryParse(colorHex.Substring(1, 2), NumberStyles.HexNumber, CultureInfo.InvariantCulture, out int red) ||
                !int.TryParse(colorHex.Substring(3, 2), NumberStyles.HexNumber, CultureInfo.InvariantCulture, out int green) ||
                !int.TryParse(colorHex.Substring(5, 2), NumberStyles.HexNumber, CultureInfo.InvariantCulture, out int blue))
            {
                return false;
            }

            return red >= 180 && green <= 130 && blue <= 130 && red > green && red > blue;
        }

        private static bool LastInspectionShowsUnitScale(string inspection)
        {
            return inspection.IndexOf("localScale=(1,1,1)", StringComparison.OrdinalIgnoreCase) >= 0 ||
                inspection.IndexOf("localScale=(1, 1, 1)", StringComparison.OrdinalIgnoreCase) >= 0;
        }

        private static void AppendVerificationIssue(ToolLoopState state, string issue)
        {
            if (state == null || string.IsNullOrWhiteSpace(issue))
            {
                return;
            }

            string existing = state.IssueLog.ToString();
            if (existing.IndexOf(issue, StringComparison.OrdinalIgnoreCase) >= 0)
            {
                return;
            }

            AppendUserFacingLine(state.IssueLog, issue);
        }

        private static bool StartsWithCompletionWord(string value)
        {
            if (string.IsNullOrWhiteSpace(value))
            {
                return false;
            }

            string trimmed = value.TrimStart();
            return trimmed.StartsWith("Implemented", StringComparison.OrdinalIgnoreCase) ||
                trimmed.StartsWith("Finished", StringComparison.OrdinalIgnoreCase) ||
                trimmed.StartsWith("Fixed", StringComparison.OrdinalIgnoreCase) ||
                trimmed.StartsWith("Done", StringComparison.OrdinalIgnoreCase) ||
                trimmed.StartsWith("Completed", StringComparison.OrdinalIgnoreCase);
        }

        private static void AppendCodexStyleLogSection(StringBuilder builder, string title, StringBuilder log)
        {
            AppendCodexStyleLogSection(builder, title, log == null ? string.Empty : log.ToString());
        }

        private static void AppendCodexStyleLogSection(StringBuilder builder, string title, string log)
        {
            if (builder == null || string.IsNullOrWhiteSpace(log))
            {
                return;
            }

            builder.AppendLine();
            builder.AppendLine(title);
            builder.AppendLine();

            string[] lines = log.Replace("\r\n", "\n").Replace('\r', '\n').Split('\n');
            foreach (string line in lines)
            {
                string trimmed = line.Trim();
                if (string.IsNullOrWhiteSpace(trimmed))
                {
                    continue;
                }

                if (trimmed.StartsWith("- ", StringComparison.Ordinal))
                {
                    builder.AppendLine(trimmed);
                }
                else
                {
                    builder.AppendLine("- " + trimmed);
                }
            }
        }

        private static void AppendToolLogLine(StringBuilder builder, int index, string toolName, string toolResult)
        {
            if (builder == null)
            {
                return;
            }

            builder.Append(index);
            builder.Append(". ");
            builder.Append(string.IsNullOrWhiteSpace(toolName) ? "tool" : toolName.Trim());
            builder.Append(" - ");
            AppendFullToolResult(builder, toolResult);
        }

        private static void AppendFullToolResult(StringBuilder builder, string toolResult)
        {
            string result = string.IsNullOrWhiteSpace(toolResult)
                ? "completed"
                : toolResult.Trim();
            string normalized = result.Replace("\r\n", "\n").Replace('\r', '\n');
            string[] lines = normalized.Split('\n');
            if (lines.Length == 0)
            {
                builder.AppendLine("completed");
                return;
            }

            builder.AppendLine(lines[0].TrimEnd());
            for (int i = 1; i < lines.Length; i++)
            {
                string line = lines[i];
                if (string.IsNullOrWhiteSpace(line))
                {
                    builder.AppendLine();
                }
                else
                {
                    builder.Append("   ");
                    builder.AppendLine(line.TrimEnd());
                }
            }
        }

        private static void RecordUserFacingToolResult(ToolLoopState state, AgentAction action, string toolName, string toolResult)
        {
            if (state == null)
            {
                return;
            }

            string normalizedTool = NormalizeActionType(action?.type ?? toolName);
            string result = string.IsNullOrWhiteSpace(toolResult) ? "completed" : toolResult.Trim();

            if (IsTaskPlanAction(normalizedTool))
            {
                AppendUserFacingLine(state.ContextLog, SummarizeToolResult(toolName, result));
                return;
            }

            if (string.Equals(normalizedTool, "read_compiler_diagnostics", StringComparison.OrdinalIgnoreCase))
            {
                string compilerSummary = SummarizeCompilerDiagnostics(result, out bool hasCompilerError);
                if (hasCompilerError)
                {
                    if (string.Equals(state.LastCompilerFailureSummary, compilerSummary, StringComparison.Ordinal))
                    {
                        state.RepeatedCompilerFailureCount++;
                    }
                    else
                    {
                        state.LastCompilerFailureSummary = compilerSummary;
                        state.RepeatedCompilerFailureCount = 1;
                        state.CompilerFailureRepairEscalated = false;
                    }

                    if (state.RepeatedCompilerFailureCount == 1)
                    {
                        AppendUserFacingLine(state.IssueLog, compilerSummary);
                    }
                    else if (state.RepeatedCompilerFailureCount == MaxRepeatedCompilerFailureBeforeFocusedRepairEscalation)
                    {
                        AppendUserFacingLine(
                            state.IssueLog,
                            compilerSummary + $" (repeated {state.RepeatedCompilerFailureCount} times)");
                    }
                }
                else
                {
                    ResetCompilerFailureTracking(state);
                    RemoveIssueLinesContaining(
                        state.IssueLog,
                        "Compiler blocker",
                        "Compiler diagnostics:",
                        "Script Compilation Error",
                        "Tundra build failed",
                        "compile failure");
                    AppendUserFacingLine(state.ValidationLog, compilerSummary);
                }
                return;
            }

            if (string.Equals(normalizedTool, "validate_scene", StringComparison.OrdinalIgnoreCase))
            {
                if (IsCleanSceneValidationResult(result))
                {
                    RemoveIssueLinesContaining(state.IssueLog, "scene validation found");
                    AppendUserFacingLine(state.ValidationLog, result);
                }
                else
                {
                    AppendUserFacingLine(state.IssueLog, result);
                }

                return;
            }

            if (IsReferenceTool(normalizedTool))
            {
                if (IsReferenceToolFailure(normalizedTool, result))
                {
                    AppendUserFacingLine(state.IssueLog, SummarizeIssueToolResult(result));
                }
                else
                {
                    AppendUserFacingLine(state.ContextLog, SummarizeReferenceToolResult(normalizedTool, action, result));
                }

                return;
            }

            if (IsIssueToolResult(result))
            {
                AppendUserFacingLine(state.IssueLog, SummarizeIssueToolResult(result));
                return;
            }

            if (string.Equals(normalizedTool, "write_csharp_script", StringComparison.OrdinalIgnoreCase) ||
                string.Equals(normalizedTool, "write_text_file", StringComparison.OrdinalIgnoreCase))
            {
                AppendWrittenFileSummary(state, action, result);
                return;
            }

            if (string.Equals(normalizedTool, "capture_game_view", StringComparison.OrdinalIgnoreCase) ||
                string.Equals(normalizedTool, "capture_game_view_diagnostics", StringComparison.OrdinalIgnoreCase))
            {
                AppendUserFacingLine(state.ValidationLog, SummarizeToolResult(toolName, result));
                return;
            }

            if (!IsReadOnlyAction(normalizedTool))
            {
                AppendUserFacingLine(state.AchievementLog, SummarizeToolResult(toolName, result));
            }
        }

        private static void AppendWrittenFileSummary(ToolLoopState state, AgentAction action, string result)
        {
            string normalizedType = NormalizeActionType(action?.type);
            bool isCSharpScript = string.Equals(normalizedType, "write_csharp_script", StringComparison.OrdinalIgnoreCase);
            string path = NormalizeAssetPath(action?.path);
            if (string.IsNullOrWhiteSpace(path) && isCSharpScript)
            {
                string className = string.IsNullOrWhiteSpace(action?.component) ? "AgenticComponent" : SanitizeFileName(action.component);
                path = $"Assets/Scripts/{className}.cs";
            }

            if (string.IsNullOrWhiteSpace(path))
            {
                path = "written file";
            }

            AppendUserFacingLine(state.AchievementLog, isCSharpScript ? $"Wrote C# script {path}." : $"Wrote {path}.");
            string snippet = BuildCodeSnippet(path, action?.content);
            if (!string.IsNullOrWhiteSpace(snippet))
            {
                if (isCSharpScript)
                {
                    state.CodeSnippetLog.AppendLine($"Script path: {path}");
                    state.CodeSnippetLog.AppendLine("Script preview:");
                    state.CodeSnippetLog.Append(snippet);
                    state.CodeSnippetLog.AppendLine();
                }
                else
                {
                    state.CodeSnippetLog.AppendLine(path);
                    state.CodeSnippetLog.Append(snippet);
                    state.CodeSnippetLog.AppendLine();
                }
            }
            else if (!string.IsNullOrWhiteSpace(result))
            {
                AppendUserFacingLine(state.CodeSnippetLog, result);
            }
        }

        private static bool IsReferenceTool(string normalizedTool)
        {
            return string.Equals(normalizedTool, "search_project", StringComparison.OrdinalIgnoreCase) ||
                string.Equals(normalizedTool, "read_text_file", StringComparison.OrdinalIgnoreCase) ||
                string.Equals(normalizedTool, "inspect_prefab", StringComparison.OrdinalIgnoreCase) ||
                string.Equals(normalizedTool, "inspect_runtime_state", StringComparison.OrdinalIgnoreCase) ||
                string.Equals(normalizedTool, "search_unity_docs", StringComparison.OrdinalIgnoreCase) ||
                string.Equals(normalizedTool, "read_unity_doc", StringComparison.OrdinalIgnoreCase) ||
                string.Equals(normalizedTool, "search_unity_api", StringComparison.OrdinalIgnoreCase) ||
                string.Equals(normalizedTool, "read_unity_api", StringComparison.OrdinalIgnoreCase) ||
                string.Equals(normalizedTool, "search_web", StringComparison.OrdinalIgnoreCase);
        }

        private static bool IsReferenceToolFailure(string normalizedTool, string result)
        {
            if (string.IsNullOrWhiteSpace(result))
            {
                return false;
            }

            string trimmed = result.Trim();
            if (trimmed.StartsWith("Tool failed:", StringComparison.OrdinalIgnoreCase) ||
                trimmed.StartsWith("Tool blocked:", StringComparison.OrdinalIgnoreCase))
            {
                return true;
            }

            return trimmed.StartsWith("read_text_file missing", StringComparison.OrdinalIgnoreCase) ||
                trimmed.StartsWith("read_text_file path", StringComparison.OrdinalIgnoreCase) ||
                trimmed.StartsWith("read_text_file only supports", StringComparison.OrdinalIgnoreCase) ||
                trimmed.StartsWith("inspect_prefab missing", StringComparison.OrdinalIgnoreCase) ||
                trimmed.StartsWith("inspect_prefab path", StringComparison.OrdinalIgnoreCase) ||
                trimmed.StartsWith("inspect_prefab failed", StringComparison.OrdinalIgnoreCase) ||
                trimmed.StartsWith("inspect_runtime_state failed", StringComparison.OrdinalIgnoreCase) ||
                trimmed.StartsWith("prefab not found", StringComparison.OrdinalIgnoreCase) ||
                trimmed.StartsWith("search_project missing", StringComparison.OrdinalIgnoreCase) ||
                trimmed.StartsWith("Local Unity docs index is empty", StringComparison.OrdinalIgnoreCase) ||
                trimmed.StartsWith("read_unity_doc missing", StringComparison.OrdinalIgnoreCase) ||
                trimmed.StartsWith("read_unity_doc not found", StringComparison.OrdinalIgnoreCase) ||
                trimmed.StartsWith("search_unity_api missing", StringComparison.OrdinalIgnoreCase) ||
                trimmed.StartsWith("read_unity_api missing", StringComparison.OrdinalIgnoreCase);
        }

        private static bool IsCleanSceneValidationResult(string result)
        {
            return !string.IsNullOrWhiteSpace(result) &&
                result.Trim().StartsWith("scene validation passed", StringComparison.OrdinalIgnoreCase);
        }

        private static void RemoveIssueLinesContaining(StringBuilder issueLog, params string[] needles)
        {
            if (issueLog == null || issueLog.Length == 0 || needles == null || needles.Length == 0)
            {
                return;
            }

            string[] lines = issueLog.ToString().Replace("\r\n", "\n").Replace('\r', '\n').Split('\n');
            issueLog.Length = 0;
            foreach (string line in lines)
            {
                if (string.IsNullOrWhiteSpace(line))
                {
                    continue;
                }

                bool remove = false;
                foreach (string needle in needles)
                {
                    if (!string.IsNullOrWhiteSpace(needle) &&
                        line.IndexOf(needle, StringComparison.OrdinalIgnoreCase) >= 0)
                    {
                        remove = true;
                        break;
                    }
                }

                if (!remove)
                {
                    issueLog.AppendLine(line.TrimEnd());
                }
            }
        }

        private static string FormatOptionalQuery(string query)
        {
            return string.IsNullOrWhiteSpace(query) ? string.Empty : $" for \"{CompactOneLine(query, 80)}\"";
        }

        private static string SummarizeReferenceToolResult(string normalizedTool, AgentAction action, string result)
        {
            if (string.Equals(normalizedTool, "search_project", StringComparison.OrdinalIgnoreCase))
            {
                string query = FirstNonEmpty(action?.query, action?.value, action?.name, action?.content, action?.path, action?.asset_path);
                string references = JoinTopMatchingLines(result, "- [", 4);
                return string.IsNullOrWhiteSpace(references)
                    ? $"Searched project for \"{CompactOneLine(query, 96)}\"."
                    : $"Searched project for \"{CompactOneLine(query, 96)}\"; top matches: {references}.";
            }

            if (string.Equals(normalizedTool, "search_unity_docs", StringComparison.OrdinalIgnoreCase))
            {
                string query = FirstNonEmpty(action?.query, action?.value, action?.name, action?.content, action?.path, action?.asset_path);
                string references = SummarizeUnityDocSearchResults(result, 4);
                return string.IsNullOrWhiteSpace(references)
                    ? $"Searched local Unity docs for \"{CompactOneLine(query, 96)}\"."
                    : $"Searched local Unity docs for \"{CompactOneLine(query, 96)}\"; top docs: {references}.";
            }

            if (string.Equals(normalizedTool, "search_unity_api", StringComparison.OrdinalIgnoreCase))
            {
                string query = FirstNonEmpty(action?.query, action?.value, action?.name, action?.content, action?.path, action?.asset_path);
                string references = SummarizeUnityApiSearchResults(result, 5);
                return string.IsNullOrWhiteSpace(references)
                    ? $"Searched installed Unity/package API source for \"{CompactOneLine(query, 96)}\"."
                    : $"Searched installed Unity/package API source for \"{CompactOneLine(query, 96)}\"; top source: {references}.";
            }

            if (string.Equals(normalizedTool, "read_text_file", StringComparison.OrdinalIgnoreCase))
            {
                string path = NormalizeReadableProjectPath(FirstNonEmpty(action?.path, action?.asset_path));
                string preview = ExtractReadTextFilePreview(result);
                return string.IsNullOrWhiteSpace(preview)
                    ? $"Read {path}."
                    : $"Read {path}; preview: {preview}.";
            }

            if (string.Equals(normalizedTool, "inspect_prefab", StringComparison.OrdinalIgnoreCase))
            {
                string path = NormalizeAssetPath(FirstNonEmpty(action?.path, action?.asset_path));
                string preview = ExtractPrefabInspectionPreview(result);
                return string.IsNullOrWhiteSpace(preview)
                    ? $"Inspected prefab {path}."
                    : $"Inspected prefab {path}; {preview}.";
            }

            if (string.Equals(normalizedTool, "inspect_runtime_state", StringComparison.OrdinalIgnoreCase))
            {
                string query = FirstNonEmpty(action?.query, action?.target, action?.name, action?.value, action?.content, action?.component);
                string preview = ExtractRuntimeStatePreview(result);
                return string.IsNullOrWhiteSpace(preview)
                    ? $"Inspected runtime state{FormatOptionalQuery(query)}."
                    : $"Inspected runtime state{FormatOptionalQuery(query)}; preview: {preview}.";
            }

            if (string.Equals(normalizedTool, "read_unity_api", StringComparison.OrdinalIgnoreCase))
            {
                string path = NormalizeReadableProjectPath(FirstNonEmpty(action?.path, action?.asset_path, action?.value, action?.query));
                string preview = ExtractReadTextFilePreview(result);
                return string.IsNullOrWhiteSpace(preview)
                    ? $"Read API source {path}."
                    : $"Read API source {path}; preview: {preview}.";
            }

            if (string.Equals(normalizedTool, "read_unity_doc", StringComparison.OrdinalIgnoreCase))
            {
                string idOrPath = FirstNonEmpty(action?.path, action?.asset_path, action?.name, action?.value, action?.query, action?.content);
                string preview = ExtractPlainPreview(result, 180);
                return string.IsNullOrWhiteSpace(preview)
                    ? $"Read Unity doc {CompactOneLine(idOrPath, 120)}."
                    : $"Read Unity doc {CompactOneLine(idOrPath, 120)}; preview: {preview}.";
            }

            return SummarizeToolResult(normalizedTool, result);
        }

        private static string SummarizeCompilerDiagnostics(string result, out bool hasCompilerError)
        {
            hasCompilerError = false;
            if (string.IsNullOrWhiteSpace(result))
            {
                return "Compiler diagnostics: no output.";
            }

            string normalized = result.Replace("\r\n", "\n").Replace('\r', '\n');
            if (normalized.IndexOf("No recent C# compiler diagnostics", StringComparison.OrdinalIgnoreCase) >= 0)
            {
                return "Compiler diagnostics: clean.";
            }

            string[] lines = normalized.Split('\n');
            List<string> diagnostics = new List<string>();
            foreach (string line in lines)
            {
                string trimmed = line.Trim();
                if (string.IsNullOrWhiteSpace(trimmed) ||
                    trimmed.StartsWith("Source:", StringComparison.OrdinalIgnoreCase) ||
                    trimmed.StartsWith("Compiler diagnostics", StringComparison.OrdinalIgnoreCase))
                {
                    continue;
                }

                bool isError = trimmed.IndexOf("error CS", StringComparison.OrdinalIgnoreCase) >= 0 ||
                    trimmed.IndexOf("Tundra build failed", StringComparison.OrdinalIgnoreCase) >= 0 ||
                    trimmed.IndexOf("Script Compilation Error", StringComparison.OrdinalIgnoreCase) >= 0;
                bool isWarning = trimmed.IndexOf("warning CS", StringComparison.OrdinalIgnoreCase) >= 0;
                if (!isError && !isWarning)
                {
                    continue;
                }

                hasCompilerError |= isError;
                diagnostics.Add(CompactOneLine(trimmed, 220));
                if (diagnostics.Count >= 3)
                {
                    break;
                }
            }

            if (diagnostics.Count == 0)
            {
                hasCompilerError = normalized.IndexOf("error", StringComparison.OrdinalIgnoreCase) >= 0 ||
                    normalized.IndexOf("failed", StringComparison.OrdinalIgnoreCase) >= 0;
                return hasCompilerError
                    ? "Compiler diagnostics: Unity reported a compile failure; inspect compiler diagnostics for details."
                    : "Compiler diagnostics: no current errors reported.";
            }

            string label = hasCompilerError ? "Compiler blocker" : "Compiler warnings";
            return $"{label}: {string.Join("; ", diagnostics.ToArray())}";
        }

        private static string SummarizeIssueToolResult(string result)
        {
            if (string.IsNullOrWhiteSpace(result))
            {
                return "Tool reported an issue.";
            }

            string normalized = result.Replace("\r\n", "\n").Replace('\r', '\n');
            string[] lines = normalized.Split('\n');
            List<string> important = new List<string>();
            foreach (string line in lines)
            {
                string trimmed = line.Trim();
                if (string.IsNullOrWhiteSpace(trimmed))
                {
                    continue;
                }

                if (important.Count == 0 ||
                    trimmed.StartsWith("Tool failed:", StringComparison.OrdinalIgnoreCase) ||
                    trimmed.StartsWith("Tool blocked:", StringComparison.OrdinalIgnoreCase) ||
                    trimmed.IndexOf("error CS", StringComparison.OrdinalIgnoreCase) >= 0 ||
                    trimmed.IndexOf(" not found", StringComparison.OrdinalIgnoreCase) >= 0 ||
                    trimmed.IndexOf("unsupported ", StringComparison.OrdinalIgnoreCase) >= 0 ||
                    trimmed.IndexOf("missing ", StringComparison.OrdinalIgnoreCase) >= 0)
                {
                    important.Add(CompactOneLine(trimmed, 220));
                }

                if (important.Count >= 3)
                {
                    break;
                }
            }

            return important.Count == 0
                ? CompactOneLine(normalized, 220)
                : string.Join("; ", important.ToArray());
        }

        private static string JoinTopMatchingLines(string result, string prefix, int maxCount)
        {
            if (string.IsNullOrWhiteSpace(result))
            {
                return string.Empty;
            }

            string[] lines = result.Replace("\r\n", "\n").Replace('\r', '\n').Split('\n');
            List<string> matches = new List<string>();
            foreach (string line in lines)
            {
                string trimmed = line.Trim();
                if (!trimmed.StartsWith(prefix, StringComparison.Ordinal))
                {
                    continue;
                }

                matches.Add(CompactOneLine(trimmed.TrimStart('-', ' '), 160));
                if (matches.Count >= maxCount)
                {
                    break;
                }
            }

            return string.Join("; ", matches.ToArray());
        }

        private static string SummarizeUnityDocSearchResults(string result, int maxCount)
        {
            if (string.IsNullOrWhiteSpace(result))
            {
                return string.Empty;
            }

            string[] lines = result.Replace("\r\n", "\n").Replace('\r', '\n').Split('\n');
            List<string> docs = new List<string>();
            string currentId = string.Empty;
            string currentTitle = string.Empty;
            string currentPath = string.Empty;
            for (int i = 0; i < lines.Length; i++)
            {
                string trimmed = lines[i].Trim();
                if (trimmed.StartsWith("- id=", StringComparison.Ordinal))
                {
                    AddDocReference(docs, currentId, currentTitle, currentPath, maxCount);
                    if (docs.Count >= maxCount)
                    {
                        break;
                    }

                    currentId = trimmed.Substring(2).Trim();
                    int space = currentId.IndexOf(' ');
                    if (space > 0)
                    {
                        currentId = currentId.Substring(0, space);
                    }

                    if (currentId.StartsWith("id=", StringComparison.Ordinal))
                    {
                        currentId = currentId.Substring(3);
                    }

                    currentTitle = string.Empty;
                    currentPath = string.Empty;
                    continue;
                }

                if (trimmed.StartsWith("title:", StringComparison.OrdinalIgnoreCase))
                {
                    currentTitle = trimmed.Substring("title:".Length).Trim();
                    continue;
                }

                if (trimmed.StartsWith("path:", StringComparison.OrdinalIgnoreCase))
                {
                    currentPath = trimmed.Substring("path:".Length).Trim();
                }
            }

            AddDocReference(docs, currentId, currentTitle, currentPath, maxCount);
            return string.Join("; ", docs.ToArray());
        }

        private static void AddDocReference(List<string> docs, string id, string title, string path, int maxCount)
        {
            if (docs == null || docs.Count >= maxCount || string.IsNullOrWhiteSpace(id))
            {
                return;
            }

            string label = string.IsNullOrWhiteSpace(title) ? id : $"{title} ({id})";
            if (!string.IsNullOrWhiteSpace(path))
            {
                label += $" at {path}";
            }

            docs.Add(CompactOneLine(label, 180));
        }

        private static string SummarizeUnityApiSearchResults(string result, int maxCount)
        {
            if (string.IsNullOrWhiteSpace(result))
            {
                return string.Empty;
            }

            string[] lines = result.Replace("\r\n", "\n").Replace('\r', '\n').Split('\n');
            List<string> sources = new List<string>();
            string currentPath = string.Empty;
            string currentTitle = string.Empty;
            for (int i = 0; i < lines.Length; i++)
            {
                string trimmed = lines[i].Trim();
                if (trimmed.StartsWith("- path=", StringComparison.Ordinal))
                {
                    AddApiReference(sources, currentPath, currentTitle, maxCount);
                    if (sources.Count >= maxCount)
                    {
                        break;
                    }

                    currentPath = trimmed.Substring("- path=".Length).Trim();
                    int score = currentPath.IndexOf(" score=", StringComparison.Ordinal);
                    if (score > 0)
                    {
                        currentPath = currentPath.Substring(0, score).Trim();
                    }

                    currentTitle = string.Empty;
                    continue;
                }

                if (trimmed.StartsWith("title:", StringComparison.OrdinalIgnoreCase))
                {
                    currentTitle = trimmed.Substring("title:".Length).Trim();
                }
            }

            AddApiReference(sources, currentPath, currentTitle, maxCount);
            return string.Join("; ", sources.ToArray());
        }

        private static void AddApiReference(List<string> sources, string path, string title, int maxCount)
        {
            if (sources == null || sources.Count >= maxCount || string.IsNullOrWhiteSpace(path))
            {
                return;
            }

            string label = string.IsNullOrWhiteSpace(title) ? path : $"{title} at {path}";
            sources.Add(CompactOneLine(label, 180));
        }

        private static string ExtractReadTextFilePreview(string result)
        {
            if (string.IsNullOrWhiteSpace(result))
            {
                return string.Empty;
            }

            string normalized = result.Replace("\r\n", "\n").Replace('\r', '\n');
            int firstFence = normalized.IndexOf("```", StringComparison.Ordinal);
            if (firstFence < 0)
            {
                return ExtractPlainPreview(normalized, 180);
            }

            int contentStart = normalized.IndexOf('\n', firstFence);
            if (contentStart < 0)
            {
                return string.Empty;
            }

            int lastFence = normalized.IndexOf("```", contentStart + 1, StringComparison.Ordinal);
            string content = lastFence < 0
                ? normalized.Substring(contentStart + 1)
                : normalized.Substring(contentStart + 1, lastFence - contentStart - 1);
            return ExtractPlainPreview(content, 180);
        }

        private static string ExtractPrefabInspectionPreview(string result)
        {
            if (string.IsNullOrWhiteSpace(result))
            {
                return string.Empty;
            }

            string[] lines = result.Replace("\r\n", "\n").Replace('\r', '\n').Split('\n');
            List<string> parts = new List<string>();
            foreach (string line in lines)
            {
                string trimmed = line.Trim();
                if (string.IsNullOrWhiteSpace(trimmed) ||
                    trimmed.StartsWith("Prefab:", StringComparison.OrdinalIgnoreCase))
                {
                    continue;
                }

                parts.Add(CompactOneLine(trimmed.TrimStart('-', ' '), 180));
                if (parts.Count >= 4)
                {
                    break;
                }
            }

            return string.Join("; ", parts.ToArray());
        }

        private static string ExtractRuntimeStatePreview(string result)
        {
            if (string.IsNullOrWhiteSpace(result))
            {
                return string.Empty;
            }

            string[] lines = result.Replace("\r\n", "\n").Replace('\r', '\n').Split('\n');
            List<string> parts = new List<string>();
            foreach (string line in lines)
            {
                string trimmed = line.Trim();
                if (string.IsNullOrWhiteSpace(trimmed) ||
                    string.Equals(trimmed, "Runtime state", StringComparison.OrdinalIgnoreCase))
                {
                    continue;
                }

                bool keep =
                    trimmed.StartsWith("- editor playing=", StringComparison.OrdinalIgnoreCase) ||
                    trimmed.StartsWith("- scene object count=", StringComparison.OrdinalIgnoreCase) ||
                    trimmed.StartsWith("- role counts:", StringComparison.OrdinalIgnoreCase) ||
                    trimmed.StartsWith("- MonoBehaviour/component counts:", StringComparison.OrdinalIgnoreCase) ||
                    trimmed.StartsWith("- matching ", StringComparison.OrdinalIgnoreCase) ||
                    trimmed.StartsWith("- inspect_runtime_state failed:", StringComparison.OrdinalIgnoreCase) ||
                    trimmed.StartsWith("- ", StringComparison.Ordinal);
                if (!keep)
                {
                    continue;
                }

                parts.Add(CompactOneLine(trimmed.TrimStart('-', ' '), 220));
                if (parts.Count >= 7)
                {
                    break;
                }
            }

            return string.Join("; ", parts.ToArray());
        }

        private static string ExtractPlainPreview(string value, int maxLength)
        {
            if (string.IsNullOrWhiteSpace(value))
            {
                return string.Empty;
            }

            string[] lines = value.Replace("\r\n", "\n").Replace('\r', '\n').Split('\n');
            foreach (string line in lines)
            {
                string trimmed = line.Trim();
                if (string.IsNullOrWhiteSpace(trimmed) ||
                    trimmed.StartsWith("```", StringComparison.Ordinal) ||
                    trimmed.StartsWith("File:", StringComparison.OrdinalIgnoreCase) ||
                    trimmed.StartsWith("Content length:", StringComparison.OrdinalIgnoreCase) ||
                    trimmed.StartsWith("Content truncated", StringComparison.OrdinalIgnoreCase))
                {
                    continue;
                }

                return CompactOneLine(trimmed, maxLength);
            }

            return string.Empty;
        }

        private static string BuildCodeSnippet(string path, string content)
        {
            if (string.IsNullOrWhiteSpace(content))
            {
                return string.Empty;
            }

            string language = GetSnippetLanguage(path);
            string normalized = content.Replace("\r\n", "\n").Replace('\r', '\n').Trim();
            string[] lines = normalized.Split('\n');
            int maxLines = Mathf.Min(lines.Length, 48);
            StringBuilder builder = new StringBuilder();
            builder.Append("```");
            builder.AppendLine(language);
            for (int i = 0; i < maxLines; i++)
            {
                builder.AppendLine(lines[i].TrimEnd());
            }

            if (lines.Length > maxLines)
            {
                builder.AppendLine($"// ... {lines.Length - maxLines} more line(s)");
            }

            builder.AppendLine("```");
            return builder.ToString();
        }

        private static string GetSnippetLanguage(string path)
        {
            string extension = Path.GetExtension(path ?? string.Empty).ToLowerInvariant();
            switch (extension)
            {
                case ".cs":
                    return "csharp";
                case ".json":
                    return "json";
                case ".uss":
                case ".css":
                    return "css";
                case ".uxml":
                case ".xml":
                    return "xml";
                case ".shader":
                case ".hlsl":
                case ".compute":
                    return "hlsl";
                case ".md":
                    return "markdown";
                default:
                    return string.Empty;
            }
        }

        private static bool IsIssueToolResult(string result)
        {
            if (string.IsNullOrWhiteSpace(result))
            {
                return false;
            }

            string normalized = result.Trim();
            return normalized.StartsWith("Tool failed:", StringComparison.OrdinalIgnoreCase) ||
                normalized.StartsWith("Tool blocked:", StringComparison.OrdinalIgnoreCase) ||
                normalized.StartsWith("missing ", StringComparison.OrdinalIgnoreCase) ||
                normalized.StartsWith("invalid ", StringComparison.OrdinalIgnoreCase) ||
                normalized.IndexOf(" missing ", StringComparison.OrdinalIgnoreCase) >= 0 ||
                normalized.IndexOf(" not found", StringComparison.OrdinalIgnoreCase) >= 0 ||
                normalized.IndexOf("unsupported ", StringComparison.OrdinalIgnoreCase) >= 0;
        }

        private static void AppendUserFacingLine(StringBuilder builder, string value)
        {
            if (builder == null || string.IsNullOrWhiteSpace(value))
            {
                return;
            }

            builder.AppendLine("- " + value.Trim());
        }

        private static string SummarizeToolResult(string toolName, string toolResult)
        {
            if (string.IsNullOrWhiteSpace(toolResult))
            {
                return "completed";
            }

            string[] lines = toolResult.Split(new[] { '\n' }, StringSplitOptions.RemoveEmptyEntries);
            if (!string.Equals(toolName, "capture_game_view", StringComparison.OrdinalIgnoreCase) &&
                !string.Equals(toolName, "capture_game_view_diagnostics", StringComparison.OrdinalIgnoreCase))
            {
                return lines.Length == 0 ? toolResult.Trim() : lines[0].Trim();
            }

            List<string> parts = new List<string>();
            if (lines.Length > 0)
            {
                string first = lines[0].Trim();
                int screenshotIndex = first.IndexOf("; screenshot=", StringComparison.OrdinalIgnoreCase);
                parts.Add(screenshotIndex >= 0 ? first.Substring(0, screenshotIndex).Trim() : first);
            }

            foreach (string rawLine in lines)
            {
                string line = rawLine.Trim();
                if (line.StartsWith("Visual stats:", StringComparison.OrdinalIgnoreCase))
                {
                    parts.Add(CompactVisualStats(line));
                }
                else if (line.StartsWith("Light influence test for ", StringComparison.OrdinalIgnoreCase))
                {
                    parts.Add(CompactLightInfluence(line));
                }
                else if (line.StartsWith("Warning:", StringComparison.OrdinalIgnoreCase) ||
                         line.StartsWith("Light influence warning", StringComparison.OrdinalIgnoreCase))
                {
                    parts.Add(line);
                }
            }

            return parts.Count == 0 ? toolResult.Trim() : string.Join(" | ", parts.ToArray());
        }

        private static string CompactVisualStats(string line)
        {
            List<string> parts = new List<string>();
            AppendMetric(parts, line, "avgLuminance=");
            AppendMetric(parts, line, "nonBlackPixels=");
            AppendMetric(parts, line, "brightPixels=");
            return parts.Count == 0 ? line : $"render {string.Join(", ", parts.ToArray())}";
        }

        private static string CompactLightInfluence(string line)
        {
            string target = line.Substring("Light influence test for ".Length);
            int separator = target.IndexOf(": disabling", StringComparison.OrdinalIgnoreCase);
            if (separator >= 0)
            {
                target = target.Substring(0, separator);
            }

            target = CompactLightTarget(target);
            List<string> parts = new List<string>();
            AppendMetric(parts, line, "changedPixels=");
            AppendMetric(parts, line, "avgLuminance=");
            return parts.Count == 0
                ? $"{target} influence measured"
                : $"{target} influence {string.Join(", ", parts.ToArray())}";
        }

        private static string CompactLightTarget(string target)
        {
            if (string.IsNullOrWhiteSpace(target))
            {
                return "light";
            }

            int serializedIndex = target.IndexOf("; serialized:", StringComparison.OrdinalIgnoreCase);
            if (serializedIndex >= 0)
            {
                target = target.Substring(0, serializedIndex);
            }

            int pathIndex = target.IndexOf(" path=", StringComparison.OrdinalIgnoreCase);
            if (pathIndex >= 0)
            {
                target = target.Substring(0, pathIndex);
            }

            return target.Trim();
        }

        private static void AppendMetric(List<string> parts, string line, string key)
        {
            string value = ExtractMetric(line, key);
            if (!string.IsNullOrWhiteSpace(value))
            {
                parts.Add($"{key.TrimEnd('=')}={value}");
            }
        }

        private static string ExtractMetric(string line, string key)
        {
            int start = line.IndexOf(key, StringComparison.OrdinalIgnoreCase);
            if (start < 0)
            {
                return string.Empty;
            }

            start += key.Length;
            int end = line.IndexOf(',', start);
            if (end < 0)
            {
                end = line.IndexOf(';', start);
            }

            if (end < 0)
            {
                end = line.Length;
            }

            return line.Substring(start, end - start).Trim();
        }

        public static string RunOpenAIToolLoop(string prompt, Action<string> progress)
        {
            return GetBackendRequiredMessage();
        }

        public static PlanReviewResult ParsePlanReview(PreparedRequest request, string responseJson)
        {
            if (request == null)
            {
                throw new ArgumentNullException(nameof(request));
            }

            string content = request.Kind == PreparedRequestKind.OpenAIPlanReview
                ? ExtractOpenAIMessageContent(responseJson)
                : responseJson;
            if (string.IsNullOrWhiteSpace(content))
            {
                return PlanReviewResult.Failed(request.OriginalPrompt, "OpenAI returned an empty plan response.");
            }

            if (!TryExtractJson(content, out string json))
            {
                return PlanReviewResult.Failed(request.OriginalPrompt, $"The agent returned a non-JSON plan response.\n\nRaw response:\n{content.Trim()}");
            }

            BackendResponse backendResponse;
            try
            {
                backendResponse = JsonUtility.FromJson<BackendResponse>(json);
            }
            catch (Exception exception)
            {
                return PlanReviewResult.Failed(request.OriginalPrompt, BuildInvalidJsonResponse(exception, json));
            }

            if (backendResponse == null)
            {
                return PlanReviewResult.Failed(request.OriginalPrompt, "The agent returned an empty plan response.");
            }

            int proposedActionCount = CountExecutableActions(backendResponse.actions);
            return new PlanReviewResult
            {
                Prompt = request.OriginalPrompt,
                Message = string.IsNullOrWhiteSpace(backendResponse.message)
                    ? (proposedActionCount == 0 ? "The agent returned an empty response." : "Review the proposed Unity changes.")
                    : backendResponse.message.Trim(),
                Plan = backendResponse.plan ?? new string[0],
                Progress = backendResponse.progress ?? new string[0],
                ActionSummaries = BuildPlannedActionSummaries(backendResponse.actions),
                ProposedActionCount = proposedActionCount,
                ProposedActionJson = proposedActionCount == 0 ? string.Empty : JsonUtility.ToJson(backendResponse),
                IsValid = true
            };
        }

        public static string BuildContext(string currentPrompt = "")
        {
            return BuildContextForRole(currentPrompt, AgentRoleDefault);
        }

        private static string BuildContextForRole(string currentPrompt, string agentRole)
        {
            AgenticProjectMemoryStore.ObserveLiveState(currentPrompt);
            Scene scene = SceneManager.GetActiveScene();
            StringBuilder builder = new StringBuilder();
            builder.AppendLine($"Project: {Application.productName}");
            builder.AppendLine($"Unity: {Application.unityVersion}");
            builder.AppendLine($"Active scene: {scene.name}");
            builder.AppendLine($"Scene path: {scene.path}");
            builder.AppendLine($"Scene dirty: {scene.isDirty}");
            builder.AppendLine();

            AppendEditorContext(builder);
            builder.AppendLine();

            AppendRecentCompilerDiagnostics(builder);
            builder.AppendLine();

            AppendRenderPipelineContext(builder);
            builder.AppendLine();

            AppendProjectManagementContext(builder);
            builder.AppendLine();

            builder.AppendLine(AgenticProjectGraphStore.BuildContextSection(currentPrompt));
            builder.AppendLine();

            builder.AppendLine(AgenticProjectContextIndexStore.BuildContextSection(currentPrompt));
            builder.AppendLine();

            builder.AppendLine(AgenticProjectMemoryStore.BuildContextSection());
            builder.AppendLine();

            AppendInstructionMemoryContext(builder, null, currentPrompt);

            builder.AppendLine(AgenticMemoryStore.BuildContextSection(currentPrompt));
            builder.AppendLine();

            builder.AppendLine(AgenticRoleDocsMemoryStore.BuildContextSection(agentRole, currentPrompt));
            builder.AppendLine();

            builder.AppendLine(AgenticTaggedContextStore.BuildContextSection());
            builder.AppendLine();

            AppendPromptRelevantProjectContext(builder, currentPrompt);
            builder.AppendLine();

            builder.AppendLine("Selection:");
            if (Selection.gameObjects.Length == 0)
            {
                builder.AppendLine("- none");
            }
            else
            {
                foreach (GameObject selected in Selection.gameObjects)
                {
                    builder.AppendLine($"- {GetHierarchyPath(selected)}{FormatGameObjectState(selected)}");
                    Component[] components = selected.GetComponents<Component>();
                    foreach (Component component in components)
                    {
                        if (component != null)
                        {
                            builder.AppendLine($"  component: {FormatComponentForContext(component)}");
                        }
                    }
                }
            }

            builder.AppendLine();
            builder.AppendLine("Scene roots:");
            GameObject[] roots = scene.GetRootGameObjects();
            int rootCount = Mathf.Min(roots.Length, 80);
            for (int i = 0; i < rootCount; i++)
            {
                AppendHierarchy(builder, roots[i], 0, 3);
            }

            if (roots.Length > rootCount)
            {
                builder.AppendLine($"- ... {roots.Length - rootCount} more root objects");
            }

            builder.AppendLine();
            AppendRuntimeInspectionContext(builder, currentPrompt, 24);

            builder.AppendLine();
            builder.AppendLine("Scene validation:");
            builder.AppendLine($"- {ValidateScene()}");

            builder.AppendLine();
            AppendGameViewDiagnostics(builder);

            builder.AppendLine();
            builder.AppendLine("Project assets:");
            string[] assetRoots = { "Assets" };
            int scriptCount = AssetDatabase.FindAssets("t:MonoScript", assetRoots).Length;
            int sceneCount = AssetDatabase.FindAssets("t:Scene", assetRoots).Length;
            int prefabCount = AssetDatabase.FindAssets("t:Prefab", assetRoots).Length;
            int textureCount = AssetDatabase.FindAssets("t:Texture2D", assetRoots).Length;
            builder.AppendLine($"- scripts: {scriptCount}");
            builder.AppendLine($"- scenes: {sceneCount}");
            builder.AppendLine($"- prefabs: {prefabCount}");
            builder.AppendLine($"- sprites/textures: {textureCount}");
            AppendAssetList(builder, "Script assets", "t:MonoScript", assetRoots, 40);
            AppendAssetList(builder, "Scene assets", "t:Scene", assetRoots, 20);
            AppendAssetList(builder, "Sprite/texture assets", "t:Texture2D", assetRoots, 30);

            return builder.ToString();
        }

        private static string BuildToolLoopContext(string currentPrompt, AgentAction lastAction, string agentRole)
        {
            return BuildToolLoopContext(null, currentPrompt, lastAction, agentRole);
        }

        private static string BuildToolLoopContext(ToolLoopState state, AgentAction lastAction, string agentRole)
        {
            return BuildToolLoopContext(state, state == null ? string.Empty : state.Prompt, lastAction, agentRole);
        }

        private static string BuildToolLoopContext(ToolLoopState state, string currentPrompt, AgentAction lastAction, string agentRole)
        {
            AgenticProjectMemoryStore.ObserveLiveState(state == null ? currentPrompt : state.Prompt);
            Scene scene = SceneManager.GetActiveScene();
            StringBuilder builder = new StringBuilder();
            builder.AppendLine($"Project: {Application.productName}");
            builder.AppendLine($"Unity: {Application.unityVersion}");
            builder.AppendLine($"Active scene: {scene.name}");
            builder.AppendLine($"Scene path: {scene.path}");
            builder.AppendLine($"Scene dirty: {scene.isDirty}");
            builder.AppendLine();

            builder.AppendLine(AgenticProjectMemoryStore.BuildContextSection());
            builder.AppendLine();

            builder.AppendLine(AgenticProjectGraphStore.BuildContextSection(currentPrompt));
            builder.AppendLine();

            builder.AppendLine(AgenticProjectContextIndexStore.BuildContextSection(currentPrompt));
            builder.AppendLine();

            AppendInstructionMemoryContext(builder, state, currentPrompt);

            builder.AppendLine(AgenticRoleDocsMemoryStore.BuildContextSection(agentRole, currentPrompt));
            builder.AppendLine();

            AppendTaskPlanContext(builder, state);
            AppendCompletedHandoffContext(builder, state);

            AppendLiveEditorContext(builder);
            builder.AppendLine();

            builder.Append(GetCachedToolLoopSelectionContext(state));
            builder.AppendLine();

            builder.Append(GetCachedToolLoopSceneRootContext(state, scene));
            builder.AppendLine();

            builder.Append(GetCachedToolLoopRuntimeInspectionContext(state, currentPrompt));
            builder.AppendLine();

            builder.AppendLine("Scene validation:");
            builder.AppendLine($"- {GetCachedToolLoopValidationSummary(state, scene)}");

            if (ShouldIncludeToolLoopGameView(lastAction))
            {
                builder.AppendLine();
                builder.Append(GetCachedToolLoopGameViewContext(state));
            }

            return builder.ToString();
        }

        private static string GetCachedToolLoopSelectionContext(ToolLoopState state)
        {
            if (state == null)
            {
                StringBuilder uncached = new StringBuilder();
                AppendSelectionContext(uncached);
                return uncached.ToString().TrimEnd();
            }

            int selectionHash = ComputeSelectionHash();
            if (selectionHash == state.CachedToolLoopSelectionHash &&
                !string.IsNullOrWhiteSpace(state.CachedToolLoopSelectionContext))
            {
                return state.CachedToolLoopSelectionContext;
            }

            StringBuilder builder = new StringBuilder();
            AppendSelectionContext(builder);
            state.CachedToolLoopSelectionHash = selectionHash;
            state.CachedToolLoopSelectionContext = builder.ToString().TrimEnd();
            return state.CachedToolLoopSelectionContext;
        }

        private static string GetCachedToolLoopSceneRootContext(ToolLoopState state, Scene scene)
        {
            if (state == null)
            {
                StringBuilder uncached = new StringBuilder();
                AppendSceneRootSummary(uncached);
                return uncached.ToString().TrimEnd();
            }

            string key = $"{scene.path}|{scene.isDirty}|{state.AppliedActions}";
            if (string.Equals(state.CachedToolLoopSceneRootKey, key, StringComparison.Ordinal) &&
                !string.IsNullOrWhiteSpace(state.CachedToolLoopSceneRootContext))
            {
                return state.CachedToolLoopSceneRootContext;
            }

            StringBuilder builder = new StringBuilder();
            AppendSceneRootSummary(builder);
            state.CachedToolLoopSceneRootKey = key;
            state.CachedToolLoopSceneRootContext = builder.ToString().TrimEnd();
            return state.CachedToolLoopSceneRootContext;
        }

        private static string GetCachedToolLoopRuntimeInspectionContext(ToolLoopState state, string currentPrompt)
        {
            if (state == null)
            {
                StringBuilder uncached = new StringBuilder();
                AppendRuntimeInspectionContext(uncached, currentPrompt, 18);
                return uncached.ToString().TrimEnd();
            }

            string promptKey = CompactOneLine(currentPrompt, 220);
            string key = $"{state.AppliedActions}|{EditorApplication.isPlaying}|{promptKey}";
            if (string.Equals(state.CachedToolLoopRuntimeInspectionKey, key, StringComparison.Ordinal) &&
                !string.IsNullOrWhiteSpace(state.CachedToolLoopRuntimeInspectionContext))
            {
                return state.CachedToolLoopRuntimeInspectionContext;
            }

            StringBuilder builder = new StringBuilder();
            AppendRuntimeInspectionContext(builder, currentPrompt, 18);
            state.CachedToolLoopRuntimeInspectionKey = key;
            state.CachedToolLoopRuntimeInspectionContext = builder.ToString().TrimEnd();
            return state.CachedToolLoopRuntimeInspectionContext;
        }

        private static string GetCachedToolLoopValidationSummary(ToolLoopState state, Scene scene)
        {
            if (state == null)
            {
                return ValidateScene();
            }

            string key = $"{scene.path}|{scene.isDirty}|{state.AppliedActions}";
            if (string.Equals(state.CachedToolLoopValidationKey, key, StringComparison.Ordinal) &&
                !string.IsNullOrWhiteSpace(state.CachedToolLoopValidationSummary))
            {
                return state.CachedToolLoopValidationSummary;
            }

            state.CachedToolLoopValidationKey = key;
            state.CachedToolLoopValidationSummary = ValidateScene();
            return state.CachedToolLoopValidationSummary;
        }

        private static string GetCachedToolLoopGameViewContext(ToolLoopState state)
        {
            if (state == null)
            {
                StringBuilder uncached = new StringBuilder();
                AppendGameViewDiagnostics(uncached, saveScreenshot: false);
                return uncached.ToString().TrimEnd();
            }

            string key = $"{state.AppliedActions}|{EditorApplication.isPlaying}";
            if (string.Equals(state.CachedToolLoopGameViewKey, key, StringComparison.Ordinal) &&
                !string.IsNullOrWhiteSpace(state.CachedToolLoopGameViewContext))
            {
                return state.CachedToolLoopGameViewContext;
            }

            StringBuilder builder = new StringBuilder();
            AppendGameViewDiagnostics(builder, saveScreenshot: false);
            state.CachedToolLoopGameViewKey = key;
            state.CachedToolLoopGameViewContext = builder.ToString().TrimEnd();
            return state.CachedToolLoopGameViewContext;
        }

        private static int ComputeSelectionHash()
        {
            unchecked
            {
                int hash = 17;
                GameObject[] selected = Selection.gameObjects;
                hash = (hash * 31) + selected.Length;
                for (int i = 0; i < selected.Length; i++)
                {
                    GameObject gameObject = selected[i];
                    hash = (hash * 31) + (gameObject == null ? 0 : gameObject.GetInstanceID());
                }

                return hash;
            }
        }

        private static void AppendLiveEditorContext(StringBuilder builder)
        {
            builder.AppendLine("Editor state:");
            builder.AppendLine($"- playing: {EditorApplication.isPlaying}");
            builder.AppendLine($"- paused: {EditorApplication.isPaused}");
            builder.AppendLine($"- compiling: {EditorApplication.isCompiling}");
            builder.AppendLine($"- updating assets: {EditorApplication.isUpdating}");
            builder.AppendLine($"- active build target: {EditorUserBuildSettings.activeBuildTarget}");
            int activeInputHandler = ReadProjectSettingInt("ProjectSettings/ProjectSettings.asset", "activeInputHandler", -1);
            builder.AppendLine($"- active input handling: {DescribeActiveInputHandling(activeInputHandler)}");
        }

        private static void AppendCompletedHandoffContext(StringBuilder builder, ToolLoopState state)
        {
            if (builder == null || state == null || state.CompletedHandoffEntries.Count == 0)
            {
                return;
            }

            builder.AppendLine("Completed specialist handoffs:");
            int shown = 0;
            for (int i = state.CompletedHandoffEntries.Count - 1; i >= 0 && shown < 8; i--)
            {
                if (!TryParseCompletedHandoffEntry(
                        state.CompletedHandoffEntries[i],
                        out int appliedActions,
                        out string role,
                        out string task))
                {
                    continue;
                }

                string stateLabel = appliedActions == state.AppliedActions
                    ? "current project state"
                    : $"after {appliedActions} applied action(s)";
                builder.AppendLine($"- {GetAgentDisplayName(role)} completed {stateLabel}: {CompactOneLine(task, 220)}");
                shown++;
            }

            builder.AppendLine("- Do not hand off the same role for a matching task again unless the project state changed or the next task is materially different.");
            builder.AppendLine();
        }

        private static void AppendSelectionContext(StringBuilder builder)
        {
            builder.AppendLine("Selection:");
            if (Selection.gameObjects.Length == 0)
            {
                builder.AppendLine("- none");
                return;
            }

            foreach (GameObject selected in Selection.gameObjects)
            {
                builder.AppendLine($"- {GetHierarchyPath(selected)}{FormatGameObjectState(selected)}");
                Component[] components = selected.GetComponents<Component>();
                int count = Mathf.Min(components.Length, 12);
                for (int i = 0; i < count; i++)
                {
                    Component component = components[i];
                    if (component != null)
                    {
                        builder.AppendLine($"  component: {FormatComponentForContext(component)}");
                    }
                }

                if (components.Length > count)
                {
                    builder.AppendLine($"  ... {components.Length - count} more component(s)");
                }
            }
        }

        private static void AppendSceneRootSummary(StringBuilder builder)
        {
            builder.AppendLine("Scene roots:");
            GameObject[] roots = SceneManager.GetActiveScene().GetRootGameObjects();
            int rootCount = Mathf.Min(roots.Length, 24);
            for (int i = 0; i < rootCount; i++)
            {
                AppendHierarchy(builder, roots[i], 0, 2);
            }

            if (roots.Length > rootCount)
            {
                builder.AppendLine($"- ... {roots.Length - rootCount} more root objects");
            }
        }

        private static bool ShouldIncludeToolLoopGameView(AgentAction lastAction)
        {
            string normalized = NormalizeActionType(lastAction?.type);
            return string.Equals(normalized, "capture_game_view", StringComparison.Ordinal) ||
                string.Equals(normalized, "capture_game_view_diagnostics", StringComparison.Ordinal) ||
                string.Equals(normalized, "create_object", StringComparison.Ordinal) ||
                string.Equals(normalized, "set_transform", StringComparison.Ordinal) ||
                string.Equals(normalized, "set_component_property", StringComparison.Ordinal) ||
                string.Equals(normalized, "set_object_property", StringComparison.Ordinal) ||
                string.Equals(normalized, "add_component", StringComparison.Ordinal) ||
                string.Equals(normalized, "remove_component", StringComparison.Ordinal) ||
                string.Equals(normalized, "instantiate_prefab", StringComparison.Ordinal) ||
                string.Equals(normalized, "open_scene", StringComparison.Ordinal) ||
                string.Equals(normalized, "create_scene", StringComparison.Ordinal);
        }

        private static void AppendEditorContext(StringBuilder builder)
        {
            builder.AppendLine("Editor state:");
            builder.AppendLine($"- playing: {EditorApplication.isPlaying}");
            builder.AppendLine($"- paused: {EditorApplication.isPaused}");
            builder.AppendLine($"- compiling: {EditorApplication.isCompiling}");
            builder.AppendLine($"- updating assets: {EditorApplication.isUpdating}");
            builder.AppendLine($"- active build target: {EditorUserBuildSettings.activeBuildTarget}");
            builder.AppendLine($"- color space: {PlayerSettings.colorSpace}");
            int activeInputHandler = ReadProjectSettingInt("ProjectSettings/ProjectSettings.asset", "activeInputHandler", -1);
            builder.AppendLine($"- active input handling: {DescribeActiveInputHandling(activeInputHandler)}");
        }

        private static void AppendRecentCompilerDiagnostics(StringBuilder builder)
        {
            builder.AppendLine("Compiler diagnostics:");
            string diagnostics = ReadRecentCompilerDiagnostics(80, 12000, out string logPath);
            builder.AppendLine($"- source: {logPath}");
            if (string.IsNullOrWhiteSpace(diagnostics))
            {
                builder.AppendLine("- no recent C# compiler diagnostics found in Editor.log");
                return;
            }

            AppendIndentedBlock(builder, diagnostics, "- ");
        }

        private static void AppendRenderPipelineContext(StringBuilder builder)
        {
            builder.AppendLine("Render pipeline:");
            AppendPipelineAsset(builder, "current", GraphicsSettings.currentRenderPipeline);
            AppendPipelineAsset(builder, "default", GraphicsSettings.defaultRenderPipeline);
            AppendPipelineAsset(builder, "quality", QualitySettings.renderPipeline);
        }

        private static void AppendProjectManagementContext(StringBuilder builder)
        {
            AppendSceneManagementContext(builder);
            builder.AppendLine();
            AppendBuildContext(builder);
            builder.AppendLine();
            AppendProjectSettingsContext(builder);
            builder.AppendLine();
            AppendTagsLayersContext(builder);
            builder.AppendLine();
            AppendPackageContext(builder);
        }

        private static void AppendSceneManagementContext(StringBuilder builder)
        {
            builder.AppendLine("Scene management:");
            builder.AppendLine($"- loaded scene count: {SceneManager.sceneCount}");
            for (int i = 0; i < SceneManager.sceneCount; i++)
            {
                Scene loadedScene = SceneManager.GetSceneAt(i);
                builder.AppendLine($"- loaded[{i}]: {loadedScene.name} path={loadedScene.path} active={loadedScene == SceneManager.GetActiveScene()} dirty={loadedScene.isDirty} loaded={loadedScene.isLoaded}");
            }

            EditorBuildSettingsScene[] buildScenes = EditorBuildSettings.scenes;
            builder.AppendLine($"- build scenes: {buildScenes.Length}");
            int count = Mathf.Min(buildScenes.Length, 20);
            for (int i = 0; i < count; i++)
            {
                EditorBuildSettingsScene buildScene = buildScenes[i];
                builder.AppendLine($"  [{i}] enabled={buildScene.enabled} path={buildScene.path}");
            }

            if (buildScenes.Length > count)
            {
                builder.AppendLine($"  ... {buildScenes.Length - count} more build scene(s)");
            }
        }

        private static void AppendBuildContext(StringBuilder builder)
        {
            builder.AppendLine("Build management:");
            builder.AppendLine($"- selected build target group: {EditorUserBuildSettings.selectedBuildTargetGroup}");
            builder.AppendLine($"- active build target: {EditorUserBuildSettings.activeBuildTarget}");
            builder.AppendLine($"- active build profile: {GetActiveBuildProfileSummary()}");
            builder.AppendLine($"- development build: {EditorUserBuildSettings.development}");
            builder.AppendLine($"- connect profiler: {EditorUserBuildSettings.connectProfiler}");
            builder.AppendLine($"- allow debugging: {EditorUserBuildSettings.allowDebugging}");
            builder.AppendLine($"- script debugging: {EditorUserBuildSettings.allowDebugging}");
        }

        private static string GetActiveBuildProfileSummary()
        {
            try
            {
                Type buildProfileType = FindTypeByName("UnityEditor.Build.Profile.BuildProfile");
                Type editorUserBuildSettingsType = typeof(EditorUserBuildSettings);
                PropertyInfo property = editorUserBuildSettingsType.GetProperty("activeBuildProfile", BindingFlags.Static | BindingFlags.Public | BindingFlags.NonPublic);
                if (property == null)
                {
                    return "not available in this Unity API";
                }

                object profile = property.GetValue(null, null);
                if (profile == null)
                {
                    return "none";
                }

                Object unityObject = profile as Object;
                if (unityObject != null)
                {
                    return $"{unityObject.name}{FormatAssetPath(AssetDatabase.GetAssetPath(unityObject))}";
                }

                return profile.ToString();
            }
            catch (Exception exception)
            {
                return $"unavailable ({exception.GetBaseException().Message})";
            }
        }

        private static void AppendProjectSettingsContext(StringBuilder builder)
        {
            builder.AppendLine("Project settings summary:");
            builder.AppendLine($"- company name: {PlayerSettings.companyName}");
            builder.AppendLine($"- product name: {PlayerSettings.productName}");
            builder.AppendLine($"- application identifier: {PlayerSettings.applicationIdentifier}");
            builder.AppendLine($"- run in background: {PlayerSettings.runInBackground}");
            builder.AppendLine($"- color space: {PlayerSettings.colorSpace}");
            builder.AppendLine($"- quality level: {QualitySettings.GetQualityLevel()} {GetCurrentQualityName()}");
            builder.AppendLine($"- quality names: {string.Join(", ", QualitySettings.names)}");
            builder.AppendLine($"- vSync count: {QualitySettings.vSyncCount}");
            builder.AppendLine($"- anti aliasing: {QualitySettings.antiAliasing}");
            builder.AppendLine($"- target frame rate: {Application.targetFrameRate}");
            builder.AppendLine($"- time scale: {FormatFloat(Time.timeScale)}, fixedDeltaTime={FormatFloat(Time.fixedDeltaTime)}, maximumDeltaTime={FormatFloat(Time.maximumDeltaTime)}");
            builder.AppendLine($"- physics gravity: {FormatVector3(Physics.gravity)}");
            builder.AppendLine($"- physics2D gravity: {FormatVector2(Physics2D.gravity)}");
            builder.AppendLine($"- physics2D queriesHitTriggers: {Physics2D.queriesHitTriggers}, queriesStartInColliders={Physics2D.queriesStartInColliders}");
            builder.AppendLine($"- audio speaker mode: {AudioSettings.speakerMode}");
            builder.AppendLine($"- audio output sample rate: {AudioSettings.outputSampleRate}");
            builder.AppendLine($"- lighting GI workflow: {GetLightmappingGiWorkflowMode()}");
            builder.AppendLine($"- lighting baked GI: {Lightmapping.bakedGI}, realtime GI: {Lightmapping.realtimeGI}");
        }

        private static string GetLightmappingGiWorkflowMode()
        {
            try
            {
                System.Reflection.PropertyInfo property = typeof(Lightmapping).GetProperty("giWorkflowMode", BindingFlags.Public | BindingFlags.Static);
                object value = property == null ? null : property.GetValue(null, null);
                return value == null ? "unavailable" : value.ToString();
            }
            catch (Exception exception)
            {
                return $"unavailable ({exception.GetBaseException().Message})";
            }
        }

        private static string GetCurrentQualityName()
        {
            string[] names = QualitySettings.names;
            int index = QualitySettings.GetQualityLevel();
            return names != null && index >= 0 && index < names.Length ? names[index] : string.Empty;
        }

        private static void AppendTagsLayersContext(StringBuilder builder)
        {
            builder.AppendLine("Tags, layers, and sorting:");
            builder.AppendLine($"- tags: {JoinLimited(InternalEditorUtility.tags, 30)}");
            builder.AppendLine($"- layers: {JoinLimited(InternalEditorUtility.layers, 32)}");
            SortingLayer[] sortingLayers = SortingLayer.layers;
            List<string> sortingNames = new List<string>();
            foreach (SortingLayer layer in sortingLayers)
            {
                sortingNames.Add($"{layer.name}(id={layer.id}, value={layer.value})");
            }

            builder.AppendLine($"- sorting layers: {JoinLimited(sortingNames.ToArray(), 30)}");
        }

        private static void AppendPackageContext(StringBuilder builder)
        {
            builder.AppendLine("Packages:");
            string manifestPath = Path.Combine(Directory.GetParent(Application.dataPath)?.FullName ?? string.Empty, "Packages/manifest.json");
            builder.AppendLine($"- manifest: Packages/manifest.json exists={File.Exists(manifestPath)}");
            string[] packages = ReadManifestPackageSummaries(manifestPath, 80);
            foreach (string package in packages)
            {
                builder.AppendLine($"- {package}");
            }
        }

        private static string[] ReadManifestPackageSummaries(string manifestPath, int maxCount)
        {
            if (string.IsNullOrWhiteSpace(manifestPath) || !File.Exists(manifestPath))
            {
                return new[] { "manifest not found" };
            }

            List<string> packages = new List<string>();
            bool inDependencies = false;
            foreach (string rawLine in File.ReadAllLines(manifestPath))
            {
                string line = rawLine.Trim();
                if (line.StartsWith("\"dependencies\"", StringComparison.Ordinal))
                {
                    inDependencies = true;
                    continue;
                }

                if (!inDependencies)
                {
                    continue;
                }

                if (line.StartsWith("}", StringComparison.Ordinal))
                {
                    break;
                }

                int separator = line.IndexOf(':');
                if (separator <= 0)
                {
                    continue;
                }

                string key = line.Substring(0, separator).Trim().Trim('"');
                string value = line.Substring(separator + 1).Trim().Trim(',').Trim().Trim('"');
                if (!string.IsNullOrWhiteSpace(key))
                {
                    packages.Add($"{key}@{value}");
                }

                if (packages.Count >= maxCount)
                {
                    packages.Add("... more packages omitted");
                    break;
                }
            }

            return packages.Count == 0 ? new[] { "no dependencies parsed" } : packages.ToArray();
        }

        private static string JoinLimited(string[] values, int maxCount)
        {
            if (values == null || values.Length == 0)
            {
                return "none";
            }

            int count = Mathf.Min(values.Length, maxCount);
            List<string> parts = new List<string>();
            for (int i = 0; i < count; i++)
            {
                if (!string.IsNullOrWhiteSpace(values[i]))
                {
                    parts.Add(values[i]);
                }
            }

            if (values.Length > count)
            {
                parts.Add($"... {values.Length - count} more");
            }

            return parts.Count == 0 ? "none" : string.Join(", ", parts.ToArray());
        }

        private static void AppendPipelineAsset(StringBuilder builder, string label, RenderPipelineAsset asset)
        {
            if (asset == null)
            {
                builder.AppendLine($"- {label}: Built-in Render Pipeline or not assigned");
                return;
            }

            string path = AssetDatabase.GetAssetPath(asset);
            builder.AppendLine($"- {label}: {asset.name} ({asset.GetType().Name}){FormatAssetPath(path)}{FormatSerializedDetails(asset, 6)}");
        }

        private static string FormatAssetPath(string path)
        {
            return string.IsNullOrWhiteSpace(path) ? string.Empty : $" path={path}";
        }

        private static void AppendGameViewDiagnostics(StringBuilder builder, bool saveScreenshot = true)
        {
            builder.AppendLine("Game view diagnostics:");
            string diagnostics = CaptureGameViewDiagnostics(saveScreenshot);
            if (string.IsNullOrWhiteSpace(diagnostics))
            {
                builder.AppendLine("- unavailable");
                return;
            }

            foreach (string line in diagnostics.Split(new[] { '\n' }, StringSplitOptions.RemoveEmptyEntries))
            {
                builder.AppendLine($"- {line.Trim()}");
            }
        }

        private static string CaptureGameViewDiagnostics(bool saveScreenshot)
        {
            Camera camera = FindDiagnosticCamera();
            if (camera == null)
            {
                return "No enabled camera was found, so the Game view could not be rendered.";
            }

            RenderCapture capture = null;
            try
            {
                string screenshotPath = saveScreenshot ? GetDiagnosticScreenshotPath() : string.Empty;
                capture = CaptureCameraRender(camera, screenshotPath);
                if (capture == null)
                {
                    return $"Failed to render camera {GetHierarchyPath(camera.gameObject)}.";
                }

                StringBuilder builder = new StringBuilder();
                builder.Append($"Rendered {GetHierarchyPath(camera.gameObject)} at {capture.Width}x{capture.Height}");
                if (!string.IsNullOrWhiteSpace(capture.ScreenshotPath))
                {
                    builder.Append($"; screenshot={capture.ScreenshotPath}");
                }

                builder.AppendLine();
                builder.AppendLine($"Visual stats: avgLuminance={FormatFloat(capture.AverageLuminance)}, maxLuminance={FormatFloat(capture.MaxLuminance)}, nonBlackPixels={FormatFloat(capture.NonBlackRatio * 100f)}%, brightPixels={FormatFloat(capture.BrightRatio * 100f)}%, contrast={FormatFloat(capture.LuminanceStdDev)}, averageColor={FormatColor(capture.AverageColor)}");
                string centerSample = capture.DescribeViewportSample("center", new Vector2(0.5f, 0.5f), 0.04f);
                builder.AppendLine($"Center sample: {centerSample}");

                AppendObjectRenderSample(builder, capture, camera, "Player_Red");
                AppendObjectRenderSample(builder, capture, camera, "Player_Light");

                string topColors = capture.DescribeTopColors(5);
                if (!string.IsNullOrWhiteSpace(topColors))
                {
                    builder.AppendLine($"Dominant colors: {topColors}");
                }

                AppendLightInfluenceDiagnostics(builder, camera, capture);

                if (capture.AverageLuminance < 0.03f && capture.NonBlackRatio < 0.08f)
                {
                    builder.AppendLine("Warning: rendered camera image is mostly dark/black.");
                }

                return builder.ToString().TrimEnd();
            }
            catch (Exception exception)
            {
                return $"Game view render diagnostic failed: {exception.GetType().Name}: {exception.Message}";
            }
            finally
            {
                capture?.Dispose();
            }
        }

        private static Camera FindDiagnosticCamera()
        {
            Camera mainCamera = Camera.main;
            if (mainCamera != null && mainCamera.enabled && mainCamera.gameObject.activeInHierarchy)
            {
                return mainCamera;
            }

            Camera[] cameras = Object.FindObjectsByType<Camera>(FindObjectsInactive.Exclude, FindObjectsSortMode.None);
            foreach (Camera camera in cameras)
            {
                if (camera != null && camera.enabled && camera.gameObject.activeInHierarchy)
                {
                    return camera;
                }
            }

            return cameras.Length == 0 ? null : cameras[0];
        }

        private static string GetDiagnosticScreenshotPath()
        {
            string directory = Path.GetFullPath(Path.Combine(Application.dataPath, "../Library/AgenticGamedev/Diagnostics"));
            Directory.CreateDirectory(directory);
            string sceneName = SanitizeFileName(SceneManager.GetActiveScene().name);
            return Path.Combine(directory, $"{sceneName}-gameview-latest.png");
        }

        private static RenderCapture CaptureCameraRender(Camera camera, string screenshotPath)
        {
            RenderTexture previousTarget = camera.targetTexture;
            RenderTexture previousActive = RenderTexture.active;
            RenderTexture renderTexture = null;
            Texture2D texture = null;

            try
            {
                renderTexture = new RenderTexture(DiagnosticRenderWidth, DiagnosticRenderHeight, 24, RenderTextureFormat.ARGB32)
                {
                    antiAliasing = 1
                };
                texture = new Texture2D(DiagnosticRenderWidth, DiagnosticRenderHeight, TextureFormat.RGBA32, false);
                camera.targetTexture = renderTexture;
                RenderTexture.active = renderTexture;
                camera.Render();
                texture.ReadPixels(new Rect(0, 0, DiagnosticRenderWidth, DiagnosticRenderHeight), 0, 0);
                texture.Apply(false);

                if (!string.IsNullOrWhiteSpace(screenshotPath))
                {
                    File.WriteAllBytes(screenshotPath, texture.EncodeToPNG());
                }

                return new RenderCapture(DiagnosticRenderWidth, DiagnosticRenderHeight, texture.GetPixels32(), screenshotPath);
            }
            finally
            {
                camera.targetTexture = previousTarget;
                RenderTexture.active = previousActive;
                if (renderTexture != null)
                {
                    renderTexture.Release();
                    Object.DestroyImmediate(renderTexture);
                }

                if (texture != null)
                {
                    Object.DestroyImmediate(texture);
                }
            }
        }

        private static void AppendObjectRenderSample(StringBuilder builder, RenderCapture capture, Camera camera, string objectName)
        {
            GameObject target = FindTarget(objectName);
            if (target == null)
            {
                return;
            }

            Vector3 viewport = camera.WorldToViewportPoint(target.transform.position);
            if (viewport.z < 0f || viewport.x < 0f || viewport.x > 1f || viewport.y < 0f || viewport.y > 1f)
            {
                builder.AppendLine($"{objectName} render sample: outside camera view at viewport=({FormatFloat(viewport.x)},{FormatFloat(viewport.y)},{FormatFloat(viewport.z)})");
                return;
            }

            builder.AppendLine($"{objectName} render sample: viewport=({FormatFloat(viewport.x)},{FormatFloat(viewport.y)}), {capture.DescribeViewportSample(objectName, new Vector2(viewport.x, viewport.y), 0.06f)}");
        }

        private static void AppendLightInfluenceDiagnostics(StringBuilder builder, Camera camera, RenderCapture currentCapture)
        {
            List<Component> candidates = FindDiagnosticLightComponents();
            if (candidates.Count == 0)
            {
                builder.AppendLine("Light influence test: no Light or Light2D components found to test.");
                return;
            }

            int tested = 0;
            foreach (Component lightComponent in candidates)
            {
                if (lightComponent == null || tested >= 4)
                {
                    continue;
                }

                tested++;
                string description = DescribeLightComponentForDiagnostic(lightComponent);
                bool originalEnabled;
                if (!TryGetEnabledState(lightComponent, out originalEnabled))
                {
                    builder.AppendLine($"Light influence test for {description}: component enabled state could not be toggled.");
                    continue;
                }

                RenderCapture disabledCapture = null;
                try
                {
                    SetEnabledState(lightComponent, false);
                    disabledCapture = CaptureCameraRender(camera, string.Empty);
                    PixelDifference difference = PixelDifference.Compare(currentCapture, disabledCapture);
                    builder.AppendLine($"Light influence test for {description}: disabling it changed avgRGB={FormatFloat(difference.AverageRgbDelta)}, avgLuminance={FormatFloat(difference.AverageLuminanceDelta)}, changedPixels={FormatFloat(difference.ChangedRatio * 100f)}%");
                    if (difference.AverageRgbDelta < 0.004f && difference.ChangedRatio < 0.01f)
                    {
                        builder.AppendLine($"Light influence warning for {description}: this light has little or no visible effect in the camera render.");
                    }
                }
                catch (Exception exception)
                {
                    builder.AppendLine($"Light influence test for {description} failed: {exception.GetType().Name}: {exception.Message}");
                }
                finally
                {
                    SetEnabledState(lightComponent, originalEnabled);
                    disabledCapture?.Dispose();
                }
            }
        }

        private static List<Component> FindDiagnosticLightComponents()
        {
            List<Component> components = new List<Component>();
            AddDiagnosticLightComponents(components, Selection.activeGameObject);
            AddDiagnosticLightComponents(components, FindTarget("Player_Light"));

            Light[] lights = Object.FindObjectsByType<Light>(FindObjectsInactive.Exclude, FindObjectsSortMode.None);
            foreach (Light light in lights)
            {
                AddUniqueComponent(components, light);
            }

            foreach (GameObject root in SceneManager.GetActiveScene().GetRootGameObjects())
            {
                AddLight2DComponentsInChildren(components, root.transform);
            }

            return components;
        }

        private static void AddDiagnosticLightComponents(List<Component> components, GameObject gameObject)
        {
            if (components == null || gameObject == null)
            {
                return;
            }

            Component[] allComponents = gameObject.GetComponents<Component>();
            foreach (Component component in allComponents)
            {
                if (IsLightLikeComponent(component))
                {
                    AddUniqueComponent(components, component);
                }
            }
        }

        private static void AddLight2DComponentsInChildren(List<Component> components, Transform transform)
        {
            if (components == null || transform == null)
            {
                return;
            }

            AddDiagnosticLightComponents(components, transform.gameObject);
            for (int i = 0; i < transform.childCount; i++)
            {
                AddLight2DComponentsInChildren(components, transform.GetChild(i));
            }
        }

        private static bool IsLightLikeComponent(Component component)
        {
            return component is Light ||
                (component != null && string.Equals(component.GetType().Name, "Light2D", StringComparison.OrdinalIgnoreCase));
        }

        private static void AddUniqueComponent(List<Component> components, Component component)
        {
            if (component != null && !components.Contains(component))
            {
                components.Add(component);
            }
        }

        private static string DescribeLightComponentForDiagnostic(Component component)
        {
            if (component == null)
            {
                return "missing light";
            }

            return $"{GetHierarchyPath(component.gameObject)} {FormatComponentForContext(component)}";
        }

        private static bool TryGetEnabledState(Component component, out bool enabled)
        {
            if (component is Behaviour behaviour)
            {
                enabled = behaviour.enabled;
                return true;
            }

            enabled = false;
            return false;
        }

        private static void SetEnabledState(Component component, bool enabled)
        {
            if (component is Behaviour behaviour)
            {
                behaviour.enabled = enabled;
            }
        }

        public static string GetBackendRequiredMessage()
        {
            return $"Backend scripting agent is not reachable. Start AgentDaemon with `cd AgentDaemon && npm run server`, then use endpoint {DefaultEndpoint}.";
        }

        public static string FormatRequestException(Exception exception)
        {
            return FormatRequestException(exception, Environment.GetEnvironmentVariable(ApiKeyEnvironmentKey));
        }

        public static void ClearTransientOpenAIRetryState(ToolLoopState state)
        {
            if (state != null)
            {
                state.ConsecutiveRequestFailureCount = 0;
            }
        }

        public static bool TryPrepareTransientOpenAIRetry(
            ToolLoopState state,
            Exception exception,
            out string summary,
            out int delayMs)
        {
            summary = string.Empty;
            delayMs = 0;
            if (state == null || !IsTransientOpenAIRequestFailure(exception))
            {
                return false;
            }

            int nextAttempt = state.ConsecutiveRequestFailureCount + 1;
            if (nextAttempt > MaxTransientOpenAIRetries)
            {
                return false;
            }

            state.ConsecutiveRequestFailureCount = nextAttempt;
            int[] delays = { 1500, 4000 };
            delayMs = delays[Mathf.Clamp(nextAttempt - 1, 0, delays.Length - 1)];
            summary = $"Transient OpenAI network/TLS failure; retrying request {nextAttempt}/{MaxTransientOpenAIRetries} in {Mathf.RoundToInt(delayMs / 1000f)}s.";
            SaveResumableToolLoopState(state);
            return true;
        }

        public static bool IsTransientOpenAIRequestFailure(Exception exception)
        {
            if (exception == null)
            {
                return false;
            }

            string formatted = FormatRequestException(exception);
            string lower = formatted.ToLowerInvariant();
            if (ContainsAny(lower, "invalid_api_key", "incorrect api key", "unauthorized", "http 401", "permission denied"))
            {
                return false;
            }

            if (ContainsAny(
                    lower,
                    "unitytls_internal_error",
                    "failed to read data to tls context",
                    "tls",
                    "ssl",
                    "secure channel",
                    "connection reset",
                    "connection closed",
                    "request was aborted",
                    "request aborted",
                    "temporarily unavailable",
                    "timeout",
                    "timed out",
                    "name resolution",
                    "receivefailure",
                    "sendfailure",
                    "keepalivefailure",
                    "connectfailure"))
            {
                return true;
            }

            Exception current = exception is AggregateException aggregateException
                ? aggregateException.Flatten().InnerException ?? exception
                : exception;
            int depth = 0;
            while (current != null && depth < 8)
            {
                if (current is WebException webException)
                {
                    switch (webException.Status)
                    {
                        case WebExceptionStatus.ConnectFailure:
                        case WebExceptionStatus.ConnectionClosed:
                        case WebExceptionStatus.KeepAliveFailure:
                        case WebExceptionStatus.NameResolutionFailure:
                        case WebExceptionStatus.ReceiveFailure:
                        case WebExceptionStatus.RequestCanceled:
                        case WebExceptionStatus.SecureChannelFailure:
                        case WebExceptionStatus.SendFailure:
                        case WebExceptionStatus.Timeout:
                            return true;
                    }
                }

                string typeName = current.GetType().Name;
                if (typeName.IndexOf("TlsException", StringComparison.OrdinalIgnoreCase) >= 0)
                {
                    return true;
                }

                current = current.InnerException;
                depth++;
            }

            return false;
        }

        private static string FormatRequestException(Exception exception, string apiKey)
        {
            if (exception == null)
            {
                return "Unknown request failure.";
            }

            if (exception is AggregateException aggregateException)
            {
                exception = aggregateException.Flatten().InnerException ?? aggregateException;
            }

            StringBuilder builder = new StringBuilder();
            Exception current = exception;
            int depth = 0;
            while (current != null && depth < 6)
            {
                string message = RedactRequestSecret(current.Message, apiKey);
                if (!string.IsNullOrWhiteSpace(message))
                {
                    if (builder.Length > 0)
                    {
                        builder.Append(" Inner: ");
                    }

                    builder.Append(current.GetType().Name);
                    builder.Append(": ");
                    builder.Append(message);
                }

                current = current.InnerException;
                depth++;
            }

            return builder.Length == 0 ? exception.GetType().Name : builder.ToString();
        }

        private static string RunOpenAIDirect(string prompt)
        {
            try
            {
                string context = BuildContext(prompt);
                string requestJson = JsonUtility.ToJson(new OpenAIChatRequest
                {
                    model = GetModel(),
                    response_format = OpenAIResponseFormat.JsonObject(),
                    messages = new[]
                    {
                        new OpenAIRequestMessage
                        {
                            role = "developer",
                            content = BuildOpenAISystemPrompt(context)
                        },
                        new OpenAIRequestMessage
                        {
                            role = "user",
                            content = prompt
                        }
                    }
                });

                string responseJson = PostJson(OpenAIChatCompletionsEndpoint, requestJson, includeApiKeyHeader: false);
                string content = ExtractOpenAIMessageContent(responseJson);
                if (string.IsNullOrWhiteSpace(content))
                {
                    return "OpenAI returned an empty message.";
                }

                if (TryExtractJson(content, out string actionJson))
                {
                    return ExecuteResponseJson(actionJson);
                }

                return content.Trim();
            }
            catch (Exception exception)
            {
                return $"OpenAI request failed: {FormatRequestException(exception)}";
            }
        }

        private static string BuildOpenAISystemPrompt()
        {
            return BuildOpenAISystemPrompt(BuildContext());
        }

        private static string BuildOpenAISystemPrompt(string context)
        {
            return BuildOpenAIApprovedExecutionPrompt(context, AnalyzePromptInterpretation(string.Empty));
        }

        private static string BuildOpenAIPlanReviewPrompt(string context, PromptInterpretation interpretation)
        {
            return "You are an agentic Unity game-development assistant, closer to Codex, Claude Code, or Cursor than a narrow task runner. Use the provided Unity context, including project management context and actual Game view render diagnostics, and the user's prompt to decide what the user is asking for. Return only JSON in this shape: {\"message\":\"direct user-facing response\",\"plan\":[\"optional high-level step\"],\"progress\":[\"optional observable note\"],\"actions\":[...]}. Do not wrap in markdown. Do not reveal hidden chain-of-thought; plan and progress must be concise, user-facing operational notes. If the user only asks a question, answer it directly and return actions:[]. Treat error/debugging prompts as fix requests unless the user explicitly asks for explanation only. If the user asks for a project/editor/code/scene change, or if the best response is to propose a concrete repair that changes the project, include the exact executable Unity actions that should run only after approval. The editor will show approval controls when actions is non-empty, so do not ask the user to approve in prose. If more information is genuinely required before a safe action can be proposed, ask one direct question and return actions:[]. Work toward the user's goal end-to-end across scene, project settings, lighting, packages, build scenes/profiles, assets, importers, and scripts. Runtime behavior, object recreation on Play, component lifecycle, and script-error debugging require source inspection; use read_text_file or propose source-reading/editing actions before claiming a code cause. Prefer direct generic tools when available. Use direct actions for ordinary scene, component, package-component, and Play Mode work; only write an Editor script under Assets/Editor when the direct action schema cannot perform the needed UnityEditor API operation. Build scene objects generically from JSON: create_object for the GameObject, ensure_components for required components, set_component_property for serialized fields, then validate. Do not rely on preset-specific object creation actions. Do not claim that files, scripts, lights, components, or objects will be created unless the actions array contains the corresponding actions. Do not create an empty GameObject unless it is intentionally an empty parent/container; otherwise include required components and properties. For new C# components, use write_csharp_script(path,content,target,component); Unity will attach it after scripts compile. Include validate_scene near the end of non-trivial changes, and include capture_game_view after visual, lighting, camera, material, or render changes. " +
                FeatureCompletionInstruction + " " +
                PlayableSceneSetupInstruction + " " +
                EnemyArchetypeInstruction + " " +
                WorkingMemoryInstruction + " " +
                SemanticWorkflowInstruction + " " +
                PromptDepthInstruction + " " +
                ModularImplementationInstruction + " " +
                FocusedImplementationInstruction + " " +
                ImplementationResearchInstruction + " " +
                ResponsivenessInstruction + " " +
                BuildPromptDepthBehavior(interpretation) + " " +
                TaskPlanningInstruction + " " +
                DocsFallbackInstruction + " " +
                CompilerRepairInstruction + " " +
                FinalResponseInstruction + " " +
                GetActionSchema() +
                "\n\nCurrent Unity context:\n" +
                context;
        }

        private static string BuildOpenAIManagerPrompt(string context, PromptInterpretation interpretation)
        {
            return "You are the Orchestrator manager for a multi-agent Unity game-development system. Understand the high-level engineering goal, break it into concrete work, route work to specialist agents, and review their output against the user's request before responding. You do not directly modify the Unity project except for read/review tools. Use handoff_to_agent(role, content) to delegate one scoped task at a time. Built-in specialist roles: default for broad fallback work, worker for focused implementation and code fixes, explorer for read-heavy codebase/project navigation, scene_setup for live scene hierarchy/component/camera/layout work, asset_management for prefab/material/sprite/asset/build-settings work, and monitor for play-mode/validation/polling workflows. After a specialist returns, use that result as authoritative context: either give the final concise answer or delegate a materially different follow-up task tied to a specific remaining blocker. Do not hand off the same role for the same or reworded task again when the project has not changed since that specialist returned. For change requests such as make, improve, fix, add, remove, implement, tune, or replace, exploration alone is not completion: after Explorer returns findings, delegate concrete implementation to Worker, Scene Setup, Asset Management, or Default unless the specialist found a specific blocker that prevents safe edits. Do not finish a change request with only suggestions, likely improvements, or next-step language when tools can still make the project change. " +
                FeatureCompletionInstruction + " " +
                PlayableSceneSetupInstruction + " " +
                EnemyArchetypeInstruction + " " +
                WorkingMemoryInstruction + " " +
                SemanticWorkflowInstruction + " " +
                PromptDepthInstruction + " " +
                ModularImplementationInstruction + " " +
                FocusedImplementationInstruction + " " +
                ImplementationResearchInstruction + " " +
                ResponsivenessInstruction + " " +
                BuildPromptDepthBehavior(interpretation) + " " +
                TaskPlanningInstruction + " " +
                DocsFallbackInstruction + " " +
                CompilerRepairInstruction + " " +
                FinalResponseInstruction + " " +
                SceneFirstInstruction + " Use the role-scoped docs memory as a router: keep high-level Unity workflow/docs context in the manager and delegate exact API/source retrieval to the appropriate specialist. Prefer explorer before worker when a bug or feature requires source discovery. Prefer scene_setup before worker for scene-bearing feature work. Prefer asset_management before worker for prefab, asset, and Build Settings work. Prefer worker for concrete code edits after scene and asset prerequisites are in place. Prefer scene_setup for scene cameras, hierarchy, transforms, object composition, and scene wiring. Prefer asset_management for prefabs, asset values, generated assets, and Build Settings scene lists. Prefer monitor for Play Mode, validation, Game view capture, and repeated checks. Call exactly one tool per assistant turn. Do not reveal hidden chain-of-thought. Manager allowed tools: " +
                BuildAllowedToolList(AgentRoleManager) +
                ". The handoff tool takes role plus content/query/value for the delegated task. In this function-calling loop, call function tools directly; use the action schema only for argument names and serialized Unity property guidance. " +
                GetActionSchema() +
                "\n\nCurrent Unity context:\n" +
                context;
        }

        private static string BuildOpenAISpecialistPrompt(string role, string context, string task, PromptInterpretation interpretation)
        {
            string normalizedRole = NormalizeAgentRole(role);
            return "You are the " + GetAgentDisplayName(normalizedRole) + " specialist in a multi-agent Unity game-development system. You received a delegated task from the Orchestrator manager. Work only on that delegated task, use your allowed tools, and return a concise result when done. Call exactly one Unity tool per assistant turn, then inspect the tool result and updated context before choosing the next step. Do not delegate to another agent; return findings or completed work to the manager. Do not reveal hidden chain-of-thought. In this function-calling loop, call function tools directly; use the action schema only for argument names and serialized Unity property guidance. " +
                FeatureCompletionInstruction + " " +
                PlayableSceneSetupInstruction + " " +
                EnemyArchetypeInstruction + " " +
                WorkingMemoryInstruction + " " +
                SemanticWorkflowInstruction + " " +
                PromptDepthInstruction + " " +
                ModularImplementationInstruction + " " +
                FocusedImplementationInstruction + " " +
                ImplementationResearchInstruction + " " +
                ResponsivenessInstruction + " " +
                BuildPromptDepthBehavior(interpretation) + " " +
                TaskPlanningInstruction + " " +
                DocsFallbackInstruction + " " +
                CompilerRepairInstruction + " " +
                FinalResponseInstruction + " " +
                SceneFirstInstruction + " " +
                BuildRoleInstruction(normalizedRole) +
                " Allowed tools for this specialist: " + BuildAllowedToolList(normalizedRole) + ". " +
                GetActionSchema() +
                "\n\nDelegated task:\n" +
                (task ?? string.Empty) +
                "\n\nCurrent Unity context:\n" +
                context;
        }

        private static string BuildSpecialistUserPrompt(
            string role,
            string task,
            string originalPrompt,
            string instructionMemory,
            PromptInterpretation interpretation)
        {
            StringBuilder builder = new StringBuilder();
            builder.AppendLine("Delegated specialist task for " + GetAgentDisplayName(role) + ":");
            builder.AppendLine(task ?? string.Empty);
            builder.AppendLine();
            if (!string.IsNullOrWhiteSpace(instructionMemory))
            {
                builder.AppendLine(instructionMemory.Trim());
                builder.AppendLine();
            }

            builder.AppendLine("Interpretation mode: " + NormalizePromptInterpretationMode(interpretation.Mode));
            builder.AppendLine("Interpretation guidance: " + (string.IsNullOrWhiteSpace(interpretation.Summary) ? "Use best judgment." : interpretation.Summary));
            if (!string.IsNullOrWhiteSpace(originalPrompt))
            {
                builder.AppendLine();
                builder.AppendLine("Original user request:");
                builder.AppendLine(originalPrompt.Trim());
            }

            builder.AppendLine();
            builder.AppendLine("Use tools only as needed. When done, return a concise result for the Orchestrator manager.");
            return builder.ToString().TrimEnd();
        }

        private static string BuildRoleInstruction(string role)
        {
            switch (NormalizeAgentRole(role))
            {
                case AgentRoleWorker:
                    return "Worker is execution-focused: implement code fixes, reusable modules, and script-level behavior after source inspection. Execute the current directive directly and keep scope tight; do not drift into adjacent redesign work. For focused code requests, use a small reusable module plus the minimal source integration point instead of broad scene churn. For scene/asset-dependent feature work, only require scene_setup or asset_management when a concrete camera, object, prefab, reference, or asset value is missing and the code cannot work without it. Use the role-scoped programming docs/API memory for recall, then search/read exact local docs or installed API source before writing code that depends on uncertain Unity members, setters, serialized paths, lifecycle behavior, or package APIs. If local docs and installed source do not outline the required implementation approach, call search_web before choosing or writing a custom pattern. If an installed engine or package feature already solves the requested pattern cleanly, consider it before writing a custom equivalent. Keep one hypothesis per compile cycle: do not rewrite the same file with multiple alternative service shapes, architectural directions, or namespace/package strategies unless new local evidence forces that change. Inspect relevant project source before editing, keep changes scoped, rebuild/read compiler diagnostics after writing, and validate only as much as the request requires. Broad destructive/project-wide actions are intentionally blocked. ";
                case AgentRoleExplorer:
                    return "Explorer is read-heavy: navigate scripts, prefabs, assets, packages, and scene context; gather evidence; do not mutate project state. Return concrete file/object references and recommended next steps. ";
                case AgentRoleSceneSetup:
                    return "Scene Setup handles live scene authoring: create and wire GameObjects, cameras, transforms, colliders, lights, scene hierarchy, and scene-level component configuration. Prefer direct scene actions over writing code when the schema already covers the change. For feature work, set up the required in-editor scene state before asking for new scripts. If runtime validation says a required scene object such as a camera is missing, fix the live scene directly before returning. ";
                case AgentRoleAssetManagement:
                    return "Asset Management handles prefab and asset workflows: inspect and edit prefabs, materials, sprites, generated assets, scriptable objects, and Build Settings scene lists. Establish prefab and asset prerequisites before code changes depend on them, and verify prefab and asset values directly after editing instead of assuming a helper script changed them. ";
                case AgentRoleMonitor:
                    return "Monitor handles long-running and validation-oriented workflows: enter or exit Play Mode when needed, inspect_runtime_state after Play Mode starts, capture Game view diagnostics, run validation, poll observable state, and report completion/failure signals. For gameplay tasks, do not treat a nonblank render as proof: verify live spawned objects, component references, UI state, and runtime counters through inspect_runtime_state or report them as unverified blockers. ";
                default:
                    return "Default is the general fallback specialist: handle mixed Unity tasks pragmatically, inspect before changing code, use direct generic tools, and validate non-trivial changes. ";
            }
        }

        private static string BuildOpenAIToolLoopPrompt(string context, PromptInterpretation interpretation)
        {
            return "You are an agentic Unity game-development assistant running in auto-run mode. The user has allowed you to modify the Unity project without a separate approval step. Use the provided Unity context, including project management context and actual Game view render diagnostics, and decide what to do from the user's prompt. If the user only asks a question, answer directly without calling tools. Treat error/debugging prompts as fix requests unless the user explicitly asks for explanation only. If the user asks for a change or if a diagnosis clearly needs a concrete project repair, call Unity tools directly. Call exactly one Unity tool per assistant turn, then wait for the tool result and updated Unity context before choosing the next tool. You may modify scene, project settings, lighting, packages, build scenes/profiles, assets, importers, and scripts. Runtime behavior, object recreation on Play, component lifecycle, and script-error debugging require source inspection; call read_text_file on the relevant scripts before selecting, validating, or editing scene objects, and do not claim a code cause until source was inspected. Prefer direct generic tools when available. Use direct actions for ordinary scene, component, package-component, and Play Mode work; only write an Editor script under Assets/Editor when the direct action schema cannot perform the needed UnityEditor API operation. Build scene objects generically from JSON: create_object for the GameObject, ensure_components for required components, set_component_property for serialized fields, then validate. Do not rely on preset-specific object creation actions. Set up live scene and asset state before writing new scripts whenever the request includes visible in-editor setup. This is important: inspect the result after every tool call and adapt before continuing. Use capture_game_view after visual, lighting, camera, material, sprite, or render changes so you can validate the actual camera render. Use validate_scene near the end of non-trivial scene changes. Do not output a plan before tool calls. Do not reveal hidden chain-of-thought. When finished, give a concise summary of what changed and what validation showed. Available tools have permissive JSON arguments matching the Ark action schema. " +
                FeatureCompletionInstruction + " " +
                PlayableSceneSetupInstruction + " " +
                EnemyArchetypeInstruction + " " +
                WorkingMemoryInstruction + " " +
                SemanticWorkflowInstruction + " " +
                PromptDepthInstruction + " " +
                BuildPromptDepthBehavior(interpretation) + " " +
                TaskPlanningInstruction + " " +
                SceneFirstInstruction + " " +
                ModularImplementationInstruction + " " +
                FocusedImplementationInstruction + " " +
                ImplementationResearchInstruction + " " +
                ResponsivenessInstruction + " " +
                DocsFallbackInstruction + " " +
                CompilerRepairInstruction + " " +
                FinalResponseInstruction + " " +
                GetActionSchema() +
                "\n\nCurrent Unity context:\n" +
                context;
        }

        private static string BuildOpenAIAnswerPrompt(string context)
        {
            return "You are a generalist Unity project assistant inside the Unity Editor with project-aware inspection context, live camera render diagnostics, and broad editor/project control. Answer the user's question about this project, scene, scripts, Unity concepts, debugging, architecture, or next steps. Use the provided Unity context as ground truth. Be specific to the current project: name the actual scene objects, components, scripts, assets, render pipeline settings, materials, observed property values, and Game view diagnostic measurements that matter. The Game view diagnostics section is an actual camera render captured by the Unity editor; treat its screenshot path, pixel stats, object samples, and light influence tests as authoritative visual validation. Do not give a generic checklist when the context already contains the fact; say what is currently true. For example, prefer \"Player_Light is a Point Light with intensity X and range Y, but disabling it changed 0% of rendered pixels, so it is not visibly affecting this camera render\" over \"check that the light is Point and has enough range.\" If runtime behavior or object recreation likely depends on scripts and no source excerpt is present, say source inspection is needed instead of pretending the scene snapshot proves the code path. If the context is insufficient, say what is missing and what additional inspection or editor action would reveal it. For diagnosis questions, include concrete observations, the likely issue, and the exact fix you can apply if the user asks you to change it. Return only JSON in this shape: {\"message\":\"direct answer\",\"plan\":[],\"progress\":[],\"actions\":[]}. Do not include executable actions in answer mode and do not ask for approval unless the user requests a project-changing fix. Keep answers concise, practical, and specific. Do not reveal hidden chain-of-thought.\n\nCurrent Unity context:\n" +
                context;
        }

        private static string BuildOpenAIApprovedExecutionPrompt(string context, PromptInterpretation interpretation)
        {
            return "You are an agentic Unity game-development assistant executing a plan that the user already approved. Return only JSON in this shape: {\"message\":\"short summary\",\"plan\":[\"high-level step\"],\"progress\":[\"observable work completed\"],\"actions\":[...]}. Do not wrap in markdown. Do not reveal hidden chain-of-thought; plan and progress must be concise, user-facing operational notes. Work toward the user's goal end-to-end across scene, project settings, lighting, packages, build scenes/profiles, assets, importers, and scripts. For approved project-changing plans, actions must be non-empty and must contain concrete executable action objects. Runtime behavior, object recreation on Play, component lifecycle, and script-error debugging require source inspection; use read_text_file before editing code when the relevant source is not already shown. Prefer direct generic tools when available. Use direct actions for ordinary scene, component, package-component, and Play Mode work; only write an Editor script under Assets/Editor when the direct action schema cannot perform the needed UnityEditor API operation. Build scene objects generically from JSON: create_object for the GameObject, ensure_components for required components, set_component_property for serialized fields, then validate. Do not rely on preset-specific object creation actions. Do not claim that files, scripts, lights, components, or objects were created unless the actions array contains the corresponding actions. Do not create an empty GameObject unless it is intentionally an empty parent/container; otherwise include required components and properties. For visible feature work, create and verify the live in-editor setup before writing new scripts. For new C# components, use write_csharp_script(path,content,target,component) only after the scene or asset prerequisites are already in place; Unity will attach it after scripts compile. Include validate_scene near the end of non-trivial changes, and include capture_game_view after visual, lighting, camera, material, or render changes so the result is checked against the actual camera render. " +
                FeatureCompletionInstruction + " " +
                PlayableSceneSetupInstruction + " " +
                EnemyArchetypeInstruction + " " +
                SemanticWorkflowInstruction + " " +
                PromptDepthInstruction + " " +
                ModularImplementationInstruction + " " +
                FocusedImplementationInstruction + " " +
                ImplementationResearchInstruction + " " +
                ResponsivenessInstruction + " " +
                BuildPromptDepthBehavior(interpretation) + " " +
                SceneFirstInstruction + " " +
                DocsFallbackInstruction + " " +
                CompilerRepairInstruction + " " +
                FinalResponseInstruction + " " +
                GetActionSchema() +
                "\n\nCurrent Unity context:\n" +
                context;
        }

        private static string BuildApprovedExecutionUserPrompt(string prompt, PlanReviewResult plan, PromptInterpretation interpretation)
        {
            StringBuilder builder = new StringBuilder();
            builder.AppendLine("The user approved this Unity change plan. Execute it now by returning concrete action JSON.");
            builder.AppendLine("Interpretation mode: " + NormalizePromptInterpretationMode(interpretation.Mode));
            builder.AppendLine("Interpretation guidance: " + (string.IsNullOrWhiteSpace(interpretation.Summary) ? "Use best judgment." : interpretation.Summary));
            builder.AppendLine();
            builder.AppendLine("Original user prompt:");
            builder.AppendLine(prompt ?? string.Empty);
            builder.AppendLine();
            builder.AppendLine("Approved plan:");
            builder.AppendLine(plan == null ? string.Empty : plan.ToApprovedPlanText());
            builder.AppendLine();
            builder.AppendLine("Return executable actions now. If the approved plan says to create or attach something, include the action objects that do it.");
            return builder.ToString();
        }

        private static AgentAction BuildActionFromToolCall(OpenAIToolCall toolCall)
        {
            if (toolCall == null || toolCall.function == null || string.IsNullOrWhiteSpace(toolCall.function.name))
            {
                throw new InvalidOperationException("OpenAI returned an invalid Unity tool call.");
            }

            string arguments = string.IsNullOrWhiteSpace(toolCall.function.arguments)
                ? "{}"
                : toolCall.function.arguments;
            AgentAction action = JsonUtility.FromJson<AgentAction>(arguments) ?? new AgentAction();
            action.type = toolCall.function.name.Trim();
            return action;
        }

        private static OpenAIToolChatMessage BuildToolResultMessage(OpenAIToolCall toolCall, string result)
        {
            return new OpenAIToolChatMessage
            {
                role = "tool",
                tool_call_id = string.IsNullOrWhiteSpace(toolCall?.id) ? "missing_tool_call_id" : toolCall.id,
                content = ClampText(
                    string.IsNullOrWhiteSpace(result) ? "Tool completed with no output." : result,
                    MaxToolResultMessageChars)
            };
        }

        private static string ExtractToolLoopFinalMessage(string content)
        {
            if (string.IsNullOrWhiteSpace(content))
            {
                return string.Empty;
            }

            if (TryExtractJson(content, out string json))
            {
                try
                {
                    BackendResponse response = JsonUtility.FromJson<BackendResponse>(json);
                    if (response != null && !string.IsNullOrWhiteSpace(response.message))
                    {
                        StringBuilder builder = new StringBuilder(response.message.Trim());
                        AppendStringList(builder, "Notes", response.progress);
                        return builder.ToString().TrimEnd();
                    }
                }
                catch (Exception)
                {
                    return content.Trim();
                }
            }

            return content.Trim();
        }

        private static OpenAIToolDefinition[] BuildOpenAITools(string agentRole)
        {
            List<OpenAIToolDefinition> tools = new List<OpenAIToolDefinition>();
            AddRoleTool(tools, agentRole, HandoffToolName, "Manager-only. Delegate a task to a specialist agent. Args: role is one of default, worker, explorer, scene_setup, asset_management, or monitor; content/query/value is the delegated task.");
            AddRoleTool(tools, agentRole, "set_task_plan", "Manager-only. Set the structured task DAG before execution. Args: tasks is an array of {id,title,description,assignee,status,dependsOn,acceptanceCriteria,verification}. Use this for non-trivial change requests before specialist handoffs.");
            AddRoleTool(tools, agentRole, "update_task_status", "Manager-only. Update one task in the structured task plan. Args: id/name/target identifies the task, status is pending/in_progress/completed/failed/blocked/skipped, verification/content records proof or blocker.");
            AddRoleTool(tools, agentRole, "create_folder", "Create an Assets folder.");
            AddRoleTool(tools, agentRole, "search_project", "Search scripts, prefabs, assets, package manifests, and readable project files for prompt-relevant context.");
            AddRoleTool(tools, agentRole, "read_text_file", "Read a text/source/YAML Unity asset file under Assets, Packages, ProjectSettings, or Library/PackageCache before diagnosing script, prefab, scene, asset, or Unity/package API behavior.");
            AddRoleTool(tools, agentRole, "inspect_prefab", "Load a prefab asset and report its GameObject, transform, component, renderer, collider, Rigidbody, and serialized script values. Use before and after prefab edits to verify actual prefab state.");
            AddRoleTool(tools, agentRole, "inspect_runtime_state", "Inspect live scene/runtime GameObjects, component counts, and serialized values. Use after entering Play Mode to verify spawned objects, assigned references, UI state, and gameplay wiring.");
            AddRoleTool(tools, agentRole, "read_compiler_diagnostics", "Read recent Unity C# compiler diagnostics from Editor.log. Use after script writes, failed editor utility invocation, or when context reports compile errors.");
            AddRoleTool(tools, agentRole, "search_web", "Read-only Tavily-backed external web search for implementation choices when local project source, local Unity docs, and installed API source are insufficient. Prefer official Unity/package/maintainer docs and keep queries focused.");
            AddRoleTool(tools, agentRole, "search_unity_docs", "Search the local Unity/package/project docs index. Use this before complex or uncertain Unity APIs, package workflows, importers, render pipeline, input, animation, build, or editor automation work.");
            AddRoleTool(tools, agentRole, "read_unity_doc", "Read a local Unity/package/project doc result by id or path returned from search_unity_docs.");
            AddRoleTool(tools, agentRole, "search_unity_api", "Search installed Unity/package C# API source under Library/PackageCache, Packages, and Assets. Use this to verify exact type names, members, setters, overloads, and casing before writing Unity API code.");
            AddRoleTool(tools, agentRole, "read_unity_api", "Read a Unity/package/project C# API source file returned by search_unity_api.");
            AddRoleTool(tools, agentRole, "rebuild_unity", "Explicitly refresh assets and trigger Unity import/compilation when needed after script or assembly-definition writes.");
            AddRoleTool(tools, agentRole, "write_text_file", "Write a text file under Assets.");
            AddRoleTool(tools, agentRole, "write_csharp_script", "Write a C# MonoBehaviour script under Assets and optionally queue attachment after compile.");
            AddRoleTool(tools, agentRole, "create_object", "Create a GameObject from generic JSON with optional components, parent, and transform.");
            AddRoleTool(tools, agentRole, "ensure_components", "Ensure a GameObject has role-based and explicit components.");
            AddRoleTool(tools, agentRole, "ensure_unity_workflow", "Semantic repair for composite Unity workflows. Args: name/value/query/content describe workflow such as gameplay wiring, prefab references, spawn setup, UI, visual polish, post-processing, camera, audio, animation, particles, or scene relationships. Creates/assigns linked scene objects, prefabs, references, arrays, sprites, and settings where possible, then saves dirty scene/assets.");
            AddRoleTool(tools, agentRole, "repair_scene_relationships", "Scan the active scene and repair common relational gaps: important empty prefab/reference arrays, unassigned object references, missing lookup-prefix objects, missing tags, missing sprites, VolumeProfile overrides, and missing camera post-processing wiring.");
            AddRoleTool(tools, agentRole, "setup_urp_post_processing", "Create or reuse a global URP Volume, create/assign a VolumeProfile, add active Bloom/Vignette overrides with visible values, enable URP camera post-processing, and optionally set camera background color.");
            AddRoleTool(tools, agentRole, "apply_default_sprite", "Apply generated square/circle placeholder sprites to a target or scene.");
            AddRoleTool(tools, agentRole, "create_sprite_asset", "Create a generated PNG sprite asset.");
            AddRoleTool(tools, agentRole, "create_unity_asset", "Create supported Unity assets such as materials, render textures, physics materials, tiles, animation clips, or scriptable objects.");
            AddRoleTool(tools, agentRole, "delete_game_object", "Delete a GameObject by target.");
            AddRoleTool(tools, agentRole, "clear_scene", "Delete all root objects from the active scene.");
            AddRoleTool(tools, agentRole, "set_object_property", "Set GameObject-level properties such as name, tag, layer, active, or static.");
            AddRoleTool(tools, agentRole, "set_transform", "Set transform position, rotation, or scale.");
            AddRoleTool(tools, agentRole, "set_component_property", "Set a serialized component property on a scene GameObject or prefab asset.");
            AddRoleTool(tools, agentRole, "add_component", "Add a component by type name.");
            AddRoleTool(tools, agentRole, "remove_component", "Remove a component by type name.");
            AddRoleTool(tools, agentRole, "select", "Select a target GameObject.");
            AddRoleTool(tools, agentRole, "create_prefab_from_selected", "Create a prefab from the current selection.");
            AddRoleTool(tools, agentRole, "instantiate_prefab", "Instantiate a prefab asset.");
            AddRoleTool(tools, agentRole, "create_scene", "Create a scene asset.");
            AddRoleTool(tools, agentRole, "open_scene", "Open a scene asset.");
            AddRoleTool(tools, agentRole, "execute_menu_item", "Execute a Unity editor menu item.");
            AddRoleTool(tools, agentRole, "enter_play_mode", "Enter Unity Play Mode to validate runtime behavior.");
            AddRoleTool(tools, agentRole, "exit_play_mode", "Exit Unity Play Mode after runtime validation.");
            AddRoleTool(tools, agentRole, "add_package", "Start adding a Unity package.");
            AddRoleTool(tools, agentRole, "remove_package", "Start removing a Unity package.");
            AddRoleTool(tools, agentRole, "set_player_setting", "Set supported Unity Player Settings such as active input handling, company name, product name, or color space.");
            AddRoleTool(tools, agentRole, "set_project_setting", "Set a scalar serialized value in a ProjectSettings asset such as ProjectSettings/ProjectSettings.asset.");
            AddRoleTool(tools, agentRole, "set_asset_property", "Set a serialized property on a Unity asset by asset path; for prefab component values prefer set_component_property with path or asset_path set to the prefab.");
            AddRoleTool(tools, agentRole, "set_editor_build_scenes", "Set or append scenes in Build Settings. Use bool_value true or value add/append/include to preserve existing scenes and add the supplied paths.");
            AddRoleTool(tools, agentRole, "invoke_editor_method", "Invoke a compiled static editor method, optionally with one string argument.");
            AddRoleTool(tools, agentRole, "validate_scene", "Run structural and relational scene validation, including serialized references, important arrays, scene lookup contracts, Resources fallbacks, and camera/render wiring.");
            AddRoleTool(tools, agentRole, "capture_game_view", "Render the active camera, save a diagnostic screenshot, sample pixels, and test light influence.");
            AddRoleTool(tools, agentRole, "save_scene", "Save open scenes.");
            AddRoleTool(tools, agentRole, "save_assets", "Save and refresh assets.");
            return tools.ToArray();
        }

        private static string[] BuildOpenAIToolNames(string agentRole)
        {
            OpenAIToolDefinition[] tools = BuildOpenAITools(agentRole);
            string[] names = new string[tools.Length];
            for (int i = 0; i < tools.Length; i++)
            {
                names[i] = tools[i].function.name;
            }

            return names;
        }

        private static void AddRoleTool(List<OpenAIToolDefinition> tools, string agentRole, string name, string description)
        {
            if (IsToolAllowedForRole(agentRole, name))
            {
                tools.Add(Tool(name, description));
            }
        }

        private static OpenAIToolDefinition Tool(string name, string description)
        {
            return new OpenAIToolDefinition
            {
                type = "function",
                function = new OpenAIToolFunctionDefinition
                {
                    name = name,
                    description = description,
                    parameters = OpenAIToolParameters.Permissive()
                }
            };
        }

        private static string BuildOpenAIToolRequestJson(List<OpenAIToolChatMessage> messages, string agentRole = AgentRoleDefault)
        {
            return BuildOpenAIToolRequestJson(messages, agentRole, DefaultOpenAIModel);
        }

        private static string BuildOpenAIToolRequestJson(List<OpenAIToolChatMessage> messages, string agentRole, string model)
        {
            StringBuilder builder = new StringBuilder();
            builder.Append('{');
            builder.Append("\"model\":");
            AppendJsonString(builder, string.IsNullOrWhiteSpace(model) ? DefaultOpenAIModel : model.Trim());
            builder.Append(",\"tool_choice\":\"auto\"");
            builder.Append(",\"messages\":[");
            for (int i = 0; i < messages.Count; i++)
            {
                if (i > 0)
                {
                    builder.Append(',');
                }

                AppendToolMessageJson(builder, messages[i]);
            }

            builder.Append(']');
            builder.Append(",\"tools\":[");
            OpenAIToolDefinition[] tools = BuildOpenAITools(agentRole);
            for (int i = 0; i < tools.Length; i++)
            {
                if (i > 0)
                {
                    builder.Append(',');
                }

                AppendToolDefinitionJson(builder, tools[i]);
            }

            builder.Append(']');
            builder.Append('}');
            return builder.ToString();
        }

        private static void AppendToolMessageJson(StringBuilder builder, OpenAIToolChatMessage message)
        {
            string role = NormalizeOpenAIMessageRole(message?.role);
            bool isAssistant = string.Equals(role, "assistant", StringComparison.Ordinal);
            bool isTool = string.Equals(role, "tool", StringComparison.Ordinal);
            builder.Append('{');
            builder.Append("\"role\":");
            AppendJsonString(builder, role);
            if (!string.IsNullOrWhiteSpace(message?.content))
            {
                builder.Append(",\"content\":");
                AppendJsonString(builder, message.content);
            }
            else if (!isAssistant || message.tool_calls == null || message.tool_calls.Length == 0)
            {
                builder.Append(",\"content\":\"\"");
            }

            if (isTool && !string.IsNullOrWhiteSpace(message?.tool_call_id))
            {
                builder.Append(",\"tool_call_id\":");
                AppendJsonString(builder, message.tool_call_id);
            }

            if (isAssistant && message?.tool_calls != null && message.tool_calls.Length > 0)
            {
                builder.Append(",\"tool_calls\":[");
                for (int i = 0; i < message.tool_calls.Length; i++)
                {
                    if (i > 0)
                    {
                        builder.Append(',');
                    }

                    AppendToolCallJson(builder, message.tool_calls[i]);
                }

                builder.Append(']');
            }

            builder.Append('}');
        }

        private static void AppendToolCallJson(StringBuilder builder, OpenAIToolCall toolCall)
        {
            builder.Append('{');
            builder.Append("\"id\":");
            AppendJsonString(builder, toolCall?.id);
            builder.Append(",\"type\":");
            AppendJsonString(builder, string.IsNullOrWhiteSpace(toolCall?.type) ? "function" : toolCall.type);
            builder.Append(",\"function\":{");
            builder.Append("\"name\":");
            AppendJsonString(builder, toolCall?.function?.name);
            builder.Append(",\"arguments\":");
            AppendJsonString(builder, toolCall?.function?.arguments ?? "{}");
            builder.Append("}}");
        }

        private static void AppendToolDefinitionJson(StringBuilder builder, OpenAIToolDefinition tool)
        {
            builder.Append("{\"type\":\"function\",\"function\":{");
            builder.Append("\"name\":");
            AppendJsonString(builder, tool.function.name);
            builder.Append(",\"description\":");
            AppendJsonString(builder, tool.function.description);
            builder.Append(",\"parameters\":{\"type\":\"object\",\"additionalProperties\":true}");
            builder.Append("}}");
        }

        private static void AppendJsonString(StringBuilder builder, string value)
        {
            builder.Append('"');
            if (!string.IsNullOrEmpty(value))
            {
                foreach (char character in value)
                {
                    switch (character)
                    {
                        case '\\':
                            builder.Append("\\\\");
                            break;
                        case '"':
                            builder.Append("\\\"");
                            break;
                        case '\n':
                            builder.Append("\\n");
                            break;
                        case '\r':
                            builder.Append("\\r");
                            break;
                        case '\t':
                            builder.Append("\\t");
                            break;
                        case '\b':
                            builder.Append("\\b");
                            break;
                        case '\f':
                            builder.Append("\\f");
                            break;
                        default:
                            if (character < ' ')
                            {
                                builder.Append("\\u");
                                builder.Append(((int)character).ToString("x4", CultureInfo.InvariantCulture));
                            }
                            else
                            {
                                builder.Append(character);
                            }
                            break;
                    }
                }
            }

            builder.Append('"');
        }

        private static string ExecuteResponseJson(string json)
        {
            return ExecuteResponseJson(json, requireActions: false);
        }

        private static string PreviewResponseJson(string json)
        {
            BackendResponse backendResponse;
            try
            {
                backendResponse = JsonUtility.FromJson<BackendResponse>(json);
            }
            catch (Exception exception)
            {
                return BuildInvalidJsonResponse(exception, json);
            }

            if (backendResponse == null)
            {
                return "The action JSON is empty.";
            }

            int total = 0;
            int readOnly = 0;
            int mutating = 0;
            int destructive = 0;
            StringBuilder actions = new StringBuilder();
            if (backendResponse.actions != null)
            {
                foreach (AgentAction action in backendResponse.actions)
                {
                    if (action == null || string.IsNullOrWhiteSpace(action.type))
                    {
                        continue;
                    }

                    total++;
                    string type = action.type.Trim();
                    bool isReadOnly = IsReadOnlyAction(type);
                    bool isDestructive = IsDestructiveAction(type);
                    if (isReadOnly)
                    {
                        readOnly++;
                    }
                    else
                    {
                        mutating++;
                    }

                    if (isDestructive)
                    {
                        destructive++;
                    }

                    actions.Append("- ");
                    actions.Append(type);
                    if (isReadOnly)
                    {
                        actions.Append(" [read-only]");
                    }
                    else if (isDestructive)
                    {
                        actions.Append(" [destructive]");
                    }
                    else
                    {
                        actions.Append(" [mutating]");
                    }

                    actions.AppendLine(PreviewActionTarget(action));
                }
            }

            StringBuilder response = new StringBuilder();
            response.AppendLine("Dry run only. No Unity actions were executed.");
            if (!string.IsNullOrWhiteSpace(backendResponse.message))
            {
                response.AppendLine();
                response.AppendLine(backendResponse.message.Trim());
            }

            response.AppendLine();
            response.AppendLine($"Actions: {total}");
            response.AppendLine($"Read-only: {readOnly}");
            response.AppendLine($"Mutating: {mutating}");
            response.AppendLine($"Destructive/high-risk: {destructive}");
            if (actions.Length > 0)
            {
                response.AppendLine();
                response.Append(actions);
            }

            return response.ToString().TrimEnd();
        }

        private static string ExecuteReadOnlyResponseJson(string json)
        {
            BackendResponse backendResponse;
            try
            {
                backendResponse = JsonUtility.FromJson<BackendResponse>(json);
            }
            catch (Exception exception)
            {
                return BuildInvalidJsonResponse(exception, json);
            }

            if (backendResponse == null)
            {
                return "The action JSON is empty.";
            }

            List<AgentAction> actions = new List<AgentAction>();
            List<string> blocked = new List<string>();
            if (backendResponse.actions != null)
            {
                foreach (AgentAction action in backendResponse.actions)
                {
                    if (action == null || string.IsNullOrWhiteSpace(action.type))
                    {
                        continue;
                    }

                    if (!IsReadOnlyAction(action.type))
                    {
                        blocked.Add(action.type.Trim() + PreviewActionTarget(action));
                        continue;
                    }

                    actions.Add(action);
                }
            }

            if (blocked.Count > 0)
            {
                StringBuilder blockedResponse = new StringBuilder();
                blockedResponse.AppendLine("Readonly execution blocked. No Unity actions were executed because the request contained mutating actions:");
                foreach (string blockedAction in blocked)
                {
                    blockedResponse.AppendLine("- " + blockedAction);
                }

                return blockedResponse.ToString().TrimEnd();
            }

            int toolCallCount = 0;
            ToolLoopState presentationState = new ToolLoopState();
            foreach (AgentAction action in actions)
            {
                toolCallCount++;
                string toolResult = ExecuteAction(action);
                AppendToolLogLine(presentationState.ActionLog, toolCallCount, action.type, toolResult);
                RecordUserFacingToolResult(presentationState, action, action.type, toolResult);
            }

            string message = string.IsNullOrWhiteSpace(backendResponse.message)
                ? "Readonly Unity actions executed."
                : backendResponse.message.Trim();

            presentationState.Prompt = message;
            presentationState.FinalMessage = message;
            AppendAutomaticVerificationIssues(presentationState);

            StringBuilder response = new StringBuilder();
            AppendCodexStyleLead(response, message, presentationState);
            if (toolCallCount > 0)
            {
                AppendUserFacingOutcomeSections(response, 0, presentationState);
            }

            return response.ToString().TrimEnd();
        }

        private static string ExtractAnswerText(string content)
        {
            if (string.IsNullOrWhiteSpace(content))
            {
                return "OpenAI returned an empty answer.";
            }

            if (!TryExtractJson(content, out string json))
            {
                return content.Trim();
            }

            try
            {
                BackendResponse response = JsonUtility.FromJson<BackendResponse>(json);
                if (response != null && !string.IsNullOrWhiteSpace(response.message))
                {
                    StringBuilder builder = new StringBuilder(response.message.Trim());
                    AppendStringList(builder, "Notes", response.progress);
                    return builder.ToString().TrimEnd();
                }
            }
            catch (Exception)
            {
                // Fall through and return the raw content.
            }

            return content.Trim();
        }

        private static string ExecuteResponseJson(string json, bool requireActions)
        {
            BackendResponse backendResponse;
            try
            {
                backendResponse = JsonUtility.FromJson<BackendResponse>(json);
            }
            catch (Exception exception)
            {
                return BuildInvalidJsonResponse(exception, json);
            }

            if (backendResponse == null)
            {
                return "The agent returned an empty response.";
            }

            int appliedActionCount = 0;
            int toolCallCount = 0;
            ToolLoopState presentationState = new ToolLoopState();
            if (backendResponse.actions != null)
            {
                foreach (AgentAction action in backendResponse.actions)
                {
                    if (action == null || string.IsNullOrWhiteSpace(action.type))
                    {
                        continue;
                    }

                    toolCallCount++;
                    string toolResult = ExecuteAction(action);
                    AppendToolLogLine(presentationState.ActionLog, toolCallCount, action.type, toolResult);
                    if (!IsReadOnlyAction(action.type) && !IsIssueToolResult(toolResult))
                    {
                        appliedActionCount++;
                    }

                    RecordUserFacingToolResult(presentationState, action, action.type, toolResult);
                }
            }

            AssetDatabase.SaveAssets();
            string message = string.IsNullOrWhiteSpace(backendResponse.message)
                ? "Agent actions executed."
                : backendResponse.message.Trim();

            presentationState.Prompt = message;
            presentationState.FinalMessage = message;
            AppendAutomaticVerificationIssues(presentationState);

            StringBuilder response = new StringBuilder();
            AppendCodexStyleLead(response, message, presentationState);

            if (toolCallCount == 0)
            {
                if (requireActions)
                {
                    if (GetDeveloperMode())
                    {
                        AppendCodexStyleLogSection(response, "Remaining issues:", "- Approved execution returned no executable Unity actions, so nothing was changed. Try approving again; if it repeats, the model response is not following the action schema.");
                    }
                    else
                    {
                        response.Clear();
                        response.AppendLine("• Approved execution returned no executable Unity actions, so nothing was changed.");
                    }
                }

                return response.ToString().TrimEnd();
            }

            AppendUserFacingOutcomeSections(response, appliedActionCount, presentationState);
            return response.ToString().TrimEnd();
        }

        private static string FormatBackendAgentResult(string json)
        {
            BackendResponse backendResponse;
            try
            {
                backendResponse = JsonUtility.FromJson<BackendResponse>(json);
            }
            catch (Exception exception)
            {
                return BuildInvalidJsonResponse(exception, json);
            }

            if (backendResponse == null)
            {
                return "• Backend agent returned an empty response.";
            }

            string message = string.IsNullOrWhiteSpace(backendResponse.message)
                ? "Backend agent finished."
                : backendResponse.message.Trim();

            StringBuilder builder = new StringBuilder();
            builder.AppendLine("• " + message);
            AppendStringList(builder, "Plan", backendResponse.plan);
            AppendStringList(builder, "Notes", backendResponse.progress);

            int proposedActionCount = 0;
            if (backendResponse.actions != null)
            {
                foreach (AgentAction action in backendResponse.actions)
                {
                    if (action != null && !string.IsNullOrWhiteSpace(action.type))
                    {
                        proposedActionCount++;
                    }
                }
            }

            if (proposedActionCount > 0 && GetDeveloperMode())
            {
                builder.AppendLine();
                builder.AppendLine();
                builder.AppendLine("Backend note:");
                builder.AppendLine($"- Ignored {proposedActionCount} returned Unity action(s); backend scripting agents must execute their own actions before returning.");
            }

            return builder.ToString().TrimEnd();
        }

        private static bool TryBuildLocalPlanActions(string prompt, BackendResponse source, out BackendResponse response)
        {
            response = null;
            string normalized = BuildIntentText(prompt, source);
            if (string.IsNullOrWhiteSpace(normalized))
            {
                return false;
            }

            if (IsClearSceneIntent(normalized))
            {
                response = BuildLocalResponse(
                    source,
                    "Clear the current scene.",
                    new[] { "Delete all root objects from the active scene.", "Save the open scene." },
                    new[] { "Using built-in clear_scene action because the model returned no executable actions." },
                    new[]
                    {
                        new AgentAction { type = "clear_scene" },
                        new AgentAction { type = "save_scene" }
                    });
                return true;
            }

            if (IsTopDownShooterProjectIntent(normalized))
            {
                response = BuildLocalResponse(
                    source,
                    "Set up a complete top-down shooter prototype.",
                    new[]
                    {
                        "Build a clean top-down arena using default square and circle sprites.",
                        "Create a red player, white walls, a target dummy, camera, player light, and runtime controls.",
                        "Write and attach movement/shooting and camera follow scripts.",
                        "Validate and save the scene."
                    },
                    new[] { "Synthesized a full top-down shooter setup locally because the plan did not include executable actions." },
                    BuildTopDownShooterActions());
                return true;
            }

            if (IsCameraIntent(normalized))
            {
                response = BuildLocalResponse(
                    source,
                    "Add or repair the main camera.",
                    new[] { "Ensure Main Camera exists with Camera and AudioListener components.", "Position it for a top-down view.", "Validate the scene." },
                    new[] { "Synthesized camera actions locally because the plan did not include executable actions." },
                    new[]
                    {
                        new AgentAction
                        {
                            type = "create_object",
                            name = "Main Camera",
                            components = new[] { "Camera", "AudioListener" },
                            use_position = true,
                            position = new Vector3Value { x = 0f, y = 0f, z = -10f }
                        },
                        new AgentAction
                        {
                            type = "set_object_property",
                            target = "Main Camera",
                            property_path = "tag",
                            value = "MainCamera"
                        },
                        new AgentAction
                        {
                            type = "set_component_property",
                            target = "Main Camera",
                            component = "Camera",
                            property_path = "m_Orthographic",
                            value_type = "bool",
                            bool_value = true
                        },
                        new AgentAction
                        {
                            type = "set_component_property",
                            target = "Main Camera",
                            component = "Camera",
                            property_path = "m_OrthographicSize",
                            value_type = "float",
                            float_value = 6f
                        },
                        new AgentAction { type = "validate_scene" }
                    });
                return true;
            }

            if (IsSquareSpriteIntent(normalized))
            {
                response = BuildLocalResponse(
                    source,
                    "Apply default square sprites to scene objects.",
                    new[] { "Create a reusable default square sprite asset if needed.", "Apply it to every non-camera/non-light scene object.", "Validate the scene." },
                    new[] { "Synthesized sprite assignment actions locally because the plan did not include executable actions." },
                    new[]
                    {
                        new AgentAction
                        {
                            type = "apply_default_sprite",
                            target = "scene",
                            shape = "square"
                        },
                        new AgentAction { type = "validate_scene" }
                    });
                return true;
            }

            if (IsPlayerMovementAndLightIntent(normalized))
            {
                string playerTarget = FindLikelyPlayerTarget();
                List<AgentAction> actions = new List<AgentAction>();
                if (string.IsNullOrWhiteSpace(playerTarget))
                {
                    playerTarget = "Player_Red";
                    actions.Add(new AgentAction
                    {
                        type = "create_object",
                        name = playerTarget,
                        components = new[] { "SpriteRenderer", "Rigidbody2D", "CircleCollider2D" },
                        use_position = true,
                        position = new Vector3Value { x = 0f, y = 0f, z = 0f }
                    });
                    actions.Add(new AgentAction
                    {
                        type = "apply_default_sprite",
                        target = playerTarget,
                        shape = "circle",
                        color = "#ff3333"
                    });
                }

                Type existingController = FindComponentType("TopDownPlayerController");
                if (existingController != null)
                {
                    actions.Add(new AgentAction
                    {
                        type = "ensure_components",
                        target = playerTarget,
                        components = new[] { "Rigidbody2D", "CircleCollider2D", "TopDownPlayerController" }
                    });
                }
                else
                {
                    actions.Add(new AgentAction
                    {
                        type = "write_csharp_script",
                        path = "Assets/Scripts/AgenticTopDownPlayerMovement.cs",
                        component = "AgenticTopDownPlayerMovement",
                        target = playerTarget,
                        content = BuildTopDownMovementScript()
                    });
                    actions.Add(new AgentAction
                    {
                        type = "ensure_components",
                        target = playerTarget,
                        components = new[] { "Rigidbody2D", "CircleCollider2D" }
                    });
                }

                actions.Add(new AgentAction
                {
                    type = "create_object",
                    name = $"{playerTarget}_PointLight",
                    components = new[] { "Light" },
                    parent = playerTarget,
                    use_position = true,
                    position = new Vector3Value { x = 0f, y = 0f, z = -2f }
                });
                actions.Add(new AgentAction
                {
                    type = "set_component_property",
                    target = $"{playerTarget}/{playerTarget}_PointLight",
                    component = "Light",
                    property_path = "m_Type",
                    value_type = "int",
                    int_value = (int)LightType.Point
                });
                actions.Add(new AgentAction
                {
                    type = "set_component_property",
                    target = $"{playerTarget}/{playerTarget}_PointLight",
                    component = "Light",
                    property_path = "m_Color",
                    value_type = "color",
                    color = "#ff6040"
                });
                actions.Add(new AgentAction
                {
                    type = "set_component_property",
                    target = $"{playerTarget}/{playerTarget}_PointLight",
                    component = "Light",
                    property_path = "m_Intensity",
                    value_type = "float",
                    float_value = 2.5f
                });
                actions.Add(new AgentAction
                {
                    type = "set_component_property",
                    target = $"{playerTarget}/{playerTarget}_PointLight",
                    component = "Light",
                    property_path = "m_Range",
                    value_type = "float",
                    float_value = 7f
                });
                actions.Add(new AgentAction { type = "validate_scene" });

                response = BuildLocalResponse(
                    source,
                    "Add top-down player movement and a point light.",
                    new[] { "Ensure the player has 2D movement dependencies.", "Attach or create a top-down movement script.", "Add a point light as a player child.", "Validate the scene." },
                    new[] { "Synthesized player actions locally because the plan did not include executable actions." },
                    actions.ToArray());
                return true;
            }

            return false;
        }

        private static bool ShouldUseLocalPlanFallback(string prompt, BackendResponse source, int proposedActionCount)
        {
            if (proposedActionCount == 0)
            {
                return true;
            }

            string normalized = BuildIntentText(prompt, source);
            return IsTopDownShooterProjectIntent(normalized) && proposedActionCount < 12;
        }

        private static string BuildIntentText(string prompt, BackendResponse source)
        {
            StringBuilder builder = new StringBuilder();
            AppendIntentPart(builder, prompt);
            AppendIntentPart(builder, source?.message);
            AppendIntentParts(builder, source?.plan);
            AppendIntentParts(builder, source?.progress);
            return NormalizeIntentText(builder.ToString());
        }

        private static void AppendIntentParts(StringBuilder builder, string[] values)
        {
            if (values == null)
            {
                return;
            }

            foreach (string value in values)
            {
                AppendIntentPart(builder, value);
            }
        }

        private static void AppendIntentPart(StringBuilder builder, string value)
        {
            if (builder == null || string.IsNullOrWhiteSpace(value))
            {
                return;
            }

            if (builder.Length > 0)
            {
                builder.Append(' ');
            }

            builder.Append(value);
        }

        private static BackendResponse BuildLocalResponse(
            BackendResponse source,
            string message,
            string[] plan,
            string[] progress,
            AgentAction[] actions)
        {
            return new BackendResponse
            {
                message = message,
                plan = plan,
                progress = progress,
                actions = actions
            };
        }

        private static string NormalizeIntentText(string text)
        {
            if (string.IsNullOrWhiteSpace(text))
            {
                return string.Empty;
            }

            return text.Trim().ToLowerInvariant();
        }

        private static bool IsClearSceneIntent(string normalized)
        {
            bool clearVerb = normalized.IndexOf("clear", StringComparison.Ordinal) >= 0 ||
                normalized.IndexOf("remove", StringComparison.Ordinal) >= 0 ||
                normalized.IndexOf("delete", StringComparison.Ordinal) >= 0 ||
                normalized.IndexOf("empty", StringComparison.Ordinal) >= 0;
            bool scope = normalized.IndexOf("scene", StringComparison.Ordinal) >= 0 ||
                normalized.IndexOf("everything", StringComparison.Ordinal) >= 0 ||
                normalized.IndexOf("all objects", StringComparison.Ordinal) >= 0 ||
                normalized.IndexOf("root objects", StringComparison.Ordinal) >= 0;
            return clearVerb && scope;
        }

        private static bool IsCameraIntent(string normalized)
        {
            return normalized.IndexOf("camera", StringComparison.Ordinal) >= 0 &&
                (normalized.IndexOf("add", StringComparison.Ordinal) >= 0 ||
                    normalized.IndexOf("create", StringComparison.Ordinal) >= 0 ||
                    normalized.IndexOf("make", StringComparison.Ordinal) >= 0 ||
                    normalized.IndexOf("setup", StringComparison.Ordinal) >= 0 ||
                    normalized.IndexOf("set up", StringComparison.Ordinal) >= 0);
        }

        private static bool IsTopDownShooterProjectIntent(string normalized)
        {
            bool topDown = normalized.IndexOf("top down", StringComparison.Ordinal) >= 0 ||
                normalized.IndexOf("top-down", StringComparison.Ordinal) >= 0;
            bool shooter = normalized.IndexOf("shooter", StringComparison.Ordinal) >= 0 ||
                normalized.IndexOf("shooting", StringComparison.Ordinal) >= 0 ||
                normalized.IndexOf("shoot", StringComparison.Ordinal) >= 0;
            bool setup = normalized.IndexOf("set up", StringComparison.Ordinal) >= 0 ||
                normalized.IndexOf("setup", StringComparison.Ordinal) >= 0 ||
                normalized.IndexOf("make", StringComparison.Ordinal) >= 0 ||
                normalized.IndexOf("create", StringComparison.Ordinal) >= 0 ||
                normalized.IndexOf("build", StringComparison.Ordinal) >= 0;
            return topDown && shooter && setup;
        }

        private static AgentAction[] BuildTopDownShooterActions()
        {
            List<AgentAction> actions = new List<AgentAction>
            {
                new AgentAction { type = "clear_scene" },
                new AgentAction { type = "create_folder", path = "Assets/Scripts" },
                new AgentAction
                {
                    type = "create_object",
                    name = "Arena",
                    use_position = true,
                    position = new Vector3Value { x = 0f, y = 0f, z = 0f }
                },
                new AgentAction
                {
                    type = "create_object",
                    name = "Player_Red",
                    components = new[] { "SpriteRenderer", "Rigidbody2D", "CircleCollider2D" },
                    use_position = true,
                    position = new Vector3Value { x = 0f, y = 0f, z = 0f },
                    use_scale = true,
                    scale = new Vector3Value { x = 1f, y = 1f, z = 1f }
                },
                new AgentAction
                {
                    type = "apply_default_sprite",
                    target = "Player_Red",
                    shape = "circle",
                    color = "#ff3333"
                }
            };

            AddWallActions(actions, "Wall_North", 0f, 5.5f, 18f, 1f);
            AddWallActions(actions, "Wall_South", 0f, -5.5f, 18f, 1f);
            AddWallActions(actions, "Wall_East", 8.5f, 0f, 1f, 12f);
            AddWallActions(actions, "Wall_West", -8.5f, 0f, 1f, 12f);
            AddWallActions(actions, "Obstacle_Block_A", -3f, 1.5f, 2f, 1f);
            AddWallActions(actions, "Obstacle_Block_B", 3f, -1.5f, 2f, 1f);

            actions.Add(new AgentAction
            {
                type = "create_object",
                name = "Target_Dummy",
                components = new[] { "SpriteRenderer", "CircleCollider2D" },
                use_position = true,
                position = new Vector3Value { x = 4.5f, y = 2.75f, z = 0f }
            });
            actions.Add(new AgentAction
            {
                type = "apply_default_sprite",
                target = "Target_Dummy",
                shape = "circle",
                color = "#2f7dff"
            });
            actions.Add(new AgentAction
            {
                type = "create_object",
                name = "Player_Red_PointLight",
                components = new[] { "Light" },
                parent = "Player_Red",
                use_position = true,
                position = new Vector3Value { x = 0f, y = 0f, z = -2f }
            });
            actions.Add(new AgentAction
            {
                type = "set_component_property",
                target = "Player_Red/Player_Red_PointLight",
                component = "Light",
                property_path = "m_Type",
                value_type = "int",
                int_value = (int)LightType.Point
            });
            actions.Add(new AgentAction
            {
                type = "set_component_property",
                target = "Player_Red/Player_Red_PointLight",
                component = "Light",
                property_path = "m_Color",
                value_type = "color",
                color = "#ff6040"
            });
            actions.Add(new AgentAction
            {
                type = "set_component_property",
                target = "Player_Red/Player_Red_PointLight",
                component = "Light",
                property_path = "m_Intensity",
                value_type = "float",
                float_value = 2.5f
            });
            actions.Add(new AgentAction
            {
                type = "set_component_property",
                target = "Player_Red/Player_Red_PointLight",
                component = "Light",
                property_path = "m_Range",
                value_type = "float",
                float_value = 7f
            });
            actions.Add(new AgentAction
            {
                type = "create_object",
                name = "Main Camera",
                components = new[] { "Camera", "AudioListener" },
                use_position = true,
                position = new Vector3Value { x = 0f, y = 0f, z = -10f }
            });
            actions.Add(new AgentAction
            {
                type = "set_object_property",
                target = "Main Camera",
                property_path = "tag",
                value = "MainCamera"
            });
            actions.Add(new AgentAction
            {
                type = "set_component_property",
                target = "Main Camera",
                component = "Camera",
                property_path = "m_Orthographic",
                value_type = "bool",
                bool_value = true
            });
            actions.Add(new AgentAction
            {
                type = "set_component_property",
                target = "Main Camera",
                component = "Camera",
                property_path = "m_OrthographicSize",
                value_type = "float",
                float_value = 6.25f
            });
            actions.Add(new AgentAction
            {
                type = "write_csharp_script",
                path = "Assets/Scripts/AgenticTopDownShooterPlayer.cs",
                component = "AgenticTopDownShooterPlayer",
                target = "Player_Red",
                content = BuildTopDownShooterPlayerScript()
            });
            actions.Add(new AgentAction
            {
                type = "write_csharp_script",
                path = "Assets/Scripts/AgenticTopDownCameraFollow.cs",
                component = "AgenticTopDownCameraFollow",
                target = "Main Camera",
                content = BuildTopDownCameraFollowScript()
            });
            actions.Add(new AgentAction { type = "validate_scene" });
            actions.Add(new AgentAction { type = "save_scene" });
            actions.Add(new AgentAction { type = "save_assets" });
            return actions.ToArray();
        }

        private static void AddWallActions(List<AgentAction> actions, string name, float x, float y, float scaleX, float scaleY)
        {
            actions.Add(new AgentAction
            {
                type = "create_object",
                name = name,
                parent = "Arena",
                components = new[] { "SpriteRenderer", "BoxCollider2D" },
                use_position = true,
                position = new Vector3Value { x = x, y = y, z = 0f },
                use_scale = true,
                scale = new Vector3Value { x = scaleX, y = scaleY, z = 1f }
            });
            actions.Add(new AgentAction
            {
                type = "apply_default_sprite",
                target = $"Arena/{name}",
                shape = "square",
                color = "#ffffff"
            });
        }

        private static bool IsSquareSpriteIntent(string normalized)
        {
            return normalized.IndexOf("square", StringComparison.Ordinal) >= 0 &&
                normalized.IndexOf("sprite", StringComparison.Ordinal) >= 0 &&
                (normalized.IndexOf("everything", StringComparison.Ordinal) >= 0 ||
                    normalized.IndexOf("all", StringComparison.Ordinal) >= 0 ||
                    normalized.IndexOf("objects", StringComparison.Ordinal) >= 0);
        }

        private static bool IsPlayerMovementAndLightIntent(string normalized)
        {
            bool player = normalized.IndexOf("player", StringComparison.Ordinal) >= 0 ||
                normalized.IndexOf("p layer", StringComparison.Ordinal) >= 0;
            bool movement = normalized.IndexOf("movement", StringComparison.Ordinal) >= 0 ||
                normalized.IndexOf("move", StringComparison.Ordinal) >= 0 ||
                normalized.IndexOf("top down", StringComparison.Ordinal) >= 0 ||
                normalized.IndexOf("top-down", StringComparison.Ordinal) >= 0;
            bool light = normalized.IndexOf("light", StringComparison.Ordinal) >= 0;
            return player && movement && light;
        }

        private static string FindLikelyPlayerTarget()
        {
            GameObject selected = Selection.activeGameObject;
            if (selected != null && selected.name.IndexOf("player", StringComparison.OrdinalIgnoreCase) >= 0)
            {
                return GetHierarchyPath(selected);
            }

            GameObject direct = FindTarget("Player_Red") ?? FindTarget("Player");
            if (direct != null)
            {
                return GetHierarchyPath(direct);
            }

            foreach (GameObject root in SceneManager.GetActiveScene().GetRootGameObjects())
            {
                GameObject found = FindFirstByNameContains(root.transform, "player");
                if (found != null)
                {
                    return GetHierarchyPath(found);
                }
            }

            return string.Empty;
        }

        private static GameObject FindFirstByNameContains(Transform transform, string value)
        {
            if (transform == null || string.IsNullOrWhiteSpace(value))
            {
                return null;
            }

            if (transform.name.IndexOf(value, StringComparison.OrdinalIgnoreCase) >= 0)
            {
                return transform.gameObject;
            }

            for (int i = 0; i < transform.childCount; i++)
            {
                GameObject found = FindFirstByNameContains(transform.GetChild(i), value);
                if (found != null)
                {
                    return found;
                }
            }

            return null;
        }

        private static string BuildTopDownMovementScript()
        {
            return @"using UnityEngine;
#if ENABLE_INPUT_SYSTEM
using UnityEngine.InputSystem;
#endif

[RequireComponent(typeof(Rigidbody2D))]
public class AgenticTopDownPlayerMovement : MonoBehaviour
{
    public float moveSpeed = 6f;

    private Rigidbody2D body;
    private Vector2 moveInput;

    private void Awake()
    {
        body = GetComponent<Rigidbody2D>();
        body.gravityScale = 0f;
        body.freezeRotation = true;
    }

    private void Update()
    {
#if ENABLE_INPUT_SYSTEM
        moveInput = ReadMoveInput();
#else
        moveInput = new Vector2(Input.GetAxisRaw(""Horizontal""), Input.GetAxisRaw(""Vertical"")).normalized;
#endif
    }

    private void FixedUpdate()
    {
        body.linearVelocity = moveInput * moveSpeed;
    }

#if ENABLE_INPUT_SYSTEM
    private Vector2 ReadMoveInput()
    {
        Keyboard keyboard = Keyboard.current;
        if (keyboard == null)
        {
            return Vector2.zero;
        }

        Vector2 input = Vector2.zero;
        if (keyboard.aKey.isPressed || keyboard.leftArrowKey.isPressed) input.x -= 1f;
        if (keyboard.dKey.isPressed || keyboard.rightArrowKey.isPressed) input.x += 1f;
        if (keyboard.sKey.isPressed || keyboard.downArrowKey.isPressed) input.y -= 1f;
        if (keyboard.wKey.isPressed || keyboard.upArrowKey.isPressed) input.y += 1f;
        return input.normalized;
    }
#endif
}
";
        }

        private static string BuildTopDownShooterPlayerScript()
        {
            return @"using UnityEngine;
#if ENABLE_INPUT_SYSTEM
using UnityEngine.InputSystem;
#endif

[RequireComponent(typeof(Rigidbody2D))]
public class AgenticTopDownShooterPlayer : MonoBehaviour
{
    public float moveSpeed = 6f;
    public float fireRate = 0.16f;
    public float bulletSpeed = 12f;
    public float bulletLifetime = 2.5f;

    private Rigidbody2D body;
    private Vector2 moveInput;
    private float nextFireTime;
    private static Sprite bulletSprite;

    private void Awake()
    {
        body = GetComponent<Rigidbody2D>();
        body.gravityScale = 0f;
        body.freezeRotation = true;
    }

    private void Update()
    {
#if ENABLE_INPUT_SYSTEM
        moveInput = ReadMoveInput();
        AimAtPointer();

        if (IsFirePressed() && Time.time >= nextFireTime)
#else
        moveInput = new Vector2(Input.GetAxisRaw(""Horizontal""), Input.GetAxisRaw(""Vertical"")).normalized;
        AimAtMouse();

        if (Input.GetMouseButton(0) && Time.time >= nextFireTime)
#endif
        {
            nextFireTime = Time.time + fireRate;
            Shoot();
        }
    }

    private void FixedUpdate()
    {
        body.linearVelocity = moveInput * moveSpeed;
    }

#if !ENABLE_INPUT_SYSTEM
    private void AimAtMouse()
    {
        Camera camera = Camera.main;
        if (camera == null)
        {
            return;
        }

        Vector3 mouse = camera.ScreenToWorldPoint(Input.mousePosition);
        Vector2 direction = mouse - transform.position;
        if (direction.sqrMagnitude > 0.001f)
        {
            float angle = Mathf.Atan2(direction.y, direction.x) * Mathf.Rad2Deg;
            transform.rotation = Quaternion.Euler(0f, 0f, angle);
        }
    }
#endif

#if ENABLE_INPUT_SYSTEM
    private Vector2 ReadMoveInput()
    {
        Keyboard keyboard = Keyboard.current;
        if (keyboard == null)
        {
            return Vector2.zero;
        }

        Vector2 input = Vector2.zero;
        if (keyboard.aKey.isPressed || keyboard.leftArrowKey.isPressed) input.x -= 1f;
        if (keyboard.dKey.isPressed || keyboard.rightArrowKey.isPressed) input.x += 1f;
        if (keyboard.sKey.isPressed || keyboard.downArrowKey.isPressed) input.y -= 1f;
        if (keyboard.wKey.isPressed || keyboard.upArrowKey.isPressed) input.y += 1f;
        return input.normalized;
    }

    private bool IsFirePressed()
    {
        Mouse mouse = Mouse.current;
        return mouse != null && mouse.leftButton.isPressed;
    }

    private void AimAtPointer()
    {
        Camera camera = Camera.main;
        Mouse mouse = Mouse.current;
        if (camera == null || mouse == null)
        {
            return;
        }

        Vector3 pointer = camera.ScreenToWorldPoint(mouse.position.ReadValue());
        Vector2 direction = pointer - transform.position;
        if (direction.sqrMagnitude > 0.001f)
        {
            float angle = Mathf.Atan2(direction.y, direction.x) * Mathf.Rad2Deg;
            transform.rotation = Quaternion.Euler(0f, 0f, angle);
        }
    }
#endif

    private void Shoot()
    {
        Vector2 direction = transform.right;
        GameObject bullet = new GameObject(""Player_Bullet"");
        bullet.transform.position = transform.position + (Vector3)(direction * 0.75f);
        bullet.transform.localScale = new Vector3(0.25f, 0.25f, 1f);

        SpriteRenderer renderer = bullet.AddComponent<SpriteRenderer>();
        renderer.sprite = GetBulletSprite();
        renderer.color = new Color(1f, 0.9f, 0.15f, 1f);
        renderer.sortingOrder = 20;

        CircleCollider2D collider = bullet.AddComponent<CircleCollider2D>();
        collider.isTrigger = true;

        Rigidbody2D bulletBody = bullet.AddComponent<Rigidbody2D>();
        bulletBody.gravityScale = 0f;
        bulletBody.collisionDetectionMode = CollisionDetectionMode2D.Continuous;
        bulletBody.linearVelocity = direction * bulletSpeed;

        Destroy(bullet, bulletLifetime);
    }

    private static Sprite GetBulletSprite()
    {
        if (bulletSprite != null)
        {
            return bulletSprite;
        }

        const int size = 32;
        Texture2D texture = new Texture2D(size, size, TextureFormat.RGBA32, false);
        texture.filterMode = FilterMode.Point;
        Vector2 center = new Vector2((size - 1) * 0.5f, (size - 1) * 0.5f);
        float radius = size * 0.45f;
        for (int y = 0; y < size; y++)
        {
            for (int x = 0; x < size; x++)
            {
                float distance = Vector2.Distance(new Vector2(x, y), center);
                texture.SetPixel(x, y, distance <= radius ? Color.white : Color.clear);
            }
        }

        texture.Apply();
        bulletSprite = Sprite.Create(texture, new Rect(0, 0, size, size), new Vector2(0.5f, 0.5f), size);
        bulletSprite.hideFlags = HideFlags.HideAndDontSave;
        return bulletSprite;
    }
}
";
        }

        private static string BuildTopDownCameraFollowScript()
        {
            return @"using UnityEngine;

public class AgenticTopDownCameraFollow : MonoBehaviour
{
    public string targetName = ""Player_Red"";
    public float followSpeed = 10f;
    public Vector3 offset = new Vector3(0f, 0f, -10f);

    private Transform target;

    private void LateUpdate()
    {
        if (target == null)
        {
            GameObject found = GameObject.Find(targetName);
            if (found != null)
            {
                target = found.transform;
            }
        }

        if (target == null)
        {
            return;
        }

        Vector3 desired = target.position + offset;
        transform.position = Vector3.Lerp(transform.position, desired, Time.deltaTime * followSpeed);
    }
}
";
        }

        private static int CountExecutableActions(AgentAction[] actions)
        {
            if (actions == null)
            {
                return 0;
            }

            int count = 0;
            foreach (AgentAction action in actions)
            {
                if (action != null && !string.IsNullOrWhiteSpace(action.type))
                {
                    count++;
                }
            }

            return count;
        }

        private static string[] BuildPlannedActionSummaries(AgentAction[] actions)
        {
            if (actions == null || actions.Length == 0)
            {
                return new string[0];
            }

            List<string> summaries = new List<string>();
            foreach (AgentAction action in actions)
            {
                if (action == null || string.IsNullOrWhiteSpace(action.type))
                {
                    continue;
                }

                string type = action.type.Trim();
                bool readOnly = IsReadOnlyAction(type);
                bool destructive = IsDestructiveAction(type);
                StringBuilder builder = new StringBuilder();
                builder.Append(type);
                if (readOnly)
                {
                    builder.Append(" [read-only]");
                }
                else if (destructive)
                {
                    builder.Append(" [destructive/high-risk]");
                }
                else
                {
                    builder.Append(" [mutating]");
                }

                builder.Append(PreviewActionTarget(action));

                string detail = BuildPlannedActionDetail(action);
                if (!string.IsNullOrWhiteSpace(detail))
                {
                    builder.Append(" — ");
                    builder.Append(detail);
                }

                summaries.Add(builder.ToString());
            }

            return summaries.ToArray();
        }

        private static string BuildPlannedActionDetail(AgentAction action)
        {
            if (action == null)
            {
                return string.Empty;
            }

            string type = (action.type ?? string.Empty).Trim().ToLowerInvariant();
            switch (type)
            {
                case "write_csharp_script":
                case "write_text_file":
                    return action.path;
                case "create_object":
                    return JoinNonEmpty(", ", action.component, action.role, action.parent);
                case "ensure_components":
                    return action.components != null && action.components.Length > 0
                        ? string.Join(", ", action.components)
                        : action.component;
                case "ensure_unity_workflow":
                case "repair_scene_relationships":
                case "setup_urp_post_processing":
                    return FirstNonEmpty(action.query, action.value, action.content, action.name);
                case "set_component_property":
                case "set_object_property":
                case "set_asset_property":
                case "set_project_setting":
                case "set_player_setting":
                    return action.property_path;
                case "set_transform":
                    return DescribeTransformIntent(action);
                case "instantiate_prefab":
                case "inspect_prefab":
                    return action.asset_path;
                case "create_scene":
                case "open_scene":
                case "save_scene":
                    return action.path;
                case "set_editor_build_scenes":
                    return action.paths != null && action.paths.Length > 0 ? string.Join(", ", action.paths) : string.Empty;
                case "invoke_editor_method":
                    return JoinNonEmpty(".", action.class_name, action.method_name);
                default:
                    return string.Empty;
            }
        }

        private static string DescribeTransformIntent(AgentAction action)
        {
            List<string> parts = new List<string>();
            if (action.use_position)
            {
                parts.Add("position");
            }

            if (action.use_rotation)
            {
                parts.Add("rotation");
            }

            if (action.use_scale)
            {
                parts.Add("scale");
            }

            return parts.Count == 0 ? string.Empty : string.Join(", ", parts);
        }

        private static string JoinNonEmpty(string separator, params string[] values)
        {
            if (values == null || values.Length == 0)
            {
                return string.Empty;
            }

            List<string> parts = new List<string>();
            foreach (string value in values)
            {
                if (!string.IsNullOrWhiteSpace(value))
                {
                    parts.Add(value.Trim());
                }
            }

            return parts.Count == 0 ? string.Empty : string.Join(separator, parts.ToArray());
        }

        private static bool IsReadOnlyAction(string actionType)
        {
            if (string.IsNullOrWhiteSpace(actionType))
            {
                return false;
            }

            switch (actionType.Trim().ToLowerInvariant())
            {
                case "read_unity_doc":
                case "read_compiler_diagnostics":
                case "read_text_file":
                case "inspect_prefab":
                case "inspect_runtime_state":
                case "read_unity_api":
                case "set_task_plan":
                case "update_task_status":
                case "search_unity_api":
                case "search_unity_docs":
                case "search_web":
                case "search_project":
                case "rebuild_unity":
                case "select":
                case "validate_scene":
                case "capture_game_view":
                case "capture_game_view_diagnostics":
                    return true;
                default:
                    return false;
            }
        }

        private static bool IsDestructiveAction(string actionType)
        {
            if (string.IsNullOrWhiteSpace(actionType))
            {
                return false;
            }

            switch (actionType.Trim().ToLowerInvariant())
            {
                case "clear_scene":
                case "delete_game_object":
                case "remove_component":
                case "remove_package":
                case "set_player_setting":
                case "set_project_setting":
                case "set_editor_build_scenes":
                case "invoke_editor_method":
                    return true;
                default:
                    return false;
            }
        }

        private static string PreviewActionTarget(AgentAction action)
        {
            if (action == null)
            {
                return string.Empty;
            }

            string target = FirstNonEmpty(
                action.target,
                action.name,
                action.path,
                action.asset_path,
                action.menu_item,
                action.package_id,
                action.property_path,
                action.class_name);
            return string.IsNullOrWhiteSpace(target) ? string.Empty : $" {target.Trim()}";
        }

        private static string ExecuteAction(AgentAction action)
        {
            switch (action.type.Trim().ToLowerInvariant())
            {
                case "set_task_plan":
                case "update_task_status":
                    return "task plan metadata action is only applied inside the live OpenAI tool loop";

                case "create_folder":
                    EnsureAssetFolder(NormalizeAssetPath(action.path));
                    return $"created folder {NormalizeAssetPath(action.path)}";

                case "search_project":
                    return SearchProject(action);

                case "search_web":
                    return SearchWeb(action);

                case "search_unity_docs":
                    return SearchUnityDocs(action);

                case "search_unity_api":
                    return SearchUnityApi(action);

                case "write_text_file":
                    return WriteTextFile(action);

                case "read_text_file":
                    return ReadTextFile(action);

                case "inspect_prefab":
                    return InspectPrefab(action);

                case "inspect_runtime_state":
                    return InspectRuntimeState(action);

                case "read_compiler_diagnostics":
                    return ReadCompilerDiagnostics(action);

                case "read_unity_doc":
                    return ReadUnityDoc(action);

                case "read_unity_api":
                    return ReadUnityApi(action);

                case "rebuild_unity":
                    return RebuildUnity();

                case "write_csharp_script":
                    return WriteCSharpScript(action);

                case "create_object":
                case "create_game_object":
                    return CreateGameObject(action);

                case "ensure_components":
                    return EnsureComponents(action);

                case "ensure_unity_workflow":
                    return EnsureUnityWorkflow(action);

                case "repair_scene_relationships":
                    return RepairSceneRelationships(action);

                case "setup_urp_post_processing":
                    return SetupUrpPostProcessing(action);

                case "apply_default_sprite":
                    return ApplyDefaultSprite(action);

                case "create_sprite_object":
                    return CreateSpriteObject(action);

                case "create_primitive":
                    return CreatePrimitive(action);

                case "create_camera":
                    return CreateCamera(action);

                case "ensure_camera":
                    return EnsureCamera(action);

                case "create_light":
                    return CreateLight(action);

                case "create_tilemap":
                    return CreateTilemap(action);

                case "create_sprite_asset":
                    return CreateSpriteAsset(action);

                case "create_unity_asset":
                    return CreateUnityAsset(action);

                case "delete_game_object":
                    return DeleteGameObject(action);

                case "clear_scene":
                    return ClearScene();

                case "set_object_property":
                    return SetObjectProperty(action);

                case "set_transform":
                    return SetTransform(action);

                case "set_component_property":
                    return SetComponentProperty(action);

                case "add_component":
                    return AddComponent(action);

                case "remove_component":
                    return RemoveComponent(action);

                case "select":
                    return SelectTarget(action);

                case "create_prefab_from_selected":
                    return CreatePrefabFromSelected(action);

                case "instantiate_prefab":
                    return InstantiatePrefab(action);

                case "create_scene":
                    return CreateScene(action);

                case "open_scene":
                    return OpenScene(action);

                case "execute_menu_item":
                    return ExecuteMenuItem(action);

                case "enter_play_mode":
                    return EnterPlayMode();

                case "exit_play_mode":
                    return ExitPlayMode();

                case "add_package":
                    return AddPackage(action);

                case "remove_package":
                    return RemovePackage(action);

                case "set_player_setting":
                    return SetPlayerSetting(action);

                case "set_project_setting":
                    return SetProjectSetting(action);

                case "set_asset_property":
                    return SetAssetProperty(action);

                case "set_editor_build_scenes":
                    return SetEditorBuildScenes(action);

                case "invoke_editor_method":
                    return InvokeEditorMethod(action);

                case "validate_scene":
                    return ValidateScene();

                case "capture_game_view":
                case "capture_game_view_diagnostics":
                    return CaptureGameViewDiagnostics(saveScreenshot: true);

                case "save_scene":
                    EditorSceneManager.SaveOpenScenes();
                    return "saved open scenes";

                case "save_assets":
                    AssetDatabase.SaveAssets();
                    return "saved assets";

                default:
                    return $"ignored unknown action type {action.type}";
            }
        }

        private static string WriteTextFile(AgentAction action)
        {
            string path = NormalizeAssetPath(action.path);
            if (string.IsNullOrWhiteSpace(path))
            {
                return "write_text_file missing path";
            }

            string prefabBuilderBlock = GetPrefabBuilderScriptWriteBlockReason(path, action.content);
            if (!string.IsNullOrWhiteSpace(prefabBuilderBlock))
            {
                return prefabBuilderBlock;
            }

            string coveredEditorUtilityBlock = GetCoveredEditorUtilityScriptWriteBlockReason(path, action.content);
            if (!string.IsNullOrWhiteSpace(coveredEditorUtilityBlock))
            {
                return coveredEditorUtilityBlock;
            }

            if (string.Equals(Path.GetExtension(path), ".meta", StringComparison.OrdinalIgnoreCase))
            {
                return "Tool blocked: do not write Unity .meta files directly. Create the real folder or asset instead; Unity will generate the .meta file.";
            }

            EnsureAssetFolder(Path.GetDirectoryName(path)?.Replace("\\", "/"));
            File.WriteAllText(path, action.content ?? string.Empty, Encoding.UTF8);
            if (ShouldDeferRefreshForScriptCompilation(path))
            {
                return $"wrote {path}; Unity rebuild required before imports or compilation will be visible";
            }

            AssetDatabase.ImportAsset(path, ImportAssetOptions.ForceUpdate);
            return $"wrote {path}";
        }

        private static string WriteCSharpScript(AgentAction action)
        {
            string path = NormalizeAssetPath(action.path);
            if (string.IsNullOrWhiteSpace(path))
            {
                string className = string.IsNullOrWhiteSpace(action.component) ? "AgenticComponent" : SanitizeFileName(action.component);
                path = $"Assets/Scripts/{className}.cs";
            }

            if (!string.Equals(Path.GetExtension(path), ".cs", StringComparison.OrdinalIgnoreCase))
            {
                path += ".cs";
            }

            string prefabBuilderBlock = GetPrefabBuilderScriptWriteBlockReason(path, action.content);
            if (!string.IsNullOrWhiteSpace(prefabBuilderBlock))
            {
                return prefabBuilderBlock;
            }

            string coveredEditorUtilityBlock = GetCoveredEditorUtilityScriptWriteBlockReason(path, action.content);
            if (!string.IsNullOrWhiteSpace(coveredEditorUtilityBlock))
            {
                return coveredEditorUtilityBlock;
            }

            EnsureAssetFolder(Path.GetDirectoryName(path)?.Replace("\\", "/"));
            File.WriteAllText(path, action.content ?? string.Empty, Encoding.UTF8);

            string componentName = string.IsNullOrWhiteSpace(action.component)
                ? Path.GetFileNameWithoutExtension(path)
                : action.component.Trim();
            string target = string.IsNullOrWhiteSpace(action.target) ? action.parent : action.target;

            if (!string.IsNullOrWhiteSpace(target) && !string.IsNullOrWhiteSpace(componentName))
            {
                QueuePendingScriptAttachment(target, componentName);
                return $"wrote {path}; queued {componentName} attachment to {target} after a future Unity rebuild compiles scripts";
            }

            return $"wrote {path}; Unity rebuild required before the script is compiled";
        }

        private static string RebuildUnity()
        {
            if (EditorApplication.isCompiling)
            {
                return "Unity rebuild already in progress: scripts are compiling";
            }

            if (EditorApplication.isUpdating)
            {
                return "Unity rebuild deferred: asset update already in progress";
            }

            AssetDatabase.SaveAssets();
            AssetDatabase.Refresh();
            if (EditorApplication.isCompiling)
            {
                return "started Unity rebuild; scripts are compiling";
            }

            if (EditorApplication.isUpdating)
            {
                return "started Unity rebuild; assets are refreshing";
            }

            return "completed Unity rebuild";
        }

        private static string GetCoveredEditorUtilityScriptWriteBlockReason(string path, string content)
        {
            if (!IsCoveredEditorUtilityScriptWrite(path, content))
            {
                return string.Empty;
            }

            return "Tool blocked: this editor utility duplicates direct Agentic tools. Use create_scene/open_scene/save_scene and set_editor_build_scenes directly instead of writing or invoking an Assets/Editor script.";
        }

        private static bool IsCoveredEditorUtilityScriptWrite(string path, string content)
        {
            if (string.IsNullOrWhiteSpace(path))
            {
                return false;
            }

            string normalizedPath = path.Trim().Replace("\\", "/");
            if (!normalizedPath.StartsWith("Assets/Editor/", StringComparison.OrdinalIgnoreCase) ||
                !string.Equals(Path.GetExtension(normalizedPath), ".cs", StringComparison.OrdinalIgnoreCase))
            {
                return false;
            }

            string fileName = Path.GetFileNameWithoutExtension(normalizedPath);
            if (fileName.IndexOf("SceneBuildSettingsUtility", StringComparison.OrdinalIgnoreCase) >= 0 ||
                fileName.IndexOf("BuildSettingsUtility", StringComparison.OrdinalIgnoreCase) >= 0)
            {
                return true;
            }

            string source = content ?? string.Empty;
            return source.IndexOf("EditorBuildSettings", StringComparison.OrdinalIgnoreCase) >= 0 ||
                source.IndexOf("EditorBuildSettingsScene", StringComparison.OrdinalIgnoreCase) >= 0 ||
                (source.IndexOf("EditorSceneManager", StringComparison.OrdinalIgnoreCase) >= 0 &&
                 source.IndexOf("OpenScene", StringComparison.OrdinalIgnoreCase) >= 0 &&
                 source.IndexOf("Assets/Scenes/", StringComparison.OrdinalIgnoreCase) >= 0);
        }

        private static string GetPrefabBuilderScriptWriteBlockReason(string path, string content)
        {
            if (!IsPrefabBuilderScriptWrite(path, content))
            {
                return string.Empty;
            }

            return "Tool blocked: prefab builder scripts are not used for ordinary prefab edits. Edit the prefab asset directly with set_component_property, set_transform, set_object_property, ensure_components, add_component, remove_component, or set_asset_property, then inspect_prefab to verify the actual prefab values.";
        }

        private static bool IsPrefabBuilderScriptWrite(string path, string content)
        {
            if (string.IsNullOrWhiteSpace(path))
            {
                return false;
            }

            string normalizedPath = path.Trim().Replace("\\", "/");
            if (!normalizedPath.StartsWith("Assets/Editor/", StringComparison.OrdinalIgnoreCase) ||
                !string.Equals(Path.GetExtension(normalizedPath), ".cs", StringComparison.OrdinalIgnoreCase))
            {
                return false;
            }

            string fileName = Path.GetFileNameWithoutExtension(normalizedPath);
            if (fileName.IndexOf("PrefabBuilder", StringComparison.OrdinalIgnoreCase) >= 0)
            {
                return true;
            }

            string source = content ?? string.Empty;
            return source.IndexOf("PrefabBuilder", StringComparison.OrdinalIgnoreCase) >= 0 &&
                (source.IndexOf("PrefabUtility", StringComparison.OrdinalIgnoreCase) >= 0 ||
                 source.IndexOf("SaveAsPrefabAsset", StringComparison.OrdinalIgnoreCase) >= 0);
        }

        private static string ReadTextFile(AgentAction action)
        {
            string path = NormalizeReadableProjectPath(string.IsNullOrWhiteSpace(action.path) ? action.asset_path : action.path);
            if (string.IsNullOrWhiteSpace(path))
            {
                return "read_text_file missing path";
            }

            string projectRoot = Directory.GetParent(Application.dataPath)?.FullName ?? Directory.GetCurrentDirectory();
            string fullPath = Path.GetFullPath(Path.Combine(projectRoot, path));
            string normalizedRoot = Path.GetFullPath(projectRoot);
            if (!fullPath.StartsWith(normalizedRoot + Path.DirectorySeparatorChar, StringComparison.Ordinal) &&
                !string.Equals(fullPath, normalizedRoot, StringComparison.Ordinal))
            {
                return $"read_text_file path is outside the project: {path}";
            }

            if (!File.Exists(fullPath))
            {
                return $"read_text_file path not found: {path}";
            }

            string extension = Path.GetExtension(path);
            if (!IsReadableTextExtension(extension))
            {
                return $"read_text_file only supports text/source files; unsupported extension: {extension}";
            }

            const int maxChars = 24000;
            string content = File.ReadAllText(fullPath, Encoding.UTF8);
            bool truncated = content.Length > maxChars;
            if (truncated)
            {
                content = content.Substring(0, maxChars);
            }

            StringBuilder builder = new StringBuilder();
            builder.AppendLine($"File: {path}");
            builder.AppendLine(truncated
                ? $"Content truncated to {maxChars} characters."
                : $"Content length: {content.Length} characters.");
            builder.AppendLine("```");
            builder.Append(content);
            if (!content.EndsWith("\n", StringComparison.Ordinal))
            {
                builder.AppendLine();
            }

            builder.Append("```");
            return builder.ToString();
        }

        private static string InspectPrefab(AgentAction action)
        {
            string path = NormalizeAssetPath(FirstNonEmpty(action.path, action.asset_path, action.value, action.query));
            if (string.IsNullOrWhiteSpace(path))
            {
                return "inspect_prefab missing path";
            }

            if (!string.Equals(Path.GetExtension(path), ".prefab", StringComparison.OrdinalIgnoreCase))
            {
                return $"inspect_prefab path must be a .prefab asset: {path}";
            }

            GameObject prefabRoot = null;
            try
            {
                prefabRoot = PrefabUtility.LoadPrefabContents(path);
                if (prefabRoot == null)
                {
                    return $"prefab not found: {path}";
                }

                string targetName = FirstNonEmpty(action.target, action.name);
                GameObject target = FindPrefabContentTarget(prefabRoot, targetName);
                if (target == null)
                {
                    return string.IsNullOrWhiteSpace(targetName)
                        ? $"prefab root not found: {path}"
                        : $"inspect_prefab target not found: {path}/{targetName}";
                }

                StringBuilder builder = new StringBuilder();
                builder.AppendLine($"Prefab: {path}");
                AppendPrefabObjectInspection(builder, target, includeChildren: true);
                return builder.ToString().TrimEnd();
            }
            catch (Exception exception)
            {
                return $"inspect_prefab failed for {path}: {exception.Message}";
            }
            finally
            {
                if (prefabRoot != null)
                {
                    PrefabUtility.UnloadPrefabContents(prefabRoot);
                }
            }
        }

        private static void AppendPrefabObjectInspection(StringBuilder builder, GameObject gameObject, bool includeChildren)
        {
            if (builder == null || gameObject == null)
            {
                return;
            }

            builder.AppendLine($"- {GetHierarchyPath(gameObject)}: active={gameObject.activeSelf}, tag={gameObject.tag}, layer={gameObject.layer}, localPosition={FormatVector3(gameObject.transform.localPosition)}, localRotation={FormatVector3(gameObject.transform.localEulerAngles)}, localScale={FormatVector3(gameObject.transform.localScale)}");
            Component[] components = gameObject.GetComponents<Component>();
            foreach (Component component in components)
            {
                if (component == null || component is Transform)
                {
                    continue;
                }

                builder.AppendLine($"  - {FormatComponentForContext(component)}");
            }

            if (!includeChildren)
            {
                return;
            }

            for (int i = 0; i < gameObject.transform.childCount; i++)
            {
                AppendPrefabObjectInspection(builder, gameObject.transform.GetChild(i).gameObject, includeChildren: true);
            }
        }

        private static string InspectRuntimeState(AgentAction action)
        {
            string query = FirstNonEmpty(action?.query, action?.target, action?.name, action?.value, action?.content, action?.component);
            int maxObjects = action != null && action.int_value > 0 ? Mathf.Clamp(action.int_value, 5, 60) : 24;
            StringBuilder builder = new StringBuilder();
            builder.AppendLine("Runtime state");
            AppendRuntimeStateSummary(builder, query, maxObjects);
            return builder.ToString().TrimEnd();
        }

        private static void AppendRuntimeInspectionContext(StringBuilder builder, string prompt, int maxObjects)
        {
            if (builder == null)
            {
                return;
            }

            builder.AppendLine("Runtime state:");
            AppendRuntimeStateSummary(builder, BuildRuntimeContextQuery(prompt), maxObjects);
        }

        private static void AppendRuntimeStateSummary(StringBuilder builder, string query, int maxObjects)
        {
            builder.AppendLine($"- editor playing={EditorApplication.isPlaying}, playingOrWillChange={EditorApplication.isPlayingOrWillChangePlaymode}, paused={EditorApplication.isPaused}, time={FormatFloat(Time.time)}, frame={Time.frameCount}, timeScale={FormatFloat(Time.timeScale)}");

            GameObject[] objects;
            try
            {
                objects = Object.FindObjectsByType<GameObject>(FindObjectsInactive.Include, FindObjectsSortMode.None);
            }
            catch (Exception exception)
            {
                builder.AppendLine($"- inspect_runtime_state failed: {exception.GetBaseException().Message}");
                return;
            }

            Dictionary<string, int> roleCounts = new Dictionary<string, int>(StringComparer.OrdinalIgnoreCase);
            Dictionary<string, int> componentCounts = new Dictionary<string, int>(StringComparer.OrdinalIgnoreCase);
            List<GameObject> matches = new List<GameObject>();
            int sceneObjectCount = 0;
            foreach (GameObject gameObject in objects)
            {
                if (gameObject == null || !gameObject.scene.IsValid())
                {
                    continue;
                }

                sceneObjectCount++;
                AccumulateRuntimeRoleCounts(roleCounts, gameObject);
                AccumulateRuntimeComponentCounts(componentCounts, gameObject);
                if (matches.Count < maxObjects && RuntimeObjectMatchesQuery(gameObject, query))
                {
                    matches.Add(gameObject);
                }
            }

            builder.AppendLine($"- scene object count={sceneObjectCount}");
            AppendCountSummary(builder, "role counts", roleCounts, 12);
            AppendCountSummary(builder, "MonoBehaviour/component counts", componentCounts, 14);

            string label = string.IsNullOrWhiteSpace(query)
                ? "matching runtime-relevant objects"
                : $"matching objects for \"{CompactOneLine(query, 80)}\"";
            builder.AppendLine($"- {label}: {matches.Count}");
            foreach (GameObject match in matches)
            {
                AppendRuntimeObjectInspection(builder, match);
            }
        }

        private static string BuildRuntimeContextQuery(string prompt)
        {
            List<string> tokens = ExtractSearchTokens(prompt);
            if (tokens.Count == 0)
            {
                return "player enemy spawn bullet projectile health wave manager ui win loss";
            }

            List<string> runtimeTokens = new List<string>();
            foreach (string token in tokens)
            {
                if (ContainsAny(token, "player", "enemy", "spawn", "bullet", "projectile", "health", "wave", "manager", "ui", "win", "loss", "restart", "damage", "combat", "arena"))
                {
                    runtimeTokens.Add(token);
                }
            }

            return runtimeTokens.Count == 0
                ? "player enemy spawn bullet projectile health wave manager ui win loss"
                : string.Join(" ", runtimeTokens.ToArray());
        }

        private static void AccumulateRuntimeRoleCounts(Dictionary<string, int> counts, GameObject gameObject)
        {
            string text = NormalizeIntentText(GetHierarchyPath(gameObject));
            AddRuntimeRoleCountIfContains(counts, text, "player");
            AddRuntimeRoleCountIfContains(counts, text, "enemy");
            AddRuntimeRoleCountIfContains(counts, text, "spawn");
            AddRuntimeRoleCountIfContains(counts, text, "bullet");
            AddRuntimeRoleCountIfContains(counts, text, "projectile");
            AddRuntimeRoleCountIfContains(counts, text, "health");
            AddRuntimeRoleCountIfContains(counts, text, "wave");
            AddRuntimeRoleCountIfContains(counts, text, "manager");
            AddRuntimeRoleCountIfContains(counts, text, "ui");
            AddRuntimeRoleCountIfContains(counts, text, "canvas");
            AddRuntimeRoleCountIfContains(counts, text, "win");
            AddRuntimeRoleCountIfContains(counts, text, "loss");
            AddRuntimeRoleCountIfContains(counts, text, "restart");
        }

        private static void AddRuntimeRoleCountIfContains(Dictionary<string, int> counts, string text, string role)
        {
            if (!string.IsNullOrWhiteSpace(text) && text.IndexOf(role, StringComparison.OrdinalIgnoreCase) >= 0)
            {
                IncrementCount(counts, role);
            }
        }

        private static void AccumulateRuntimeComponentCounts(Dictionary<string, int> counts, GameObject gameObject)
        {
            Component[] components = gameObject.GetComponents<Component>();
            foreach (Component component in components)
            {
                if (component == null || component is Transform)
                {
                    continue;
                }

                Type type = component.GetType();
                if (component is MonoBehaviour ||
                    type.Name.IndexOf("Canvas", StringComparison.OrdinalIgnoreCase) >= 0 ||
                    type.Name.IndexOf("Button", StringComparison.OrdinalIgnoreCase) >= 0 ||
                    type.Name.IndexOf("Text", StringComparison.OrdinalIgnoreCase) >= 0)
                {
                    IncrementCount(counts, type.Name);
                }
            }
        }

        private static void IncrementCount(Dictionary<string, int> counts, string key)
        {
            if (counts == null || string.IsNullOrWhiteSpace(key))
            {
                return;
            }

            counts.TryGetValue(key, out int count);
            counts[key] = count + 1;
        }

        private static bool RuntimeObjectMatchesQuery(GameObject gameObject, string query)
        {
            if (gameObject == null)
            {
                return false;
            }

            if (string.IsNullOrWhiteSpace(query))
            {
                return IsRuntimeRelevantObject(gameObject);
            }

            string normalizedQuery = NormalizeIntentText(query);
            string searchable = NormalizeIntentText(GetHierarchyPath(gameObject) + " " + BuildComponentNameList(gameObject));
            foreach (string token in ExtractSearchTokens(normalizedQuery))
            {
                if (searchable.IndexOf(token, StringComparison.OrdinalIgnoreCase) >= 0)
                {
                    return true;
                }
            }

            return false;
        }

        private static bool IsRuntimeRelevantObject(GameObject gameObject)
        {
            string searchable = NormalizeIntentText(GetHierarchyPath(gameObject) + " " + BuildComponentNameList(gameObject));
            return ContainsAny(
                searchable,
                "player", "enemy", "spawn", "bullet", "projectile", "health", "wave",
                "manager", "canvas", "button", "text", "ui", "win", "loss", "restart", "damage", "combat", "arena");
        }

        private static string BuildComponentNameList(GameObject gameObject)
        {
            if (gameObject == null)
            {
                return string.Empty;
            }

            Component[] components = gameObject.GetComponents<Component>();
            List<string> names = new List<string>();
            foreach (Component component in components)
            {
                if (component != null)
                {
                    names.Add(component.GetType().Name);
                }
            }

            return string.Join(" ", names.ToArray());
        }

        private static void AppendRuntimeObjectInspection(StringBuilder builder, GameObject gameObject)
        {
            builder.AppendLine($"  - {GetHierarchyPath(gameObject)}{FormatGameObjectState(gameObject)}");
            Component[] components = gameObject.GetComponents<Component>();
            int written = 0;
            foreach (Component component in components)
            {
                if (component == null || component is Transform)
                {
                    continue;
                }

                builder.AppendLine($"    component: {FormatComponentForContext(component)}");
                written++;
                if (written >= 8)
                {
                    break;
                }
            }
        }

        private static void AppendCountSummary(StringBuilder builder, string label, Dictionary<string, int> counts, int maxCount)
        {
            if (counts == null || counts.Count == 0)
            {
                builder.AppendLine($"- {label}: none");
                return;
            }

            List<KeyValuePair<string, int>> ranked = new List<KeyValuePair<string, int>>(counts);
            ranked.Sort((left, right) =>
            {
                int countCompare = right.Value.CompareTo(left.Value);
                return countCompare != 0 ? countCompare : string.Compare(left.Key, right.Key, StringComparison.OrdinalIgnoreCase);
            });

            int count = Mathf.Min(maxCount, ranked.Count);
            List<string> parts = new List<string>();
            for (int i = 0; i < count; i++)
            {
                parts.Add($"{ranked[i].Key}={ranked[i].Value}");
            }

            builder.AppendLine($"- {label}: {string.Join(", ", parts.ToArray())}");
        }

        private static string ReadCompilerDiagnostics(AgentAction action)
        {
            int maxLines = action != null && action.int_value > 0 ? Mathf.Clamp(action.int_value, 20, 200) : 120;
            string diagnostics = ReadRecentCompilerDiagnostics(maxLines, 20000, out string logPath);
            StringBuilder builder = new StringBuilder();
            builder.AppendLine("Compiler diagnostics");
            builder.AppendLine($"Source: {logPath}");
            if (string.IsNullOrWhiteSpace(diagnostics))
            {
                builder.AppendLine("No recent C# compiler diagnostics found in Editor.log.");
                return builder.ToString().TrimEnd();
            }

            builder.Append(diagnostics);
            return builder.ToString().TrimEnd();
        }

        private static string SearchProject(AgentAction action)
        {
            string query = FirstNonEmpty(action.query, action.value, action.name, action.content, action.path, action.asset_path);
            if (string.IsNullOrWhiteSpace(query))
            {
                return "search_project missing query/value";
            }

            StringBuilder builder = new StringBuilder();
            builder.AppendLine($"Project search: {query.Trim()}");
            AppendPromptRelevantProjectContext(builder, query);
            return builder.ToString().TrimEnd();
        }

        private static string SearchWeb(AgentAction action)
        {
            string query = FirstNonEmpty(action.query, action.value, action.name, action.content, action.path, action.asset_path);
            if (string.IsNullOrWhiteSpace(query))
            {
                return "search_web missing query/value";
            }

            int maxResults = action != null && action.int_value > 0 ? Mathf.Clamp(action.int_value, 1, 8) : 5;
            string trimmedQuery = query.Trim();
            string tavilyApiKey = GetTavilyApiKey();
            if (string.IsNullOrWhiteSpace(tavilyApiKey))
            {
                return "search_web requires a Tavily API key. Open Tools > Ark > Agent Backend > Settings and paste a Tavily API key, or set AGENTIC_UNITY_TAVILY_API_KEY / TAVILY_API_KEY in the Unity editor environment.";
            }

            try
            {
                TavilySearchRequest request = new TavilySearchRequest
                {
                    api_key = tavilyApiKey,
                    query = trimmedQuery,
                    search_depth = "basic",
                    max_results = maxResults,
                    include_answer = true,
                    include_raw_content = false
                };
                string responseJson = PostJson(TavilySearchEndpoint, JsonUtility.ToJson(request), includeApiKeyHeader: false, apiKey: tavilyApiKey);
                TavilySearchResponse response = JsonUtility.FromJson<TavilySearchResponse>(responseJson);

                StringBuilder builder = new StringBuilder();
                builder.AppendLine($"External web search: {trimmedQuery}");
                builder.AppendLine("Provider: Tavily");
                builder.AppendLine("Use as advisory implementation research only. Prefer official Unity/package/maintainer docs and verify against installed project APIs before writing code.");
                if (!string.IsNullOrWhiteSpace(response?.answer))
                {
                    builder.AppendLine();
                    builder.AppendLine("Answer:");
                    builder.AppendLine(ClampText(response.answer.Trim(), 900));
                }

                TavilySearchResult[] results = response?.results ?? new TavilySearchResult[0];
                if (results.Length == 0)
                {
                    builder.AppendLine();
                    builder.AppendLine("No Tavily search results returned.");
                    return builder.ToString().TrimEnd();
                }

                int count = Mathf.Min(results.Length, maxResults);
                for (int i = 0; i < count; i++)
                {
                    TavilySearchResult result = results[i];
                    if (result == null)
                    {
                        continue;
                    }

                    builder.AppendLine();
                    builder.AppendLine($"- {FirstNonEmpty(result.title, "Untitled result")}");
                    builder.AppendLine($"  url: {result.url}");
                    if (result.score > 0f)
                    {
                        builder.AppendLine($"  score: {FormatFloat(result.score)}");
                    }

                    if (!string.IsNullOrWhiteSpace(result.content))
                    {
                        builder.AppendLine($"  snippet: {ClampText(result.content.Trim(), 500)}");
                    }
                }

                return builder.ToString().TrimEnd();
            }
            catch (Exception exception)
            {
                return $"search_web Tavily request failed for \"{trimmedQuery}\": {RedactRequestSecret(exception.Message, tavilyApiKey)}. Use search_unity_docs/search_unity_api and installed package source as fallback.";
            }
        }

        private static string SearchUnityDocs(AgentAction action)
        {
            string query = FirstNonEmpty(action.query, action.value, action.name, action.content, action.path, action.asset_path);
            int maxResults = action.int_value > 0 ? action.int_value : 8;
            return AgenticUnityDocsIndex.Search(query, maxResults);
        }

        private static string ReadUnityDoc(AgentAction action)
        {
            string idOrPath = FirstNonEmpty(action.path, action.asset_path, action.name, action.value, action.query, action.content);
            return AgenticUnityDocsIndex.Read(idOrPath);
        }

        private static string SearchUnityApi(AgentAction action)
        {
            string query = FirstNonEmpty(action.query, action.value, action.name, action.content, action.path, action.asset_path);
            int maxResults = action.int_value > 0 ? action.int_value : 8;
            return AgenticUnityDocsIndex.SearchApi(query, maxResults);
        }

        private static string ReadUnityApi(AgentAction action)
        {
            string path = FirstNonEmpty(action.path, action.asset_path, action.value, action.query, action.name, action.content);
            if (string.IsNullOrWhiteSpace(path))
            {
                return "read_unity_api missing path. Use search_unity_api first, then read a returned source path.";
            }

            action.path = path;
            return ReadTextFile(action);
        }

        private static string CreateGameObject(AgentAction action)
        {
            bool genericCreateObject = string.Equals(action.type, "create_object", StringComparison.OrdinalIgnoreCase);
            if (!genericCreateObject && ShouldPromoteGameObjectToCamera(action))
            {
                return CreateCamera(action);
            }

            if (!genericCreateObject && ShouldPromoteGameObjectToLight(action))
            {
                return CreateLight(action);
            }

            string objectName = string.IsNullOrWhiteSpace(action.name) ? "Agentic Object" : action.name.Trim();
            GameObject gameObject = FindTarget(FirstNonEmpty(action.target, objectName));
            bool created = gameObject == null;
            if (created)
            {
                gameObject = new GameObject(objectName);
                Undo.RegisterCreatedObjectUndo(gameObject, "Agentic Create GameObject");
            }
            else
            {
                Undo.RecordObject(gameObject, "Agentic Update GameObject");
            }

            ApplyParent(gameObject, action.parent);
            ApplyTransform(gameObject.transform, action);
            string completion = CompleteObjectForGoal(gameObject, action);
            Selection.activeGameObject = gameObject;
            EditorSceneManager.MarkSceneDirty(SceneManager.GetActiveScene());
            return AppendDetail($"{(created ? "created" : "updated")} GameObject {GetHierarchyPath(gameObject)}", completion);
        }

        private static string EnsureComponents(AgentAction action)
        {
            GameObject target = FindSceneTargetForEdit(action);
            if (target == null)
            {
                string prefabResult;
                if (TryEditPrefabGameObject(action, "ensure_components", prefabTarget =>
                {
                    string prefabCompletion = CompleteObjectForGoal(prefabTarget, action);
                    return string.IsNullOrWhiteSpace(prefabCompletion)
                        ? $"prefab {GetPrefabEditSummary(prefabTarget)} already has requested components"
                        : $"ensured components on prefab {GetPrefabEditSummary(prefabTarget)}: {prefabCompletion}";
                }, out prefabResult))
                {
                    return prefabResult;
                }

                return "ensure_components target not found";
            }

            string result = CompleteObjectForGoal(target, action);
            EditorSceneManager.MarkSceneDirty(SceneManager.GetActiveScene());
            return string.IsNullOrWhiteSpace(result)
                ? $"{GetHierarchyPath(target)} already has requested components"
                : $"ensured components on {GetHierarchyPath(target)}: {result}";
        }

        private static string EnsureUnityWorkflow(AgentAction action)
        {
            string intent = NormalizeIntentText(GetWorkflowIntent(action));
            List<string> results = new List<string>();

            bool wantsPostProcessing = ContainsAny(intent, "post processing", "postprocessing", "postprocess", "bloom", "vignette", "volume");
            bool wantsCameraVisuals = ContainsAny(intent, "camera", "background", "render", "visual", "lighting", "color");
            bool wantsCinemachine = ContainsAny(intent, "cinemachine", "screen shake", "screenshake", "camera shake", "impulse");
            bool wantsRelationships = ContainsAny(
                intent,
                "relationship", "wire", "wiring", "reference", "prefab", "spawn", "spawner",
                "runtime", "gameplay", "ui", "scene", "system", "everything", "all");

            if (wantsPostProcessing)
            {
                results.Add(SetupUrpPostProcessing(action));
            }

            if (wantsCameraVisuals)
            {
                results.Add(EnsureCameraVisualWorkflow(action));
            }

            if (wantsCinemachine)
            {
                results.Add(EnsureCinemachineSceneSetup(action));
            }

            if (wantsRelationships || results.Count == 0)
            {
                results.Add(RepairSceneRelationships(action));
            }

            return CombineWorkflowResults("ensured Unity workflow", results);
        }

        private static string EnsureCameraVisualWorkflow(AgentAction action)
        {
            Camera camera = FindWorkflowCamera(action);
            if (camera == null)
            {
                return "camera visual workflow found no camera";
            }

            Undo.RecordObject(camera, "Agentic Ensure Camera Visual Workflow");
            string intent = NormalizeIntentText(GetWorkflowIntent(action));
            Color background = TryGetActionColor(action, out Color parsedColor)
                ? parsedColor
                : (ContainsAny(intent, "black", "dark") ? Color.black : camera.backgroundColor);

            if (ContainsAny(intent, "background", "clear", "black", "dark") || TryGetActionColor(action, out _))
            {
                camera.clearFlags = CameraClearFlags.SolidColor;
                camera.backgroundColor = background;
            }

            EditorUtility.SetDirty(camera);
            EditorSceneManager.MarkSceneDirty(SceneManager.GetActiveScene());
            return $"ensured camera visuals on {GetHierarchyPath(camera.gameObject)}";
        }

        private static string RepairSceneRelationships(AgentAction action)
        {
            List<string> notes = new List<string>();
            int repaired = 0;
            SceneRelationshipIndex index = BuildSceneRelationshipIndex();
#if ARK_HAS_URP
            bool repairedPostProcessing = false;
#endif

            repaired += RepairCinemachineSceneSetup(BuildRuntimeScriptPackageDependencies(), action, index, notes);

            foreach (GameObject gameObject in index.Objects)
            {
                if (gameObject == null)
                {
                    continue;
                }

                if (RepairSpriteRendererRelationship(gameObject, notes))
                {
                    repaired++;
                }

#if ARK_HAS_URP
                Volume volume = gameObject.GetComponent<Volume>();
                if (!repairedPostProcessing && volume != null &&
                    (volume.sharedProfile == null || !HasAnyActiveVolumeOverride(volume.sharedProfile)))
                {
                    notes.Add(SetupUrpPostProcessing(action));
                    repaired++;
                    repairedPostProcessing = true;
                }
#endif

                MonoBehaviour[] behaviours = gameObject.GetComponents<MonoBehaviour>();
                foreach (MonoBehaviour behaviour in behaviours)
                {
                    if (behaviour == null)
                    {
                        continue;
                    }

                    repaired += RepairSerializedRelationships(behaviour, index, action, notes);
                    repaired += RepairLookupStringRelationships(behaviour, index, action, notes);
                }
            }

            if (repaired > 0)
            {
                EditorSceneManager.MarkSceneDirty(SceneManager.GetActiveScene());
                AssetDatabase.SaveAssets();
            }

            if (notes.Count == 0)
            {
                return "scene relationship repair found no automatic fixes";
            }

            return $"repaired {repaired} scene relationship issue(s): {JoinLimited(notes.ToArray(), 8)}";
        }

        private static string EnsureCinemachineSceneSetup(AgentAction action)
        {
            RuntimeScriptPackageDependencies dependencies = BuildRuntimeScriptPackageDependencies();
            string intent = NormalizeIntentText(GetWorkflowIntent(action));
            if (!dependencies.UsesCinemachine && !ContainsAny(intent, "cinemachine", "screen shake", "screenshake", "camera shake", "impulse"))
            {
                return "Cinemachine setup skipped: no Cinemachine dependency detected";
            }

            List<string> notes = new List<string>();
            int repaired = RepairCinemachineSceneSetup(dependencies, action, BuildSceneRelationshipIndex(), notes);
            if (repaired <= 0)
            {
                return "Cinemachine scene setup already satisfied or package component types are unavailable";
            }

            EditorSceneManager.MarkSceneDirty(SceneManager.GetActiveScene());
            AssetDatabase.SaveAssets();
            return $"ensured Cinemachine scene setup: {JoinLimited(notes.ToArray(), 8)}";
        }

        private static int RepairCinemachineSceneSetup(
            RuntimeScriptPackageDependencies dependencies,
            AgentAction action,
            SceneRelationshipIndex index,
            List<string> notes)
        {
            string intent = NormalizeIntentText(GetWorkflowIntent(action));
            bool requested = ContainsAny(intent, "cinemachine", "screen shake", "screenshake", "camera shake", "impulse");
            if (!dependencies.UsesCinemachine && !requested)
            {
                return 0;
            }

            Type brainType = FindComponentType("CinemachineBrain");
            Type cameraType = FindComponentType("CinemachineCamera");
            Type followType = FindComponentType("CinemachineFollow");
            Type impulseListenerType = FindComponentType("CinemachineImpulseListener");
            Type impulseSourceType = FindComponentType("CinemachineImpulseSource");
            if (brainType == null && cameraType == null && impulseListenerType == null && impulseSourceType == null)
            {
                notes?.Add("Cinemachine package component types are not loaded");
                return 0;
            }

            int repaired = 0;
            bool needsImpulse = dependencies.UsesCinemachineImpulse ||
                ContainsAny(intent, "screen shake", "screenshake", "camera shake", "impulse");
            bool needsVirtualCamera = dependencies.UsesCinemachineCamera || needsImpulse || ContainsAny(intent, "cinemachine");

            Camera camera = FindWorkflowCamera(action);
            if (camera == null)
            {
                GameObject cameraObject = FindTarget("Main Camera");
                bool createdCameraObject = false;
                if (cameraObject == null)
                {
                    cameraObject = new GameObject("Main Camera");
                    createdCameraObject = true;
                }

                if (createdCameraObject)
                {
                    Undo.RegisterCreatedObjectUndo(cameraObject, "Agentic Create Main Camera");
                }

                SetTagIfAvailable(cameraObject, "MainCamera");
                camera = cameraObject.GetComponent<Camera>() ?? Undo.AddComponent<Camera>(cameraObject);
                if (cameraObject.GetComponent<AudioListener>() == null)
                {
                    Undo.AddComponent<AudioListener>(cameraObject);
                }

                repaired++;
                notes?.Add("created Main Camera for Cinemachine");
            }

            if (camera != null && brainType != null && camera.gameObject.GetComponent(brainType) == null)
            {
                Undo.AddComponent(camera.gameObject, brainType);
                EditorUtility.SetDirty(camera.gameObject);
                repaired++;
                notes?.Add($"added CinemachineBrain to {GetHierarchyPath(camera.gameObject)}");
            }

            GameObject cinemachineCameraObject = null;
            if (needsVirtualCamera)
            {
                cinemachineCameraObject = FindSceneObjectWithComponentType(index, "CinemachineCamera") ??
                    FindTarget("Cinemachine Camera") ??
                    FindTarget("Gameplay Cinemachine Camera");

                if (cinemachineCameraObject == null)
                {
                    cinemachineCameraObject = new GameObject("Cinemachine Camera");
                    Undo.RegisterCreatedObjectUndo(cinemachineCameraObject, "Agentic Create Cinemachine Camera");
                    if (camera != null)
                    {
                        cinemachineCameraObject.transform.position = camera.transform.position;
                        cinemachineCameraObject.transform.rotation = camera.transform.rotation;
                    }

                    repaired++;
                    notes?.Add("created Cinemachine Camera");
                }

                if (cameraType != null && cinemachineCameraObject.GetComponent(cameraType) == null)
                {
                    Undo.AddComponent(cinemachineCameraObject, cameraType);
                    repaired++;
                    notes?.Add($"added CinemachineCamera to {GetHierarchyPath(cinemachineCameraObject)}");
                }

                if (followType != null && cinemachineCameraObject.GetComponent(followType) == null)
                {
                    Undo.AddComponent(cinemachineCameraObject, followType);
                    repaired++;
                    notes?.Add($"added CinemachineFollow to {GetHierarchyPath(cinemachineCameraObject)}");
                }

                if (ConfigureCinemachineCamera(cinemachineCameraObject, camera, action, notes))
                {
                    repaired++;
                }
            }

            if (needsImpulse)
            {
                GameObject listenerHost = cinemachineCameraObject ??
                    FindSceneObjectWithComponentType(index, "CinemachineCamera") ??
                    (camera == null ? null : camera.gameObject);
                if (listenerHost != null && impulseListenerType != null && listenerHost.GetComponent(impulseListenerType) == null)
                {
                    Component listener = Undo.AddComponent(listenerHost, impulseListenerType);
                    ConfigureCinemachineImpulseListener(listener);
                    repaired++;
                    notes?.Add($"added CinemachineImpulseListener to {GetHierarchyPath(listenerHost)}");
                }

                GameObject sourceHost = FindTarget("ScreenShakeService") ??
                    FindTarget("Screen Shake Service") ??
                    FindTarget("ScreenShakeService") ??
                    (camera == null ? null : camera.gameObject);
                if (sourceHost == null)
                {
                    sourceHost = new GameObject("ScreenShakeService");
                    Undo.RegisterCreatedObjectUndo(sourceHost, "Agentic Create Screen Shake Service");
                    repaired++;
                    notes?.Add("created ScreenShakeService host");
                }

                if (sourceHost != null && impulseSourceType != null && !SceneHasComponentType(index, "CinemachineImpulseSource"))
                {
                    Component source = Undo.AddComponent(sourceHost, impulseSourceType);
                    ConfigureCinemachineImpulseSource(source);
                    repaired++;
                    notes?.Add($"added CinemachineImpulseSource to {GetHierarchyPath(sourceHost)}");
                }
            }

            if (repaired > 0)
            {
                EditorSceneManager.MarkSceneDirty(SceneManager.GetActiveScene());
            }

            return repaired;
        }

        private static bool ConfigureCinemachineCamera(GameObject cinemachineCameraObject, Camera camera, AgentAction action, List<string> notes)
        {
            if (cinemachineCameraObject == null)
            {
                return false;
            }

            Type cameraType = FindComponentType("CinemachineCamera");
            Component cinemachineCamera = cameraType == null ? null : cinemachineCameraObject.GetComponent(cameraType);
            if (cinemachineCamera == null)
            {
                return false;
            }

            bool changed = false;
            Transform trackingTarget = FindWorkflowTrackingTarget(action);
            if (trackingTarget != null)
            {
                PropertyInfo followProperty = cameraType.GetProperty("Follow", BindingFlags.Instance | BindingFlags.Public);
                if (followProperty != null && followProperty.CanWrite)
                {
                    object current = followProperty.GetValue(cinemachineCamera);
                    if (!ReferenceEquals(current, trackingTarget))
                    {
                        Undo.RecordObject(cinemachineCamera, "Agentic Configure Cinemachine Camera");
                        followProperty.SetValue(cinemachineCamera, trackingTarget);
                        changed = true;
                    }
                }
            }

            Type followType = FindComponentType("CinemachineFollow");
            Component follow = followType == null ? null : cinemachineCameraObject.GetComponent(followType);
            if (follow != null)
            {
                FieldInfo offsetField = followType.GetField("FollowOffset", BindingFlags.Instance | BindingFlags.Public);
                if (offsetField != null && offsetField.FieldType == typeof(Vector3))
                {
                    Vector3 desiredOffset = camera != null && camera.orthographic
                        ? new Vector3(0f, 0f, -10f)
                        : Vector3.back * 10f;
                    Vector3 currentOffset = (Vector3)offsetField.GetValue(follow);
                    if ((currentOffset - desiredOffset).sqrMagnitude > 0.001f)
                    {
                        Undo.RecordObject(follow, "Agentic Configure Cinemachine Follow");
                        offsetField.SetValue(follow, desiredOffset);
                        changed = true;
                    }
                }
            }

            if (changed)
            {
                EditorUtility.SetDirty(cinemachineCamera);
                if (follow != null)
                {
                    EditorUtility.SetDirty(follow);
                }

                notes?.Add($"configured Cinemachine Camera target/follow on {GetHierarchyPath(cinemachineCameraObject)}");
            }

            return changed;
        }

        private static Transform FindWorkflowTrackingTarget(AgentAction action)
        {
            GameObject target = FindTarget(FirstNonEmpty(action?.reference_target, action?.target, action?.name));
            if (target != null && target.GetComponent<Camera>() == null)
            {
                return target.transform;
            }

            target = FindTaggedObject("Player") ?? FindTarget("Player");
            return target == null ? null : target.transform;
        }

        private static void ConfigureCinemachineImpulseListener(Component listener)
        {
            if (listener == null)
            {
                return;
            }

            Undo.RecordObject(listener, "Agentic Configure Cinemachine Impulse Listener");
            SetPublicMemberIfPresent(listener, "ChannelMask", -1);
            SetPublicMemberIfPresent(listener, "Gain", 1f);
            SetPublicMemberIfPresent(listener, "Use2DDistance", true);
            EditorUtility.SetDirty(listener);
        }

        private static void ConfigureCinemachineImpulseSource(Component source)
        {
            if (source == null)
            {
                return;
            }

            Undo.RecordObject(source, "Agentic Configure Cinemachine Impulse Source");
            SetPublicMemberIfPresent(source, "DefaultVelocity", new Vector3(0f, -1f, 0f));
            EditorUtility.SetDirty(source);
        }

        private static void SetPublicMemberIfPresent(Component component, string memberName, object value)
        {
            if (component == null || string.IsNullOrWhiteSpace(memberName))
            {
                return;
            }

            Type type = component.GetType();
            FieldInfo field = type.GetField(memberName, BindingFlags.Instance | BindingFlags.Public);
            if (field != null && field.FieldType.IsInstanceOfType(value))
            {
                field.SetValue(component, value);
                return;
            }

            PropertyInfo property = type.GetProperty(memberName, BindingFlags.Instance | BindingFlags.Public);
            if (property != null && property.CanWrite && property.PropertyType.IsInstanceOfType(value))
            {
                property.SetValue(component, value);
            }
        }

        private static string SetupUrpPostProcessing(AgentAction action)
        {
#if !ARK_HAS_URP
            return "URP post-processing setup requires the Universal Render Pipeline package";
#else
            string profilePath = NormalizeAssetPath(FirstNonEmpty(
                action.asset_path,
                action.path,
                "Assets/Settings/VolumeProfile_PostProcessing.asset"));
            EnsureAssetFolder(Path.GetDirectoryName(profilePath)?.Replace("\\", "/"));

            VolumeProfile profile = AssetDatabase.LoadAssetAtPath<VolumeProfile>(profilePath);
            if (profile == null)
            {
                profile = ScriptableObject.CreateInstance<VolumeProfile>();
                profile.name = Path.GetFileNameWithoutExtension(profilePath);
                AssetDatabase.CreateAsset(profile, profilePath);
            }

            string intent = NormalizeIntentText(GetWorkflowIntent(action));
            bool wantsVignette = ContainsAny(intent, "vignette") || !ContainsAny(intent, "bloom");
            bool wantsBloom = ContainsAny(intent, "bloom") || !ContainsAny(intent, "vignette");
            if (ContainsAny(intent, "post processing", "postprocessing", "postprocess", "volume"))
            {
                wantsBloom = true;
                wantsVignette = true;
            }

            if (wantsBloom)
            {
                Bloom bloom = GetOrAddVolumeOverride<Bloom>(profile);
                bloom.active = true;
                bloom.intensity.overrideState = true;
                bloom.intensity.value = action.float_value > 0f ? action.float_value : 4.5f;
                bloom.threshold.overrideState = true;
                bloom.threshold.value = 0.85f;
                bloom.scatter.overrideState = true;
                bloom.scatter.value = 0.85f;
                bloom.tint.overrideState = true;
                bloom.tint.value = Color.white;
                bloom.clamp.overrideState = true;
                bloom.clamp.value = 65472f;
                bloom.highQualityFiltering.overrideState = true;
                bloom.highQualityFiltering.value = true;
            }

            if (wantsVignette)
            {
                Vignette vignette = GetOrAddVolumeOverride<Vignette>(profile);
                vignette.active = true;
                vignette.color.overrideState = true;
                vignette.color.value = new Color(0.04f, 0.03f, 0.06f, 1f);
                vignette.intensity.overrideState = true;
                vignette.intensity.value = 0.38f;
                vignette.smoothness.overrideState = true;
                vignette.smoothness.value = 0.9f;
                vignette.center.overrideState = true;
                vignette.center.value = new Vector2(0.5f, 0.5f);
                vignette.rounded.overrideState = true;
                vignette.rounded.value = false;
            }

            Volume volume = FindOrCreateGlobalVolume();
            Undo.RecordObject(volume, "Agentic Setup URP Post Processing");
            volume.enabled = true;
            volume.isGlobal = true;
            volume.priority = 10f;
            volume.weight = 1f;
            volume.sharedProfile = profile;

            Camera camera = FindWorkflowCamera(action);
            if (camera != null)
            {
                Undo.RecordObject(camera, "Agentic Setup URP Post Processing Camera");
                UniversalAdditionalCameraData cameraData = camera.GetComponent<UniversalAdditionalCameraData>();
                if (cameraData == null)
                {
                    cameraData = Undo.AddComponent<UniversalAdditionalCameraData>(camera.gameObject);
                }

                cameraData.renderPostProcessing = true;

                if (TryGetActionColor(action, out Color background) ||
                    ContainsAny(intent, "black background", "camera background", "background black"))
                {
                    camera.clearFlags = CameraClearFlags.SolidColor;
                    camera.backgroundColor = TryGetActionColor(action, out background) ? background : Color.black;
                }

                EditorUtility.SetDirty(camera);
                EditorUtility.SetDirty(cameraData);
            }

            EditorUtility.SetDirty(profile);
            EditorUtility.SetDirty(volume);
            AssetDatabase.SaveAssets();
            EditorSceneManager.MarkSceneDirty(SceneManager.GetActiveScene());

            string overrides = JoinNonEmpty(", ", wantsBloom ? "Bloom" : string.Empty, wantsVignette ? "Vignette" : string.Empty);
            return $"set up URP post-processing ({overrides}) using {profilePath}";
#endif
        }

#if ARK_HAS_URP
        private static T GetOrAddVolumeOverride<T>(VolumeProfile profile) where T : VolumeComponent
        {
            profile.components.RemoveAll(component => component == null);
            if (profile.TryGet(out T component) && component != null)
            {
                return component;
            }

            component = profile.Add<T>(true);
            component.hideFlags = HideFlags.HideInInspector | HideFlags.HideInHierarchy;
            AssetDatabase.AddObjectToAsset(component, profile);
            return component;
        }

        private static Volume FindOrCreateGlobalVolume()
        {
            foreach (GameObject root in SceneManager.GetActiveScene().GetRootGameObjects())
            {
                Volume existing = root.GetComponentInChildren<Volume>(true);
                if (existing != null && existing.isGlobal)
                {
                    return existing;
                }
            }

            GameObject volumeObject = FindTarget("Global Volume") ?? new GameObject("Global Volume");
            if (volumeObject.GetComponent<Volume>() == null)
            {
                Undo.RegisterCreatedObjectUndo(volumeObject, "Agentic Create Global Volume");
                return Undo.AddComponent<Volume>(volumeObject);
            }

            return volumeObject.GetComponent<Volume>();
        }
#endif

        private static Camera FindWorkflowCamera(AgentAction action)
        {
            GameObject target = FindTarget(FirstNonEmpty(action.target, action.name));
            Camera camera = target == null ? null : target.GetComponent<Camera>();
            if (camera != null)
            {
                return camera;
            }

            if (Camera.main != null)
            {
                return Camera.main;
            }

            foreach (GameObject root in SceneManager.GetActiveScene().GetRootGameObjects())
            {
                camera = root.GetComponentInChildren<Camera>(true);
                if (camera != null)
                {
                    return camera;
                }
            }

            return null;
        }

        private static bool RepairSpriteRendererRelationship(GameObject gameObject, List<string> notes)
        {
            SpriteRenderer renderer = gameObject == null ? null : gameObject.GetComponent<SpriteRenderer>();
            if (renderer == null || renderer.sprite != null)
            {
                return false;
            }

            string shape = NameContainsAny(gameObject.name, "player", "enemy", "bullet", "projectile") ? "circle" : "square";
            Sprite sprite = EnsureDefaultSprite(shape);
            if (sprite == null)
            {
                return false;
            }

            Undo.RecordObject(renderer, "Agentic Repair Sprite Relationship");
            renderer.sprite = sprite;
            renderer.color = InferDefaultSpriteColor(gameObject, renderer.color);
            EditorUtility.SetDirty(renderer);
            notes?.Add($"assigned default {shape} sprite to {GetHierarchyPath(gameObject)}");
            return true;
        }

        private static int RepairSerializedRelationships(
            MonoBehaviour component,
            SceneRelationshipIndex index,
            AgentAction action,
            List<string> notes)
        {
            int repaired = 0;
            try
            {
                SerializedObject serializedObject = new SerializedObject(component);
                SerializedProperty property = serializedObject.GetIterator();
                bool enterChildren = true;
                while (property.NextVisible(enterChildren))
                {
                    enterChildren = false;
                    if (ShouldSkipSerializedReferenceValidation(property) || !IsImportantSerializedReferenceField(property.propertyPath))
                    {
                        continue;
                    }

                    if (property.isArray && property.propertyType != SerializedPropertyType.String)
                    {
                        if (TryRepairObjectReferenceArray(component, serializedObject, property, index, action, notes))
                        {
                            repaired++;
                        }

                        continue;
                    }

                    if (property.propertyType == SerializedPropertyType.ObjectReference &&
                        property.objectReferenceValue == null &&
                        TryRepairObjectReference(component, property, index, action, notes))
                    {
                        repaired++;
                    }
                }

                if (repaired > 0)
                {
                    serializedObject.ApplyModifiedProperties();
                    EditorUtility.SetDirty(component);
                }
            }
            catch (Exception exception)
            {
                notes?.Add($"{component.GetType().Name} relationship repair skipped: {exception.Message}");
            }

            return repaired;
        }

        private static bool TryRepairObjectReferenceArray(
            MonoBehaviour component,
            SerializedObject serializedObject,
            SerializedProperty property,
            SceneRelationshipIndex index,
            AgentAction action,
            List<string> notes)
        {
            if (property == null || !property.isArray || property.propertyType == SerializedPropertyType.String)
            {
                return false;
            }

            string elementType = GetArrayElementObjectReferenceType(property);
            if (string.IsNullOrWhiteSpace(elementType))
            {
                return false;
            }

            List<Object> references = FindReferenceCandidatesForProperty(component, property.propertyPath, elementType, index, action, 6);
            if (references.Count == 0)
            {
                return false;
            }

            bool changed = false;
            if (property.arraySize == 0)
            {
                property.arraySize = references.Count;
                for (int i = 0; i < references.Count; i++)
                {
                    SerializedProperty element = property.GetArrayElementAtIndex(i);
                    if (element != null && element.propertyType == SerializedPropertyType.ObjectReference)
                    {
                        element.objectReferenceValue = references[i];
                        changed = true;
                    }
                }
            }
            else
            {
                int referenceIndex = 0;
                for (int i = 0; i < property.arraySize; i++)
                {
                    SerializedProperty element = property.GetArrayElementAtIndex(i);
                    if (element == null ||
                        element.propertyType != SerializedPropertyType.ObjectReference ||
                        element.objectReferenceValue != null)
                    {
                        continue;
                    }

                    element.objectReferenceValue = references[Mathf.Min(referenceIndex, references.Count - 1)];
                    referenceIndex++;
                    changed = true;
                }
            }

            if (changed)
            {
                notes?.Add($"wired {component.GetType().Name}.{property.propertyPath}");
                serializedObject.ApplyModifiedProperties();
            }

            return changed;
        }

        private static bool TryRepairObjectReference(
            MonoBehaviour component,
            SerializedProperty property,
            SceneRelationshipIndex index,
            AgentAction action,
            List<string> notes)
        {
            string expectedType = ExtractObjectReferenceTypeName(property.type);
            List<Object> references = FindReferenceCandidatesForProperty(component, property.propertyPath, expectedType, index, action, 3);
            foreach (Object reference in references)
            {
                if (TrySetObjectReference(property, reference))
                {
                    notes?.Add($"wired {component.GetType().Name}.{property.propertyPath}");
                    return true;
                }
            }

            return false;
        }

        private static List<Object> FindReferenceCandidatesForProperty(
            Component owner,
            string propertyPath,
            string expectedType,
            SceneRelationshipIndex index,
            AgentAction action,
            int maxCount)
        {
            List<Object> references = new List<Object>();
            string normalized = NormalizeSettingKey(propertyPath);
            bool wantsPrefab = normalized.IndexOf("prefab", StringComparison.OrdinalIgnoreCase) >= 0 ||
                normalized.IndexOf("projectile", StringComparison.OrdinalIgnoreCase) >= 0 ||
                normalized.IndexOf("bullet", StringComparison.OrdinalIgnoreCase) >= 0 ||
                normalized.IndexOf("enemy", StringComparison.OrdinalIgnoreCase) >= 0 && normalized.IndexOf("target", StringComparison.OrdinalIgnoreCase) < 0;

            if (wantsPrefab)
            {
                AddAssetReferenceCandidates(references, owner, propertyPath, maxCount);
                if (references.Count == 0)
                {
                    Object fallback = CreateFallbackPrefabForProperty(propertyPath, expectedType);
                    if (fallback != null)
                    {
                        references.Add(fallback);
                    }
                }
            }

            if (references.Count < maxCount)
            {
                AddSceneReferenceCandidates(references, propertyPath, expectedType, index, maxCount);
            }

            return references;
        }

        private static void AddAssetReferenceCandidates(List<Object> references, Component owner, string propertyPath, int maxCount)
        {
            if (references == null || references.Count >= maxCount)
            {
                return;
            }

            if (!TryGetAssetReferenceExpectation(propertyPath, out AssetReferenceExpectation expectation))
            {
                return;
            }

            List<string> tokens = ExtractAssetReferenceTokens(owner, propertyPath);
            List<string> candidates = FindAssetReferenceCandidates(expectation.SearchFilter, tokens, maxCount);
            foreach (string candidatePath in candidates)
            {
                Object asset = AssetDatabase.LoadAssetAtPath<Object>(candidatePath);
                if (asset != null && !references.Contains(asset))
                {
                    references.Add(asset);
                    if (references.Count >= maxCount)
                    {
                        break;
                    }
                }
            }
        }

        private static void AddSceneReferenceCandidates(
            List<Object> references,
            string propertyPath,
            string expectedType,
            SceneRelationshipIndex index,
            int maxCount)
        {
            if (references == null || index == null || references.Count >= maxCount)
            {
                return;
            }

            string normalized = NormalizeSettingKey(propertyPath);
            foreach (GameObject gameObject in index.Objects)
            {
                if (gameObject == null || !MatchesReferenceIntent(gameObject, normalized))
                {
                    continue;
                }

                Object reference = ConvertGameObjectToExpectedReference(gameObject, expectedType);
                if (reference != null && !references.Contains(reference))
                {
                    references.Add(reference);
                    if (references.Count >= maxCount)
                    {
                        return;
                    }
                }
            }
        }

        private static bool MatchesReferenceIntent(GameObject gameObject, string normalizedPropertyPath)
        {
            string objectName = NormalizeSettingKey(gameObject.name);
            if (normalizedPropertyPath.IndexOf("player", StringComparison.OrdinalIgnoreCase) >= 0)
            {
                return string.Equals(gameObject.tag, "Player", StringComparison.OrdinalIgnoreCase) ||
                    objectName.IndexOf("player", StringComparison.OrdinalIgnoreCase) >= 0;
            }

            if (normalizedPropertyPath.IndexOf("camera", StringComparison.OrdinalIgnoreCase) >= 0)
            {
                return gameObject.GetComponent<Camera>() != null || objectName.IndexOf("camera", StringComparison.OrdinalIgnoreCase) >= 0;
            }

            if (normalizedPropertyPath.IndexOf("canvas", StringComparison.OrdinalIgnoreCase) >= 0 ||
                normalizedPropertyPath.IndexOf("ui", StringComparison.OrdinalIgnoreCase) >= 0)
            {
                return gameObject.GetComponent<Canvas>() != null || objectName.IndexOf("ui", StringComparison.OrdinalIgnoreCase) >= 0;
            }

            if (normalizedPropertyPath.IndexOf("text", StringComparison.OrdinalIgnoreCase) >= 0 ||
                normalizedPropertyPath.IndexOf("button", StringComparison.OrdinalIgnoreCase) >= 0 ||
                normalizedPropertyPath.IndexOf("overlay", StringComparison.OrdinalIgnoreCase) >= 0)
            {
                return objectName.IndexOf("text", StringComparison.OrdinalIgnoreCase) >= 0 ||
                    objectName.IndexOf("button", StringComparison.OrdinalIgnoreCase) >= 0 ||
                    objectName.IndexOf("overlay", StringComparison.OrdinalIgnoreCase) >= 0;
            }

            if (normalizedPropertyPath.IndexOf("enemy", StringComparison.OrdinalIgnoreCase) >= 0)
            {
                return objectName.IndexOf("enemy", StringComparison.OrdinalIgnoreCase) >= 0;
            }

            if (normalizedPropertyPath.IndexOf("spawn", StringComparison.OrdinalIgnoreCase) >= 0)
            {
                return objectName.IndexOf("spawn", StringComparison.OrdinalIgnoreCase) >= 0;
            }

            return false;
        }

        private static Object ConvertGameObjectToExpectedReference(GameObject gameObject, string expectedType)
        {
            if (gameObject == null)
            {
                return null;
            }

            if (string.IsNullOrWhiteSpace(expectedType) || expectedType.IndexOf("GameObject", StringComparison.OrdinalIgnoreCase) >= 0)
            {
                return gameObject;
            }

            if (expectedType.IndexOf("Transform", StringComparison.OrdinalIgnoreCase) >= 0)
            {
                return gameObject.transform;
            }

            Type componentType = FindComponentType(expectedType);
            if (componentType != null)
            {
                return gameObject.GetComponent(componentType);
            }

            return gameObject;
        }

        private static bool TrySetObjectReference(SerializedProperty property, Object reference)
        {
            if (property == null || reference == null || property.propertyType != SerializedPropertyType.ObjectReference)
            {
                return false;
            }

            Object previous = property.objectReferenceValue;
            try
            {
                property.objectReferenceValue = reference;
                return property.objectReferenceValue == reference;
            }
            catch (Exception)
            {
                property.objectReferenceValue = previous;
                return false;
            }
        }

        private static string GetArrayElementObjectReferenceType(SerializedProperty arrayProperty)
        {
            if (arrayProperty == null || !arrayProperty.isArray || arrayProperty.propertyType == SerializedPropertyType.String)
            {
                return string.Empty;
            }

            int originalSize = arrayProperty.arraySize;
            if (arrayProperty.arraySize == 0)
            {
                arrayProperty.arraySize = 1;
            }

            SerializedProperty element = arrayProperty.GetArrayElementAtIndex(0);
            string typeName = element != null && element.propertyType == SerializedPropertyType.ObjectReference
                ? ExtractObjectReferenceTypeName(element.type)
                : string.Empty;
            arrayProperty.arraySize = originalSize;
            return typeName;
        }

        private static string ExtractObjectReferenceTypeName(string serializedType)
        {
            if (string.IsNullOrWhiteSpace(serializedType))
            {
                return string.Empty;
            }

            Match match = Regex.Match(serializedType, @"PPtr<\$?([^>]+)>");
            return match.Success ? match.Groups[1].Value.Trim() : serializedType.Trim();
        }

        private static Object CreateFallbackPrefabForProperty(string propertyPath, string expectedType)
        {
            string normalized = NormalizeSettingKey(propertyPath);
            if (normalized.IndexOf("prefab", StringComparison.OrdinalIgnoreCase) < 0 &&
                normalized.IndexOf("bullet", StringComparison.OrdinalIgnoreCase) < 0 &&
                normalized.IndexOf("projectile", StringComparison.OrdinalIgnoreCase) < 0 &&
                normalized.IndexOf("enemy", StringComparison.OrdinalIgnoreCase) < 0)
            {
                return null;
            }

            EnsureAssetFolder("Assets/Prefabs");
            bool bullet = normalized.IndexOf("bullet", StringComparison.OrdinalIgnoreCase) >= 0 ||
                normalized.IndexOf("projectile", StringComparison.OrdinalIgnoreCase) >= 0;
            bool enemy = normalized.IndexOf("enemy", StringComparison.OrdinalIgnoreCase) >= 0 && !bullet;
            string prefabPath = bullet ? "Assets/Prefabs/PlayerBullet.prefab" : enemy ? "Assets/Prefabs/ArenaEnemy.prefab" : "Assets/Prefabs/GeneratedPrefab.prefab";
            GameObject existing = AssetDatabase.LoadAssetAtPath<GameObject>(prefabPath);
            if (existing != null)
            {
                return existing;
            }

            GameObject root = new GameObject(bullet ? "PlayerBullet" : enemy ? "ArenaEnemy" : "GeneratedPrefab");
            try
            {
                SpriteRenderer renderer = root.AddComponent<SpriteRenderer>();
                renderer.sprite = EnsureDefaultSprite("circle");
                renderer.color = bullet ? new Color(1f, 0.25f, 0.28f, 1f) : new Color(0.95f, 0.22f, 0.18f, 1f);
                Rigidbody2D body = root.AddComponent<Rigidbody2D>();
                body.gravityScale = 0f;
                body.freezeRotation = true;
                body.collisionDetectionMode = CollisionDetectionMode2D.Continuous;
                CircleCollider2D collider = root.AddComponent<CircleCollider2D>();
                collider.isTrigger = bullet;
                collider.radius = bullet ? 0.24f : 0.45f;
                root.transform.localScale = bullet ? new Vector3(0.2f, 0.2f, 0.2f) : Vector3.one;

                Type behaviorType = FindComponentType(bullet ? "TopDownBullet" : "ArenaCombatEnemy");
                if (behaviorType != null && root.GetComponent(behaviorType) == null)
                {
                    root.AddComponent(behaviorType);
                }

                PrefabUtility.SaveAsPrefabAsset(root, prefabPath);
                AssetDatabase.ImportAsset(prefabPath, ImportAssetOptions.ForceUpdate);
                return AssetDatabase.LoadAssetAtPath<GameObject>(prefabPath);
            }
            finally
            {
                Object.DestroyImmediate(root);
            }
        }

        private static int RepairLookupStringRelationships(
            MonoBehaviour component,
            SceneRelationshipIndex index,
            AgentAction action,
            List<string> notes)
        {
            int repaired = 0;
            try
            {
                SerializedObject serializedObject = new SerializedObject(component);
                SerializedProperty property = serializedObject.GetIterator();
                bool enterChildren = true;
                while (property.NextVisible(enterChildren))
                {
                    enterChildren = false;
                    if (property.propertyType != SerializedPropertyType.String)
                    {
                        continue;
                    }

                    string value = property.stringValue;
                    if (string.IsNullOrWhiteSpace(value))
                    {
                        continue;
                    }

                    string key = NormalizeSettingKey(property.propertyPath);
                    if (IsSceneNamePrefixField(key) && !index.HasSceneObjectNamePrefix(value))
                    {
                        repaired += CreateSceneObjectsForPrefix(value, action, notes);
                    }
                    else if (IsSceneTagLookupField(key) && !index.HasSceneObjectWithTag(value))
                    {
                        if (TryAssignTagForLookup(value, notes))
                        {
                            repaired++;
                        }
                    }
                }
            }
            catch (Exception exception)
            {
                notes?.Add($"{component.GetType().Name} lookup repair skipped: {exception.Message}");
            }

            return repaired;
        }

        private static int CreateSceneObjectsForPrefix(string prefix, AgentAction action, List<string> notes)
        {
            if (string.IsNullOrWhiteSpace(prefix))
            {
                return 0;
            }

            bool spawnPrefix = prefix.IndexOf("spawn", StringComparison.OrdinalIgnoreCase) >= 0;
            int count = action != null && action.int_value > 0 ? Mathf.Clamp(action.int_value, 1, 12) : (spawnPrefix ? 3 : 1);
            string[] suffixes = { "North", "East", "West", "South", "A", "B", "C", "D", "E", "F", "G", "H" };
            Vector3 center = FindWorkflowCenter();
            float distance = spawnPrefix ? GetSpawnMarkerDistance() : 2f;
            Vector3[] directions =
            {
                Vector3.up,
                Vector3.right,
                Vector3.left,
                Vector3.down,
                (Vector3.up + Vector3.right).normalized,
                (Vector3.up + Vector3.left).normalized,
                (Vector3.down + Vector3.right).normalized,
                (Vector3.down + Vector3.left).normalized
            };

            int created = 0;
            for (int i = 0; i < count; i++)
            {
                string suffix = i < suffixes.Length ? suffixes[i] : (i + 1).ToString(CultureInfo.InvariantCulture);
                string objectName = prefix.EndsWith("_", StringComparison.Ordinal) || prefix.EndsWith("-", StringComparison.Ordinal)
                    ? prefix + suffix
                    : prefix + suffix;
                if (FindTarget(objectName) != null)
                {
                    continue;
                }

                GameObject marker = new GameObject(objectName);
                Undo.RegisterCreatedObjectUndo(marker, "Agentic Create Lookup Marker");
                Vector3 direction = directions[i % directions.Length];
                marker.transform.position = center + direction * distance;
                created++;
            }

            if (created > 0)
            {
                notes?.Add($"created {created} scene object(s) for prefix {prefix}");
                EditorSceneManager.MarkSceneDirty(SceneManager.GetActiveScene());
            }

            return created;
        }

        private static Vector3 FindWorkflowCenter()
        {
            GameObject player = FindTarget("Player") ?? FindTaggedObject("Player");
            return player == null ? Vector3.zero : player.transform.position;
        }

        private static float GetSpawnMarkerDistance()
        {
            Camera camera = FindWorkflowCamera(new AgentAction());
            if (camera != null && camera.orthographic)
            {
                return Mathf.Max(camera.orthographicSize * camera.aspect, camera.orthographicSize) + 2f;
            }

            return 10f;
        }

        private static GameObject FindTaggedObject(string tag)
        {
            if (string.IsNullOrWhiteSpace(tag))
            {
                return null;
            }

            try
            {
                return GameObject.FindGameObjectWithTag(tag);
            }
            catch (UnityException)
            {
                return null;
            }
        }

        private static bool TryAssignTagForLookup(string tag, List<string> notes)
        {
            if (string.IsNullOrWhiteSpace(tag))
            {
                return false;
            }

            string normalized = NormalizeSettingKey(tag);
            GameObject target = null;
            if (normalized.IndexOf("player", StringComparison.OrdinalIgnoreCase) >= 0)
            {
                target = FindTarget("Player");
            }
            else if (normalized.IndexOf("enemy", StringComparison.OrdinalIgnoreCase) >= 0)
            {
                target = FindTarget("Enemy") ?? FindTarget("ArenaEnemy");
            }

            if (target == null)
            {
                return false;
            }

            Undo.RecordObject(target, "Agentic Repair Tag Lookup");
            SetTagIfAvailable(target, tag);
            notes?.Add($"tagged {GetHierarchyPath(target)} as {tag}");
            return true;
        }

        private static string GetWorkflowIntent(AgentAction action)
        {
            if (action == null)
            {
                return string.Empty;
            }

            return JoinNonEmpty(
                " ",
                action.name,
                action.value,
                action.query,
                action.content,
                action.target,
                action.property_path,
                action.asset_path,
                action.path,
                action.color);
        }

        private static bool TryGetActionColor(AgentAction action, out Color color)
        {
            color = Color.clear;
            if (action == null)
            {
                return false;
            }

            string raw = FirstNonEmpty(action.color, action.value, action.secondary_color);
            if (CanParseColor(raw))
            {
                color = ParseColor(raw, Color.clear);
                return true;
            }

            return false;
        }

        private static string CombineWorkflowResults(string prefix, List<string> results)
        {
            List<string> filtered = new List<string>();
            if (results != null)
            {
                foreach (string result in results)
                {
                    if (!string.IsNullOrWhiteSpace(result))
                    {
                        filtered.Add(result.Trim());
                    }
                }
            }

            return filtered.Count == 0 ? prefix : $"{prefix}: {JoinLimited(filtered.ToArray(), 6)}";
        }

        private static string ApplyDefaultSprite(AgentAction action)
        {
            Sprite sprite = EnsureDefaultSprite(action.shape);
            if (sprite == null)
            {
                return "could not create default sprite asset";
            }

            List<GameObject> targets = ResolveSpriteTargets(action.target);
            if (targets.Count == 0)
            {
                return "apply_default_sprite found no matching targets";
            }

            Color? color = TryParseOptionalColor(action.color);
            int applied = 0;
            foreach (GameObject target in targets)
            {
                if (target == null || ShouldSkipDefaultSpriteTarget(target))
                {
                    continue;
                }

                SpriteRenderer renderer = target.GetComponent<SpriteRenderer>();
                if (renderer == null)
                {
                    renderer = Undo.AddComponent<SpriteRenderer>(target);
                }
                else
                {
                    Undo.RecordObject(renderer, "Agentic Apply Default Sprite");
                }

                renderer.sprite = sprite;
                if (color.HasValue)
                {
                    renderer.color = color.Value;
                }
                else
                {
                    renderer.color = InferDefaultSpriteColor(target, renderer.color);
                }

                applied++;
            }

            if (applied > 0)
            {
                EditorSceneManager.MarkSceneDirty(SceneManager.GetActiveScene());
            }

            return $"applied default {NormalizeSpriteShape(action.shape)} sprite to {applied} object(s)";
        }

        private static string CreateSpriteObject(AgentAction action)
        {
            Sprite sprite = string.IsNullOrWhiteSpace(action.asset_path)
                ? null
                : AssetDatabase.LoadAssetAtPath<Sprite>(NormalizeAssetPath(action.asset_path));

            GameObject gameObject = new GameObject(string.IsNullOrWhiteSpace(action.name) ? "Sprite Object" : action.name);
            Undo.RegisterCreatedObjectUndo(gameObject, "Agentic Create Sprite Object");
            ApplyParent(gameObject, action.parent);
            ApplyTransform(gameObject.transform, action);
            SpriteRenderer renderer = Undo.AddComponent<SpriteRenderer>(gameObject);
            renderer.sprite = sprite;
            renderer.sortingOrder = action.sorting_order;
            string completion = CompleteObjectForGoal(gameObject, action);
            Selection.activeGameObject = gameObject;
            EditorSceneManager.MarkSceneDirty(SceneManager.GetActiveScene());
            string result = sprite == null
                ? $"created SpriteRenderer object {GetHierarchyPath(gameObject)} without a sprite"
                : $"created SpriteRenderer object {GetHierarchyPath(gameObject)}";
            return AppendDetail(result, completion);
        }

        private static string CreatePrimitive(AgentAction action)
        {
            PrimitiveType primitiveType = ParseEnum(action.primitive_type, PrimitiveType.Cube);
            GameObject gameObject = GameObject.CreatePrimitive(primitiveType);
            gameObject.name = string.IsNullOrWhiteSpace(action.name) ? primitiveType.ToString() : action.name;
            Undo.RegisterCreatedObjectUndo(gameObject, "Agentic Create Primitive");
            ApplyParent(gameObject, action.parent);
            ApplyTransform(gameObject.transform, action);
            string completion = CompleteObjectForGoal(gameObject, action);
            Selection.activeGameObject = gameObject;
            EditorSceneManager.MarkSceneDirty(SceneManager.GetActiveScene());
            return AppendDetail($"created {primitiveType} primitive {GetHierarchyPath(gameObject)}", completion);
        }

        private static string CreateCamera(AgentAction action)
        {
            GameObject gameObject = new GameObject(string.IsNullOrWhiteSpace(action.name) ? "Camera" : action.name);
            Undo.RegisterCreatedObjectUndo(gameObject, "Agentic Create Camera");
            Camera camera = Undo.AddComponent<Camera>(gameObject);
            if (IsMainCameraName(gameObject.name))
            {
                SetTagIfAvailable(gameObject, "MainCamera");
                if (gameObject.GetComponent<AudioListener>() == null)
                {
                    Undo.AddComponent<AudioListener>(gameObject);
                }
            }

            camera.orthographic = action.orthographic;
            if (action.field_of_view > 0f)
            {
                camera.fieldOfView = action.field_of_view;
            }

            if (action.orthographic_size > 0f)
            {
                camera.orthographicSize = action.orthographic_size;
            }

            ApplyParent(gameObject, action.parent);
            ApplyTransform(gameObject.transform, action);
            string completion = CompleteObjectForGoal(gameObject, action);
            Selection.activeGameObject = gameObject;
            EditorSceneManager.MarkSceneDirty(SceneManager.GetActiveScene());
            return AppendDetail($"created camera {GetHierarchyPath(gameObject)}", completion);
        }

        private static string EnsureCamera(AgentAction action)
        {
            string targetName = string.IsNullOrWhiteSpace(action.target)
                ? (string.IsNullOrWhiteSpace(action.name) ? "Main Camera" : action.name.Trim())
                : action.target.Trim();
            GameObject gameObject = FindTarget(targetName);
            bool created = false;
            if (gameObject == null)
            {
                gameObject = new GameObject(targetName);
                Undo.RegisterCreatedObjectUndo(gameObject, "Agentic Ensure Camera");
                created = true;
            }

            Camera camera = gameObject.GetComponent<Camera>();
            if (camera == null)
            {
                camera = Undo.AddComponent<Camera>(gameObject);
            }
            else
            {
                Undo.RecordObject(camera, "Agentic Configure Camera");
            }

            if (IsMainCameraName(gameObject.name))
            {
                SetTagIfAvailable(gameObject, "MainCamera");
                if (gameObject.GetComponent<AudioListener>() == null)
                {
                    Undo.AddComponent<AudioListener>(gameObject);
                }
            }

            camera.orthographic = action.orthographic;
            if (action.field_of_view > 0f)
            {
                camera.fieldOfView = action.field_of_view;
            }

            if (action.orthographic_size > 0f)
            {
                camera.orthographicSize = action.orthographic_size;
            }

            ApplyParent(gameObject, action.parent);
            ApplyTransform(gameObject.transform, action);
            Selection.activeGameObject = gameObject;
            EditorSceneManager.MarkSceneDirty(SceneManager.GetActiveScene());
            return created
                ? $"created camera {GetHierarchyPath(gameObject)}"
                : $"ensured camera components on {GetHierarchyPath(gameObject)}";
        }

        private static bool ShouldPromoteGameObjectToCamera(AgentAction action)
        {
            return ShouldNameImplyCamera(action?.name) ||
                string.Equals(action?.role, "camera", StringComparison.OrdinalIgnoreCase) ||
                string.Equals(action?.role, "main_camera", StringComparison.OrdinalIgnoreCase);
        }

        private static bool IsMainCameraName(string name)
        {
            return string.Equals(name?.Trim(), "Main Camera", StringComparison.OrdinalIgnoreCase);
        }

        private static bool ShouldPromoteGameObjectToLight(AgentAction action)
        {
            return ShouldNameImplyLight(action?.name) ||
                string.Equals(action?.role, "light", StringComparison.OrdinalIgnoreCase);
        }

        private static bool ShouldNameImplyCamera(string name)
        {
            name = name?.Trim();
            return string.Equals(name, "Camera", StringComparison.OrdinalIgnoreCase) ||
                IsMainCameraName(name) ||
                (!string.IsNullOrWhiteSpace(name) && name.EndsWith(" Camera", StringComparison.OrdinalIgnoreCase));
        }

        private static bool ShouldNameImplyLight(string name)
        {
            name = name?.Trim();
            return string.Equals(name, "Light", StringComparison.OrdinalIgnoreCase) ||
                string.Equals(name, "Point Light", StringComparison.OrdinalIgnoreCase) ||
                string.Equals(name, "Directional Light", StringComparison.OrdinalIgnoreCase) ||
                string.Equals(name, "Spot Light", StringComparison.OrdinalIgnoreCase) ||
                (!string.IsNullOrWhiteSpace(name) && name.EndsWith(" Light", StringComparison.OrdinalIgnoreCase));
        }

        private static void SetTagIfAvailable(GameObject gameObject, string tag)
        {
            if (gameObject == null || string.IsNullOrWhiteSpace(tag))
            {
                return;
            }

            try
            {
                gameObject.tag = tag;
            }
            catch (UnityException)
            {
                // The tag may not exist in unusual project settings.
            }
        }

        private static string CompleteObjectForGoal(GameObject gameObject, AgentAction action)
        {
            if (gameObject == null || action == null)
            {
                return string.Empty;
            }

            List<string> added = new List<string>();
            List<string> skipped = new List<string>();

            EnsureRoleComponents(gameObject, action, added, skipped);
            EnsureComponentByName(gameObject, action.component, added, skipped);
            if (action.components != null)
            {
                foreach (string component in action.components)
                {
                    EnsureComponentByName(gameObject, component, added, skipped);
                }
            }

            StringBuilder builder = new StringBuilder();
            if (added.Count > 0)
            {
                builder.Append("added ");
                builder.Append(string.Join(", ", added.ToArray()));
            }

            if (skipped.Count > 0)
            {
                if (builder.Length > 0)
                {
                    builder.Append("; ");
                }

                builder.Append("could not add ");
                builder.Append(string.Join(", ", skipped.ToArray()));
            }

            return builder.ToString();
        }

        private static void EnsureRoleComponents(GameObject gameObject, AgentAction action, List<string> added, List<string> skipped)
        {
            string role = (action.role ?? string.Empty).Trim().ToLowerInvariant();
            switch (role)
            {
                case "main_camera":
                case "main camera":
                    SetTagIfAvailable(gameObject, "MainCamera");
                    EnsureComponentByName(gameObject, "Camera", added, skipped);
                    EnsureComponentByName(gameObject, "AudioListener", added, skipped);
                    break;

                case "camera":
                    EnsureComponentByName(gameObject, "Camera", added, skipped);
                    break;

                case "light":
                    EnsureComponentByName(gameObject, "Light", added, skipped);
                    break;

                case "audio":
                case "audio_source":
                case "audio source":
                    EnsureComponentByName(gameObject, "AudioSource", added, skipped);
                    break;

                case "sprite":
                case "sprite2d":
                case "visible2d":
                case "visible_2d":
                    EnsureComponentByName(gameObject, "SpriteRenderer", added, skipped);
                    break;

                case "player2d":
                case "player_2d":
                case "enemy2d":
                case "enemy_2d":
                case "projectile2d":
                case "projectile_2d":
                case "pickup2d":
                case "pickup_2d":
                    EnsureComponentByName(gameObject, "SpriteRenderer", added, skipped);
                    EnsureComponentByName(gameObject, "Rigidbody2D", added, skipped);
                    EnsureComponentByName(gameObject, "CircleCollider2D", added, skipped);
                    Configure2DPhysicsDefaults(gameObject, role);
                    break;

                case "physics2d":
                case "physics_2d":
                case "dynamic2d":
                case "dynamic_2d":
                    EnsureComponentByName(gameObject, "Rigidbody2D", added, skipped);
                    EnsureComponentByName(gameObject, "BoxCollider2D", added, skipped);
                    Configure2DPhysicsDefaults(gameObject, role);
                    break;

                case "trigger2d":
                case "trigger_2d":
                    EnsureComponentByName(gameObject, "BoxCollider2D", added, skipped);
                    Collider2D trigger = gameObject.GetComponent<Collider2D>();
                    if (trigger != null)
                    {
                        Undo.RecordObject(trigger, "Agentic Configure Trigger");
                        trigger.isTrigger = true;
                    }
                    break;

                case "canvas":
                case "ui_canvas":
                case "ui canvas":
                    EnsureComponentByName(gameObject, "Canvas", added, skipped);
                    EnsureComponentByName(gameObject, "CanvasScaler", added, skipped);
                    EnsureComponentByName(gameObject, "GraphicRaycaster", added, skipped);
                    break;
            }

            if (IsMainCameraName(gameObject.name))
            {
                SetTagIfAvailable(gameObject, "MainCamera");
                EnsureComponentByName(gameObject, "Camera", added, skipped);
                EnsureComponentByName(gameObject, "AudioListener", added, skipped);
            }
        }

        private static void Configure2DPhysicsDefaults(GameObject gameObject, string role)
        {
            Rigidbody2D body = gameObject.GetComponent<Rigidbody2D>();
            if (body == null)
            {
                return;
            }

            Undo.RecordObject(body, "Agentic Configure Rigidbody2D");
            body.gravityScale = 0f;
            body.freezeRotation = role.IndexOf("player", StringComparison.OrdinalIgnoreCase) >= 0 ||
                role.IndexOf("enemy", StringComparison.OrdinalIgnoreCase) >= 0;
            body.collisionDetectionMode = CollisionDetectionMode2D.Continuous;
        }

        private static void EnsureComponentByName(GameObject gameObject, string componentName, List<string> added, List<string> skipped)
        {
            if (gameObject == null || string.IsNullOrWhiteSpace(componentName))
            {
                return;
            }

            string normalizedName = NormalizeComponentAlias(componentName);
            Type componentType = FindComponentType(normalizedName);
            if (componentType == null)
            {
                if (skipped != null)
                {
                    skipped.Add(componentName.Trim());
                }

                return;
            }

            if (gameObject.GetComponent(componentType) != null)
            {
                return;
            }

            Component component = Undo.AddComponent(gameObject, componentType);
            if (component != null && added != null)
            {
                added.Add(componentType.Name);
            }
        }

        private static string NormalizeComponentAlias(string componentName)
        {
            string normalized = componentName.Trim().Replace(" ", string.Empty);
            switch (normalized.ToLowerInvariant())
            {
                case "collider2d":
                    return "BoxCollider2D";
                case "collider":
                    return "BoxCollider";
                case "renderer2d":
                case "spriterenderer2d":
                    return "SpriteRenderer";
                case "rigidbody2dcomponent":
                    return "Rigidbody2D";
                case "rigidbodycomponent":
                    return "Rigidbody";
                default:
                    return normalized;
            }
        }

        private static string AppendDetail(string summary, string detail)
        {
            return string.IsNullOrWhiteSpace(detail) ? summary : $"{summary}; {detail}";
        }

        private static string CreateLight(AgentAction action)
        {
            GameObject gameObject = new GameObject(string.IsNullOrWhiteSpace(action.name) ? "Light" : action.name);
            Undo.RegisterCreatedObjectUndo(gameObject, "Agentic Create Light");
            Light light = Undo.AddComponent<Light>(gameObject);
            light.type = ParseEnum(action.light_type, LightType.Point);
            if (action.intensity > 0f)
            {
                light.intensity = action.intensity;
            }

            if (action.range > 0f)
            {
                light.range = action.range;
            }

            light.color = ParseColor(action.color, light.color);
            ApplyParent(gameObject, action.parent);
            ApplyTransform(gameObject.transform, action);
            string completion = CompleteObjectForGoal(gameObject, action);
            Selection.activeGameObject = gameObject;
            EditorSceneManager.MarkSceneDirty(SceneManager.GetActiveScene());
            return AppendDetail($"created {light.type} light {GetHierarchyPath(gameObject)}", completion);
        }

        private static string CreateTilemap(AgentAction action)
        {
            GameObject gridObject = new GameObject(string.IsNullOrWhiteSpace(action.name) ? "Grid" : action.name);
            Undo.RegisterCreatedObjectUndo(gridObject, "Agentic Create Tilemap");
            Undo.AddComponent<Grid>(gridObject);
            ApplyParent(gridObject, action.parent);
            ApplyTransform(gridObject.transform, action);

            GameObject tilemapObject = new GameObject("Tilemap");
            Undo.RegisterCreatedObjectUndo(tilemapObject, "Agentic Create Tilemap Child");
            tilemapObject.transform.SetParent(gridObject.transform);
            Undo.AddComponent<Tilemap>(tilemapObject);
            Undo.AddComponent<TilemapRenderer>(tilemapObject);

            Selection.activeGameObject = tilemapObject;
            EditorSceneManager.MarkSceneDirty(SceneManager.GetActiveScene());
            return $"created tilemap {GetHierarchyPath(tilemapObject)}";
        }

        private static string CreateSpriteAsset(AgentAction action)
        {
            string path = EnsureExtension(NormalizeAssetPath(action.path), ".png");
            if (string.IsNullOrWhiteSpace(path))
            {
                path = $"Assets/AgenticGamedev/Generated/Sprites/{SanitizeFileName(action.name)}.png";
            }

            EnsureAssetFolder(Path.GetDirectoryName(path)?.Replace("\\", "/"));
            int width = Mathf.Clamp(action.width <= 0 ? 64 : action.width, 1, 2048);
            int height = Mathf.Clamp(action.height <= 0 ? width : action.height, 1, 2048);
            Color primary = ParseColor(action.color, new Color(0.25f, 0.58f, 0.95f, 1f));
            Color secondary = ParseColor(action.secondary_color, Color.clear);
            Texture2D texture = new Texture2D(width, height, TextureFormat.RGBA32, false);

            for (int y = 0; y < height; y++)
            {
                for (int x = 0; x < width; x++)
                {
                    texture.SetPixel(x, y, EvaluateSpritePixel(action.shape, x, y, width, height, primary, secondary));
                }
            }

            texture.Apply();
            string absolutePath = Path.Combine(Path.GetDirectoryName(Application.dataPath) ?? Directory.GetCurrentDirectory(), path);
            File.WriteAllBytes(absolutePath, texture.EncodeToPNG());
            Object.DestroyImmediate(texture);
            AssetDatabase.ImportAsset(path, ImportAssetOptions.ForceUpdate);

            TextureImporter importer = AssetImporter.GetAtPath(path) as TextureImporter;
            if (importer != null)
            {
                importer.textureType = TextureImporterType.Sprite;
                importer.spritePixelsPerUnit = action.pixels_per_unit > 0f ? action.pixels_per_unit : 32f;
                importer.filterMode = FilterMode.Point;
                importer.mipmapEnabled = false;
                importer.SaveAndReimport();
            }

            return $"created sprite asset {path}";
        }

        private static string CreateUnityAsset(AgentAction action)
        {
            string assetType = (action.asset_type ?? string.Empty).Trim().ToLowerInvariant();
            Object asset;
            string extension;

            switch (assetType)
            {
                case "material":
                    Shader shader = Shader.Find("Universal Render Pipeline/Lit") ?? Shader.Find("Standard") ?? Shader.Find("Sprites/Default");
                    Material material = new Material(shader);
                    material.color = ParseColor(action.color, material.color);
                    asset = material;
                    extension = ".mat";
                    break;

                case "physic_material":
                case "physics_material":
                    asset = new PhysicsMaterial(string.IsNullOrWhiteSpace(action.name) ? "Physics Material" : action.name);
                    extension = ".physicsMaterial";
                    break;

                case "physics_material_2d":
                    asset = new PhysicsMaterial2D(string.IsNullOrWhiteSpace(action.name) ? "Physics Material 2D" : action.name);
                    extension = ".physicsMaterial2D";
                    break;

                case "animation_clip":
                    asset = new AnimationClip();
                    extension = ".anim";
                    break;

                case "render_texture":
                    int width = Mathf.Clamp(action.width <= 0 ? 256 : action.width, 1, 8192);
                    int height = Mathf.Clamp(action.height <= 0 ? width : action.height, 1, 8192);
                    int depth = Mathf.Clamp(action.depth < 0 ? 0 : action.depth, 0, 32);
                    asset = new RenderTexture(width, height, depth);
                    extension = ".renderTexture";
                    break;

                case "tile":
                    Tile tile = ScriptableObject.CreateInstance<Tile>();
                    tile.color = ParseColor(action.color, Color.white);
                    if (!string.IsNullOrWhiteSpace(action.asset_path))
                    {
                        tile.sprite = AssetDatabase.LoadAssetAtPath<Sprite>(NormalizeAssetPath(action.asset_path));
                    }

                    asset = tile;
                    extension = ".asset";
                    break;

                case "scriptable_object":
                    Type scriptableType = FindType(action.scriptable_type);
                    if (scriptableType == null || !typeof(ScriptableObject).IsAssignableFrom(scriptableType))
                    {
                        return $"scriptable object type not found: {action.scriptable_type}";
                    }

                    asset = ScriptableObject.CreateInstance(scriptableType);
                    extension = ".asset";
                    break;

                default:
                    return $"unknown Unity asset type: {action.asset_type}";
            }

            string defaultName = string.IsNullOrWhiteSpace(action.name) ? asset.GetType().Name : SanitizeFileName(action.name);
            string path = string.IsNullOrWhiteSpace(action.path)
                ? $"Assets/AgenticGamedev/Generated/Assets/{defaultName}{extension}"
                : EnsureExtension(NormalizeAssetPath(action.path), extension);

            EnsureAssetFolder(Path.GetDirectoryName(path)?.Replace("\\", "/"));
            path = AssetDatabase.GenerateUniqueAssetPath(path);
            asset.name = Path.GetFileNameWithoutExtension(path);
            AssetDatabase.CreateAsset(asset, path);
            AssetDatabase.ImportAsset(path, ImportAssetOptions.ForceUpdate);
            Selection.activeObject = asset;
            return $"created {asset.GetType().Name} asset {path}";
        }

        private static string DeleteGameObject(AgentAction action)
        {
            GameObject target = FindSceneTargetForEdit(action);
            if (target == null)
            {
                return "delete_game_object target not found";
            }

            string path = GetHierarchyPath(target);
            Undo.DestroyObjectImmediate(target);
            EditorSceneManager.MarkSceneDirty(SceneManager.GetActiveScene());
            return $"deleted {path}";
        }

        private static string ClearScene()
        {
            GameObject[] roots = SceneManager.GetActiveScene().GetRootGameObjects();
            int deleted = 0;
            foreach (GameObject root in roots)
            {
                if (root == null)
                {
                    continue;
                }

                Undo.DestroyObjectImmediate(root);
                deleted++;
            }

            EditorSceneManager.MarkSceneDirty(SceneManager.GetActiveScene());
            return $"cleared {deleted} root object(s) from the scene";
        }

        private static string SetObjectProperty(AgentAction action)
        {
            string property = NormalizeSettingKey(action.property_path);
            if (string.IsNullOrWhiteSpace(property))
            {
                return "set_object_property missing property_path";
            }

            GameObject target = FindSceneTargetForEdit(action);
            if (target == null)
            {
                string prefabResult;
                if (TryEditPrefabGameObject(action, "set_object_property", prefabTarget =>
                    ApplyObjectProperty(prefabTarget, action, property), out prefabResult))
                {
                    return prefabResult;
                }

                return "set_object_property target not found";
            }

            Undo.RecordObject(target, "Agentic Set Object Property");
            string error = ApplyObjectProperty(target, action, property);
            if (!string.IsNullOrWhiteSpace(error))
            {
                return error;
            }

            EditorSceneManager.MarkSceneDirty(SceneManager.GetActiveScene());
            return $"set {GetHierarchyPath(target)} {action.property_path}";
        }

        private static string ApplyObjectProperty(GameObject target, AgentAction action, string property)
        {
            switch (property)
            {
                case "name":
                    if (string.IsNullOrWhiteSpace(action.value))
                    {
                        return "set_object_property name missing value";
                    }

                    target.name = action.value.Trim();
                    break;

                case "tag":
                    if (string.IsNullOrWhiteSpace(action.value))
                    {
                        return "set_object_property tag missing value";
                    }

                    target.tag = action.value.Trim();
                    break;

                case "layer":
                    target.layer = ParseLayerValue(action);
                    break;

                case "active":
                case "activeself":
                    target.SetActive(ParseBoolValue(action));
                    break;

                case "static":
                case "isstatic":
                    target.isStatic = ParseBoolValue(action);
                    break;

                default:
                    return $"unsupported object property: {action.property_path}";
            }

            return string.Empty;
        }

        private static int ParseLayerValue(AgentAction action)
        {
            if (!string.IsNullOrWhiteSpace(action.value))
            {
                int namedLayer = LayerMask.NameToLayer(action.value.Trim());
                if (namedLayer >= 0)
                {
                    return namedLayer;
                }

                int parsed;
                if (int.TryParse(action.value.Trim(), NumberStyles.Integer, CultureInfo.InvariantCulture, out parsed))
                {
                    return Mathf.Clamp(parsed, 0, 31);
                }
            }

            return Mathf.Clamp(action.int_value, 0, 31);
        }

        private static bool ParseBoolValue(AgentAction action)
        {
            if (!string.IsNullOrWhiteSpace(action.value))
            {
                string normalized = NormalizeSettingKey(action.value);
                if (normalized == "true" || normalized == "yes" || normalized == "on" || normalized == "1")
                {
                    return true;
                }

                if (normalized == "false" || normalized == "no" || normalized == "off" || normalized == "0")
                {
                    return false;
                }
            }

            return action.bool_value;
        }

        private static string SetTransform(AgentAction action)
        {
            GameObject target = FindSceneTargetForEdit(action);
            if (target == null)
            {
                string prefabResult;
                if (TryEditPrefabGameObject(action, "set_transform", prefabTarget =>
                {
                    ApplyTransform(prefabTarget.transform, action);
                    return $"updated transform for prefab {GetPrefabEditSummary(prefabTarget)}";
                }, out prefabResult))
                {
                    return prefabResult;
                }

                return "set_transform target not found";
            }

            Undo.RecordObject(target.transform, "Agentic Set Transform");
            ApplyTransform(target.transform, action);
            EditorSceneManager.MarkSceneDirty(SceneManager.GetActiveScene());
            return $"updated transform for {GetHierarchyPath(target)}";
        }

        private static string SetComponentProperty(AgentAction action)
        {
            GameObject target = FindSceneTargetForEdit(action);
            if (IsCoveredEditorApiComponentName(action.component))
            {
                return $"Tool blocked: {action.component} is an editor API, not a GameObject component. Use create_scene/open_scene/save_scene or set_editor_build_scenes directly.";
            }

            Type componentType = FindComponentType(action.component);
            if (componentType == null)
            {
                return $"component type not found: {action.component}";
            }

            if (string.IsNullOrWhiteSpace(action.property_path))
            {
                return "set_component_property missing property_path";
            }

            if (target == null)
            {
                string prefabResult;
                if (TryEditPrefabGameObject(action, "set_component_property", prefabTarget =>
                    ApplyComponentProperty(prefabTarget, action, componentType, prefabTarget: true), out prefabResult))
                {
                    return prefabResult;
                }

                return "set_component_property target not found";
            }

            return ApplyComponentProperty(target, action, componentType, prefabTarget: false);
        }

        private static bool IsCoveredEditorApiComponentName(string component)
        {
            if (string.IsNullOrWhiteSpace(component))
            {
                return false;
            }

            return component.IndexOf("EditorSceneManager", StringComparison.OrdinalIgnoreCase) >= 0 ||
                component.IndexOf("EditorBuildSettings", StringComparison.OrdinalIgnoreCase) >= 0 ||
                component.IndexOf("EditorBuildSettingsScene", StringComparison.OrdinalIgnoreCase) >= 0;
        }

        private static string ApplyComponentProperty(GameObject target, AgentAction action, Type componentType, bool prefabTarget)
        {
            Component component = target.GetComponent(componentType);
            if (component == null)
            {
                return $"component not found on {target.name}: {action.component}";
            }

            if (TryApplySemanticComponentProperty(component, action, prefabTarget, out string semanticResult))
            {
                return semanticResult;
            }

            SerializedObject serializedObject = new SerializedObject(component);
            SerializedProperty property = FindSerializedPropertyForEdit(serializedObject, action.property_path, out string normalizedPropertyPath);
            if (property == null)
            {
                if (TryApplyPublicComponentMember(component, action, prefabTarget, out string publicMemberResult))
                {
                    return publicMemberResult;
                }

                return $"serialized property not found: {action.property_path}";
            }

            if (!prefabTarget)
            {
                Undo.RecordObject(component, "Agentic Set Component Property");
            }

            AgentAction valueAction = prefabTarget ? CloneActionWithoutPrefabAssetReference(action) : action;
            string valueValidation = ValidateSerializedValueInput(property, valueAction);
            if (!string.IsNullOrWhiteSpace(valueValidation))
            {
                return valueValidation;
            }

            if (!ApplySerializedValue(property, valueAction))
            {
                return $"unsupported serialized property type: {property.propertyType}";
            }

            serializedObject.ApplyModifiedProperties();
            if (prefabTarget)
            {
                EditorUtility.SetDirty(component);
                return $"set {componentType.Name}.{normalizedPropertyPath} on prefab {GetPrefabEditSummary(target)}";
            }

            EditorSceneManager.MarkSceneDirty(SceneManager.GetActiveScene());
            return $"set {componentType.Name}.{normalizedPropertyPath} on {GetHierarchyPath(target)}";
        }

        private static bool TryApplySemanticComponentProperty(
            Component component,
            AgentAction action,
            bool prefabTarget,
            out string result)
        {
            result = string.Empty;
            if (component == null || action == null)
            {
                return false;
            }

            string propertyKey = NormalizeSettingKey(action.property_path);
            if (component is Camera camera)
            {
                if (propertyKey == "backgroundcolor" || propertyKey == "mbackgroundcolor" || propertyKey == "background")
                {
                    Color color = TryGetActionColor(action, out Color parsed) ? parsed : Color.black;
                    if (!prefabTarget)
                    {
                        Undo.RecordObject(camera, "Agentic Set Camera Background");
                    }

                    camera.clearFlags = CameraClearFlags.SolidColor;
                    camera.backgroundColor = color;
                    CompleteComponentMutation(camera, prefabTarget);
                    result = $"set Camera.backgroundColor to {FormatColor(color)} on {GetHierarchyPath(camera.gameObject)}";
                    return true;
                }

                if (propertyKey == "clearflags" || propertyKey == "mclearflags")
                {
                    CameraClearFlags clearFlags = ParseCameraClearFlags(action);
                    if (!prefabTarget)
                    {
                        Undo.RecordObject(camera, "Agentic Set Camera Clear Flags");
                    }

                    camera.clearFlags = clearFlags;
                    CompleteComponentMutation(camera, prefabTarget);
                    result = $"set Camera.clearFlags to {clearFlags} on {GetHierarchyPath(camera.gameObject)}";
                    return true;
                }
            }

            if (IsUniversalAdditionalCameraData(component) &&
                (propertyKey == "renderpostprocessing" || propertyKey == "mrenderpostprocessing"))
            {
                if (!prefabTarget)
                {
                    Undo.RecordObject(component, "Agentic Set Camera Post Processing");
                }

                SerializedObject serializedObject = new SerializedObject(component);
                SerializedProperty property = serializedObject.FindProperty("m_RenderPostProcessing");
                if (property != null && property.propertyType == SerializedPropertyType.Boolean)
                {
                    property.boolValue = ParseBool(action.value, action.bool_value || string.IsNullOrWhiteSpace(action.value));
                    serializedObject.ApplyModifiedProperties();
                    CompleteComponentMutation(component, prefabTarget);
                    result = $"set {component.GetType().Name}.renderPostProcessing on {GetHierarchyPath(component.gameObject)}";
                    return true;
                }
            }

            return false;
        }

        private static bool TryApplyPublicComponentMember(
            Component component,
            AgentAction action,
            bool prefabTarget,
            out string result)
        {
            result = string.Empty;
            if (component == null || action == null || string.IsNullOrWhiteSpace(action.property_path))
            {
                return false;
            }

            string propertyKey = NormalizeSettingKey(action.property_path);
            Type type = component.GetType();
            foreach (PropertyInfo property in type.GetProperties(BindingFlags.Instance | BindingFlags.Public))
            {
                if (!property.CanWrite || NormalizeSettingKey(property.Name) != propertyKey)
                {
                    continue;
                }

                if (!TryConvertActionValue(action, property.PropertyType, out object converted))
                {
                    continue;
                }

                if (!prefabTarget)
                {
                    Undo.RecordObject(component, "Agentic Set Public Component Property");
                }

                property.SetValue(component, converted, null);
                CompleteComponentMutation(component, prefabTarget);
                result = $"set {type.Name}.{property.Name} on {GetHierarchyPath(component.gameObject)}";
                return true;
            }

            foreach (FieldInfo field in type.GetFields(BindingFlags.Instance | BindingFlags.Public))
            {
                if (field.IsInitOnly || NormalizeSettingKey(field.Name) != propertyKey)
                {
                    continue;
                }

                if (!TryConvertActionValue(action, field.FieldType, out object converted))
                {
                    continue;
                }

                if (!prefabTarget)
                {
                    Undo.RecordObject(component, "Agentic Set Public Component Field");
                }

                field.SetValue(component, converted);
                CompleteComponentMutation(component, prefabTarget);
                result = $"set {type.Name}.{field.Name} on {GetHierarchyPath(component.gameObject)}";
                return true;
            }

            return false;
        }

        private static bool TryConvertActionValue(AgentAction action, Type targetType, out object converted)
        {
            converted = null;
            if (targetType == typeof(string))
            {
                converted = action.value ?? string.Empty;
                return true;
            }

            if (targetType == typeof(bool))
            {
                converted = ParseBool(action.value, action.bool_value || string.IsNullOrWhiteSpace(action.value));
                return true;
            }

            if (targetType == typeof(int))
            {
                converted = ParseInt(action.value, action.int_value);
                return true;
            }

            if (targetType == typeof(float))
            {
                converted = ParseFloat(action.value, action.float_value);
                return true;
            }

            if (targetType == typeof(Color))
            {
                converted = TryGetActionColor(action, out Color color) ? color : Color.black;
                return true;
            }

            if (targetType == typeof(Vector2))
            {
                converted = action.use_scale ? action.scale.ToVector2() : action.position.ToVector2();
                return true;
            }

            if (targetType == typeof(Vector3))
            {
                converted = action.use_scale ? action.scale.ToVector3() : action.position.ToVector3();
                return true;
            }

            if (targetType.IsEnum)
            {
                string value = FirstNonEmpty(action.value, action.name);
                if (!string.IsNullOrWhiteSpace(value) && Enum.TryParse(targetType, value.Trim(), true, out object parsed))
                {
                    converted = parsed;
                    return true;
                }

                converted = Enum.ToObject(targetType, action.int_value);
                return true;
            }

            return false;
        }

        private static CameraClearFlags ParseCameraClearFlags(AgentAction action)
        {
            string value = NormalizeSettingKey(FirstNonEmpty(action.value, action.name, action.property_path));
            if (value.IndexOf("solid", StringComparison.OrdinalIgnoreCase) >= 0 ||
                value.IndexOf("color", StringComparison.OrdinalIgnoreCase) >= 0 ||
                value.IndexOf("black", StringComparison.OrdinalIgnoreCase) >= 0)
            {
                return CameraClearFlags.SolidColor;
            }

            if (value.IndexOf("depth", StringComparison.OrdinalIgnoreCase) >= 0)
            {
                return CameraClearFlags.Depth;
            }

            if (value.IndexOf("nothing", StringComparison.OrdinalIgnoreCase) >= 0 ||
                value.IndexOf("dontclear", StringComparison.OrdinalIgnoreCase) >= 0)
            {
                return CameraClearFlags.Nothing;
            }

            if (value.IndexOf("skybox", StringComparison.OrdinalIgnoreCase) >= 0)
            {
                return CameraClearFlags.Skybox;
            }

            return Enum.IsDefined(typeof(CameraClearFlags), action.int_value)
                ? (CameraClearFlags)action.int_value
                : CameraClearFlags.SolidColor;
        }

        private static bool IsUniversalAdditionalCameraData(Component component)
        {
            if (component == null)
            {
                return false;
            }

            Type type = component.GetType();
            return string.Equals(type.Name, "UniversalAdditionalCameraData", StringComparison.Ordinal) ||
                string.Equals(type.FullName, "UnityEngine.Rendering.Universal.UniversalAdditionalCameraData", StringComparison.Ordinal);
        }

        private static void CompleteComponentMutation(Component component, bool prefabTarget)
        {
            if (component == null)
            {
                return;
            }

            EditorUtility.SetDirty(component);
            if (!prefabTarget)
            {
                EditorSceneManager.MarkSceneDirty(SceneManager.GetActiveScene());
            }
        }

        private static AgentAction CloneActionWithoutPrefabAssetReference(AgentAction action)
        {
            AgentAction clone = CloneAction(action);
            if (clone != null &&
                string.IsNullOrWhiteSpace(clone.reference_asset_path) &&
                ContainsPrefabPath(clone.asset_path))
            {
                clone.asset_path = string.Empty;
            }

            return clone ?? action;
        }

        private static AgentAction CloneAction(AgentAction action)
        {
            if (action == null)
            {
                return null;
            }

            return new AgentAction
            {
                type = action.type,
                name = action.name,
                query = action.query,
                target = action.target,
                parent = action.parent,
                path = action.path,
                asset_path = action.asset_path,
                reference_asset_path = action.reference_asset_path,
                reference_target = action.reference_target,
                asset_type = action.asset_type,
                scriptable_type = action.scriptable_type,
                component = action.component,
                components = action.components,
                role = action.role,
                content = action.content,
                primitive_type = action.primitive_type,
                light_type = action.light_type,
                menu_item = action.menu_item,
                package_id = action.package_id,
                property_path = action.property_path,
                class_name = action.class_name,
                method_name = action.method_name,
                value = action.value,
                value_type = action.value_type,
                color = action.color,
                secondary_color = action.secondary_color,
                shape = action.shape,
                paths = action.paths,
                enabled = action.enabled,
                use_position = action.use_position,
                use_rotation = action.use_rotation,
                use_scale = action.use_scale,
                orthographic = action.orthographic,
                open_scene = action.open_scene,
                position = action.position,
                rotation = action.rotation,
                scale = action.scale,
                sorting_order = action.sorting_order,
                width = action.width,
                height = action.height,
                depth = action.depth,
                int_value = action.int_value,
                float_value = action.float_value,
                pixels_per_unit = action.pixels_per_unit,
                field_of_view = action.field_of_view,
                orthographic_size = action.orthographic_size,
                intensity = action.intensity,
                range = action.range,
                bool_value = action.bool_value
            };
        }

        private static SerializedProperty FindSerializedPropertyForEdit(SerializedObject serializedObject, string propertyPath, out string normalizedPropertyPath)
        {
            normalizedPropertyPath = propertyPath ?? string.Empty;
            if (serializedObject == null || string.IsNullOrWhiteSpace(propertyPath))
            {
                return null;
            }

            SerializedProperty property = serializedObject.FindProperty(propertyPath);
            if (property != null)
            {
                return property;
            }

            if (!TryParseArrayElementPropertyPath(propertyPath, out string arrayPath, out int arrayIndex, out string normalizedArrayPath))
            {
                return null;
            }

            property = serializedObject.FindProperty(normalizedArrayPath);
            if (property != null)
            {
                normalizedPropertyPath = normalizedArrayPath;
            }

            if (property != null)
            {
                return property;
            }

            SerializedProperty arrayProperty = serializedObject.FindProperty(arrayPath);
            if (arrayProperty == null || !arrayProperty.isArray || arrayProperty.propertyType == SerializedPropertyType.String)
            {
                return null;
            }

            if (arrayProperty.arraySize <= arrayIndex)
            {
                arrayProperty.arraySize = arrayIndex + 1;
            }

            property = arrayProperty.GetArrayElementAtIndex(arrayIndex);
            if (property != null)
            {
                normalizedPropertyPath = normalizedArrayPath;
            }

            return property;
        }

        private static bool TryParseArrayElementPropertyPath(string propertyPath, out string arrayPath, out int index, out string normalizedPath)
        {
            arrayPath = string.Empty;
            index = -1;
            normalizedPath = string.Empty;
            if (string.IsNullOrWhiteSpace(propertyPath))
            {
                return false;
            }

            string trimmed = propertyPath.Trim();
            int close = trimmed.LastIndexOf(']');
            int open = close > 0 ? trimmed.LastIndexOf('[', close) : -1;
            if (open <= 0 || close != trimmed.Length - 1)
            {
                return false;
            }

            string indexText = trimmed.Substring(open + 1, close - open - 1);
            if (!int.TryParse(indexText, NumberStyles.Integer, CultureInfo.InvariantCulture, out index) || index < 0)
            {
                return false;
            }

            arrayPath = trimmed.Substring(0, open).TrimEnd('.');
            if (string.IsNullOrWhiteSpace(arrayPath))
            {
                return false;
            }

            normalizedPath = $"{arrayPath}.Array.data[{index}]";
            return true;
        }

        private static string AddComponent(AgentAction action)
        {
            GameObject target = FindSceneTargetForEdit(action);
            if (target == null)
            {
                string prefabResult;
                if (TryEditPrefabGameObject(action, "add_component", prefabTarget =>
                    AddComponentToTarget(prefabTarget, action, prefabTarget: true), out prefabResult))
                {
                    return prefabResult;
                }

                return "add_component target not found";
            }

            return AddComponentToTarget(target, action, prefabTarget: false);
        }

        private static string AddComponentToTarget(GameObject target, AgentAction action, bool prefabTarget)
        {
            Type componentType = FindComponentType(action.component);
            if (componentType == null)
            {
                return $"component type not found: {action.component}";
            }

            if (!typeof(Component).IsAssignableFrom(componentType))
            {
                return $"{componentType.Name} is not a Unity Component";
            }

            if (target.GetComponent(componentType) != null)
            {
                return $"{target.name} already has {componentType.Name}";
            }

            if (prefabTarget)
            {
                Component component = target.AddComponent(componentType);
                if (component != null)
                {
                    EditorUtility.SetDirty(component);
                }

                return $"added {componentType.Name} to prefab {GetPrefabEditSummary(target)}";
            }

            Undo.AddComponent(target, componentType);
            EditorSceneManager.MarkSceneDirty(SceneManager.GetActiveScene());
            return $"added {componentType.Name} to {GetHierarchyPath(target)}";
        }

        private static string RemoveComponent(AgentAction action)
        {
            GameObject target = FindSceneTargetForEdit(action);
            if (target == null)
            {
                string prefabResult;
                if (TryEditPrefabGameObject(action, "remove_component", prefabTarget =>
                    RemoveComponentFromTarget(prefabTarget, action, prefabTarget: true), out prefabResult))
                {
                    return prefabResult;
                }

                return "remove_component target not found";
            }

            return RemoveComponentFromTarget(target, action, prefabTarget: false);
        }

        private static string RemoveComponentFromTarget(GameObject target, AgentAction action, bool prefabTarget)
        {
            Type componentType = FindComponentType(action.component);
            Component component = componentType == null ? null : target.GetComponent(componentType);
            if (component == null)
            {
                return $"component not found on {target.name}: {action.component}";
            }

            if (prefabTarget)
            {
                Object.DestroyImmediate(component, allowDestroyingAssets: true);
                return $"removed {componentType.Name} from prefab {GetPrefabEditSummary(target)}";
            }

            Undo.DestroyObjectImmediate(component);
            EditorSceneManager.MarkSceneDirty(SceneManager.GetActiveScene());
            return $"removed {componentType.Name} from {GetHierarchyPath(target)}";
        }

        private static string SelectTarget(AgentAction action)
        {
            GameObject target = FindTarget(action.target);
            if (target == null)
            {
                return "select target not found";
            }

            Selection.activeGameObject = target;
            return $"selected {GetHierarchyPath(target)}";
        }

        private static string CreatePrefabFromSelected(AgentAction action)
        {
            GameObject selected = Selection.activeGameObject;
            if (selected == null)
            {
                return "create_prefab_from_selected requires a selected GameObject";
            }

            string path = string.IsNullOrWhiteSpace(action.path)
                ? $"Assets/AgenticGamedev/Generated/Prefabs/{SanitizeFileName(selected.name)}.prefab"
                : NormalizeAssetPath(action.path);

            EnsureAssetFolder(Path.GetDirectoryName(path)?.Replace("\\", "/"));
            PrefabUtility.SaveAsPrefabAssetAndConnect(selected, path, InteractionMode.UserAction);
            return $"created prefab {path}";
        }

        private static string InstantiatePrefab(AgentAction action)
        {
            string path = NormalizeAssetPath(action.asset_path);
            GameObject prefab = AssetDatabase.LoadAssetAtPath<GameObject>(path);
            if (prefab == null)
            {
                return $"prefab not found: {path}";
            }

            GameObject instance = PrefabUtility.InstantiatePrefab(prefab) as GameObject;
            if (instance == null)
            {
                return $"could not instantiate prefab: {path}";
            }

            Undo.RegisterCreatedObjectUndo(instance, "Agentic Instantiate Prefab");
            ApplyParent(instance, action.parent);
            ApplyTransform(instance.transform, action);
            Selection.activeGameObject = instance;
            EditorSceneManager.MarkSceneDirty(SceneManager.GetActiveScene());
            return $"instantiated {path}";
        }

        private static GameObject FindSceneTargetForEdit(AgentAction action)
        {
            if (ShouldPreferPrefabEdit(action))
            {
                return null;
            }

            return FindTarget(action == null ? string.Empty : action.target);
        }

        private static bool ShouldPreferPrefabEdit(AgentAction action)
        {
            if (action == null || !TryResolvePrefabEditTarget(action, out _, out _))
            {
                return false;
            }

            string target = action.target;
            return string.IsNullOrWhiteSpace(target) ||
                string.Equals(target.Trim(), "selected", StringComparison.OrdinalIgnoreCase) ||
                ContainsPrefabPath(target);
        }

        private static bool TryEditPrefabGameObject(AgentAction action, string operationName, Func<GameObject, string> edit, out string result)
        {
            result = string.Empty;
            if (!TryResolvePrefabEditTarget(action, out string prefabPath, out string prefabTarget))
            {
                return false;
            }

            GameObject prefabRoot = null;
            try
            {
                prefabRoot = PrefabUtility.LoadPrefabContents(prefabPath);
                if (prefabRoot == null)
                {
                    result = $"prefab not found: {prefabPath}";
                    return true;
                }

                GameObject target = FindPrefabContentTarget(prefabRoot, prefabTarget);
                if (target == null)
                {
                    result = string.IsNullOrWhiteSpace(prefabTarget)
                        ? $"prefab root not found: {prefabPath}"
                        : $"{operationName} prefab target not found: {prefabPath}/{prefabTarget}";
                    return true;
                }

                result = edit == null ? string.Empty : edit(target);
                EditorUtility.SetDirty(prefabRoot);
                PrefabUtility.SaveAsPrefabAsset(prefabRoot, prefabPath);
                AssetDatabase.SaveAssets();
                AssetDatabase.ImportAsset(prefabPath, ImportAssetOptions.ForceUpdate);
                if (string.IsNullOrWhiteSpace(result))
                {
                    result = $"{operationName} applied to prefab {prefabPath}";
                }

                return true;
            }
            catch (Exception exception)
            {
                result = $"{operationName} failed for prefab {prefabPath}: {exception.Message}";
                return true;
            }
            finally
            {
                if (prefabRoot != null)
                {
                    PrefabUtility.UnloadPrefabContents(prefabRoot);
                }
            }
        }

        private static bool TryResolvePrefabEditTarget(AgentAction action, out string prefabPath, out string prefabTarget)
        {
            prefabPath = string.Empty;
            prefabTarget = string.Empty;
            if (action == null)
            {
                return false;
            }

            string childFromPath = string.Empty;
            if (TryExtractPrefabPath(FirstNonEmpty(action.path, action.asset_path), out prefabPath, out childFromPath))
            {
                prefabTarget = childFromPath;
            }

            if (TryExtractPrefabPath(action.target, out string targetPrefabPath, out string childFromTarget))
            {
                if (string.IsNullOrWhiteSpace(prefabPath))
                {
                    prefabPath = targetPrefabPath;
                }

                if (string.Equals(prefabPath, targetPrefabPath, StringComparison.OrdinalIgnoreCase))
                {
                    prefabTarget = childFromTarget;
                }
            }
            else if (!string.IsNullOrWhiteSpace(prefabPath) &&
                !string.IsNullOrWhiteSpace(action.target) &&
                !string.Equals(action.target.Trim(), "selected", StringComparison.OrdinalIgnoreCase))
            {
                prefabTarget = action.target.Trim();
            }

            if (string.IsNullOrWhiteSpace(prefabTarget) && !string.IsNullOrWhiteSpace(action.name))
            {
                prefabTarget = action.name.Trim();
            }

            return !string.IsNullOrWhiteSpace(prefabPath);
        }

        private static bool TryExtractPrefabPath(string value, out string prefabPath, out string prefabTarget)
        {
            prefabPath = string.Empty;
            prefabTarget = string.Empty;
            if (string.IsNullOrWhiteSpace(value))
            {
                return false;
            }

            string normalized = value.Trim().Replace("\\", "/").TrimStart('/');
            if (HasParentPathTraversal(normalized))
            {
                return false;
            }

            int prefabIndex = normalized.IndexOf(".prefab", StringComparison.OrdinalIgnoreCase);
            if (prefabIndex < 0)
            {
                return false;
            }

            string candidatePath = normalized.Substring(0, prefabIndex + ".prefab".Length);
            prefabPath = NormalizeAssetPath(candidatePath);
            if (!prefabPath.StartsWith("Assets/", StringComparison.Ordinal) ||
                !string.Equals(Path.GetExtension(prefabPath), ".prefab", StringComparison.OrdinalIgnoreCase))
            {
                prefabPath = string.Empty;
                return false;
            }

            if (prefabIndex + ".prefab".Length < normalized.Length)
            {
                prefabTarget = normalized.Substring(prefabIndex + ".prefab".Length).Trim('/');
            }

            return true;
        }

        private static bool ContainsPrefabPath(string value)
        {
            return !string.IsNullOrWhiteSpace(value) &&
                value.IndexOf(".prefab", StringComparison.OrdinalIgnoreCase) >= 0;
        }

        private static GameObject FindPrefabContentTarget(GameObject prefabRoot, string target)
        {
            if (prefabRoot == null)
            {
                return null;
            }

            if (string.IsNullOrWhiteSpace(target) ||
                string.Equals(target.Trim(), "root", StringComparison.OrdinalIgnoreCase) ||
                string.Equals(target.Trim(), prefabRoot.name, StringComparison.OrdinalIgnoreCase))
            {
                return prefabRoot;
            }

            string normalizedTarget = target.Trim().Replace("\\", "/").Trim('/');
            string rootPrefix = prefabRoot.name + "/";
            if (normalizedTarget.StartsWith(rootPrefix, StringComparison.OrdinalIgnoreCase))
            {
                normalizedTarget = normalizedTarget.Substring(rootPrefix.Length);
            }

            return FindInPrefabChildren(prefabRoot.transform, normalizedTarget);
        }

        private static GameObject FindInPrefabChildren(Transform transform, string target)
        {
            if (transform == null || string.IsNullOrWhiteSpace(target))
            {
                return null;
            }

            if (string.Equals(transform.name, target, StringComparison.OrdinalIgnoreCase) ||
                string.Equals(GetHierarchyPath(transform.gameObject), target, StringComparison.OrdinalIgnoreCase))
            {
                return transform.gameObject;
            }

            string firstSegment = target;
            string remainder = string.Empty;
            int slash = target.IndexOf('/');
            if (slash >= 0)
            {
                firstSegment = target.Substring(0, slash);
                remainder = target.Substring(slash + 1);
            }

            for (int i = 0; i < transform.childCount; i++)
            {
                Transform child = transform.GetChild(i);
                if (slash >= 0 && string.Equals(child.name, firstSegment, StringComparison.OrdinalIgnoreCase))
                {
                    return string.IsNullOrWhiteSpace(remainder)
                        ? child.gameObject
                        : FindInPrefabChildren(child, remainder);
                }

                GameObject found = FindInPrefabChildren(child, target);
                if (found != null)
                {
                    return found;
                }
            }

            return null;
        }

        private static string GetPrefabEditSummary(GameObject target)
        {
            return target == null ? "prefab target" : GetHierarchyPath(target);
        }

        private static string CreateScene(AgentAction action)
        {
            string path = EnsureExtension(NormalizeAssetPath(action.path), ".unity");
            if (string.IsNullOrWhiteSpace(path))
            {
                path = $"Assets/AgenticGamedev/Generated/Scenes/{SanitizeFileName(action.name)}.unity";
            }

            EnsureAssetFolder(Path.GetDirectoryName(path)?.Replace("\\", "/"));
            Scene scene = EditorSceneManager.NewScene(NewSceneSetup.EmptyScene, NewSceneMode.Additive);
            EditorSceneManager.SaveScene(scene, path);
            if (action.open_scene)
            {
                EditorSceneManager.SetActiveScene(scene);
            }
            else
            {
                EditorSceneManager.CloseScene(scene, true);
            }

            AssetDatabase.Refresh();
            return action.open_scene ? $"created and opened scene {path}" : $"created scene {path}";
        }

        private static string OpenScene(AgentAction action)
        {
            string path = NormalizeAssetPath(string.IsNullOrWhiteSpace(action.path) ? action.asset_path : action.path);
            if (AssetDatabase.LoadAssetAtPath<SceneAsset>(path) == null)
            {
                return $"scene not found: {path}";
            }

            EditorSceneManager.OpenScene(path);
            return $"opened scene {path}";
        }

        private static string ExecuteMenuItem(AgentAction action)
        {
            if (string.IsNullOrWhiteSpace(action.menu_item))
            {
                return "execute_menu_item missing menu_item";
            }

            if (IsCoveredBuildSettingsMenuItem(action.menu_item))
            {
                return "Tool blocked: Build Settings menu automation is covered by set_editor_build_scenes. Use create_scene/open_scene/save_scene and set_editor_build_scenes directly.";
            }

            bool executed = EditorApplication.ExecuteMenuItem(action.menu_item);
            return executed ? $"executed menu item {action.menu_item}" : $"menu item not found or failed: {action.menu_item}";
        }

        private static bool IsCoveredBuildSettingsMenuItem(string menuItem)
        {
            if (string.IsNullOrWhiteSpace(menuItem))
            {
                return false;
            }

            string normalized = NormalizeSettingKey(menuItem);
            return normalized.IndexOf("buildsettings", StringComparison.OrdinalIgnoreCase) >= 0 ||
                normalized.IndexOf("buildprofiles", StringComparison.OrdinalIgnoreCase) >= 0;
        }

        private static string EnterPlayMode()
        {
            if (EditorApplication.isCompiling || EditorApplication.isUpdating)
            {
                return "cannot enter play mode while Unity is compiling or updating assets";
            }

            if (EditorApplication.isPlaying)
            {
                return "already in play mode";
            }

            if (EditorApplication.isPlayingOrWillChangePlaymode)
            {
                return "play mode transition is already in progress";
            }

            EditorApplication.EnterPlaymode();
            return "entered play mode";
        }

        private static string ExitPlayMode()
        {
            if (EditorApplication.isCompiling || EditorApplication.isUpdating)
            {
                return "cannot exit play mode while Unity is compiling or updating assets";
            }

            if (!EditorApplication.isPlaying && !EditorApplication.isPlayingOrWillChangePlaymode)
            {
                return "already out of play mode";
            }

            EditorApplication.ExitPlaymode();
            return "exited play mode";
        }

        private static string AddPackage(AgentAction action)
        {
            if (string.IsNullOrWhiteSpace(action.package_id))
            {
                return "add_package missing package_id";
            }

            Client.Add(action.package_id.Trim());
            return $"started package add for {action.package_id.Trim()}";
        }

        private static string RemovePackage(AgentAction action)
        {
            if (string.IsNullOrWhiteSpace(action.package_id))
            {
                return "remove_package missing package_id";
            }

            Client.Remove(action.package_id.Trim());
            return $"started package removal for {action.package_id.Trim()}";
        }

        private static string SetPlayerSetting(AgentAction action)
        {
            string setting = NormalizeSettingKey(FirstNonEmpty(action.property_path, action.name, action.target));
            if (string.IsNullOrWhiteSpace(setting))
            {
                return "set_player_setting missing property_path";
            }

            switch (setting)
            {
                case "activeinputhandling":
                case "activeinputhandler":
                    int inputHandling = ParseActiveInputHandling(action);
                    string reflectionDetail;
                    bool usedInternalApi = TrySetPlayerSettingsInt("activeInputHandler", inputHandling, out reflectionDetail);
                    string fileResult = SetProjectSetting(new AgentAction
                    {
                        path = "ProjectSettings/ProjectSettings.asset",
                        property_path = "activeInputHandler",
                        value_type = "int",
                        int_value = inputHandling,
                        value = inputHandling.ToString(CultureInfo.InvariantCulture)
                    });
                    return usedInternalApi
                        ? $"set active input handling to {DescribeActiveInputHandling(inputHandling)} ({fileResult})"
                        : $"set active input handling to {DescribeActiveInputHandling(inputHandling)} via ProjectSettings.asset ({fileResult}; internal API unavailable: {reflectionDetail})";

                case "colorspace":
                    PlayerSettings.colorSpace = ParseColorSpace(action);
                    return $"set PlayerSettings color space to {PlayerSettings.colorSpace}";

                case "companyname":
                    PlayerSettings.companyName = action.value ?? string.Empty;
                    return $"set PlayerSettings company name to {PlayerSettings.companyName}";

                case "productname":
                    PlayerSettings.productName = action.value ?? string.Empty;
                    return $"set PlayerSettings product name to {PlayerSettings.productName}";

                case "applicationidentifier":
                case "bundleidentifier":
                    if (string.IsNullOrWhiteSpace(action.value))
                    {
                        return "set_player_setting application identifier missing value";
                    }

                    PlayerSettings.applicationIdentifier = action.value.Trim();
                    return $"set PlayerSettings application identifier to {PlayerSettings.applicationIdentifier}";

                default:
                    return SetProjectSetting(new AgentAction
                    {
                        path = "ProjectSettings/ProjectSettings.asset",
                        property_path = FirstNonEmpty(action.property_path, action.name, action.target),
                        value = action.value,
                        value_type = action.value_type,
                        int_value = action.int_value,
                        float_value = action.float_value,
                        bool_value = action.bool_value
                    });
            }
        }

        private static string SetProjectSetting(AgentAction action)
        {
            string relativePath = string.IsNullOrWhiteSpace(action.path)
                ? "ProjectSettings/ProjectSettings.asset"
                : action.path.Trim().Replace("\\", "/");
            if (!relativePath.StartsWith("ProjectSettings/", StringComparison.Ordinal) ||
                relativePath.IndexOf("..", StringComparison.Ordinal) >= 0)
            {
                return "set_project_setting path must be under ProjectSettings";
            }

            string key = FirstNonEmpty(action.property_path, action.name);
            if (string.IsNullOrWhiteSpace(key))
            {
                return "set_project_setting missing property_path";
            }

            string projectRoot = Directory.GetParent(Application.dataPath)?.FullName;
            if (string.IsNullOrWhiteSpace(projectRoot))
            {
                return "could not resolve Unity project root";
            }

            string fullPath = Path.GetFullPath(Path.Combine(projectRoot, relativePath));
            string settingsRoot = Path.GetFullPath(Path.Combine(projectRoot, "ProjectSettings"));
            if (!fullPath.StartsWith(settingsRoot, StringComparison.Ordinal))
            {
                return "set_project_setting resolved outside ProjectSettings";
            }

            if (!File.Exists(fullPath))
            {
                return $"project settings file not found: {relativePath}";
            }

            string yamlValue = FormatProjectSettingValue(action);
            string[] lines = File.ReadAllLines(fullPath);
            bool replaced = false;
            for (int i = 0; i < lines.Length; i++)
            {
                string line = lines[i];
                string trimmedStart = line.TrimStart();
                if (!trimmedStart.StartsWith(key + ":", StringComparison.Ordinal))
                {
                    continue;
                }

                string indent = line.Substring(0, line.Length - trimmedStart.Length);
                lines[i] = $"{indent}{key}: {yamlValue}";
                replaced = true;
                break;
            }

            if (!replaced)
            {
                Array.Resize(ref lines, lines.Length + 1);
                lines[lines.Length - 1] = $"{key}: {yamlValue}";
            }

            File.WriteAllLines(fullPath, lines);
            AssetDatabase.Refresh();
            return replaced
                ? $"set {relativePath} {key} to {yamlValue}"
                : $"added {relativePath} {key}: {yamlValue}";
        }

        private static string SetAssetProperty(AgentAction action)
        {
            string path = NormalizeAssetPath(string.IsNullOrWhiteSpace(action.asset_path) ? action.path : action.asset_path);
            if (string.IsNullOrWhiteSpace(path))
            {
                return "set_asset_property missing asset_path";
            }

            if (string.IsNullOrWhiteSpace(action.property_path))
            {
                return "set_asset_property missing property_path";
            }

            if (ContainsPrefabPath(path) && TryBuildPrefabComponentPropertyAction(action, path, out AgentAction prefabAction))
            {
                return SetComponentProperty(prefabAction);
            }

            Object[] assets = AssetDatabase.LoadAllAssetsAtPath(path);
            if (assets == null || assets.Length == 0)
            {
                return $"asset not found: {path}";
            }

            Object asset = null;
            if (string.IsNullOrWhiteSpace(action.name))
            {
                asset = assets[0];
            }
            else
            {
                foreach (Object candidate in assets)
                {
                    if (candidate != null && string.Equals(candidate.name, action.name.Trim(), StringComparison.OrdinalIgnoreCase))
                    {
                        asset = candidate;
                        break;
                    }
                }
            }

            if (asset == null)
            {
                return $"sub-asset not found in {path}: {action.name}";
            }

            SerializedObject serializedObject = new SerializedObject(asset);
            SerializedProperty property = serializedObject.FindProperty(action.property_path);
            if (property == null)
            {
                return $"asset property not found: {path} {action.property_path}";
            }

            Undo.RecordObject(asset, "Agentic Set Asset Property");
            string valueValidation = ValidateSerializedValueInput(property, action);
            if (!string.IsNullOrWhiteSpace(valueValidation))
            {
                return valueValidation;
            }

            if (!ApplySerializedValue(property, action))
            {
                return $"unsupported asset property type for {action.property_path}: {property.propertyType}";
            }

            serializedObject.ApplyModifiedProperties();
            EditorUtility.SetDirty(asset);
            AssetDatabase.SaveAssets();
            AssetDatabase.Refresh();
            return $"set asset property {path} {action.property_path}";
        }

        private static bool TryBuildPrefabComponentPropertyAction(AgentAction action, string prefabPath, out AgentAction prefabAction)
        {
            prefabAction = null;
            if (action == null || string.IsNullOrWhiteSpace(prefabPath))
            {
                return false;
            }

            string componentName = action.component;
            string componentPropertyPath = action.property_path;
            if (string.IsNullOrWhiteSpace(componentName))
            {
                if (!TrySplitComponentPropertyPath(action.property_path, out componentName, out componentPropertyPath))
                {
                    return false;
                }
            }
            else if (TrySplitComponentPropertyPath(action.property_path, out string prefixedComponent, out string prefixedProperty) &&
                ComponentNamesMatch(componentName, prefixedComponent))
            {
                componentPropertyPath = prefixedProperty;
            }

            if (string.IsNullOrWhiteSpace(componentName) || string.IsNullOrWhiteSpace(componentPropertyPath))
            {
                return false;
            }

            prefabAction = CloneAction(action);
            prefabAction.path = prefabPath;
            prefabAction.asset_path = string.Empty;
            prefabAction.component = componentName;
            prefabAction.property_path = componentPropertyPath;
            if (string.IsNullOrWhiteSpace(prefabAction.target) &&
                !string.IsNullOrWhiteSpace(action.name) &&
                !ComponentNamesMatch(action.name, componentName))
            {
                prefabAction.target = action.name;
            }

            return true;
        }

        private static bool TrySplitComponentPropertyPath(string propertyPath, out string componentName, out string componentPropertyPath)
        {
            componentName = string.Empty;
            componentPropertyPath = string.Empty;
            if (string.IsNullOrWhiteSpace(propertyPath))
            {
                return false;
            }

            string[] parts = propertyPath.Trim().Split('.');
            if (parts.Length < 2)
            {
                return false;
            }

            for (int i = parts.Length - 1; i >= 1; i--)
            {
                string candidateComponent = string.Join(".", parts, 0, i).Trim();
                string candidateProperty = string.Join(".", parts, i, parts.Length - i).Trim();
                if (string.IsNullOrWhiteSpace(candidateComponent) ||
                    string.IsNullOrWhiteSpace(candidateProperty) ||
                    FindComponentType(candidateComponent) == null)
                {
                    continue;
                }

                componentName = candidateComponent;
                componentPropertyPath = candidateProperty;
                return true;
            }

            return false;
        }

        private static bool ComponentNamesMatch(string left, string right)
        {
            Type leftType = FindComponentType(left);
            Type rightType = FindComponentType(right);
            if (leftType != null && rightType != null)
            {
                return leftType == rightType;
            }

            return string.Equals(
                string.IsNullOrWhiteSpace(left) ? string.Empty : left.Trim().Replace(" ", string.Empty),
                string.IsNullOrWhiteSpace(right) ? string.Empty : right.Trim().Replace(" ", string.Empty),
                StringComparison.OrdinalIgnoreCase);
        }

        private static string SetEditorBuildScenes(AgentAction action)
        {
            string[] scenePaths = action.paths;
            if ((scenePaths == null || scenePaths.Length == 0) && !string.IsNullOrWhiteSpace(action.path))
            {
                scenePaths = new[] { action.path };
            }

            if (scenePaths == null || scenePaths.Length == 0)
            {
                return "set_editor_build_scenes missing paths";
            }

            bool append = ShouldAppendBuildScenes(action);
            List<EditorBuildSettingsScene> scenes = new List<EditorBuildSettingsScene>();
            HashSet<string> incomingPaths = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
            for (int i = 0; i < scenePaths.Length; i++)
            {
                string scenePath = NormalizeAssetPath(scenePaths[i]);
                if (AssetDatabase.LoadAssetAtPath<SceneAsset>(scenePath) == null)
                {
                    return $"build scene not found: {scenePath}";
                }

                incomingPaths.Add(scenePath);
            }

            if (append)
            {
                foreach (EditorBuildSettingsScene existing in EditorBuildSettings.scenes)
                {
                    if (existing == null ||
                        string.IsNullOrWhiteSpace(existing.path) ||
                        incomingPaths.Contains(existing.path))
                    {
                        continue;
                    }

                    scenes.Add(existing);
                }
            }

            for (int i = 0; i < scenePaths.Length; i++)
            {
                string scenePath = NormalizeAssetPath(scenePaths[i]);
                bool enabled = action.enabled == null || i >= action.enabled.Length || action.enabled[i];
                scenes.Add(new EditorBuildSettingsScene(scenePath, enabled));
            }

            EditorBuildSettings.scenes = scenes.ToArray();
            AssetDatabase.SaveAssets();
            return append
                ? $"added build scene(s): {string.Join(", ", incomingPaths)}"
                : $"set build scenes ({scenes.Count})";
        }

        private static bool ShouldAppendBuildScenes(AgentAction action)
        {
            if (action == null)
            {
                return false;
            }

            string mode = NormalizeSettingKey(FirstNonEmpty(action.value, action.name, action.query, action.content));
            return action.bool_value ||
                mode.IndexOf("append", StringComparison.OrdinalIgnoreCase) >= 0 ||
                mode.IndexOf("add", StringComparison.OrdinalIgnoreCase) >= 0 ||
                mode.IndexOf("include", StringComparison.OrdinalIgnoreCase) >= 0;
        }

        private static string InvokeEditorMethod(AgentAction action)
        {
            string className = FirstNonEmpty(action.class_name, action.component, action.target, action.name);
            string methodName = FirstNonEmpty(action.method_name, action.property_path, action.value_type);
            if (string.IsNullOrWhiteSpace(className))
            {
                return "invoke_editor_method missing class_name";
            }

            if (string.IsNullOrWhiteSpace(methodName))
            {
                return "invoke_editor_method missing method_name";
            }

            if (IsPrefabBuilderEditorMethod(className, methodName))
            {
                return "Tool blocked: prefab builder editor methods are not used for ordinary prefab edits. Use inspect_prefab, set_component_property, set_transform, set_object_property, ensure_components, add_component, remove_component, or set_asset_property against the prefab asset path, then inspect_prefab again to verify the result.";
            }

            if (IsCoveredBuildSettingsEditorMethod(className, methodName))
            {
                return "Tool blocked: build-scene editor utility methods duplicate direct Agentic tools. Use create_scene/open_scene/save_scene and set_editor_build_scenes directly.";
            }

            Type type = FindTypeByName(className);
            if (type == null)
            {
                return $"editor type not found: {className}";
            }

            MethodInfo method = type.GetMethod(methodName, BindingFlags.Static | BindingFlags.Public | BindingFlags.NonPublic);
            if (method == null)
            {
                return $"static editor method not found: {className}.{methodName}";
            }

            ParameterInfo[] parameters = method.GetParameters();
            object result;
            if (parameters.Length == 0)
            {
                result = method.Invoke(null, null);
            }
            else if (parameters.Length == 1 && parameters[0].ParameterType == typeof(string))
            {
                result = method.Invoke(null, new object[] { action.value ?? string.Empty });
            }
            else
            {
                return $"unsupported editor method signature: {className}.{methodName}";
            }

            AssetDatabase.SaveAssets();
            AssetDatabase.Refresh();
            return result == null
                ? $"invoked {className}.{methodName}"
                : $"invoked {className}.{methodName}: {result}";
        }

        private static bool IsPrefabBuilderEditorMethod(string className, string methodName)
        {
            string normalizedClass = NormalizeSettingKey(className);
            string normalizedMethod = NormalizeSettingKey(methodName);
            if (string.IsNullOrWhiteSpace(normalizedClass))
            {
                return false;
            }

            return normalizedClass.IndexOf("prefabbuilder", StringComparison.OrdinalIgnoreCase) >= 0 ||
                (normalizedClass.IndexOf("prefab", StringComparison.OrdinalIgnoreCase) >= 0 &&
                 (normalizedMethod.IndexOf("createorrefresh", StringComparison.OrdinalIgnoreCase) >= 0 ||
                  normalizedMethod.IndexOf("rebuild", StringComparison.OrdinalIgnoreCase) >= 0 ||
                  normalizedMethod.IndexOf("builder", StringComparison.OrdinalIgnoreCase) >= 0));
        }

        private static bool IsCoveredBuildSettingsEditorMethod(string className, string methodName)
        {
            string normalizedClass = NormalizeSettingKey(className);
            string normalizedMethod = NormalizeSettingKey(methodName);
            if (string.IsNullOrWhiteSpace(normalizedClass))
            {
                return false;
            }

            return normalizedClass.IndexOf("scenebuildsettingsutility", StringComparison.OrdinalIgnoreCase) >= 0 ||
                normalizedClass.IndexOf("buildsettingsutility", StringComparison.OrdinalIgnoreCase) >= 0 ||
                (normalizedClass.IndexOf("buildsettings", StringComparison.OrdinalIgnoreCase) >= 0 &&
                 (normalizedMethod.IndexOf("add", StringComparison.OrdinalIgnoreCase) >= 0 ||
                  normalizedMethod.IndexOf("set", StringComparison.OrdinalIgnoreCase) >= 0 ||
                  normalizedMethod.IndexOf("include", StringComparison.OrdinalIgnoreCase) >= 0));
        }

        private static string FormatProjectSettingValue(AgentAction action)
        {
            string valueType = NormalizeSettingKey(action.value_type);
            switch (valueType)
            {
                case "int":
                case "integer":
                    return action.int_value.ToString(CultureInfo.InvariantCulture);

                case "float":
                case "single":
                    return action.float_value.ToString(CultureInfo.InvariantCulture);

                case "bool":
                case "boolean":
                    return action.bool_value ? "1" : "0";

                default:
                    if (!string.IsNullOrWhiteSpace(action.value))
                    {
                        return action.value.Trim();
                    }

                    if (action.bool_value)
                    {
                        return "1";
                    }

                    return action.int_value.ToString(CultureInfo.InvariantCulture);
            }
        }

        private static bool TrySetPlayerSettingsInt(string propertyName, int value, out string detail)
        {
            detail = "no matching SetPropertyInt overload";
            MethodInfo[] methods = typeof(PlayerSettings).GetMethods(BindingFlags.Static | BindingFlags.Public | BindingFlags.NonPublic);
            foreach (MethodInfo method in methods)
            {
                if (!string.Equals(method.Name, "SetPropertyInt", StringComparison.Ordinal))
                {
                    continue;
                }

                ParameterInfo[] parameters = method.GetParameters();
                object[] arguments = BuildPlayerSettingsIntArguments(parameters, propertyName, value);
                if (arguments == null)
                {
                    continue;
                }

                try
                {
                    method.Invoke(null, arguments);
                    detail = method.ToString();
                    return true;
                }
                catch (Exception exception)
                {
                    detail = exception.GetBaseException().Message;
                }
            }

            return false;
        }

        private static object[] BuildPlayerSettingsIntArguments(ParameterInfo[] parameters, string propertyName, int value)
        {
            object[] arguments = new object[parameters.Length];
            bool usedName = false;
            bool usedValue = false;
            for (int i = 0; i < parameters.Length; i++)
            {
                Type type = parameters[i].ParameterType;
                if (type == typeof(string) && !usedName)
                {
                    arguments[i] = propertyName;
                    usedName = true;
                }
                else if (type == typeof(int) && !usedValue)
                {
                    arguments[i] = value;
                    usedValue = true;
                }
                else if (type == typeof(BuildTargetGroup))
                {
                    arguments[i] = EditorUserBuildSettings.selectedBuildTargetGroup;
                }
                else if (type.IsEnum)
                {
                    arguments[i] = Enum.GetValues(type).GetValue(0);
                }
                else
                {
                    return null;
                }
            }

            return usedName && usedValue ? arguments : null;
        }

        private static int ParseActiveInputHandling(AgentAction action)
        {
            string value = NormalizeSettingKey(action.value);
            if (string.IsNullOrWhiteSpace(value))
            {
                return action.int_value;
            }

            if (value == "old" || value == "legacy" || value == "inputmanager" || value == "inputmanagerold")
            {
                return 0;
            }

            if (value == "new" || value == "inputsystem" || value == "inputsystempackage")
            {
                return 1;
            }

            if (value == "both")
            {
                return 2;
            }

            int parsed;
            return int.TryParse(value, NumberStyles.Integer, CultureInfo.InvariantCulture, out parsed)
                ? parsed
                : action.int_value;
        }

        private static string DescribeActiveInputHandling(int value)
        {
            switch (value)
            {
                case 0:
                    return "Input Manager (Old) [0]";
                case 1:
                    return "Input System Package (New) [1]";
                case 2:
                    return "Both [2]";
                default:
                    return $"Unknown [{value}]";
            }
        }

        private static int ReadProjectSettingInt(string relativePath, string key, int fallback)
        {
            string projectRoot = Directory.GetParent(Application.dataPath)?.FullName;
            if (string.IsNullOrWhiteSpace(projectRoot))
            {
                return fallback;
            }

            string fullPath = Path.Combine(projectRoot, relativePath);
            if (!File.Exists(fullPath))
            {
                return fallback;
            }

            foreach (string line in File.ReadAllLines(fullPath))
            {
                string trimmed = line.TrimStart();
                if (!trimmed.StartsWith(key + ":", StringComparison.Ordinal))
                {
                    continue;
                }

                string value = trimmed.Substring(key.Length + 1).Trim();
                int parsed;
                return int.TryParse(value, NumberStyles.Integer, CultureInfo.InvariantCulture, out parsed)
                    ? parsed
                    : fallback;
            }

            return fallback;
        }

        private static ColorSpace ParseColorSpace(AgentAction action)
        {
            string value = NormalizeSettingKey(action.value);
            if (value == "linear")
            {
                return ColorSpace.Linear;
            }

            if (value == "gamma")
            {
                return ColorSpace.Gamma;
            }

            return action.int_value == (int)ColorSpace.Linear ? ColorSpace.Linear : ColorSpace.Gamma;
        }

        private static string NormalizeSettingKey(string value)
        {
            if (string.IsNullOrWhiteSpace(value))
            {
                return string.Empty;
            }

            StringBuilder builder = new StringBuilder();
            foreach (char character in value)
            {
                if (char.IsLetterOrDigit(character))
                {
                    builder.Append(char.ToLowerInvariant(character));
                }
            }

            return builder.ToString();
        }

        private static string FirstNonEmpty(params string[] values)
        {
            if (values == null)
            {
                return string.Empty;
            }

            foreach (string value in values)
            {
                if (!string.IsNullOrWhiteSpace(value))
                {
                    return value.Trim();
                }
            }

            return string.Empty;
        }

        private static Type FindTypeByName(string typeName)
        {
            if (string.IsNullOrWhiteSpace(typeName))
            {
                return null;
            }

            string trimmed = typeName.Trim();
            Type direct = Type.GetType(trimmed);
            if (direct != null)
            {
                return direct;
            }

            foreach (Assembly assembly in AppDomain.CurrentDomain.GetAssemblies())
            {
                Type type = assembly.GetType(trimmed);
                if (type != null)
                {
                    return type;
                }
            }

            foreach (Assembly assembly in AppDomain.CurrentDomain.GetAssemblies())
            {
                Type[] types;
                try
                {
                    types = assembly.GetTypes();
                }
                catch (ReflectionTypeLoadException exception)
                {
                    types = exception.Types;
                }

                if (types == null)
                {
                    continue;
                }

                foreach (Type type in types)
                {
                    if (type == null)
                    {
                        continue;
                    }

                    if (string.Equals(type.FullName, trimmed, StringComparison.Ordinal) ||
                        string.Equals(type.Name, trimmed, StringComparison.Ordinal))
                    {
                        return type;
                    }
                }
            }

            return null;
        }

        private static string ValidateScene()
        {
            List<string> warnings = new List<string>();
            SceneRelationshipIndex relationshipIndex = BuildSceneRelationshipIndex();
            foreach (GameObject root in SceneManager.GetActiveScene().GetRootGameObjects())
            {
                AppendValidationWarnings(root, warnings);
            }

            AppendSceneRenderWorkflowWarnings(warnings);
            AppendSceneRelationshipWarnings(relationshipIndex, warnings);
            AppendPackageDependencySceneWarnings(relationshipIndex, warnings);

            if (warnings.Count == 0)
            {
                return "scene validation passed";
            }

            int count = Mathf.Min(warnings.Count, 16);
            StringBuilder builder = new StringBuilder();
            builder.Append($"scene validation found {warnings.Count} issue(s): ");
            for (int i = 0; i < count; i++)
            {
                if (i > 0)
                {
                    builder.Append("; ");
                }

                builder.Append(warnings[i]);
            }

            if (warnings.Count > count)
            {
                builder.Append($"; {warnings.Count - count} more");
            }

            return builder.ToString();
        }

        private static void AppendValidationWarnings(GameObject gameObject, List<string> warnings)
        {
            if (gameObject == null)
            {
                return;
            }

            string path = GetHierarchyPath(gameObject);
            bool cameraName = ShouldNameImplyCamera(gameObject.name);
            bool lightName = ShouldNameImplyLight(gameObject.name);

            if (cameraName && gameObject.GetComponent<Camera>() == null)
            {
                warnings.Add($"{path} is named like a camera but has no Camera component");
            }

            if (IsMainCameraName(gameObject.name) && gameObject.GetComponent<AudioListener>() == null)
            {
                warnings.Add($"{path} is Main Camera but has no AudioListener");
            }

            if (lightName && gameObject.GetComponent<Light>() == null)
            {
                warnings.Add($"{path} is named like a light but has no Light component");
            }

            if (gameObject.GetComponent<Rigidbody2D>() != null && gameObject.GetComponent<Collider2D>() == null)
            {
                warnings.Add($"{path} has Rigidbody2D but no Collider2D");
            }

            if (gameObject.GetComponent<Collider2D>() != null &&
                gameObject.GetComponent<Renderer>() == null &&
                gameObject.GetComponents<Component>().Length <= 3)
            {
                warnings.Add($"{path} has 2D collision but no renderer or behavior component");
            }

            AppendWorkflowCompletionWarnings(gameObject, path, warnings);

            Transform transform = gameObject.transform;
            for (int i = 0; i < transform.childCount; i++)
            {
                AppendValidationWarnings(transform.GetChild(i).gameObject, warnings);
            }
        }

        private static void AppendWorkflowCompletionWarnings(GameObject gameObject, string path, List<string> warnings)
        {
            SpriteRenderer spriteRenderer = gameObject.GetComponent<SpriteRenderer>();
            if (spriteRenderer != null && spriteRenderer.sprite == null)
            {
                warnings.Add($"{path} has SpriteRenderer but no sprite assigned");
            }

            AudioSource audioSource = gameObject.GetComponent<AudioSource>();
            if (audioSource != null && audioSource.clip == null)
            {
                warnings.Add($"{path} has AudioSource but no AudioClip assigned");
            }

            Animator animator = gameObject.GetComponent<Animator>();
            if (animator != null && animator.runtimeAnimatorController == null)
            {
                warnings.Add($"{path} has Animator but no controller assigned");
            }

#if ARK_HAS_URP
            Volume volume = gameObject.GetComponent<Volume>();
            if (NameContainsAny(gameObject.name, "volume", "post process", "post-processing") && volume == null)
            {
                warnings.Add($"{path} is named like a volume/post-processing object but has no Volume component");
            }

            if (volume != null)
            {
                if (volume.sharedProfile == null)
                {
                    warnings.Add($"{path} has Volume but no shared VolumeProfile assigned");
                }
                else if (!HasAnyActiveVolumeOverride(volume.sharedProfile))
                {
                    warnings.Add($"{path} has VolumeProfile {volume.sharedProfile.name} but no active overrides");
                }
                else
                {
                    AppendRequestedVolumeOverrideWarnings(gameObject, path, volume.sharedProfile, warnings);
                }
            }

            Camera camera = gameObject.GetComponent<Camera>();
            if (camera != null && SceneHasActiveGlobalVolumeOverrides() && IsUrpCameraPostProcessingDisabled(camera))
            {
                warnings.Add($"{path} has active global Volume overrides in the scene but camera post-processing is disabled");
            }
#endif

            AppendSerializedReferenceWarnings(gameObject, path, warnings);
        }

#if ARK_HAS_URP
        private static void AppendRequestedVolumeOverrideWarnings(
            GameObject gameObject,
            string path,
            VolumeProfile profile,
            List<string> warnings)
        {
            if (profile == null || warnings == null)
            {
                return;
            }

            string objectName = gameObject == null ? string.Empty : gameObject.name;
            bool mentionsBloom = NameContainsAny(objectName, "bloom") || NameContainsAny(profile.name, "bloom");
            bool mentionsVignette = NameContainsAny(objectName, "vignette") || NameContainsAny(profile.name, "vignette");
            bool mentionsPostProcessing = NameContainsAny(objectName, "post process", "post-processing", "postprocessing") ||
                NameContainsAny(profile.name, "post process", "post-processing", "postprocessing");

            if ((mentionsBloom || (mentionsPostProcessing && NameContainsAny(profile.name, "bloom"))) &&
                !HasActiveVolumeOverrideType(profile, "Bloom"))
            {
                warnings.Add($"{path} has VolumeProfile {profile.name} but no active Bloom override");
            }

            if ((mentionsVignette || (mentionsPostProcessing && NameContainsAny(profile.name, "vignette"))) &&
                !HasActiveVolumeOverrideType(profile, "Vignette"))
            {
                warnings.Add($"{path} has VolumeProfile {profile.name} but no active Vignette override");
            }
        }
#endif

        private static void AppendSceneRenderWorkflowWarnings(List<string> warnings)
        {
            if (warnings == null)
            {
                return;
            }

#if ARK_HAS_URP
            if (SceneHasActiveGlobalVolumeOverrides() && !SceneHasCameraWithEnabledUrpPostProcessing())
            {
                warnings.Add("Scene has active global Volume overrides but no enabled camera has URP post-processing enabled");
            }
#endif
        }

        private static void AppendPackageDependencySceneWarnings(SceneRelationshipIndex index, List<string> warnings)
        {
            if (index == null || warnings == null)
            {
                return;
            }

            RuntimeScriptPackageDependencies dependencies = BuildRuntimeScriptPackageDependencies();
            if (dependencies.UsesCinemachine)
            {
                if (!SceneHasComponentType(index, "CinemachineBrain"))
                {
                    AppendUniqueWarning(warnings, "Project runtime code references Cinemachine, but no scene camera has CinemachineBrain");
                }

                if (dependencies.UsesCinemachineCamera && !SceneHasComponentType(index, "CinemachineCamera"))
                {
                    AppendUniqueWarning(warnings, "Project runtime code references CinemachineCamera, but no CinemachineCamera exists in the scene");
                }
            }

            if (dependencies.UsesCinemachineImpulse)
            {
                if (!SceneHasComponentType(index, "CinemachineImpulseListener"))
                {
                    AppendUniqueWarning(warnings, "Project runtime code references Cinemachine impulse, but no CinemachineImpulseListener exists in the scene");
                }

                if (!SceneHasComponentType(index, "CinemachineImpulseSource"))
                {
                    AppendUniqueWarning(warnings, "Project runtime code references Cinemachine impulse, but no CinemachineImpulseSource exists in the scene");
                }
            }
        }

        private static RuntimeScriptPackageDependencies BuildRuntimeScriptPackageDependencies()
        {
            RuntimeScriptPackageDependencies dependencies = new RuntimeScriptPackageDependencies();
            string scriptsRoot = Path.Combine(Application.dataPath, "Scripts");
            if (!Directory.Exists(scriptsRoot))
            {
                return dependencies;
            }

            try
            {
                foreach (string filePath in Directory.EnumerateFiles(scriptsRoot, "*.cs", SearchOption.AllDirectories))
                {
                    string normalizedPath = filePath.Replace("\\", "/");
                    if (normalizedPath.IndexOf("/Editor/", StringComparison.OrdinalIgnoreCase) >= 0)
                    {
                        continue;
                    }

                    string source = File.ReadAllText(filePath, Encoding.UTF8);
                    if (SourceMentionsAny(source, "using Unity.Cinemachine", "Unity.Cinemachine.", "CinemachineBrain", "CinemachineCamera", "CinemachineImpulse"))
                    {
                        dependencies.UsesCinemachine = true;
                    }

                    if (SourceMentionsAny(source, "CinemachineCamera"))
                    {
                        dependencies.UsesCinemachineCamera = true;
                    }

                    if (SourceMentionsAny(source, "CinemachineImpulseSource", "CinemachineImpulseListener", "CinemachineImpulseDefinition"))
                    {
                        dependencies.UsesCinemachine = true;
                        dependencies.UsesCinemachineImpulse = true;
                    }
                }
            }
            catch (Exception)
            {
                // Package dependency validation is advisory and should never break validation itself.
            }

            return dependencies;
        }

        private static bool SourceMentionsAny(string source, params string[] needles)
        {
            if (string.IsNullOrWhiteSpace(source) || needles == null)
            {
                return false;
            }

            foreach (string needle in needles)
            {
                if (!string.IsNullOrWhiteSpace(needle) &&
                    source.IndexOf(needle, StringComparison.OrdinalIgnoreCase) >= 0)
                {
                    return true;
                }
            }

            return false;
        }

        private static bool SceneHasComponentType(SceneRelationshipIndex index, string componentTypeName)
        {
            return FindSceneObjectWithComponentType(index, componentTypeName) != null;
        }

        private static GameObject FindSceneObjectWithComponentType(SceneRelationshipIndex index, string componentTypeName)
        {
            if (index == null || string.IsNullOrWhiteSpace(componentTypeName))
            {
                return null;
            }

            foreach (GameObject gameObject in index.Objects)
            {
                if (gameObject == null)
                {
                    continue;
                }

                Component[] components = gameObject.GetComponents<Component>();
                foreach (Component component in components)
                {
                    if (component == null)
                    {
                        continue;
                    }

                    Type type = component.GetType();
                    if (string.Equals(type.Name, componentTypeName, StringComparison.OrdinalIgnoreCase) ||
                        string.Equals(type.FullName, componentTypeName, StringComparison.OrdinalIgnoreCase))
                    {
                        return gameObject;
                    }
                }
            }

            return null;
        }

        private static void AppendSerializedReferenceWarnings(GameObject gameObject, string path, List<string> warnings)
        {
            if (gameObject == null || warnings == null)
            {
                return;
            }

            Component[] components = gameObject.GetComponents<Component>();
            foreach (Component component in components)
            {
                if (!(component is MonoBehaviour) || component == null)
                {
                    continue;
                }

                AppendSerializedReferenceWarnings(component, path, warnings);
            }
        }

        private static void AppendSerializedReferenceWarnings(Component component, string path, List<string> warnings)
        {
            try
            {
                SerializedObject serializedObject = new SerializedObject(component);
                SerializedProperty property = serializedObject.GetIterator();
                bool enterChildren = true;
                int added = 0;
                while (property.NextVisible(enterChildren))
                {
                    enterChildren = false;
                    if (ShouldSkipSerializedReferenceValidation(property))
                    {
                        continue;
                    }

                    if (property.isArray && property.propertyType != SerializedPropertyType.String)
                    {
                        if (property.arraySize == 0 && IsImportantSerializedReferenceField(property.propertyPath))
                        {
                            AppendUniqueWarning(warnings, $"{path} {component.GetType().Name}.{property.propertyPath} is empty");
                            AppendMissingAssetCandidateWarningIfNeeded(component, property.propertyPath, warnings);
                            added++;
                        }
                        else if (property.arraySize > 0 && IsImportantSerializedReferenceField(property.propertyPath))
                        {
                            int missingElements = CountMissingObjectReferenceArrayElements(property);
                            if (missingElements > 0)
                            {
                                AppendUniqueWarning(warnings, $"{path} {component.GetType().Name}.{property.propertyPath} has {missingElements} unassigned element(s)");
                                added++;
                            }
                        }

                        continue;
                    }

                    if (property.propertyType == SerializedPropertyType.ObjectReference &&
                        property.objectReferenceValue == null &&
                        IsImportantSerializedReferenceField(property.propertyPath))
                    {
                        AppendUniqueWarning(warnings, $"{path} {component.GetType().Name}.{property.propertyPath} is unassigned");
                        AppendMissingAssetCandidateWarningIfNeeded(component, property.propertyPath, warnings);
                        added++;
                    }

                    if (added >= 6)
                    {
                        return;
                    }
                }
            }
            catch (Exception)
            {
                // Validation should never fail the scene pass because one custom component cannot serialize.
            }
        }

        private static int CountMissingObjectReferenceArrayElements(SerializedProperty arrayProperty)
        {
            if (arrayProperty == null || !arrayProperty.isArray || arrayProperty.propertyType == SerializedPropertyType.String)
            {
                return 0;
            }

            int missing = 0;
            for (int i = 0; i < arrayProperty.arraySize; i++)
            {
                SerializedProperty element = arrayProperty.GetArrayElementAtIndex(i);
                if (element != null &&
                    element.propertyType == SerializedPropertyType.ObjectReference &&
                    element.objectReferenceValue == null)
                {
                    missing++;
                }
            }

            return missing;
        }

        private static SceneRelationshipIndex BuildSceneRelationshipIndex()
        {
            SceneRelationshipIndex index = new SceneRelationshipIndex();
            try
            {
                foreach (GameObject gameObject in Object.FindObjectsByType<GameObject>(FindObjectsInactive.Include, FindObjectsSortMode.None))
                {
                    if (gameObject != null && gameObject.scene.IsValid())
                    {
                        index.Objects.Add(gameObject);
                    }
                }
            }
            catch (Exception)
            {
                foreach (GameObject root in SceneManager.GetActiveScene().GetRootGameObjects())
                {
                    AddSceneRelationshipObjectRecursive(index, root);
                }
            }

            return index;
        }

        private static void AddSceneRelationshipObjectRecursive(SceneRelationshipIndex index, GameObject gameObject)
        {
            if (index == null || gameObject == null)
            {
                return;
            }

            index.Objects.Add(gameObject);
            Transform transform = gameObject.transform;
            for (int i = 0; i < transform.childCount; i++)
            {
                AddSceneRelationshipObjectRecursive(index, transform.GetChild(i).gameObject);
            }
        }

        private static void AppendSceneRelationshipWarnings(SceneRelationshipIndex index, List<string> warnings)
        {
            if (index == null || warnings == null)
            {
                return;
            }

            Dictionary<string, ScriptLookupContracts> scriptContracts = new Dictionary<string, ScriptLookupContracts>(StringComparer.OrdinalIgnoreCase);
            int added = 0;
            foreach (GameObject gameObject in index.Objects)
            {
                if (gameObject == null)
                {
                    continue;
                }

                Component[] components = gameObject.GetComponents<Component>();
                foreach (Component component in components)
                {
                    if (!(component is MonoBehaviour monoBehaviour) || component == null)
                    {
                        continue;
                    }

                    string ownerPath = GetHierarchyPath(gameObject);
                    added += AppendSerializedLookupContractWarnings(monoBehaviour, ownerPath, index, warnings);
                    added += AppendScriptSourceLookupContractWarnings(monoBehaviour, ownerPath, index, scriptContracts, warnings);
                    if (added >= 24)
                    {
                        return;
                    }
                }
            }
        }

        private static int AppendSerializedLookupContractWarnings(
            MonoBehaviour component,
            string ownerPath,
            SceneRelationshipIndex index,
            List<string> warnings)
        {
            if (component == null || index == null || warnings == null)
            {
                return 0;
            }

            int added = 0;
            try
            {
                SerializedObject serializedObject = new SerializedObject(component);
                SerializedProperty property = serializedObject.GetIterator();
                bool enterChildren = true;
                while (property.NextVisible(enterChildren))
                {
                    enterChildren = false;
                    if (property.propertyType != SerializedPropertyType.String)
                    {
                        continue;
                    }

                    string value = property.stringValue;
                    if (string.IsNullOrWhiteSpace(value))
                    {
                        continue;
                    }

                    string propertyKey = NormalizeSettingKey(property.propertyPath);
                    if (IsSceneNamePrefixField(propertyKey) && !index.HasSceneObjectNamePrefix(value))
                    {
                        AppendUniqueWarning(warnings, $"{ownerPath} {component.GetType().Name}.{property.propertyPath} expects scene object names starting with \"{value}\", but none exist");
                        added++;
                    }
                    else if (IsSceneTagLookupField(propertyKey) && !index.HasSceneObjectWithTag(value))
                    {
                        AppendUniqueWarning(warnings, $"{ownerPath} {component.GetType().Name}.{property.propertyPath} expects a scene object tagged \"{value}\", but none exist");
                        added++;
                    }

                    if (added >= 6)
                    {
                        break;
                    }
                }
            }
            catch (Exception)
            {
                // Relationship validation is advisory and must not break scene validation.
            }

            return added;
        }

        private static int AppendScriptSourceLookupContractWarnings(
            MonoBehaviour component,
            string ownerPath,
            SceneRelationshipIndex index,
            Dictionary<string, ScriptLookupContracts> scriptContracts,
            List<string> warnings)
        {
            if (component == null || index == null || warnings == null)
            {
                return 0;
            }

            MonoScript script = MonoScript.FromMonoBehaviour(component);
            string scriptPath = script == null ? string.Empty : AssetDatabase.GetAssetPath(script);
            if (string.IsNullOrWhiteSpace(scriptPath))
            {
                return 0;
            }

            if (scriptContracts == null)
            {
                scriptContracts = new Dictionary<string, ScriptLookupContracts>(StringComparer.OrdinalIgnoreCase);
            }

            if (!scriptContracts.TryGetValue(scriptPath, out ScriptLookupContracts contracts))
            {
                contracts = ReadScriptLookupContracts(scriptPath);
                scriptContracts[scriptPath] = contracts;
            }

            if (contracts == null)
            {
                return 0;
            }

            Dictionary<string, string> serializedStrings = GetSerializedStringValues(component);
            bool hasAssignedPrefabLikeReference = HasAssignedPrefabLikeReference(component);
            int added = 0;

            foreach (string argument in contracts.SceneNamePrefixArguments)
            {
                if (!TryResolveLookupArgument(argument, serializedStrings, out string prefix) ||
                    string.IsNullOrWhiteSpace(prefix) ||
                    index.HasSceneObjectNamePrefix(prefix))
                {
                    continue;
                }

                AppendUniqueWarning(warnings, $"{ownerPath} {component.GetType().Name} looks up scene objects by name prefix \"{prefix}\", but no scene object matches");
                added++;
            }

            foreach (string argument in contracts.SceneNameArguments)
            {
                if (!TryResolveLookupArgument(argument, serializedStrings, out string objectName) ||
                    string.IsNullOrWhiteSpace(objectName) ||
                    index.HasSceneObjectName(objectName))
                {
                    continue;
                }

                AppendUniqueWarning(warnings, $"{ownerPath} {component.GetType().Name} looks up scene object \"{objectName}\", but it does not exist");
                added++;
            }

            foreach (string argument in contracts.TagArguments)
            {
                if (!TryResolveLookupArgument(argument, serializedStrings, out string tag) ||
                    string.IsNullOrWhiteSpace(tag) ||
                    index.HasSceneObjectWithTag(tag))
                {
                    continue;
                }

                AppendUniqueWarning(warnings, $"{ownerPath} {component.GetType().Name} looks up tag \"{tag}\", but no scene object uses that tag");
                added++;
            }

            if (!hasAssignedPrefabLikeReference)
            {
                foreach (string resourcePath in contracts.ResourcePaths)
                {
                    if (string.IsNullOrWhiteSpace(resourcePath) || ResourcesPathHasAssets(resourcePath))
                    {
                        continue;
                    }

                    AppendUniqueWarning(warnings, $"{ownerPath} {component.GetType().Name} falls back to Resources.Load path \"{resourcePath}\", but no matching asset exists under Assets/Resources");
                    added++;
                }
            }

            return added;
        }

        private static ScriptLookupContracts ReadScriptLookupContracts(string scriptPath)
        {
            ScriptLookupContracts contracts = new ScriptLookupContracts();
            if (string.IsNullOrWhiteSpace(scriptPath) || !File.Exists(scriptPath))
            {
                return contracts;
            }

            string source;
            try
            {
                source = File.ReadAllText(scriptPath, Encoding.UTF8);
            }
            catch (Exception)
            {
                return contracts;
            }

            AddRegexArguments(source, @"\.name\.StartsWith\s*\(\s*(?<arg>""[^""]+""|[A-Za-z_][A-Za-z0-9_]*)", contracts.SceneNamePrefixArguments);
            AddRegexArguments(source, @"GameObject\.Find\s*\(\s*(?<arg>""[^""]+""|[A-Za-z_][A-Za-z0-9_]*)", contracts.SceneNameArguments);
            AddRegexArguments(source, @"(?:FindGameObjectWithTag|FindWithTag|CompareTag)\s*\(\s*(?<arg>""[^""]+""|[A-Za-z_][A-Za-z0-9_]*)", contracts.TagArguments);
            AddRegexArguments(source, @"Resources\.Load(?:All)?(?:<[^>]+>)?\s*\(\s*(?<arg>""[^""]+"")", contracts.ResourcePaths);
            return contracts;
        }

        private static void AddRegexArguments(string source, string pattern, List<string> arguments)
        {
            if (string.IsNullOrWhiteSpace(source) || arguments == null)
            {
                return;
            }

            foreach (Match match in Regex.Matches(source, pattern))
            {
                string argument = match.Groups["arg"].Value;
                if (!string.IsNullOrWhiteSpace(argument) && !arguments.Contains(argument))
                {
                    arguments.Add(argument.Trim());
                }
            }
        }

        private static Dictionary<string, string> GetSerializedStringValues(MonoBehaviour component)
        {
            Dictionary<string, string> values = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);
            if (component == null)
            {
                return values;
            }

            try
            {
                SerializedObject serializedObject = new SerializedObject(component);
                SerializedProperty property = serializedObject.GetIterator();
                bool enterChildren = true;
                while (property.NextVisible(enterChildren))
                {
                    enterChildren = false;
                    if (property.propertyType != SerializedPropertyType.String || string.IsNullOrWhiteSpace(property.stringValue))
                    {
                        continue;
                    }

                    values[property.propertyPath] = property.stringValue;
                    values[property.name] = property.stringValue;
                }
            }
            catch (Exception)
            {
                // Ignore non-serializable custom components.
            }

            return values;
        }

        private static bool HasAssignedPrefabLikeReference(MonoBehaviour component)
        {
            if (component == null)
            {
                return false;
            }

            try
            {
                SerializedObject serializedObject = new SerializedObject(component);
                SerializedProperty property = serializedObject.GetIterator();
                bool enterChildren = true;
                while (property.NextVisible(enterChildren))
                {
                    enterChildren = false;
                    if (!IsImportantSerializedReferenceField(property.propertyPath))
                    {
                        continue;
                    }

                    if (property.propertyType == SerializedPropertyType.ObjectReference && property.objectReferenceValue != null)
                    {
                        return true;
                    }

                    if (property.isArray && property.propertyType != SerializedPropertyType.String)
                    {
                        for (int i = 0; i < property.arraySize; i++)
                        {
                            SerializedProperty element = property.GetArrayElementAtIndex(i);
                            if (element != null &&
                                element.propertyType == SerializedPropertyType.ObjectReference &&
                                element.objectReferenceValue != null)
                            {
                                return true;
                            }
                        }
                    }
                }
            }
            catch (Exception)
            {
                return false;
            }

            return false;
        }

        private static bool TryResolveLookupArgument(string argument, Dictionary<string, string> serializedStrings, out string value)
        {
            value = string.Empty;
            if (string.IsNullOrWhiteSpace(argument))
            {
                return false;
            }

            string trimmed = argument.Trim();
            if (trimmed.Length >= 2 && trimmed[0] == '"' && trimmed[trimmed.Length - 1] == '"')
            {
                value = trimmed.Substring(1, trimmed.Length - 2);
                return !string.IsNullOrWhiteSpace(value);
            }

            if (serializedStrings != null && serializedStrings.TryGetValue(trimmed, out string serializedValue))
            {
                value = serializedValue;
                return !string.IsNullOrWhiteSpace(value);
            }

            return false;
        }

        private static bool ResourcesPathHasAssets(string resourcePath)
        {
            if (string.IsNullOrWhiteSpace(resourcePath))
            {
                return false;
            }

            string normalized = resourcePath.Trim().Trim('/');
            string folder = "Assets/Resources";
            string directAssetPrefix = folder + "/" + normalized;
            string directory = directAssetPrefix;
            if (AssetDatabase.IsValidFolder(directory))
            {
                string[] guids = AssetDatabase.FindAssets(string.Empty, new[] { directory });
                return guids != null && guids.Length > 0;
            }

            string[] allGuids = AssetDatabase.FindAssets(string.Empty, new[] { folder });
            foreach (string guid in allGuids ?? Array.Empty<string>())
            {
                string path = AssetDatabase.GUIDToAssetPath(guid);
                if (!string.IsNullOrWhiteSpace(path) &&
                    path.StartsWith(directAssetPrefix, StringComparison.OrdinalIgnoreCase))
                {
                    return true;
                }
            }

            return false;
        }

        private static bool IsSceneNamePrefixField(string propertyKey)
        {
            if (string.IsNullOrWhiteSpace(propertyKey))
            {
                return false;
            }

            return propertyKey.IndexOf("prefix", StringComparison.OrdinalIgnoreCase) >= 0 &&
                ContainsAny(propertyKey, "spawn", "enemy", "player", "bullet", "projectile", "point", "marker", "wave", "manager", "target");
        }

        private static bool IsSceneTagLookupField(string propertyKey)
        {
            if (string.IsNullOrWhiteSpace(propertyKey))
            {
                return false;
            }

            return propertyKey.IndexOf("tag", StringComparison.OrdinalIgnoreCase) >= 0 &&
                ContainsAny(propertyKey, "player", "enemy", "target", "bullet", "projectile", "pickup", "damage", "goal");
        }

        private static bool ShouldSkipSerializedReferenceValidation(SerializedProperty property)
        {
            if (property == null)
            {
                return true;
            }

            return property.propertyPath == "m_Script" ||
                property.propertyPath == "m_PrefabInstance" ||
                property.propertyPath == "m_PrefabAsset" ||
                property.propertyPath == "m_GameObject";
        }

        private static bool IsImportantSerializedReferenceField(string propertyPath)
        {
            string normalized = NormalizeSettingKey(propertyPath);
            if (string.IsNullOrWhiteSpace(normalized))
            {
                return false;
            }

            return normalized.IndexOf("prefab", StringComparison.OrdinalIgnoreCase) >= 0 ||
                normalized.IndexOf("spawn", StringComparison.OrdinalIgnoreCase) >= 0 ||
                normalized.IndexOf("target", StringComparison.OrdinalIgnoreCase) >= 0 ||
                normalized.IndexOf("player", StringComparison.OrdinalIgnoreCase) >= 0 ||
                normalized.IndexOf("enemy", StringComparison.OrdinalIgnoreCase) >= 0 ||
                normalized.IndexOf("bullet", StringComparison.OrdinalIgnoreCase) >= 0 ||
                normalized.IndexOf("projectile", StringComparison.OrdinalIgnoreCase) >= 0 ||
                normalized.IndexOf("canvas", StringComparison.OrdinalIgnoreCase) >= 0 ||
                normalized.IndexOf("text", StringComparison.OrdinalIgnoreCase) >= 0 ||
                normalized.IndexOf("button", StringComparison.OrdinalIgnoreCase) >= 0 ||
                normalized.IndexOf("overlay", StringComparison.OrdinalIgnoreCase) >= 0 ||
                normalized.IndexOf("ui", StringComparison.OrdinalIgnoreCase) >= 0 ||
                normalized.IndexOf("profile", StringComparison.OrdinalIgnoreCase) >= 0 ||
                normalized.IndexOf("controller", StringComparison.OrdinalIgnoreCase) >= 0 ||
                normalized.IndexOf("clip", StringComparison.OrdinalIgnoreCase) >= 0 ||
                normalized.IndexOf("material", StringComparison.OrdinalIgnoreCase) >= 0 ||
                normalized.IndexOf("asset", StringComparison.OrdinalIgnoreCase) >= 0;
        }

        private struct AssetReferenceExpectation
        {
            public readonly string DisplayName;
            public readonly string SearchFilter;

            public AssetReferenceExpectation(string displayName, string searchFilter)
            {
                DisplayName = displayName;
                SearchFilter = searchFilter;
            }
        }

        private struct AssetCandidate
        {
            public readonly string Path;
            public readonly int Score;

            public AssetCandidate(string path, int score)
            {
                Path = path;
                Score = score;
            }
        }

        private struct RuntimeScriptPackageDependencies
        {
            public bool UsesCinemachine;
            public bool UsesCinemachineCamera;
            public bool UsesCinemachineImpulse;
        }

        private sealed class SceneRelationshipIndex
        {
            public readonly List<GameObject> Objects = new List<GameObject>();

            public bool HasSceneObjectName(string objectName)
            {
                if (string.IsNullOrWhiteSpace(objectName))
                {
                    return false;
                }

                foreach (GameObject gameObject in Objects)
                {
                    if (gameObject != null &&
                        string.Equals(gameObject.name, objectName.Trim(), StringComparison.OrdinalIgnoreCase))
                    {
                        return true;
                    }
                }

                return false;
            }

            public bool HasSceneObjectNamePrefix(string prefix)
            {
                if (string.IsNullOrWhiteSpace(prefix))
                {
                    return false;
                }

                foreach (GameObject gameObject in Objects)
                {
                    if (gameObject != null &&
                        gameObject.name.StartsWith(prefix.Trim(), StringComparison.OrdinalIgnoreCase))
                    {
                        return true;
                    }
                }

                return false;
            }

            public bool HasSceneObjectWithTag(string tag)
            {
                if (string.IsNullOrWhiteSpace(tag) ||
                    string.Equals(tag.Trim(), "Untagged", StringComparison.OrdinalIgnoreCase))
                {
                    return false;
                }

                foreach (GameObject gameObject in Objects)
                {
                    if (gameObject == null)
                    {
                        continue;
                    }

                    try
                    {
                        if (string.Equals(gameObject.tag, tag.Trim(), StringComparison.OrdinalIgnoreCase))
                        {
                            return true;
                        }
                    }
                    catch (Exception)
                    {
                        // A stale or invalid tag should be reported by the object reference that uses it.
                    }
                }

                return false;
            }
        }

        private sealed class ScriptLookupContracts
        {
            public readonly List<string> SceneNamePrefixArguments = new List<string>();
            public readonly List<string> SceneNameArguments = new List<string>();
            public readonly List<string> TagArguments = new List<string>();
            public readonly List<string> ResourcePaths = new List<string>();
        }

        private static void AppendMissingAssetCandidateWarningIfNeeded(Component component, string propertyPath, List<string> warnings)
        {
            if (warnings == null || string.IsNullOrWhiteSpace(propertyPath) ||
                !TryGetAssetReferenceExpectation(propertyPath, out AssetReferenceExpectation expectation))
            {
                return;
            }

            List<string> tokens = ExtractAssetReferenceTokens(component, propertyPath);
            if (tokens.Count == 0)
            {
                return;
            }

            string owner = component == null ? "Component" : component.GetType().Name;
            string tokenSummary = string.Join(" ", tokens.ToArray());
            List<string> candidates = FindAssetReferenceCandidates(expectation.SearchFilter, tokens, 3);
            if (candidates.Count == 0)
            {
                AppendUniqueWarning(
                    warnings,
                    $"No {expectation.DisplayName} assets matching {tokenSummary} were found for {owner}.{propertyPath}; create one and assign it.");
                return;
            }

            AppendUniqueWarning(
                warnings,
                $"{owner}.{propertyPath} is not wired; candidate {expectation.DisplayName} assets exist: {string.Join(", ", candidates.ToArray())}");
        }

        private static bool TryGetAssetReferenceExpectation(string propertyPath, out AssetReferenceExpectation expectation)
        {
            expectation = default;
            string normalized = NormalizeSettingKey(propertyPath);
            if (string.IsNullOrWhiteSpace(normalized))
            {
                return false;
            }

            if (normalized.IndexOf("prefab", StringComparison.OrdinalIgnoreCase) >= 0)
            {
                expectation = new AssetReferenceExpectation("prefab", "t:Prefab");
                return true;
            }

            if (normalized.IndexOf("material", StringComparison.OrdinalIgnoreCase) >= 0)
            {
                expectation = new AssetReferenceExpectation("material", "t:Material");
                return true;
            }

            if (normalized.IndexOf("shader", StringComparison.OrdinalIgnoreCase) >= 0)
            {
                expectation = new AssetReferenceExpectation("shader", "t:Shader");
                return true;
            }

            if (normalized.IndexOf("sprite", StringComparison.OrdinalIgnoreCase) >= 0 ||
                normalized.IndexOf("texture", StringComparison.OrdinalIgnoreCase) >= 0 ||
                normalized.IndexOf("icon", StringComparison.OrdinalIgnoreCase) >= 0)
            {
                expectation = new AssetReferenceExpectation("sprite/texture", "t:Texture2D");
                return true;
            }

            if (normalized.IndexOf("audioclip", StringComparison.OrdinalIgnoreCase) >= 0 ||
                normalized.IndexOf("audio", StringComparison.OrdinalIgnoreCase) >= 0 ||
                normalized.IndexOf("sound", StringComparison.OrdinalIgnoreCase) >= 0 ||
                normalized.IndexOf("music", StringComparison.OrdinalIgnoreCase) >= 0)
            {
                expectation = new AssetReferenceExpectation("audio clip", "t:AudioClip");
                return true;
            }

            if (normalized.IndexOf("animationclip", StringComparison.OrdinalIgnoreCase) >= 0 ||
                (normalized.IndexOf("animation", StringComparison.OrdinalIgnoreCase) >= 0 &&
                 normalized.IndexOf("clip", StringComparison.OrdinalIgnoreCase) >= 0))
            {
                expectation = new AssetReferenceExpectation("animation clip", "t:AnimationClip");
                return true;
            }

            if (normalized.IndexOf("animatorcontroller", StringComparison.OrdinalIgnoreCase) >= 0 ||
                normalized.IndexOf("runtimeanimator", StringComparison.OrdinalIgnoreCase) >= 0)
            {
                expectation = new AssetReferenceExpectation("animator controller", "t:AnimatorController");
                return true;
            }

            if (normalized.IndexOf("inputaction", StringComparison.OrdinalIgnoreCase) >= 0 ||
                normalized.IndexOf("actionasset", StringComparison.OrdinalIgnoreCase) >= 0)
            {
                expectation = new AssetReferenceExpectation("input action asset", "t:InputActionAsset");
                return true;
            }

            if (normalized.IndexOf("volumeprofile", StringComparison.OrdinalIgnoreCase) >= 0 ||
                normalized.IndexOf("postprocessingprofile", StringComparison.OrdinalIgnoreCase) >= 0 ||
                normalized.IndexOf("profile", StringComparison.OrdinalIgnoreCase) >= 0)
            {
                expectation = new AssetReferenceExpectation("profile asset", "t:VolumeProfile");
                return true;
            }

            if (normalized.IndexOf("scene", StringComparison.OrdinalIgnoreCase) >= 0)
            {
                expectation = new AssetReferenceExpectation("scene asset", "t:SceneAsset");
                return true;
            }

            if (normalized.IndexOf("clip", StringComparison.OrdinalIgnoreCase) >= 0)
            {
                expectation = new AssetReferenceExpectation("clip asset", string.Empty);
                return true;
            }

            if (normalized.IndexOf("asset", StringComparison.OrdinalIgnoreCase) >= 0)
            {
                expectation = new AssetReferenceExpectation("asset", string.Empty);
                return true;
            }

            return false;
        }

        private static List<string> ExtractAssetReferenceTokens(Component component, string propertyPath)
        {
            List<string> tokens = new List<string>();
            AddAssetReferenceTokens(tokens, propertyPath);
            if (tokens.Count == 0 && component != null)
            {
                AddAssetReferenceTokens(tokens, component.GetType().Name);
            }

            return tokens;
        }

        private static void AddAssetReferenceTokens(List<string> tokens, string value)
        {
            if (tokens == null || string.IsNullOrWhiteSpace(value))
            {
                return;
            }

            StringBuilder current = new StringBuilder();
            char previous = '\0';
            foreach (char character in value)
            {
                if (!char.IsLetterOrDigit(character))
                {
                    AddAssetReferenceToken(tokens, current);
                    previous = '\0';
                    continue;
                }

                if (current.Length > 0 &&
                    char.IsUpper(character) &&
                    (char.IsLower(previous) || char.IsDigit(previous)))
                {
                    AddAssetReferenceToken(tokens, current);
                }

                current.Append(char.ToLowerInvariant(character));
                previous = character;
            }

            AddAssetReferenceToken(tokens, current);
        }

        private static void AddAssetReferenceToken(List<string> tokens, StringBuilder current)
        {
            if (tokens == null || current == null || current.Length == 0)
            {
                return;
            }

            string token = current.ToString().Trim('_', '-').ToLowerInvariant();
            current.Length = 0;
            token = SingularizeAssetReferenceToken(token);
            if (token.Length < 3 ||
                IsSearchStopWord(token) ||
                IsGenericAssetReferenceToken(token) ||
                tokens.Contains(token))
            {
                return;
            }

            tokens.Add(token);
        }

        private static string SingularizeAssetReferenceToken(string token)
        {
            if (string.IsNullOrWhiteSpace(token))
            {
                return string.Empty;
            }

            if (token.Length > 4 && token.EndsWith("ies", StringComparison.Ordinal))
            {
                return token.Substring(0, token.Length - 3) + "y";
            }

            if (token.Length > 4 && token.EndsWith("s", StringComparison.Ordinal))
            {
                return token.Substring(0, token.Length - 1);
            }

            return token;
        }

        private static bool IsGenericAssetReferenceToken(string token)
        {
            switch (token)
            {
                case "array":
                case "asset":
                case "component":
                case "controller":
                case "data":
                case "default":
                case "element":
                case "field":
                case "gameobject":
                case "list":
                case "manager":
                case "material":
                case "object":
                case "point":
                case "prefab":
                case "profile":
                case "reference":
                case "scene":
                case "setting":
                case "spawn":
                case "sprite":
                case "target":
                case "texture":
                case "transform":
                    return true;
                default:
                    return false;
            }
        }

        private static List<string> FindAssetReferenceCandidates(string searchFilter, List<string> tokens, int maxCount)
        {
            List<AssetCandidate> candidates = new List<AssetCandidate>();
            if (tokens == null || tokens.Count == 0 || maxCount <= 0)
            {
                return new List<string>();
            }

            string[] guids;
            try
            {
                guids = AssetDatabase.FindAssets(searchFilter ?? string.Empty, new[] { "Assets" });
            }
            catch (Exception)
            {
                guids = Array.Empty<string>();
            }

            foreach (string guid in guids)
            {
                string path = AssetDatabase.GUIDToAssetPath(guid);
                if (string.IsNullOrWhiteSpace(path))
                {
                    continue;
                }

                int score = ScoreSearchText(path, tokens);
                if (score <= 0)
                {
                    continue;
                }

                InsertAssetCandidate(candidates, new AssetCandidate(path, score), maxCount);
            }

            List<string> paths = new List<string>();
            foreach (AssetCandidate candidate in candidates)
            {
                paths.Add(candidate.Path);
            }

            return paths;
        }

        private static void InsertAssetCandidate(List<AssetCandidate> candidates, AssetCandidate candidate, int maxCount)
        {
            int index = 0;
            while (index < candidates.Count && candidates[index].Score >= candidate.Score)
            {
                index++;
            }

            candidates.Insert(index, candidate);
            if (candidates.Count > maxCount)
            {
                candidates.RemoveAt(candidates.Count - 1);
            }
        }

        private static void AppendUniqueWarning(List<string> warnings, string warning)
        {
            if (warnings == null || string.IsNullOrWhiteSpace(warning) || warnings.Contains(warning))
            {
                return;
            }

            warnings.Add(warning);
        }

        private static bool NameContainsAny(string value, params string[] needles)
        {
            string normalized = (value ?? string.Empty).ToLowerInvariant();
            foreach (string needle in needles)
            {
                if (!string.IsNullOrWhiteSpace(needle) && normalized.Contains(needle.ToLowerInvariant()))
                {
                    return true;
                }
            }

            return false;
        }

        private static bool MentionsPostProcessingWorkflow(string prompt)
        {
            string normalized = NormalizeIntentText(prompt);
            return ContainsAny(normalized, "post processing", "post-processing", "postprocess", "bloom", "vignette");
        }

        private static bool MentionsBlackCameraBackground(string prompt)
        {
            string normalized = NormalizeIntentText(prompt);
            return ContainsAny(normalized, "background color", "camera background", "black background") ||
                (ContainsAny(normalized, "background") && ContainsAny(normalized, "black"));
        }

        private static bool SceneHasBlackSolidColorCameraBackground()
        {
            foreach (GameObject root in SceneManager.GetActiveScene().GetRootGameObjects())
            {
                foreach (Camera camera in root.GetComponentsInChildren<Camera>(true))
                {
                    if (camera == null || !camera.enabled)
                    {
                        continue;
                    }

                    if (camera.clearFlags == CameraClearFlags.SolidColor &&
                        IsApproximatelyBlack(camera.backgroundColor))
                    {
                        return true;
                    }
                }
            }

            return false;
        }

        private static bool IsApproximatelyBlack(Color color)
        {
            return color.r <= 0.02f && color.g <= 0.02f && color.b <= 0.02f;
        }

#if ARK_HAS_URP
        private static bool HasAnyActiveVolumeOverride(VolumeProfile profile)
        {
            if (profile == null || profile.components == null)
            {
                return false;
            }

            foreach (VolumeComponent component in profile.components)
            {
                if (component != null && component.active)
                {
                    return true;
                }
            }

            return false;
        }
#endif

#if ARK_HAS_URP
        private static bool HasActiveVolumeOverrideType(VolumeProfile profile, string typeName)
        {
            if (profile == null || profile.components == null || string.IsNullOrWhiteSpace(typeName))
            {
                return false;
            }

            foreach (VolumeComponent component in profile.components)
            {
                if (component == null || !component.active)
                {
                    continue;
                }

                Type type = component.GetType();
                if (string.Equals(type.Name, typeName, StringComparison.Ordinal) ||
                    string.Equals(type.FullName, typeName, StringComparison.Ordinal))
                {
                    return true;
                }
            }

            return false;
        }
#endif

#if ARK_HAS_URP
        private static bool SceneHasActiveGlobalVolumeOverrides()
        {
            foreach (GameObject root in SceneManager.GetActiveScene().GetRootGameObjects())
            {
                foreach (Volume volume in root.GetComponentsInChildren<Volume>(true))
                {
                    if (volume != null &&
                        volume.enabled &&
                        volume.isGlobal &&
                        HasAnyActiveVolumeOverride(volume.sharedProfile))
                    {
                        return true;
                    }
                }
            }

            return false;
        }
#else
        private static bool SceneHasActiveGlobalVolumeOverrides()
        {
            return false;
        }
#endif

#if ARK_HAS_URP
        private static bool SceneHasActiveGlobalVolumeOverrideType(string typeName)
        {
            foreach (GameObject root in SceneManager.GetActiveScene().GetRootGameObjects())
            {
                foreach (Volume volume in root.GetComponentsInChildren<Volume>(true))
                {
                    if (volume != null &&
                        volume.enabled &&
                        volume.isGlobal &&
                        HasActiveVolumeOverrideType(volume.sharedProfile, typeName))
                    {
                        return true;
                    }
                }
            }

            return false;
        }
#else
        private static bool SceneHasActiveGlobalVolumeOverrideType(string typeName)
        {
            return false;
        }
#endif

        private static bool SceneHasCameraWithEnabledUrpPostProcessing()
        {
            foreach (GameObject root in SceneManager.GetActiveScene().GetRootGameObjects())
            {
                foreach (Camera camera in root.GetComponentsInChildren<Camera>(true))
                {
                    if (camera == null || !camera.enabled)
                    {
                        continue;
                    }

                    foreach (Component component in camera.GetComponents<Component>())
                    {
                        if (component == null)
                        {
                            continue;
                        }

                        Type type = component.GetType();
                        if (!string.Equals(type.Name, "UniversalAdditionalCameraData", StringComparison.Ordinal) &&
                            !string.Equals(type.FullName, "UnityEngine.Rendering.Universal.UniversalAdditionalCameraData", StringComparison.Ordinal))
                        {
                            continue;
                        }

                        SerializedObject serializedObject = new SerializedObject(component);
                        SerializedProperty property = serializedObject.FindProperty("m_RenderPostProcessing");
                        if (property != null && property.propertyType == SerializedPropertyType.Boolean && property.boolValue)
                        {
                            return true;
                        }
                    }
                }
            }

            return false;
        }

        private static bool IsUrpCameraPostProcessingDisabled(Camera camera)
        {
            if (camera == null)
            {
                return false;
            }

            foreach (Component component in camera.GetComponents<Component>())
            {
                if (component == null)
                {
                    continue;
                }

                Type type = component.GetType();
                if (!string.Equals(type.Name, "UniversalAdditionalCameraData", StringComparison.Ordinal) &&
                    !string.Equals(type.FullName, "UnityEngine.Rendering.Universal.UniversalAdditionalCameraData", StringComparison.Ordinal))
                {
                    continue;
                }

                SerializedObject serializedObject = new SerializedObject(component);
                SerializedProperty property = serializedObject.FindProperty("m_RenderPostProcessing");
                return property != null && property.propertyType == SerializedPropertyType.Boolean && !property.boolValue;
            }

            return false;
        }

        private static void QueuePendingScriptAttachment(string target, string component)
        {
            PendingScriptAttachmentState state = LoadPendingScriptAttachments();
            List<PendingScriptAttachment> attachments = new List<PendingScriptAttachment>();
            if (state.attachments != null)
            {
                attachments.AddRange(state.attachments);
            }

            attachments.Add(new PendingScriptAttachment
            {
                target = target.Trim(),
                component = component.Trim()
            });

            state.attachments = attachments.ToArray();
            EditorPrefs.SetString(PendingScriptAttachmentsPrefsKey, JsonUtility.ToJson(state));
            EditorApplication.delayCall += ApplyPendingScriptAttachments;
        }

        private static void RequestDeferredScriptRefresh()
        {
            pendingDeferredScriptRefresh = true;
            ScheduleDeferredScriptRefresh();
        }

        private static void ScheduleDeferredScriptRefresh()
        {
            if (deferredScriptRefreshScheduled)
            {
                return;
            }

            deferredScriptRefreshScheduled = true;
            EditorApplication.delayCall += FlushDeferredScriptRefresh;
        }

        private static void FlushDeferredScriptRefresh()
        {
            deferredScriptRefreshScheduled = false;
            if (!pendingDeferredScriptRefresh)
            {
                return;
            }

            if (EditorApplication.isCompiling || EditorApplication.isUpdating)
            {
                ScheduleDeferredScriptRefresh();
                return;
            }

            pendingDeferredScriptRefresh = false;
            AssetDatabase.Refresh();
        }

        private static bool ShouldDeferRefreshForScriptCompilation(string path)
        {
            string extension = Path.GetExtension(path);
            if (string.IsNullOrWhiteSpace(extension))
            {
                return false;
            }

            switch (extension.ToLowerInvariant())
            {
                case ".asmdef":
                case ".asmref":
                case ".cs":
                case ".rsp":
                    return true;
                default:
                    return false;
            }
        }

        private static void ApplyPendingScriptAttachments()
        {
            PendingScriptAttachmentState state = LoadPendingScriptAttachments();
            if (state.attachments == null || state.attachments.Length == 0)
            {
                return;
            }

            if (EditorApplication.isCompiling || EditorApplication.isUpdating)
            {
                EditorApplication.delayCall += ApplyPendingScriptAttachments;
                return;
            }

            List<PendingScriptAttachment> remaining = new List<PendingScriptAttachment>();
            foreach (PendingScriptAttachment attachment in state.attachments)
            {
                if (attachment == null || string.IsNullOrWhiteSpace(attachment.target) || string.IsNullOrWhiteSpace(attachment.component))
                {
                    continue;
                }

                GameObject target = FindTarget(attachment.target);
                Type componentType = FindComponentType(attachment.component);
                if (target == null || componentType == null)
                {
                    attachment.attempts++;
                    if (attachment.attempts <= MaxPendingScriptAttachmentAttempts)
                    {
                        remaining.Add(attachment);
                    }
                    else
                    {
                        Debug.LogWarning($"Ark could not attach script {attachment.component} to {attachment.target}. The target or compiled component type was not found.");
                    }

                    continue;
                }

                if (target.GetComponent(componentType) == null)
                {
                    Undo.AddComponent(target, componentType);
                    EditorSceneManager.MarkSceneDirty(SceneManager.GetActiveScene());
                    Debug.Log($"Ark attached compiled script {componentType.Name} to {GetHierarchyPath(target)}.");
                }
            }

            if (remaining.Count == 0)
            {
                EditorPrefs.DeleteKey(PendingScriptAttachmentsPrefsKey);
            }
            else
            {
                state.attachments = remaining.ToArray();
                EditorPrefs.SetString(PendingScriptAttachmentsPrefsKey, JsonUtility.ToJson(state));
                EditorApplication.delayCall += ApplyPendingScriptAttachments;
            }
        }

        private static PendingScriptAttachmentState LoadPendingScriptAttachments()
        {
            string json = EditorPrefs.GetString(PendingScriptAttachmentsPrefsKey, string.Empty);
            if (string.IsNullOrWhiteSpace(json))
            {
                return new PendingScriptAttachmentState
                {
                    attachments = new PendingScriptAttachment[0]
                };
            }

            try
            {
                PendingScriptAttachmentState state = JsonUtility.FromJson<PendingScriptAttachmentState>(json);
                return state ?? new PendingScriptAttachmentState
                {
                    attachments = new PendingScriptAttachment[0]
                };
            }
            catch (Exception)
            {
                EditorPrefs.DeleteKey(PendingScriptAttachmentsPrefsKey);
                return new PendingScriptAttachmentState
                {
                    attachments = new PendingScriptAttachment[0]
                };
            }
        }

        private static void ApplyTransform(Transform transform, AgentAction action)
        {
            if (action.use_position)
            {
                transform.position = action.position.ToVector3();
            }

            if (action.use_rotation)
            {
                transform.eulerAngles = action.rotation.ToVector3();
            }

            if (action.use_scale)
            {
                transform.localScale = action.scale.ToVector3();
            }
        }

        private static void ApplyParent(GameObject gameObject, string parentPath)
        {
            if (string.IsNullOrWhiteSpace(parentPath))
            {
                return;
            }

            GameObject parent = FindTarget(parentPath);
            if (parent != null)
            {
                gameObject.transform.SetParent(parent.transform);
            }
        }

        private static bool ApplySerializedValue(SerializedProperty property, AgentAction action)
        {
            if (property != null && property.isArray && property.propertyType != SerializedPropertyType.String)
            {
                return ApplySerializedArrayValue(property, action);
            }

            switch (property.propertyType)
            {
                case SerializedPropertyType.Integer:
                    property.intValue = ParseInt(action.value, action.int_value);
                    return true;

                case SerializedPropertyType.Boolean:
                    property.boolValue = ParseBool(action.value, action.bool_value);
                    return true;

                case SerializedPropertyType.Float:
                    property.floatValue = ParseFloat(action.value, action.float_value);
                    return true;

                case SerializedPropertyType.String:
                    property.stringValue = action.value ?? string.Empty;
                    return true;

                case SerializedPropertyType.Color:
                    property.colorValue = ParseColor(action.value, ParseColor(action.color, property.colorValue));
                    return true;

                case SerializedPropertyType.ObjectReference:
                    property.objectReferenceValue = ResolveObjectReference(property, action);
                    return true;

                case SerializedPropertyType.Enum:
                    property.enumValueIndex = ResolveEnumIndex(property, action);
                    return true;

                case SerializedPropertyType.Vector2:
                    property.vector2Value = ResolveVector2SerializedValue(property, action);
                    return true;

                case SerializedPropertyType.Vector3:
                    property.vector3Value = ResolveVector3SerializedValue(property, action);
                    return true;

                case SerializedPropertyType.Vector4:
                    property.vector4Value = action.position.ToVector4();
                    return true;

                case SerializedPropertyType.Rect:
                    property.rectValue = new Rect(action.position.x, action.position.y, action.scale.x, action.scale.y);
                    return true;

                case SerializedPropertyType.Bounds:
                    property.boundsValue = new Bounds(action.position.ToVector3(), action.scale.ToVector3());
                    return true;

                default:
                    return false;
            }
        }

        private static bool ApplySerializedArrayValue(SerializedProperty property, AgentAction action)
        {
            if (property == null || action == null || !property.isArray || property.propertyType == SerializedPropertyType.String)
            {
                return false;
            }

            List<string> referencePaths = CollectReferenceAssetPaths(action);
            if (referencePaths.Count > 0)
            {
                property.arraySize = referencePaths.Count;
                for (int i = 0; i < referencePaths.Count; i++)
                {
                    SerializedProperty element = property.GetArrayElementAtIndex(i);
                    if (element.propertyType != SerializedPropertyType.ObjectReference)
                    {
                        return false;
                    }

                    AgentAction elementAction = CloneAction(action);
                    elementAction.reference_asset_path = referencePaths[i];
                    elementAction.asset_path = string.Empty;
                    Object reference = ResolveObjectReference(element, elementAction);
                    if (reference == null)
                    {
                        return false;
                    }

                    element.objectReferenceValue = reference;
                }

                return true;
            }

            List<string> referenceTargets = CollectReferenceTargets(action);
            if (referenceTargets.Count > 0)
            {
                property.arraySize = referenceTargets.Count;
                for (int i = 0; i < referenceTargets.Count; i++)
                {
                    SerializedProperty element = property.GetArrayElementAtIndex(i);
                    if (element.propertyType != SerializedPropertyType.ObjectReference)
                    {
                        return false;
                    }

                    AgentAction elementAction = CloneAction(action);
                    elementAction.reference_target = referenceTargets[i];
                    elementAction.value = string.Empty;
                    Object reference = ResolveObjectReference(element, elementAction);
                    if (reference == null)
                    {
                        return false;
                    }

                    element.objectReferenceValue = reference;
                }

                return true;
            }

            if (ShouldSetSerializedArraySize(action) &&
                string.IsNullOrWhiteSpace(action.reference_asset_path) &&
                string.IsNullOrWhiteSpace(action.reference_target) &&
                string.IsNullOrWhiteSpace(action.asset_path))
            {
                property.arraySize = action.int_value;
                return true;
            }

            return false;
        }

        private static bool ShouldSetSerializedArraySize(AgentAction action)
        {
            if (action == null || action.int_value < 0)
            {
                return false;
            }

            string valueType = NormalizeSettingKey(action.value_type);
            if (valueType == "size" || valueType == "count" || valueType == "length" || valueType == "arraysize")
            {
                return true;
            }

            return string.Equals(action.value, "size", StringComparison.OrdinalIgnoreCase) ||
                string.Equals(action.value, "count", StringComparison.OrdinalIgnoreCase);
        }

        private static List<string> CollectReferenceAssetPaths(AgentAction action)
        {
            List<string> paths = new List<string>();
            if (action == null)
            {
                return paths;
            }

            AddReferenceAssetPath(paths, action.reference_asset_path);
            AddReferenceAssetPath(paths, action.asset_path);

            if (action.paths != null)
            {
                foreach (string path in action.paths)
                {
                    AddReferenceAssetPath(paths, path);
                }
            }

            if (!string.IsNullOrWhiteSpace(action.value) && action.value.IndexOf("Assets/", StringComparison.OrdinalIgnoreCase) >= 0)
            {
                string[] split = action.value.Split(new[] { ',', ';', '\n', '\r' }, StringSplitOptions.RemoveEmptyEntries);
                foreach (string path in split)
                {
                    AddReferenceAssetPath(paths, path.Trim());
                }
            }

            return paths;
        }

        private static List<string> CollectReferenceTargets(AgentAction action)
        {
            List<string> targets = new List<string>();
            if (action == null)
            {
                return targets;
            }

            AddReferenceTarget(targets, action.reference_target);
            if (!string.IsNullOrWhiteSpace(action.value) &&
                action.value.IndexOf("Assets/", StringComparison.OrdinalIgnoreCase) < 0 &&
                !string.Equals(action.value, "size", StringComparison.OrdinalIgnoreCase) &&
                !string.Equals(action.value, "count", StringComparison.OrdinalIgnoreCase))
            {
                string[] split = action.value.Split(new[] { ',', ';', '\n', '\r' }, StringSplitOptions.RemoveEmptyEntries);
                foreach (string target in split)
                {
                    AddReferenceTarget(targets, target.Trim());
                }
            }

            return targets;
        }

        private static void AddReferenceTarget(List<string> targets, string target)
        {
            if (targets == null || string.IsNullOrWhiteSpace(target))
            {
                return;
            }

            string trimmed = target.Trim();
            if (targets.Contains(trimmed))
            {
                return;
            }

            targets.Add(trimmed);
        }

        private static void AddReferenceAssetPath(List<string> paths, string path)
        {
            if (paths == null || string.IsNullOrWhiteSpace(path))
            {
                return;
            }

            string normalizedPath = NormalizeAssetPath(path);
            if (!normalizedPath.StartsWith("Assets/", StringComparison.Ordinal) || paths.Contains(normalizedPath))
            {
                return;
            }

            paths.Add(normalizedPath);
        }

        private static string ValidateSerializedValueInput(SerializedProperty property, AgentAction action)
        {
            if (property == null || action == null)
            {
                return string.Empty;
            }

            if (property.propertyType == SerializedPropertyType.ObjectReference)
            {
                return ValidateSerializedObjectReferenceInput(property, action);
            }

            if (property.propertyType != SerializedPropertyType.Color)
            {
                return string.Empty;
            }

            string rawColor = FirstNonEmpty(action.value, action.color);
            if (string.IsNullOrWhiteSpace(rawColor))
            {
                return $"missing color value for {property.propertyPath}";
            }

            return CanParseColor(rawColor)
                ? string.Empty
                : $"invalid color value for {property.propertyPath}: {rawColor}";
        }

        private static string ValidateSerializedObjectReferenceInput(SerializedProperty property, AgentAction action)
        {
            if (property == null ||
                action == null ||
                property.propertyType != SerializedPropertyType.ObjectReference ||
                !HasExplicitObjectReferenceInput(action))
            {
                return string.Empty;
            }

            Object resolved = ResolveObjectReference(property, action);
            if (resolved != null)
            {
                return string.Empty;
            }

            string reference = FirstNonEmpty(action.reference_asset_path, action.asset_path, action.reference_target, action.value);
            return $"could not resolve object reference for {property.propertyPath}: {reference}";
        }

        private static bool HasExplicitObjectReferenceInput(AgentAction action)
        {
            return action != null &&
                (!string.IsNullOrWhiteSpace(action.reference_asset_path) ||
                    !string.IsNullOrWhiteSpace(action.reference_target) ||
                    LooksLikeAssetPath(action.asset_path) ||
                    LooksLikeAssetPath(action.value));
        }

        private static bool LooksLikeAssetPath(string value)
        {
            return !string.IsNullOrWhiteSpace(value) &&
                NormalizeAssetPath(value).StartsWith("Assets/", StringComparison.Ordinal);
        }

        private static Vector2 ResolveVector2SerializedValue(SerializedProperty property, AgentAction action)
        {
            return ShouldUseScaleSerializedValue(property, action)
                ? action.scale.ToVector2()
                : action.position.ToVector2();
        }

        private static Vector3 ResolveVector3SerializedValue(SerializedProperty property, AgentAction action)
        {
            return ShouldUseScaleSerializedValue(property, action)
                ? action.scale.ToVector3()
                : action.position.ToVector3();
        }

        private static bool ShouldUseScaleSerializedValue(SerializedProperty property, AgentAction action)
        {
            if (action != null && action.use_scale)
            {
                return true;
            }

            string propertyPath = NormalizeSettingKey(property == null ? string.Empty : property.propertyPath);
            return propertyPath.IndexOf("scale", StringComparison.OrdinalIgnoreCase) >= 0 ||
                propertyPath.IndexOf("size", StringComparison.OrdinalIgnoreCase) >= 0;
        }

        private static int ResolveEnumIndex(SerializedProperty property, AgentAction action)
        {
            if (!string.IsNullOrWhiteSpace(action.value))
            {
                for (int i = 0; i < property.enumDisplayNames.Length; i++)
                {
                    if (string.Equals(property.enumDisplayNames[i], action.value, StringComparison.OrdinalIgnoreCase) ||
                        string.Equals(property.enumNames[i], action.value, StringComparison.OrdinalIgnoreCase))
                    {
                        return i;
                    }
                }
            }

            return Mathf.Clamp(action.int_value, 0, Mathf.Max(0, property.enumDisplayNames.Length - 1));
        }

        private static Object ResolveObjectReference(SerializedProperty property, AgentAction action)
        {
            string referencePath = FirstNonEmpty(action.reference_asset_path, action.asset_path);
            if (!string.IsNullOrWhiteSpace(referencePath))
            {
                string normalizedPath = NormalizeAssetPath(referencePath);
                if (IsSpriteReferenceProperty(property))
                {
                    return ResolveSpriteAsset(normalizedPath);
                }

                Object mainAsset = AssetDatabase.LoadAssetAtPath<Object>(normalizedPath);
                if (mainAsset != null)
                {
                    return mainAsset;
                }

                Object[] subAssets = AssetDatabase.LoadAllAssetsAtPath(normalizedPath);
                if (subAssets != null)
                {
                    foreach (Object subAsset in subAssets)
                    {
                        if (subAsset != null)
                        {
                            return subAsset;
                        }
                    }
                }

                return null;
            }

            string referenceTarget = FirstNonEmpty(action.reference_target, action.value);
            if (string.IsNullOrWhiteSpace(referenceTarget))
            {
                return null;
            }

            GameObject gameObject = FindTarget(referenceTarget);
            if (gameObject == null)
            {
                return null;
            }

            string propertyType = property.type ?? string.Empty;
            if (propertyType.IndexOf("Transform", StringComparison.OrdinalIgnoreCase) >= 0)
            {
                return gameObject.transform;
            }

            if (propertyType.IndexOf("GameObject", StringComparison.OrdinalIgnoreCase) >= 0)
            {
                return gameObject;
            }

            foreach (Component component in gameObject.GetComponents<Component>())
            {
                if (component != null &&
                    propertyType.IndexOf(component.GetType().Name, StringComparison.OrdinalIgnoreCase) >= 0)
                {
                    return component;
                }
            }

            return gameObject;
        }

        private static bool IsSpriteReferenceProperty(SerializedProperty property)
        {
            if (property == null)
            {
                return false;
            }

            string type = property.type ?? string.Empty;
            string path = property.propertyPath ?? string.Empty;
            return type.IndexOf("Sprite", StringComparison.OrdinalIgnoreCase) >= 0 ||
                string.Equals(path, "m_Sprite", StringComparison.Ordinal) ||
                path.EndsWith(".m_Sprite", StringComparison.Ordinal);
        }

        private static Sprite ResolveSpriteAsset(string path)
        {
            string normalizedPath = NormalizeAssetPath(path);
            if (string.IsNullOrWhiteSpace(normalizedPath))
            {
                return null;
            }

            Sprite sprite = AssetDatabase.LoadAssetAtPath<Sprite>(normalizedPath);
            if (sprite != null)
            {
                return sprite;
            }

            Object[] assets = AssetDatabase.LoadAllAssetsAtPath(normalizedPath);
            if (assets == null)
            {
                return null;
            }

            string fileName = Path.GetFileNameWithoutExtension(normalizedPath);
            Sprite fallback = null;
            foreach (Object asset in assets)
            {
                if (asset is Sprite candidate)
                {
                    if (fallback == null)
                    {
                        fallback = candidate;
                    }

                    if (string.Equals(candidate.name, fileName, StringComparison.OrdinalIgnoreCase) ||
                        string.Equals(candidate.name, fileName + "_0", StringComparison.OrdinalIgnoreCase))
                    {
                        return candidate;
                    }
                }
            }

            return fallback;
        }

        private static Color EvaluateSpritePixel(string shape, int x, int y, int width, int height, Color primary, Color secondary)
        {
            string normalizedShape = string.IsNullOrWhiteSpace(shape) ? "solid" : shape.Trim().ToLowerInvariant();
            float nx = width <= 1 ? 0f : (x / (float)(width - 1)) * 2f - 1f;
            float ny = height <= 1 ? 0f : (y / (float)(height - 1)) * 2f - 1f;
            Color alternate = secondary.a <= 0f ? Color.clear : secondary;

            switch (normalizedShape)
            {
                case "circle":
                    return nx * nx + ny * ny <= 0.82f ? primary : alternate;

                case "ring":
                    float radius = nx * nx + ny * ny;
                    return radius <= 0.82f && radius >= 0.42f ? primary : alternate;

                case "diamond":
                    return Mathf.Abs(nx) + Mathf.Abs(ny) <= 1f ? primary : alternate;

                case "cross":
                    return Mathf.Abs(nx) < 0.24f || Mathf.Abs(ny) < 0.24f ? primary : alternate;

                case "checker":
                    return ((x / 8) + (y / 8)) % 2 == 0 ? primary : (secondary.a <= 0f ? primary * 0.65f : secondary);

                case "gradient":
                    return Color.Lerp(primary, secondary.a <= 0f ? Color.white : secondary, height <= 1 ? 0f : y / (float)(height - 1));

                default:
                    return primary;
            }
        }

        private static Sprite EnsureDefaultSprite(string shape)
        {
            string normalizedShape = NormalizeSpriteShape(shape);
            string path = $"Assets/AgenticGamedev/Generated/Sprites/Default{char.ToUpperInvariant(normalizedShape[0])}{normalizedShape.Substring(1)}.png";
            Sprite existing = ResolveSpriteAsset(path);
            if (existing != null)
            {
                return existing;
            }

            EnsureAssetFolder(Path.GetDirectoryName(path)?.Replace("\\", "/"));
            int size = 64;
            Texture2D texture = new Texture2D(size, size, TextureFormat.RGBA32, false);
            texture.filterMode = FilterMode.Point;
            for (int y = 0; y < size; y++)
            {
                for (int x = 0; x < size; x++)
                {
                    texture.SetPixel(x, y, EvaluateSpritePixel(normalizedShape, x, y, size, size, Color.white, Color.clear));
                }
            }

            texture.Apply();
            string absolutePath = Path.Combine(Path.GetDirectoryName(Application.dataPath) ?? Directory.GetCurrentDirectory(), path);
            File.WriteAllBytes(absolutePath, texture.EncodeToPNG());
            Object.DestroyImmediate(texture);
            AssetDatabase.ImportAsset(path, ImportAssetOptions.ForceUpdate);

            TextureImporter importer = AssetImporter.GetAtPath(path) as TextureImporter;
            if (importer != null)
            {
                importer.textureType = TextureImporterType.Sprite;
                importer.spritePixelsPerUnit = 32f;
                importer.filterMode = FilterMode.Point;
                importer.mipmapEnabled = false;
                importer.SaveAndReimport();
            }

            return ResolveSpriteAsset(path);
        }

        private static string NormalizeSpriteShape(string shape)
        {
            if (string.IsNullOrWhiteSpace(shape))
            {
                return "square";
            }

            string normalized = shape.Trim().ToLowerInvariant();
            switch (normalized)
            {
                case "circle":
                case "ring":
                case "diamond":
                case "cross":
                case "checker":
                case "gradient":
                    return normalized;
                default:
                    return "square";
            }
        }

        private static List<GameObject> ResolveSpriteTargets(string target)
        {
            List<GameObject> targets = new List<GameObject>();
            if (string.IsNullOrWhiteSpace(target) ||
                string.Equals(target, "scene", StringComparison.OrdinalIgnoreCase) ||
                string.Equals(target, "all", StringComparison.OrdinalIgnoreCase) ||
                string.Equals(target, "everything", StringComparison.OrdinalIgnoreCase))
            {
                foreach (GameObject root in SceneManager.GetActiveScene().GetRootGameObjects())
                {
                    CollectSpriteTargets(root, targets);
                }

                return targets;
            }

            GameObject found = FindTarget(target);
            if (found != null)
            {
                targets.Add(found);
            }

            return targets;
        }

        private static void CollectSpriteTargets(GameObject gameObject, List<GameObject> targets)
        {
            if (gameObject == null)
            {
                return;
            }

            targets.Add(gameObject);
            Transform transform = gameObject.transform;
            for (int i = 0; i < transform.childCount; i++)
            {
                CollectSpriteTargets(transform.GetChild(i).gameObject, targets);
            }
        }

        private static bool ShouldSkipDefaultSpriteTarget(GameObject gameObject)
        {
            return gameObject.GetComponent<Camera>() != null ||
                gameObject.GetComponent<Light>() != null ||
                gameObject.GetComponent<AudioListener>() != null ||
                gameObject.GetComponent("Canvas") != null ||
                gameObject.GetComponent<Tilemap>() != null;
        }

        private static Color? TryParseOptionalColor(string value)
        {
            if (string.IsNullOrWhiteSpace(value))
            {
                return null;
            }

            return ParseColor(value, Color.white);
        }

        private static Color InferDefaultSpriteColor(GameObject gameObject, Color current)
        {
            if (gameObject == null)
            {
                return current.a <= 0f ? Color.white : current;
            }

            string name = gameObject.name.ToLowerInvariant();
            if (name.IndexOf("player_red", StringComparison.Ordinal) >= 0 ||
                (name.IndexOf("player", StringComparison.Ordinal) >= 0 && name.IndexOf("red", StringComparison.Ordinal) >= 0))
            {
                return Color.red;
            }

            if (name.IndexOf("wall", StringComparison.Ordinal) >= 0)
            {
                return Color.white;
            }

            if (current.a <= 0f)
            {
                return Color.white;
            }

            return current;
        }

        private static Color ParseColor(string value, Color fallback)
        {
            if (string.IsNullOrWhiteSpace(value))
            {
                return fallback;
            }

            string color = value.Trim();
            if (!color.StartsWith("#", StringComparison.Ordinal) && color.Length == 6)
            {
                color = $"#{color}";
            }

            if (ColorUtility.TryParseHtmlString(color, out Color parsed))
            {
                return parsed;
            }

            if (TryParseColorComponents(color, out parsed))
            {
                return parsed;
            }

            switch (color.ToLowerInvariant())
            {
                case "black": return Color.black;
                case "blue": return Color.blue;
                case "clear": return Color.clear;
                case "cyan": return Color.cyan;
                case "gray":
                case "grey": return Color.gray;
                case "green": return Color.green;
                case "magenta": return Color.magenta;
                case "red": return Color.red;
                case "white": return Color.white;
                case "yellow": return Color.yellow;
                default: return fallback;
            }
        }

        private static bool CanParseColor(string value)
        {
            if (string.IsNullOrWhiteSpace(value))
            {
                return false;
            }

            string color = value.Trim();
            if (!color.StartsWith("#", StringComparison.Ordinal) && color.Length == 6)
            {
                color = $"#{color}";
            }

            if (ColorUtility.TryParseHtmlString(color, out _))
            {
                return true;
            }

            if (TryParseColorComponents(color, out _))
            {
                return true;
            }

            switch (color.ToLowerInvariant())
            {
                case "black":
                case "blue":
                case "clear":
                case "cyan":
                case "gray":
                case "grey":
                case "green":
                case "magenta":
                case "red":
                case "white":
                case "yellow":
                    return true;
                default:
                    return false;
            }
        }

        private static bool TryParseColorComponents(string value, out Color color)
        {
            color = Color.clear;
            if (string.IsNullOrWhiteSpace(value))
            {
                return false;
            }

            string normalized = value.Trim().Trim('(', ')', '[', ']');
            string[] parts = normalized.Split(new[] { ',', ' ', ';' }, StringSplitOptions.RemoveEmptyEntries);
            if (parts.Length != 3 && parts.Length != 4)
            {
                return false;
            }

            float[] components = new float[4] { 0f, 0f, 0f, 1f };
            for (int i = 0; i < parts.Length; i++)
            {
                if (!float.TryParse(parts[i], NumberStyles.Float, CultureInfo.InvariantCulture, out components[i]))
                {
                    return false;
                }
            }

            bool uses255Range = false;
            for (int i = 0; i < parts.Length; i++)
            {
                if (components[i] > 1f)
                {
                    uses255Range = true;
                    break;
                }
            }

            if (uses255Range)
            {
                for (int i = 0; i < 3; i++)
                {
                    components[i] /= 255f;
                }

                if (parts.Length == 4 && components[3] > 1f)
                {
                    components[3] /= 255f;
                }
            }

            color = new Color(
                Mathf.Clamp01(components[0]),
                Mathf.Clamp01(components[1]),
                Mathf.Clamp01(components[2]),
                Mathf.Clamp01(components[3]));
            return true;
        }

        private static T ParseEnum<T>(string value, T fallback) where T : struct
        {
            if (!string.IsNullOrWhiteSpace(value) && Enum.TryParse(value.Trim(), true, out T parsed))
            {
                return parsed;
            }

            return fallback;
        }

        private static int ParseInt(string value, int fallback)
        {
            return int.TryParse(value, out int parsed) ? parsed : fallback;
        }

        private static float ParseFloat(string value, float fallback)
        {
            return float.TryParse(value, out float parsed) ? parsed : fallback;
        }

        private static bool ParseBool(string value, bool fallback)
        {
            return bool.TryParse(value, out bool parsed) ? parsed : fallback;
        }

        private static GameObject FindTarget(string target)
        {
            if (string.IsNullOrWhiteSpace(target) || string.Equals(target, "selected", StringComparison.OrdinalIgnoreCase))
            {
                return Selection.activeGameObject;
            }

            GameObject direct = GameObject.Find(target);
            if (direct != null)
            {
                return direct;
            }

            foreach (GameObject root in SceneManager.GetActiveScene().GetRootGameObjects())
            {
                GameObject found = FindInChildren(root.transform, target);
                if (found != null)
                {
                    return found;
                }
            }

            return null;
        }

        private static GameObject FindInChildren(Transform transform, string target)
        {
            if (string.Equals(transform.name, target, StringComparison.OrdinalIgnoreCase) ||
                string.Equals(GetHierarchyPath(transform.gameObject), target, StringComparison.OrdinalIgnoreCase))
            {
                return transform.gameObject;
            }

            for (int i = 0; i < transform.childCount; i++)
            {
                GameObject found = FindInChildren(transform.GetChild(i), target);
                if (found != null)
                {
                    return found;
                }
            }

            return null;
        }

        private static Type FindComponentType(string componentName)
        {
            if (string.IsNullOrWhiteSpace(componentName))
            {
                return null;
            }

            Type type = FindType(componentName);
            return type != null && typeof(Component).IsAssignableFrom(type) ? type : null;
        }

        private static Type FindType(string typeName)
        {
            if (string.IsNullOrWhiteSpace(typeName))
            {
                return null;
            }

            string normalized = typeName.Replace(" ", string.Empty);
            foreach (Assembly assembly in AppDomain.CurrentDomain.GetAssemblies())
            {
                Type[] types;
                try
                {
                    types = assembly.GetTypes();
                }
                catch (ReflectionTypeLoadException exception)
                {
                    types = exception.Types;
                }

                foreach (Type type in types)
                {
                    if (type == null)
                    {
                        continue;
                    }

                    if (string.Equals(type.Name, normalized, StringComparison.OrdinalIgnoreCase) ||
                        string.Equals(type.FullName, typeName, StringComparison.OrdinalIgnoreCase))
                    {
                        return type;
                    }
                }
            }

            return null;
        }

        private static void EnsureAssetFolder(string path)
        {
            path = NormalizeAssetPath(path);
            if (string.IsNullOrWhiteSpace(path) || AssetDatabase.IsValidFolder(path))
            {
                return;
            }

            string parent = Path.GetDirectoryName(path)?.Replace("\\", "/");
            if (!string.IsNullOrWhiteSpace(parent))
            {
                EnsureAssetFolder(parent);
            }

            if (!string.IsNullOrWhiteSpace(parent) && AssetDatabase.IsValidFolder(parent))
            {
                AssetDatabase.CreateFolder(parent, Path.GetFileName(path));
            }
        }

        private static string NormalizeAssetPath(string path)
        {
            if (string.IsNullOrWhiteSpace(path))
            {
                return string.Empty;
            }

            path = path.Trim().Replace("\\", "/");
            if (path.StartsWith("Assets/", StringComparison.Ordinal) || string.Equals(path, "Assets", StringComparison.Ordinal))
            {
                return path;
            }

            return $"Assets/{path.TrimStart('/')}";
        }

        private static string NormalizeReadableProjectPath(string path)
        {
            if (string.IsNullOrWhiteSpace(path))
            {
                return string.Empty;
            }

            path = path.Trim().Replace("\\", "/").TrimStart('/');
            if (HasParentPathTraversal(path))
            {
                return string.Empty;
            }

            if (path.StartsWith("Assets/", StringComparison.Ordinal) ||
                path.StartsWith("Packages/", StringComparison.Ordinal) ||
                path.StartsWith("ProjectSettings/", StringComparison.Ordinal) ||
                path.StartsWith("Library/PackageCache/", StringComparison.Ordinal) ||
                string.Equals(path, "Packages/manifest.json", StringComparison.Ordinal))
            {
                return path;
            }

            return NormalizeAssetPath(path);
        }

        private static bool HasParentPathTraversal(string path)
        {
            if (string.IsNullOrWhiteSpace(path))
            {
                return false;
            }

            string[] parts = path.Replace("\\", "/").Split('/');
            foreach (string part in parts)
            {
                if (string.Equals(part, "..", StringComparison.Ordinal))
                {
                    return true;
                }
            }

            return false;
        }

        private static bool IsReadableTextExtension(string extension)
        {
            if (string.IsNullOrWhiteSpace(extension))
            {
                return false;
            }

            switch (extension.ToLowerInvariant())
            {
                case ".asmdef":
                case ".anim":
                case ".asset":
                case ".cginc":
                case ".compute":
                case ".controller":
                case ".cs":
                case ".css":
                case ".hlsl":
                case ".inputactions":
                case ".json":
                case ".mat":
                case ".md":
                case ".meta":
                case ".overridecontroller":
                case ".playable":
                case ".prefab":
                case ".rendertexture":
                case ".shader":
                case ".shadergraph":
                case ".txt":
                case ".unity":
                case ".uss":
                case ".uxml":
                case ".xml":
                case ".yaml":
                case ".yml":
                    return true;
                default:
                    return false;
            }
        }

        private static string GetEndpoint()
        {
            string endpoint = Environment.GetEnvironmentVariable(EndpointEnvironmentKey);
            if (!string.IsNullOrWhiteSpace(endpoint))
            {
                return endpoint;
            }

            return EditorPrefs.GetString(EndpointPrefsKey, string.Empty);
        }

        private static string GetBackendRunsEndpoint(string endpoint)
        {
            string value = string.IsNullOrWhiteSpace(endpoint) ? DefaultEndpoint : endpoint.Trim();
            if (value.EndsWith("/agent", StringComparison.OrdinalIgnoreCase))
            {
                return value.Substring(0, value.Length - "/agent".Length).TrimEnd('/') + "/v1/runs";
            }

            if (value.EndsWith("/v1/runs", StringComparison.OrdinalIgnoreCase))
            {
                return value;
            }

            return value.TrimEnd('/') + "/v1/runs";
        }

        private static bool IsLoopbackEndpoint(string endpoint)
        {
            return Uri.TryCreate(endpoint, UriKind.Absolute, out Uri uri) && uri.IsLoopback;
        }

        private static string GetApiKey()
        {
            string apiKey = Environment.GetEnvironmentVariable(ApiKeyEnvironmentKey);
            if (!string.IsNullOrWhiteSpace(apiKey))
            {
                return apiKey;
            }

            return EditorPrefs.GetString(ApiKeyPrefsKey, string.Empty);
        }

        private static string GetTavilyApiKey()
        {
            string apiKey = Environment.GetEnvironmentVariable(TavilyApiKeyEnvironmentKey);
            if (!string.IsNullOrWhiteSpace(apiKey))
            {
                return apiKey.Trim();
            }

            apiKey = Environment.GetEnvironmentVariable(TavilyApiKeyEnvironmentKeyShort);
            if (!string.IsNullOrWhiteSpace(apiKey))
            {
                return apiKey.Trim();
            }

            return EditorPrefs.GetString(TavilyApiKeyPrefsKey, string.Empty);
        }

        private static bool HasApiKey()
        {
            return !string.IsNullOrWhiteSpace(GetApiKey());
        }

        private static string GetModel()
        {
            string model = Environment.GetEnvironmentVariable(ModelEnvironmentKey);
            if (!string.IsNullOrWhiteSpace(model))
            {
                return model.Trim();
            }

            return EditorPrefs.GetString(ModelPrefsKey, DefaultOpenAIModel);
        }

        private static bool ShouldUseCustomBackend(string endpoint)
        {
            if (string.IsNullOrWhiteSpace(endpoint))
            {
                return false;
            }

            if (string.Equals(EditorPrefs.GetString(EndpointModePrefsKey, string.Empty), CustomEndpointMode, StringComparison.Ordinal))
            {
                return true;
            }

            return !string.Equals(endpoint.Trim().TrimEnd('/'), DefaultEndpoint.TrimEnd('/'), StringComparison.OrdinalIgnoreCase);
        }

        private static string PostJson(string endpoint, string json, bool includeApiKeyHeader)
        {
            return PostJson(endpoint, json, includeApiKeyHeader, GetApiKey());
        }

        private static string PostJson(string endpoint, string json, bool includeApiKeyHeader, string apiKey)
        {
            byte[] payload = Encoding.UTF8.GetBytes(json);
            Exception lastException = null;
            for (int attempt = 1; attempt <= MaxPostJsonAttempts; attempt++)
            {
                HttpWebRequest request = (HttpWebRequest)WebRequest.Create(endpoint);
                request.Method = "POST";
                request.ContentType = "application/json";
                request.Accept = "application/json";
                request.Timeout = OpenAIRequestTimeoutMs;
                request.ReadWriteTimeout = OpenAIRequestTimeoutMs;
                request.KeepAlive = false;
                request.ContentLength = payload.Length;

                if (!string.IsNullOrWhiteSpace(apiKey))
                {
                    request.Headers[HttpRequestHeader.Authorization] = apiKey.StartsWith("Bearer ", StringComparison.OrdinalIgnoreCase)
                        ? apiKey
                        : $"Bearer {apiKey}";
                    if (includeApiKeyHeader)
                    {
                        request.Headers["X-API-Key"] = apiKey;
                    }
                }

                try
                {
                    using (Stream stream = request.GetRequestStream())
                    {
                        stream.Write(payload, 0, payload.Length);
                    }

                    using (WebResponse response = request.GetResponse())
                    using (Stream stream = response.GetResponseStream())
                    using (StreamReader reader = new StreamReader(stream ?? Stream.Null, Encoding.UTF8))
                    {
                        return reader.ReadToEnd();
                    }
                }
                catch (WebException exception) when (exception.Response != null)
                {
                    using (WebResponse response = exception.Response)
                    using (Stream stream = response.GetResponseStream())
                    using (StreamReader reader = new StreamReader(stream ?? Stream.Null, Encoding.UTF8))
                    {
                        string body = RedactRequestSecret(reader.ReadToEnd(), apiKey);
                        string status = FormatWebResponseStatus(response);
                        string message = string.IsNullOrWhiteSpace(body)
                            ? JoinNonEmpty(" ", status, exception.Message)
                            : JoinNonEmpty(" ", status, body);
                        throw new InvalidOperationException(message, exception);
                    }
                }
                catch (Exception exception)
                {
                    lastException = exception;
                    if (attempt < MaxPostJsonAttempts && IsTransientOpenAIRequestFailure(exception))
                    {
                        Thread.Sleep(attempt * 750);
                        continue;
                    }

                    throw new InvalidOperationException(
                        $"Network/authentication error while contacting {FormatEndpointHost(endpoint)}: {FormatRequestException(exception, apiKey)}",
                        exception);
                }
            }

            throw new InvalidOperationException(
                $"Network/authentication error while contacting {FormatEndpointHost(endpoint)}: {FormatRequestException(lastException, apiKey)}",
                lastException);
        }

        private static string GetJson(string endpoint, bool includeApiKeyHeader, string apiKey)
        {
            Exception lastException = null;
            for (int attempt = 1; attempt <= MaxPostJsonAttempts; attempt++)
            {
                HttpWebRequest request = (HttpWebRequest)WebRequest.Create(endpoint);
                request.Method = "GET";
                request.Accept = "application/json";
                request.Timeout = OpenAIRequestTimeoutMs;
                request.ReadWriteTimeout = OpenAIRequestTimeoutMs;
                request.KeepAlive = false;

                if (!string.IsNullOrWhiteSpace(apiKey))
                {
                    request.Headers[HttpRequestHeader.Authorization] = apiKey.StartsWith("Bearer ", StringComparison.OrdinalIgnoreCase)
                        ? apiKey
                        : $"Bearer {apiKey}";
                    if (includeApiKeyHeader)
                    {
                        request.Headers["X-API-Key"] = apiKey;
                    }
                }

                try
                {
                    using (WebResponse response = request.GetResponse())
                    using (Stream stream = response.GetResponseStream())
                    using (StreamReader reader = new StreamReader(stream ?? Stream.Null, Encoding.UTF8))
                    {
                        return reader.ReadToEnd();
                    }
                }
                catch (WebException exception) when (exception.Response != null)
                {
                    using (WebResponse response = exception.Response)
                    using (Stream stream = response.GetResponseStream())
                    using (StreamReader reader = new StreamReader(stream ?? Stream.Null, Encoding.UTF8))
                    {
                        string body = RedactRequestSecret(reader.ReadToEnd(), apiKey);
                        string status = FormatWebResponseStatus(response);
                        string message = string.IsNullOrWhiteSpace(body)
                            ? JoinNonEmpty(" ", status, exception.Message)
                            : JoinNonEmpty(" ", status, body);
                        throw new InvalidOperationException(message, exception);
                    }
                }
                catch (Exception exception)
                {
                    lastException = exception;
                    if (attempt < MaxPostJsonAttempts && IsTransientOpenAIRequestFailure(exception))
                    {
                        Thread.Sleep(attempt * 750);
                        continue;
                    }

                    throw new InvalidOperationException(
                        $"Network/authentication error while contacting {FormatEndpointHost(endpoint)}: {FormatRequestException(exception, apiKey)}",
                        exception);
                }
            }

            throw new InvalidOperationException(
                $"Network/authentication error while contacting {FormatEndpointHost(endpoint)}: {FormatRequestException(lastException, apiKey)}",
                lastException);
        }

        private static string FormatWebResponseStatus(WebResponse response)
        {
            if (response is HttpWebResponse httpResponse)
            {
                return $"HTTP {(int)httpResponse.StatusCode} {httpResponse.StatusDescription}:";
            }

            return string.Empty;
        }

        private static string FormatEndpointHost(string endpoint)
        {
            if (Uri.TryCreate(endpoint, UriKind.Absolute, out Uri uri))
            {
                return uri.Host;
            }

            return "configured endpoint";
        }

        private static string RedactRequestSecret(string value)
        {
            return RedactRequestSecret(value, Environment.GetEnvironmentVariable(ApiKeyEnvironmentKey));
        }

        private static string RedactRequestSecret(string value, string apiKey)
        {
            if (string.IsNullOrWhiteSpace(value))
            {
                return string.Empty;
            }

            string redacted = value;
            if (!string.IsNullOrWhiteSpace(apiKey))
            {
                redacted = redacted.Replace(apiKey, "[redacted-api-key]");
            }

            int bearerIndex = redacted.IndexOf("Bearer ", StringComparison.OrdinalIgnoreCase);
            if (bearerIndex >= 0)
            {
                int tokenStart = bearerIndex + "Bearer ".Length;
                int tokenEnd = tokenStart;
                while (tokenEnd < redacted.Length && !char.IsWhiteSpace(redacted[tokenEnd]) && redacted[tokenEnd] != '"' && redacted[tokenEnd] != '\'')
                {
                    tokenEnd++;
                }

                if (tokenEnd > tokenStart)
                {
                    redacted = redacted.Substring(0, tokenStart) + "[redacted]" + redacted.Substring(tokenEnd);
                }
            }

            return redacted;
        }

        private static bool TryExtractJson(string prompt, out string json)
        {
            json = string.Empty;
            if (string.IsNullOrWhiteSpace(prompt))
            {
                return false;
            }

            string trimmed = prompt.Trim();
            if (trimmed.StartsWith("```", StringComparison.Ordinal))
            {
                int firstLine = trimmed.IndexOf('\n');
                int lastFence = trimmed.LastIndexOf("```", StringComparison.Ordinal);
                if (firstLine >= 0 && lastFence > firstLine)
                {
                    trimmed = trimmed.Substring(firstLine + 1, lastFence - firstLine - 1).Trim();
                }
            }

            int start = trimmed.IndexOf('{');
            if (start < 0)
            {
                return false;
            }

            if (TryReadBalancedJsonObject(trimmed, start, out string balancedJson))
            {
                json = balancedJson;
                return HasAgenticJsonKeys(json);
            }

            string possibleJson = trimmed.Substring(start).Trim();
            if (!HasAgenticJsonKeys(possibleJson))
            {
                return false;
            }

            json = possibleJson;
            return true;
        }

        private static bool TryReadBalancedJsonObject(string text, int start, out string json)
        {
            json = string.Empty;
            int depth = 0;
            bool inString = false;
            bool escaping = false;

            for (int i = start; i < text.Length; i++)
            {
                char character = text[i];
                if (inString)
                {
                    if (escaping)
                    {
                        escaping = false;
                    }
                    else if (character == '\\')
                    {
                        escaping = true;
                    }
                    else if (character == '"')
                    {
                        inString = false;
                    }

                    continue;
                }

                if (character == '"')
                {
                    inString = true;
                }
                else if (character == '{')
                {
                    depth++;
                }
                else if (character == '}')
                {
                    depth--;
                    if (depth == 0)
                    {
                        json = text.Substring(start, i - start + 1).Trim();
                        return true;
                    }
                }
            }

            return false;
        }

        private static bool HasAgenticJsonKeys(string json)
        {
            return json.IndexOf("\"actions\"", StringComparison.OrdinalIgnoreCase) >= 0 ||
                json.IndexOf("\"message\"", StringComparison.OrdinalIgnoreCase) >= 0 ||
                json.IndexOf("\"plan\"", StringComparison.OrdinalIgnoreCase) >= 0 ||
                json.IndexOf("\"progress\"", StringComparison.OrdinalIgnoreCase) >= 0;
        }

        private static string BuildInvalidJsonResponse(Exception exception, string json)
        {
            return "The agent returned invalid action JSON, so no Unity actions were applied.\n\n" +
                $"Parser error: {exception.Message}\n\n" +
                "Raw response:\n" +
                (json ?? string.Empty).Trim();
        }

        private static string ExtractOpenAIMessageContent(string responseJson)
        {
            OpenAIChatResponse response = JsonUtility.FromJson<OpenAIChatResponse>(responseJson);
            if (response?.choices == null || response.choices.Length == 0 || response.choices[0]?.message == null)
            {
                OpenAIErrorEnvelope error = JsonUtility.FromJson<OpenAIErrorEnvelope>(responseJson);
                return error?.error == null ? string.Empty : $"OpenAI error: {error.error.message}";
            }

            return response.choices[0].message.content;
        }

        private static void AppendHierarchy(StringBuilder builder, GameObject gameObject, int depth, int maxDepth)
        {
            builder.AppendLine($"{new string(' ', depth * 2)}- {gameObject.name}{FormatGameObjectState(gameObject)}{FormatComponentSummary(gameObject)}");
            if (depth >= maxDepth)
            {
                return;
            }

            for (int i = 0; i < gameObject.transform.childCount; i++)
            {
                AppendHierarchy(builder, gameObject.transform.GetChild(i).gameObject, depth + 1, maxDepth);
            }
        }

        private static string FormatGameObjectState(GameObject gameObject)
        {
            if (gameObject == null)
            {
                return string.Empty;
            }

            string layerName = LayerMask.LayerToName(gameObject.layer);
            if (string.IsNullOrWhiteSpace(layerName))
            {
                layerName = gameObject.layer.ToString(CultureInfo.InvariantCulture);
            }

            Transform transform = gameObject.transform;
            return $" [activeSelf={gameObject.activeSelf}, activeInHierarchy={gameObject.activeInHierarchy}, tag={gameObject.tag}, layer={layerName}, pos={FormatVector3(transform.position)}, rot={FormatVector3(transform.eulerAngles)}, scale={FormatVector3(transform.localScale)}]";
        }

        private static string FormatComponentSummary(GameObject gameObject)
        {
            if (gameObject == null)
            {
                return string.Empty;
            }

            Component[] components = gameObject.GetComponents<Component>();
            List<string> names = new List<string>();
            foreach (Component component in components)
            {
                if (component == null || component is Transform)
                {
                    continue;
                }

                names.Add(FormatComponentForContext(component));
            }

            return names.Count == 0 ? string.Empty : $" ({string.Join(", ", names.ToArray())})";
        }

        private static string FormatComponentForContext(Component component)
        {
            if (component == null)
            {
                return "Missing Component";
            }

            if (component is Transform)
            {
                return "Transform";
            }

            if (component is Camera camera)
            {
                return $"Camera: enabled={camera.enabled}, orthographic={camera.orthographic}, size={FormatFloat(camera.orthographicSize)}, fov={FormatFloat(camera.fieldOfView)}, depth={FormatFloat(camera.depth)}, clearFlags={camera.clearFlags}, background={FormatColor(camera.backgroundColor)}, cullingMask={camera.cullingMask}";
            }

            if (component is Light light)
            {
                return $"Light: enabled={light.enabled}, type={light.type}, intensity={FormatFloat(light.intensity)}, range={FormatFloat(light.range)}, color={FormatColor(light.color)}, shadows={light.shadows}";
            }

            if (component is SpriteRenderer spriteRenderer)
            {
                string spriteName = spriteRenderer.sprite == null ? "none" : spriteRenderer.sprite.name;
                string spritePath = spriteRenderer.sprite == null ? string.Empty : AssetDatabase.GetAssetPath(spriteRenderer.sprite);
                string materialName = spriteRenderer.sharedMaterial == null ? "none" : spriteRenderer.sharedMaterial.name;
                string shaderName = spriteRenderer.sharedMaterial == null || spriteRenderer.sharedMaterial.shader == null ? "none" : spriteRenderer.sharedMaterial.shader.name;
                return $"SpriteRenderer: enabled={spriteRenderer.enabled}, sprite={spriteName}{FormatAssetPath(spritePath)}, color={FormatColor(spriteRenderer.color)}, material={materialName}, shader={shaderName}, sortingLayer={spriteRenderer.sortingLayerName}, sortingOrder={spriteRenderer.sortingOrder}";
            }

            if (component is Rigidbody2D body2D)
            {
                return $"Rigidbody2D: bodyType={body2D.bodyType}, gravityScale={FormatFloat(body2D.gravityScale)}, mass={FormatFloat(body2D.mass)}, freezeRotation={body2D.freezeRotation}, collisionDetection={body2D.collisionDetectionMode}";
            }

            if (component is BoxCollider2D box2D)
            {
                return $"BoxCollider2D: enabled={box2D.enabled}, isTrigger={box2D.isTrigger}, size={FormatVector2(box2D.size)}, offset={FormatVector2(box2D.offset)}";
            }

            if (component is CircleCollider2D circle2D)
            {
                return $"CircleCollider2D: enabled={circle2D.enabled}, isTrigger={circle2D.isTrigger}, radius={FormatFloat(circle2D.radius)}, offset={FormatVector2(circle2D.offset)}";
            }

            if (component is Collider2D collider2D)
            {
                return $"{component.GetType().Name}: enabled={collider2D.enabled}, isTrigger={collider2D.isTrigger}, offset={FormatVector2(collider2D.offset)}";
            }

            if (component is Rigidbody body3D)
            {
                return $"Rigidbody: mass={FormatFloat(body3D.mass)}, useGravity={body3D.useGravity}, isKinematic={body3D.isKinematic}, collisionDetection={body3D.collisionDetectionMode}";
            }

            if (component is Collider collider3D)
            {
                return $"{component.GetType().Name}: enabled={collider3D.enabled}, isTrigger={collider3D.isTrigger}";
            }

            if (component is Renderer renderer)
            {
                string materialName = renderer.sharedMaterial == null ? "none" : renderer.sharedMaterial.name;
                string shaderName = renderer.sharedMaterial == null || renderer.sharedMaterial.shader == null ? "none" : renderer.sharedMaterial.shader.name;
                return $"{component.GetType().Name}: enabled={renderer.enabled}, material={materialName}, shader={shaderName}, sortingLayer={renderer.sortingLayerName}, sortingOrder={renderer.sortingOrder}";
            }

            if (component is Behaviour behaviour)
            {
                return $"{component.GetType().Name}: enabled={behaviour.enabled}{FormatScriptPath(component)}{FormatSerializedDetails(component, 6)}";
            }

            return $"{component.GetType().Name}{FormatSerializedDetails(component, 6)}";
        }

        private static string FormatScriptPath(Component component)
        {
            if (component is MonoBehaviour monoBehaviour)
            {
                MonoScript script = MonoScript.FromMonoBehaviour(monoBehaviour);
                string path = script == null ? string.Empty : AssetDatabase.GetAssetPath(script);
                return FormatAssetPath(path);
            }

            return string.Empty;
        }

        private static string FormatSerializedDetails(Object unityObject, int maxCount)
        {
            if (unityObject == null || maxCount <= 0)
            {
                return string.Empty;
            }

            try
            {
                SerializedObject serializedObject = new SerializedObject(unityObject);
                SerializedProperty property = serializedObject.GetIterator();
                List<string> parts = new List<string>();
                bool enterChildren = true;
                while (property.NextVisible(enterChildren) && parts.Count < maxCount)
                {
                    enterChildren = false;
                    if (ShouldSkipSerializedContextProperty(property))
                    {
                        continue;
                    }

                    if (TryFormatSerializedProperty(property, out string formatted))
                    {
                        parts.Add(formatted);
                    }
                }

                return parts.Count == 0 ? string.Empty : $"; serialized: {string.Join(", ", parts.ToArray())}";
            }
            catch (Exception)
            {
                return string.Empty;
            }
        }

        private static bool ShouldSkipSerializedContextProperty(SerializedProperty property)
        {
            if (property == null)
            {
                return true;
            }

            if (property.propertyPath == "m_Script" ||
                property.propertyPath == "m_PrefabInstance" ||
                property.propertyPath == "m_PrefabAsset" ||
                property.propertyPath == "m_GameObject")
            {
                return true;
            }

            return false;
        }

        private static bool TryFormatSerializedProperty(SerializedProperty property, out string formatted)
        {
            formatted = string.Empty;
            if (property == null)
            {
                return false;
            }

            switch (property.propertyType)
            {
                case SerializedPropertyType.Generic:
                    if (property.isArray)
                    {
                        formatted = $"{property.propertyPath}.size={property.arraySize}";
                        return true;
                    }

                    return false;
                case SerializedPropertyType.Boolean:
                    formatted = $"{property.propertyPath}={property.boolValue}";
                    return true;
                case SerializedPropertyType.Integer:
                    formatted = $"{property.propertyPath}={property.intValue}";
                    return true;
                case SerializedPropertyType.Float:
                    formatted = $"{property.propertyPath}={FormatFloat(property.floatValue)}";
                    return true;
                case SerializedPropertyType.Enum:
                    formatted = $"{property.propertyPath}={property.enumDisplayNames[property.enumValueIndex]}";
                    return true;
                case SerializedPropertyType.String:
                    if (string.IsNullOrWhiteSpace(property.stringValue))
                    {
                        return false;
                    }

                    formatted = $"{property.propertyPath}={property.stringValue}";
                    return true;
                case SerializedPropertyType.Color:
                    formatted = $"{property.propertyPath}={FormatColor(property.colorValue)}";
                    return true;
                case SerializedPropertyType.Vector2:
                    formatted = $"{property.propertyPath}={FormatVector2(property.vector2Value)}";
                    return true;
                case SerializedPropertyType.Vector3:
                    formatted = $"{property.propertyPath}={FormatVector3(property.vector3Value)}";
                    return true;
                case SerializedPropertyType.ObjectReference:
                    if (property.objectReferenceValue == null)
                    {
                        formatted = $"{property.propertyPath}=null";
                        return true;
                    }

                    formatted = $"{property.propertyPath}={property.objectReferenceValue.name}{FormatAssetPath(AssetDatabase.GetAssetPath(property.objectReferenceValue))}";
                    return true;
                default:
                    return false;
            }
        }

        private static string FormatVector2(Vector2 value)
        {
            return $"({FormatFloat(value.x)},{FormatFloat(value.y)})";
        }

        private static string FormatVector3(Vector3 value)
        {
            return $"({FormatFloat(value.x)},{FormatFloat(value.y)},{FormatFloat(value.z)})";
        }

        private static string FormatColor(Color color)
        {
            return $"#{ColorUtility.ToHtmlStringRGBA(color)}";
        }

        private static string FormatFloat(float value)
        {
            return value.ToString("0.###", CultureInfo.InvariantCulture);
        }

        private static void AppendAssetList(StringBuilder builder, string title, string filter, string[] roots, int maxCount)
        {
            string[] guids = AssetDatabase.FindAssets(filter, roots);
            if (guids == null || guids.Length == 0)
            {
                return;
            }

            builder.AppendLine();
            builder.AppendLine($"{title}:");
            int count = Mathf.Min(guids.Length, maxCount);
            for (int i = 0; i < count; i++)
            {
                builder.AppendLine($"- {AssetDatabase.GUIDToAssetPath(guids[i])}");
            }

            if (guids.Length > count)
            {
                builder.AppendLine($"- ... {guids.Length - count} more");
            }
        }

        private static void AppendPromptRelevantProjectContext(StringBuilder builder, string prompt)
        {
            List<string> tokens = ExtractSearchTokens(prompt);
            builder.AppendLine("Prompt-relevant project context:");
            builder.AppendLine("- contract: these files/assets/packages were selected by matching the current prompt against project paths, asset names, package names, and script contents; use read_text_file or search_project for deeper inspection before changing code.");
            if (tokens.Count == 0)
            {
                builder.AppendLine("- no prompt keywords available");
                return;
            }

            builder.AppendLine($"- query tokens: {string.Join(", ", tokens.ToArray())}");

            List<ProjectSearchCandidate> candidates = BuildProjectSearchCandidates(tokens);
            AppendSearchCandidateGroup(builder, "Relevant scripts", candidates, "Script", 6, includeSnippets: true);
            AppendSearchCandidateGroup(builder, "Relevant package source", candidates, "Package source", 8, includeSnippets: true);
            AppendSearchCandidateGroup(builder, "Relevant prefabs", candidates, "Prefab", 6, includeSnippets: false);
            AppendSearchCandidateGroup(builder, "Relevant assets", candidates, string.Empty, 12, includeSnippets: false);
            AppendRelevantPackages(builder, tokens, 8);
        }

        private static List<ProjectSearchCandidate> BuildProjectSearchCandidates(List<string> tokens)
        {
            List<ProjectSearchCandidate> candidates = new List<ProjectSearchCandidate>();
            string[] paths = AssetDatabase.GetAllAssetPaths();
            foreach (string path in paths)
            {
                if (string.IsNullOrWhiteSpace(path) ||
                    (!path.StartsWith("Assets/", StringComparison.Ordinal) &&
                     !path.StartsWith("Packages/", StringComparison.Ordinal)))
                {
                    continue;
                }

                string extension = Path.GetExtension(path);
                string kind = GetSearchAssetKind(path, extension);
                int score = ScoreSearchText(path, tokens) + ScoreSearchText(Path.GetFileNameWithoutExtension(path), tokens) * 2;
                string snippets = string.Empty;

                if (string.Equals(kind, "Script", StringComparison.Ordinal))
                {
                    string fullPath = GetProjectFullPath(path);
                    if (File.Exists(fullPath))
                    {
                        string content = ReadFilePrefix(fullPath, 90000);
                        score += ScoreSearchText(content, tokens);
                        snippets = BuildSearchSnippets(content, tokens, 3);
                    }
                }
                else if (IsReadableTextExtension(extension))
                {
                    string fullPath = GetProjectFullPath(path);
                    if (File.Exists(fullPath))
                    {
                        string content = ReadFilePrefix(fullPath, 30000);
                        score += ScoreSearchText(content, tokens) / 2;
                        snippets = BuildSearchSnippets(content, tokens, 2);
                    }
                }

                if (score <= 0)
                {
                    continue;
                }

                candidates.Add(new ProjectSearchCandidate
                {
                    Path = path,
                    Kind = kind,
                    Score = score,
                    Snippets = snippets,
                    Summary = BuildAssetSearchSummary(path, kind)
                });
            }

            if (ShouldSearchPackageCache(tokens))
            {
                AddPackageCacheSearchCandidates(candidates, tokens);
            }

            candidates.Sort((left, right) =>
            {
                int scoreCompare = right.Score.CompareTo(left.Score);
                return scoreCompare != 0 ? scoreCompare : string.Compare(left.Path, right.Path, StringComparison.OrdinalIgnoreCase);
            });
            return candidates;
        }

        private static void AppendSearchCandidateGroup(
            StringBuilder builder,
            string title,
            List<ProjectSearchCandidate> candidates,
            string kindFilter,
            int maxCount,
            bool includeSnippets)
        {
            int written = 0;
            bool excludeScriptsAndPrefabs = string.IsNullOrWhiteSpace(kindFilter);
            foreach (ProjectSearchCandidate candidate in candidates)
            {
                if (!string.IsNullOrWhiteSpace(kindFilter) &&
                    !string.Equals(candidate.Kind, kindFilter, StringComparison.Ordinal))
                {
                    continue;
                }

                if (excludeScriptsAndPrefabs &&
                    (string.Equals(candidate.Kind, "Script", StringComparison.Ordinal) ||
                     string.Equals(candidate.Kind, "Package source", StringComparison.Ordinal) ||
                     string.Equals(candidate.Kind, "Prefab", StringComparison.Ordinal)))
                {
                    continue;
                }

                if (written == 0)
                {
                    builder.AppendLine();
                    builder.AppendLine($"{title}:");
                }

                builder.AppendLine($"- [{candidate.Kind}] {candidate.Path} score={candidate.Score}{candidate.Summary}");
                if (includeSnippets && !string.IsNullOrWhiteSpace(candidate.Snippets))
                {
                    builder.AppendLine(candidate.Snippets);
                }

                written++;
                if (written >= maxCount)
                {
                    return;
                }
            }
        }

        private static void AppendRelevantPackages(StringBuilder builder, List<string> tokens, int maxCount)
        {
            List<ProjectSearchCandidate> packages = new List<ProjectSearchCandidate>();
            AddPackageSearchCandidates(packages, tokens, "Packages/manifest.json");
            AddPackageSearchCandidates(packages, tokens, "Packages/packages-lock.json");
            packages.Sort((left, right) => right.Score.CompareTo(left.Score));
            if (packages.Count == 0)
            {
                return;
            }

            builder.AppendLine();
            builder.AppendLine("Relevant packages:");
            int count = Mathf.Min(packages.Count, maxCount);
            for (int i = 0; i < count; i++)
            {
                ProjectSearchCandidate package = packages[i];
                builder.AppendLine($"- {package.Path} score={package.Score}: {package.Summary}");
            }
        }

        private static void AddPackageSearchCandidates(List<ProjectSearchCandidate> candidates, List<string> tokens, string path)
        {
            string fullPath = GetProjectFullPath(path);
            if (!File.Exists(fullPath))
            {
                return;
            }

            string[] lines = File.ReadAllLines(fullPath);
            HashSet<string> seen = new HashSet<string>();
            foreach (string line in lines)
            {
                int score = ScoreSearchText(line, tokens);
                if (score <= 0)
                {
                    continue;
                }

                string trimmed = line.Trim().TrimEnd(',');
                if (!seen.Add(trimmed))
                {
                    continue;
                }

                candidates.Add(new ProjectSearchCandidate
                {
                    Path = path,
                    Kind = "Package",
                    Score = score,
                    Summary = trimmed
                });
            }
        }

        private static void AddPackageCacheSearchCandidates(List<ProjectSearchCandidate> candidates, List<string> tokens)
        {
            if (candidates == null || tokens == null || tokens.Count == 0)
            {
                return;
            }

            string packageCacheRoot = GetProjectFullPath("Library/PackageCache");
            if (!Directory.Exists(packageCacheRoot))
            {
                return;
            }

            const int maxFilesToScan = 6000;
            int scanned = 0;
            IEnumerable<string> files;
            try
            {
                files = Directory.EnumerateFiles(packageCacheRoot, "*.cs", SearchOption.AllDirectories);
            }
            catch (Exception)
            {
                return;
            }

            foreach (string fullPath in files)
            {
                if (scanned++ >= maxFilesToScan)
                {
                    break;
                }

                string relativePath = GetProjectRelativePath(fullPath);
                if (string.IsNullOrWhiteSpace(relativePath) ||
                    !relativePath.StartsWith("Library/PackageCache/", StringComparison.Ordinal))
                {
                    continue;
                }

                int score = ScoreSearchText(relativePath, tokens) + ScoreSearchText(Path.GetFileNameWithoutExtension(relativePath), tokens) * 2;
                string content = ReadFilePrefix(fullPath, 90000);
                if (!string.IsNullOrWhiteSpace(content))
                {
                    score += ScoreSearchText(content, tokens);
                }

                if (score <= 0)
                {
                    continue;
                }

                candidates.Add(new ProjectSearchCandidate
                {
                    Path = relativePath,
                    Kind = "Package source",
                    Score = score,
                    Snippets = BuildSearchSnippets(content, tokens, 3),
                    Summary = $" package={GetPackageCacheFolderName(relativePath)}"
                });
            }
        }

        private static bool ShouldSearchPackageCache(List<string> tokens)
        {
            if (tokens == null || tokens.Count == 0)
            {
                return false;
            }

            foreach (string token in tokens)
            {
                switch (token)
                {
                    case "api":
                    case "assetdatabase":
                    case "bloom":
                    case "cinemachine":
                    case "compile":
                    case "compiler":
                    case "definition":
                    case "editor":
                    case "error":
                    case "input":
                    case "light2d":
                    case "member":
                    case "namespace":
                    case "override":
                    case "package":
                    case "pipeline":
                    case "post":
                    case "processing":
                    case "render":
                    case "scriptable":
                    case "serialized":
                    case "shader":
                    case "urp":
                    case "vignette":
                    case "volume":
                    case "volumeprofile":
                        return true;
                    default:
                        if (token.StartsWith("cs", StringComparison.Ordinal) && token.Length >= 6)
                        {
                            return true;
                        }

                        break;
                }
            }

            return false;
        }

        private static string GetPackageCacheFolderName(string relativePath)
        {
            if (string.IsNullOrWhiteSpace(relativePath))
            {
                return "unknown";
            }

            string normalized = relativePath.Replace("\\", "/");
            const string prefix = "Library/PackageCache/";
            if (!normalized.StartsWith(prefix, StringComparison.Ordinal))
            {
                return "unknown";
            }

            string remainder = normalized.Substring(prefix.Length);
            int slash = remainder.IndexOf('/');
            return slash <= 0 ? remainder : remainder.Substring(0, slash);
        }

        private static string GetSearchAssetKind(string path, string extension)
        {
            if (string.Equals(extension, ".cs", StringComparison.OrdinalIgnoreCase)) return "Script";
            if (string.Equals(extension, ".prefab", StringComparison.OrdinalIgnoreCase)) return "Prefab";
            if (string.Equals(extension, ".unity", StringComparison.OrdinalIgnoreCase)) return "Scene";
            if (string.Equals(extension, ".mat", StringComparison.OrdinalIgnoreCase)) return "Material";
            if (string.Equals(extension, ".controller", StringComparison.OrdinalIgnoreCase)) return "Animator";
            if (string.Equals(extension, ".anim", StringComparison.OrdinalIgnoreCase)) return "Animation";
            if (string.Equals(extension, ".asset", StringComparison.OrdinalIgnoreCase)) return "Asset";
            if (string.Equals(extension, ".asmdef", StringComparison.OrdinalIgnoreCase)) return "Assembly";
            if (string.Equals(extension, ".shader", StringComparison.OrdinalIgnoreCase)) return "Shader";
            if (string.Equals(extension, ".png", StringComparison.OrdinalIgnoreCase) ||
                string.Equals(extension, ".jpg", StringComparison.OrdinalIgnoreCase) ||
                string.Equals(extension, ".jpeg", StringComparison.OrdinalIgnoreCase) ||
                string.Equals(extension, ".psd", StringComparison.OrdinalIgnoreCase))
            {
                return "Texture";
            }

            return string.IsNullOrWhiteSpace(extension) ? "Asset" : extension.TrimStart('.').ToUpperInvariant();
        }

        private static string BuildAssetSearchSummary(string path, string kind)
        {
            if (string.Equals(kind, "Prefab", StringComparison.Ordinal))
            {
                GameObject prefab = AssetDatabase.LoadAssetAtPath<GameObject>(path);
                return prefab == null ? string.Empty : $" components={FormatPrefabComponentNames(prefab)}";
            }

            if (string.Equals(kind, "Script", StringComparison.Ordinal))
            {
                MonoScript script = AssetDatabase.LoadAssetAtPath<MonoScript>(path);
                Type type = script == null ? null : script.GetClass();
                return type == null ? string.Empty : $" class={type.FullName}";
            }

            Object asset = AssetDatabase.LoadAssetAtPath<Object>(path);
            return asset == null ? string.Empty : $" name={asset.name} type={asset.GetType().Name}";
        }

        private static string FormatPrefabComponentNames(GameObject prefab)
        {
            if (prefab == null)
            {
                return string.Empty;
            }

            List<string> names = new List<string>();
            Component[] components = prefab.GetComponentsInChildren<Component>(includeInactive: true);
            for (int i = 0; i < components.Length && names.Count < 12; i++)
            {
                Component component = components[i];
                if (component == null || component is Transform)
                {
                    continue;
                }

                string name = component.GetType().Name;
                if (!names.Contains(name))
                {
                    names.Add(name);
                }
            }

            return names.Count == 0 ? "none" : string.Join(",", names.ToArray());
        }

        private static List<string> ExtractSearchTokens(string prompt)
        {
            List<string> tokens = new List<string>();
            if (string.IsNullOrWhiteSpace(prompt))
            {
                return tokens;
            }

            StringBuilder current = new StringBuilder();
            foreach (char character in prompt)
            {
                if (char.IsLetterOrDigit(character) || character == '_' || character == '-')
                {
                    current.Append(char.ToLowerInvariant(character));
                    continue;
                }

                AddSearchToken(tokens, current);
            }

            AddSearchToken(tokens, current);
            return tokens;
        }

        private static void AddSearchToken(List<string> tokens, StringBuilder current)
        {
            if (current.Length == 0)
            {
                return;
            }

            string token = current.ToString().Trim('_', '-');
            current.Length = 0;
            if (token.Length < 3 || IsSearchStopWord(token) || tokens.Contains(token))
            {
                return;
            }

            tokens.Add(token);
        }

        private static bool IsSearchStopWord(string token)
        {
            switch (token)
            {
                case "the":
                case "and":
                case "for":
                case "with":
                case "that":
                case "this":
                case "should":
                case "could":
                case "would":
                case "please":
                case "make":
                case "change":
                case "fix":
                case "add":
                case "remove":
                case "using":
                case "from":
                case "into":
                case "work":
                case "works":
                case "want":
                case "need":
                    return true;
                default:
                    return false;
            }
        }

        private static int ScoreSearchText(string text, List<string> tokens)
        {
            if (string.IsNullOrWhiteSpace(text) || tokens == null || tokens.Count == 0)
            {
                return 0;
            }

            string normalized = text.ToLowerInvariant();
            int score = 0;
            foreach (string token in tokens)
            {
                int first = normalized.IndexOf(token, StringComparison.Ordinal);
                if (first < 0)
                {
                    continue;
                }

                score += 4;
                int index = first + token.Length;
                int extraHits = 0;
                while (extraHits < 8)
                {
                    index = normalized.IndexOf(token, index, StringComparison.Ordinal);
                    if (index < 0)
                    {
                        break;
                    }

                    score++;
                    index += token.Length;
                    extraHits++;
                }
            }

            return score;
        }

        private static string BuildSearchSnippets(string content, List<string> tokens, int maxSnippets)
        {
            if (string.IsNullOrWhiteSpace(content) || tokens == null || tokens.Count == 0)
            {
                return string.Empty;
            }

            string[] lines = content.Replace("\r\n", "\n").Replace('\r', '\n').Split('\n');
            StringBuilder builder = new StringBuilder();
            int written = 0;
            for (int i = 0; i < lines.Length && written < maxSnippets; i++)
            {
                if (ScoreSearchText(lines[i], tokens) <= 0)
                {
                    continue;
                }

                string snippet = lines[i].Trim();
                if (snippet.Length > 180)
                {
                    snippet = snippet.Substring(0, 180) + "...";
                }

                builder.AppendLine($"  line {i + 1}: {snippet}");
                written++;
            }

            return builder.ToString().TrimEnd();
        }

        private static string ReadFilePrefix(string fullPath, int maxChars)
        {
            try
            {
                string content = File.ReadAllText(fullPath, Encoding.UTF8);
                return content.Length <= maxChars ? content : content.Substring(0, maxChars);
            }
            catch (Exception)
            {
                return string.Empty;
            }
        }

        private static string ReadRecentCompilerDiagnostics(int maxLines, int maxChars, out string logPath)
        {
            logPath = GetUnityEditorLogPath();
            if (string.IsNullOrWhiteSpace(logPath) || !File.Exists(logPath))
            {
                return string.Empty;
            }

            string logTail = ReadFileTail(logPath, 768 * 1024);
            if (string.IsNullOrWhiteSpace(logTail))
            {
                return string.Empty;
            }

            string projectRoot = Directory.GetParent(Application.dataPath)?.FullName ?? Directory.GetCurrentDirectory();
            string normalizedRoot = Path.GetFullPath(projectRoot).Replace("\\", "/");
            string[] lines = logTail.Replace("\r\n", "\n").Replace('\r', '\n').Split('\n');
            List<string> diagnostics = new List<string>();
            foreach (string rawLine in lines)
            {
                string line = NormalizeCompilerDiagnosticLine(rawLine, normalizedRoot);
                if (IsCompilerSuccessLine(line))
                {
                    diagnostics.Clear();
                }
                else if (IsCompilerDiagnosticLine(line))
                {
                    diagnostics.Add(line);
                }
            }

            if (diagnostics.Count == 0)
            {
                return string.Empty;
            }

            int first = Mathf.Max(0, diagnostics.Count - Mathf.Max(1, maxLines));
            StringBuilder builder = new StringBuilder();
            for (int i = first; i < diagnostics.Count; i++)
            {
                if (builder.Length > 0)
                {
                    builder.AppendLine();
                }

                builder.Append(diagnostics[i]);
                if (maxChars > 0 && builder.Length >= maxChars)
                {
                    break;
                }
            }

            if (maxChars > 0 && builder.Length > maxChars)
            {
                return builder.ToString(0, maxChars).TrimEnd() + "\n... diagnostics truncated";
            }

            return builder.ToString().TrimEnd();
        }

        private static string GetUnityEditorLogPath()
        {
            switch (Application.platform)
            {
                case RuntimePlatform.OSXEditor:
                    return Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.Personal), "Library", "Logs", "Unity", "Editor.log");
                case RuntimePlatform.WindowsEditor:
                    return Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "Unity", "Editor", "Editor.log");
                default:
                    return Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.Personal), ".config", "unity3d", "Editor.log");
            }
        }

        private static string ReadFileTail(string fullPath, int maxBytes)
        {
            try
            {
                using (FileStream stream = new FileStream(fullPath, FileMode.Open, FileAccess.Read, FileShare.ReadWrite))
                {
                    long length = stream.Length;
                    long start = maxBytes > 0 && length > maxBytes ? length - maxBytes : 0;
                    stream.Seek(start, SeekOrigin.Begin);
                    int count = (int)(length - start);
                    byte[] buffer = new byte[count];
                    int read = stream.Read(buffer, 0, count);
                    return Encoding.UTF8.GetString(buffer, 0, read);
                }
            }
            catch (Exception)
            {
                return string.Empty;
            }
        }

        private static string NormalizeCompilerDiagnosticLine(string rawLine, string normalizedProjectRoot)
        {
            if (string.IsNullOrWhiteSpace(rawLine))
            {
                return string.Empty;
            }

            string line = rawLine.Trim().Replace("\\", "/");
            if (!string.IsNullOrWhiteSpace(normalizedProjectRoot))
            {
                line = line.Replace(normalizedProjectRoot.TrimEnd('/') + "/", string.Empty);
            }

            return line;
        }

        private static bool IsCompilerDiagnosticLine(string line)
        {
            if (string.IsNullOrWhiteSpace(line))
            {
                return false;
            }

            string normalized = line.ToLowerInvariant();
            return normalized.IndexOf("error cs", StringComparison.Ordinal) >= 0 ||
                normalized.IndexOf("warning cs", StringComparison.Ordinal) >= 0 ||
                normalized.IndexOf("script compilation error", StringComparison.Ordinal) >= 0 ||
                normalized.IndexOf("compilation failed", StringComparison.Ordinal) >= 0 ||
                normalized.IndexOf("tundra build failed", StringComparison.Ordinal) >= 0 ||
                normalized.IndexOf("compiler error", StringComparison.Ordinal) >= 0 ||
                ((normalized.IndexOf("assets/", StringComparison.Ordinal) >= 0 ||
                  normalized.IndexOf("packages/", StringComparison.Ordinal) >= 0 ||
                  normalized.IndexOf("library/packagecache/", StringComparison.Ordinal) >= 0) &&
                 normalized.IndexOf(".cs(", StringComparison.Ordinal) >= 0 &&
                 (normalized.IndexOf(": error", StringComparison.Ordinal) >= 0 ||
                  normalized.IndexOf(": warning", StringComparison.Ordinal) >= 0 ||
                  normalized.IndexOf(" error ", StringComparison.Ordinal) >= 0 ||
                  normalized.IndexOf(" warning ", StringComparison.Ordinal) >= 0));
        }

        private static bool IsCompilerSuccessLine(string line)
        {
            if (string.IsNullOrWhiteSpace(line))
            {
                return false;
            }

            string normalized = line.ToLowerInvariant();
            return normalized.IndexOf("tundra build success", StringComparison.Ordinal) >= 0 ||
                normalized.IndexOf("reload assemblies after finishing script compilation", StringComparison.Ordinal) >= 0 ||
                normalized.IndexOf("reloading assemblies after finishing script compilation", StringComparison.Ordinal) >= 0;
        }

        private static void AppendIndentedBlock(StringBuilder builder, string value, string prefix)
        {
            if (builder == null || string.IsNullOrWhiteSpace(value))
            {
                return;
            }

            string[] lines = value.Replace("\r\n", "\n").Replace('\r', '\n').Split('\n');
            foreach (string line in lines)
            {
                if (string.IsNullOrWhiteSpace(line))
                {
                    continue;
                }

                builder.Append(prefix ?? string.Empty);
                builder.AppendLine(line.TrimEnd());
            }
        }

        private static string GetProjectFullPath(string relativePath)
        {
            string projectRoot = Directory.GetParent(Application.dataPath)?.FullName ?? Directory.GetCurrentDirectory();
            return Path.GetFullPath(Path.Combine(projectRoot, relativePath));
        }

        private static string GetProjectRelativePath(string fullPath)
        {
            if (string.IsNullOrWhiteSpace(fullPath))
            {
                return string.Empty;
            }

            string projectRoot = Directory.GetParent(Application.dataPath)?.FullName ?? Directory.GetCurrentDirectory();
            string normalizedRoot = Path.GetFullPath(projectRoot).Replace("\\", "/").TrimEnd('/');
            string normalizedFullPath = Path.GetFullPath(fullPath).Replace("\\", "/");
            string prefix = normalizedRoot + "/";
            if (!normalizedFullPath.StartsWith(prefix, StringComparison.Ordinal))
            {
                return string.Empty;
            }

            return normalizedFullPath.Substring(prefix.Length);
        }

        private sealed class ProjectSearchCandidate
        {
            public string Path;
            public string Kind;
            public string Summary;
            public string Snippets;
            public int Score;
        }

        [Serializable]
        private sealed class TavilySearchRequest
        {
            public string api_key;
            public string query;
            public string search_depth;
            public int max_results;
            public bool include_answer;
            public bool include_raw_content;
        }

        [Serializable]
        private sealed class TavilySearchResponse
        {
            public string answer;
            public TavilySearchResult[] results;
        }

        [Serializable]
        private sealed class TavilySearchResult
        {
            public string title;
            public string url;
            public string content;
            public float score;
        }

        private static string GetHierarchyPath(GameObject gameObject)
        {
            if (gameObject == null)
            {
                return string.Empty;
            }

            Transform current = gameObject.transform;
            string path = current.name;
            while (current.parent != null)
            {
                current = current.parent;
                path = $"{current.name}/{path}";
            }

            return path;
        }

        private static string SanitizeFileName(string name)
        {
            if (string.IsNullOrWhiteSpace(name))
            {
                return "AgenticAsset";
            }

            foreach (char invalid in Path.GetInvalidFileNameChars())
            {
                name = name.Replace(invalid, '_');
            }

            return string.IsNullOrWhiteSpace(name) ? "AgenticPrefab" : name;
        }

        private static string EnsureExtension(string path, string extension)
        {
            if (string.IsNullOrWhiteSpace(path))
            {
                return string.Empty;
            }

            return string.Equals(Path.GetExtension(path), extension, StringComparison.OrdinalIgnoreCase)
                ? path
                : $"{path}{extension}";
        }

        private static void AppendStringList(StringBuilder builder, string title, string[] values)
        {
            if (values == null || values.Length == 0)
            {
                return;
            }

            bool wroteHeader = false;
            foreach (string value in values)
            {
                if (string.IsNullOrWhiteSpace(value))
                {
                    continue;
                }

                if (!wroteHeader)
                {
                    builder.AppendLine();
                    builder.AppendLine();
                    builder.AppendLine($"{title}:");
                    wroteHeader = true;
                }

                builder.AppendLine($"- {value.Trim()}");
            }
        }

        private static string GetActionSchema()
        {
            return "Return JSON: {\"message\":\"short user-facing summary\",\"plan\":[\"concise high-level step\"],\"progress\":[\"observable progress\"],\"actions\":[...]} . Supported action types: set_task_plan(tasks,content), update_task_status(id,name,target,status,value,verification,content), create_folder(path), search_project(query,value), search_web(query,value,int_value), read_text_file(path), inspect_prefab(path,asset_path,target,name), inspect_runtime_state(query,target,name,component,int_value), read_compiler_diagnostics(int_value), search_unity_docs(query,int_value), read_unity_doc(path,value), search_unity_api(query,int_value), read_unity_api(path,value), rebuild_unity, write_text_file(path,content), write_csharp_script(path,content,target,component), create_object(name,components,parent,use_position,position,use_rotation,rotation,use_scale,scale), ensure_components(target,component,components), ensure_unity_workflow(name,value,query,content,target,path,asset_path,color,int_value,float_value,bool_value), repair_scene_relationships(query,value,content,int_value), setup_urp_post_processing(target,name,path,asset_path,value,query,content,color,float_value,bool_value), apply_default_sprite(target,shape,color), create_sprite_asset(path,name,width,height,color,secondary_color,shape,pixels_per_unit), create_unity_asset(path,name,asset_type,color,width,height,depth,asset_path,scriptable_type), delete_game_object(target), clear_scene, set_object_property(target,property_path,value,value_type,int_value,bool_value), set_transform(target,use_position,position,use_rotation,rotation,use_scale,scale), set_component_property(target,component,property_path,value,value_type,int_value,float_value,bool_value,asset_path,reference_asset_path,reference_target,color,position,scale), add_component(target,component), remove_component(target,component), select(target), create_prefab_from_selected(path), instantiate_prefab(asset_path,parent,use_position,position), create_scene(path,name,open_scene), open_scene(path), execute_menu_item(menu_item), enter_play_mode, exit_play_mode, add_package(package_id), remove_package(package_id), set_player_setting(property_path,value,value_type,int_value,bool_value), set_project_setting(path,property_path,value,value_type,int_value,float_value,bool_value), set_asset_property(path,name,property_path,value,value_type,int_value,float_value,bool_value,reference_asset_path,color,position,scale), set_editor_build_scenes(paths,enabled,bool_value,value), invoke_editor_method(class_name,method_name,value), validate_scene, capture_game_view, save_scene, save_assets. For composite Unity workflows, prefer ensure_unity_workflow or repair_scene_relationships before raw property guessing. ensure_unity_workflow is the default repair/action for gameplay wiring, prefab/reference wiring, scene lookup contracts, UI/visual setup, camera/render requests, and multi-object feature work; it creates or assigns linked scene objects, fallback prefabs, important serialized references/arrays, sprites, lookup-prefix markers, tags, and render/post-processing settings where possible. repair_scene_relationships specifically scans the live scene for missing important references/arrays, missing prefix lookup objects such as EnemySpawn_, missing tag targets, missing SpriteRenderer sprites, incomplete Volume profiles, and disabled camera post-processing. setup_urp_post_processing creates or reuses a global Volume, creates/assigns a VolumeProfile, adds active Bloom/Vignette overrides with visible values, enables UniversalAdditionalCameraData renderPostProcessing, and can set camera background color. Build every scene object generically: create_object creates or reuses the GameObject, components adds Unity component types such as Camera, Light, AudioSource, SpriteRenderer, Rigidbody2D, BoxCollider2D, CircleCollider2D, Canvas, package components such as Unity.Cinemachine.CinemachineCamera, or custom MonoBehaviours, set_object_property configures GameObject-level fields such as tag/layer/active/static/name, and set_component_property configures serialized component fields on scene GameObjects or prefab assets. set_component_property supports semantic Camera background/clearFlags and public writable component members, plus object-reference arrays: set property_path to enemyPrefabs with reference_asset_path/asset_path/paths to replace the array, or enemyPrefabs[0] to set or grow one element; use reference_target/value for arrays of scene objects, Transforms, or components. Use rebuild_unity explicitly when a prior write_text_file/write_csharp_script of .cs, .asmdef, .asmref, or .rsp files must become visible to Unity import or compilation, or when queued script attachments need the compiled type before attachment. write_csharp_script no longer implies an automatic refresh or compile. For scene assets and Build Settings, use create_scene/open_scene/save_scene and set_editor_build_scenes directly; to add scenes without removing existing Build Settings entries, call set_editor_build_scenes with bool_value true or value add/append/include. Do not write SceneBuildSettingsUtility scripts, treat EditorSceneManager as a component, or automate the Build Settings menu for this. For prefab assets, use inspect_prefab before and after value edits to see actual prefab components and serialized values; read_text_file can inspect the .prefab YAML, but make edits through direct tools: set path or asset_path to Assets/...prefab, set target or name only when editing a nested prefab child, and use ensure_components, add_component, remove_component, set_transform, set_object_property, or set_component_property; set_asset_property also accepts prefab component paths like SpriteRenderer.m_Color or Transform.m_LocalScale and routes them through the prefab component editor. Use reference_asset_path for object-reference values so the prefab path is not treated as the referenced object. For cameras, prefer setup_urp_post_processing or ensure_unity_workflow for render/camera workflows; for precise edits, create_object with components [\"Camera\"] then set tag MainCamera with set_object_property and set Camera fields such as m_Orthographic, orthographic size, m_ClearFlags, m_BackGroundColor/backgroundColor, and transform. For URP post-processing, use setup_urp_post_processing instead of manually editing VolumeProfile YAML or guessing override serialized paths, then validate_scene and capture_game_view. For Cinemachine 3, do not write an editor setup script: ensure Unity.Cinemachine.CinemachineBrain on Main Camera, create a GameObject with Unity.Cinemachine.CinemachineCamera and Unity.Cinemachine.CinemachineFollow, then set CinemachineCamera Target.TrackingTarget with reference_target, Lens.OrthographicSize, Priority.Enabled, Priority.m_Value, and CinemachineFollow FollowOffset. For built-in 3D lights, create_object with components [\"Light\"] then set Light fields such as m_Type, m_Color, m_Intensity, and m_Range. For URP 2D lights, create_object or target an object, ensure_components with Light2D, then set serialized Light2D fields such as m_LightType, m_Intensity, m_Color, and m_PointLightOuterRadius. Do not rely on preset-specific object creation actions; older preset aliases may exist only for backward compatibility. Do not write or invoke temporary/project-specific editor setup scripts for ordinary scene/component/prefab/build-settings work when semantic or direct tools can do the job; existing builder utilities may encode stale colors, sizes, references, or assumptions and are not proof of completion. Prompt-relevant scripts, prefabs, assets, packages, and matching package source files are included automatically in context; call search_project before diagnosing when the initial context is not enough, then call read_text_file on the relevant files before claiming code behavior. Local Unity/package/project docs are available through search_unity_docs and read_unity_doc; installed Unity/package C# API source is available through search_unity_api and read_unity_api; external implementation research is available through search_web when local docs/source are insufficient or do not outline the implementation approach the agent is about to use. Use docs before complex workflows, use search_web before inventing a custom pattern not covered by those docs/source, and use API source before writing or repairing Unity C# that depends on exact type names, public members, setters, overloads, or casing. Use read_compiler_diagnostics after rebuild_unity, after failed invoke_editor_method calls, or whenever the context reports compiler errors. Use read_text_file before diagnosing code-driven behavior such as runtime spawning, object recreation, input/movement bugs, component lifecycle methods, prefab wiring, or script errors. Use search_unity_api and read_unity_api on Library/PackageCache paths when compiler errors indicate missing Unity/package members, read-only properties, wrong casing, or ambiguous APIs; do not use a member until the installed source confirms it is public and assignable. Use enter_play_mode to reproduce runtime-only behavior, inspect_runtime_state after Play Mode starts to verify live objects/component references/spawned instances/UI state, capture_game_view for visible gameplay, then use exit_play_mode before finishing. Use capture_game_view after visual/render/lighting/camera changes to validate the actual camera render and include validate_scene near the end of non-trivial scene changes. Use apply_default_sprite with target scene/all/everything for broad square/circle sprite assignment. create_object without components is only for empty parent containers. Composite workflow requests such as post-processing, animation, input, audio, particles, materials, cameras, build profiles, UI, prefabs, and render settings must include the required linked assets, sub-assets, overrides, object references, component values, and non-default settings; do not stop at a root object, package, profile, controller, material, prefab, or placeholder asset. If validate_scene reports missing profiles, overrides, assigned assets, references, controllers, sprites, clips, or disabled camera/render settings, continue fixing those warnings. Use write_csharp_script rather than write_text_file when creating a new MonoBehaviour that should be attached after Unity compiles. For Unity editor/project features that are not covered by a semantic or direct action, write an Editor script under Assets/Editor with a static method, then call rebuild_unity when the compiled method must become available, then call read_compiler_diagnostics; if compile succeeds, call invoke_editor_method, then inspect the affected scene/assets before claiming request-specific values changed. This escape hatch is for Project Settings tabs, lighting settings, build profiles, importers, package/build automation, controller/state-machine setup, input/action assets, audio mixer/effect setup, and UnityEditor APIs that direct actions cannot cover. set_player_setting supports active_input_handling values old/input_manager, new/input_system, and both. set_project_setting edits scalar fields under ProjectSettings/*.asset. set_asset_property edits serialized properties on assets under Assets and can route prefab component edits when component is supplied or property_path is Component.property; use reference_asset_path for object reference properties. set_editor_build_scenes sets Build Settings scene list; with bool_value true or value add/append/include it preserves existing entries and appends/enables the supplied scene paths. asset_type supports material, physic_material, physics_material_2d, animation_clip, render_texture, tile, scriptable_object. sprite shape supports square, circle, ring, diamond, cross, checker, gradient. Task planning tools are orchestration metadata for the manager: set_task_plan accepts tasks=[{id,title,description,assignee,status,dependsOn,acceptanceCriteria,verification}] or content containing that JSON; update_task_status accepts id/name/target plus status and verification/content. These tools do not mutate Unity, but unfinished task-plan items block final completion. Write paths must be under Assets except set_project_setting paths, which must be under ProjectSettings; read_text_file accepts Assets, Packages, ProjectSettings, Library/PackageCache, and common Unity YAML asset paths such as .prefab, .asset, .mat, .controller, .anim, and .unity; inspect_prefab accepts prefab asset paths under Assets; read_unity_doc accepts only ids/paths returned by the local docs index. Use target \"selected\" for the current selection.";
        }

        private sealed class RenderCapture : IDisposable
        {
            public readonly int Width;
            public readonly int Height;
            public readonly Color32[] Pixels;
            public readonly string ScreenshotPath;
            public readonly float AverageLuminance;
            public readonly float MaxLuminance;
            public readonly float NonBlackRatio;
            public readonly float BrightRatio;
            public readonly float LuminanceStdDev;
            public readonly Color AverageColor;

            public RenderCapture(int width, int height, Color32[] pixels, string screenshotPath)
            {
                Width = width;
                Height = height;
                Pixels = pixels ?? Array.Empty<Color32>();
                ScreenshotPath = screenshotPath;
                AnalyzePixels(
                    Pixels,
                    out AverageLuminance,
                    out MaxLuminance,
                    out NonBlackRatio,
                    out BrightRatio,
                    out LuminanceStdDev,
                    out AverageColor);
            }

            public string DescribeViewportSample(string label, Vector2 viewportPosition, float viewportRadius)
            {
                if (Pixels.Length == 0)
                {
                    return $"{label}: no pixels captured";
                }

                int centerX = Mathf.Clamp(Mathf.RoundToInt(viewportPosition.x * (Width - 1)), 0, Width - 1);
                int centerY = Mathf.Clamp(Mathf.RoundToInt(viewportPosition.y * (Height - 1)), 0, Height - 1);
                int radius = Mathf.Max(1, Mathf.RoundToInt(Mathf.Min(Width, Height) * viewportRadius));
                int minX = Mathf.Max(0, centerX - radius);
                int maxX = Mathf.Min(Width - 1, centerX + radius);
                int minY = Mathf.Max(0, centerY - radius);
                int maxY = Mathf.Min(Height - 1, centerY + radius);

                float totalLuminance = 0f;
                float maxLuminance = 0f;
                float totalR = 0f;
                float totalG = 0f;
                float totalB = 0f;
                int count = 0;
                for (int y = minY; y <= maxY; y++)
                {
                    for (int x = minX; x <= maxX; x++)
                    {
                        Color32 color = Pixels[y * Width + x];
                        float luminance = GetLuminance(color);
                        totalLuminance += luminance;
                        maxLuminance = Mathf.Max(maxLuminance, luminance);
                        totalR += color.r / 255f;
                        totalG += color.g / 255f;
                        totalB += color.b / 255f;
                        count++;
                    }
                }

                if (count == 0)
                {
                    return $"{label}: empty sample";
                }

                Color average = new Color(totalR / count, totalG / count, totalB / count, 1f);
                return $"avgColor={FormatColor(average)}, avgLuminance={FormatFloat(totalLuminance / count)}, maxLuminance={FormatFloat(maxLuminance)}, pixels={count}";
            }

            public string DescribeTopColors(int maxCount)
            {
                if (Pixels.Length == 0 || maxCount <= 0)
                {
                    return string.Empty;
                }

                Dictionary<int, int> counts = new Dictionary<int, int>();
                foreach (Color32 pixel in Pixels)
                {
                    int r = pixel.r / 32;
                    int g = pixel.g / 32;
                    int b = pixel.b / 32;
                    int key = (r << 16) | (g << 8) | b;
                    counts.TryGetValue(key, out int count);
                    counts[key] = count + 1;
                }

                List<KeyValuePair<int, int>> ranked = new List<KeyValuePair<int, int>>(counts);
                ranked.Sort((left, right) => right.Value.CompareTo(left.Value));
                int countToWrite = Mathf.Min(maxCount, ranked.Count);
                List<string> parts = new List<string>();
                for (int i = 0; i < countToWrite; i++)
                {
                    int key = ranked[i].Key;
                    int r = ((key >> 16) & 0xff) * 32 + 16;
                    int g = ((key >> 8) & 0xff) * 32 + 16;
                    int b = (key & 0xff) * 32 + 16;
                    float ratio = ranked[i].Value / (float)Pixels.Length;
                    parts.Add($"{FormatColor(new Color32((byte)Mathf.Clamp(r, 0, 255), (byte)Mathf.Clamp(g, 0, 255), (byte)Mathf.Clamp(b, 0, 255), 255))} {FormatFloat(ratio * 100f)}%");
                }

                return string.Join(", ", parts.ToArray());
            }

            public void Dispose()
            {
            }

            private static void AnalyzePixels(
                Color32[] pixels,
                out float averageLuminance,
                out float maxLuminance,
                out float nonBlackRatio,
                out float brightRatio,
                out float luminanceStdDev,
                out Color averageColor)
            {
                averageLuminance = 0f;
                maxLuminance = 0f;
                nonBlackRatio = 0f;
                brightRatio = 0f;
                luminanceStdDev = 0f;
                averageColor = Color.black;
                if (pixels == null || pixels.Length == 0)
                {
                    return;
                }

                float totalLuminance = 0f;
                float totalSquaredLuminance = 0f;
                float totalR = 0f;
                float totalG = 0f;
                float totalB = 0f;
                int nonBlack = 0;
                int bright = 0;
                foreach (Color32 pixel in pixels)
                {
                    float luminance = GetLuminance(pixel);
                    totalLuminance += luminance;
                    totalSquaredLuminance += luminance * luminance;
                    maxLuminance = Mathf.Max(maxLuminance, luminance);
                    totalR += pixel.r / 255f;
                    totalG += pixel.g / 255f;
                    totalB += pixel.b / 255f;
                    if (luminance > 0.02f)
                    {
                        nonBlack++;
                    }

                    if (luminance > 0.5f)
                    {
                        bright++;
                    }
                }

                averageLuminance = totalLuminance / pixels.Length;
                float variance = Mathf.Max(0f, totalSquaredLuminance / pixels.Length - averageLuminance * averageLuminance);
                luminanceStdDev = Mathf.Sqrt(variance);
                nonBlackRatio = nonBlack / (float)pixels.Length;
                brightRatio = bright / (float)pixels.Length;
                averageColor = new Color(totalR / pixels.Length, totalG / pixels.Length, totalB / pixels.Length, 1f);
            }

            public static float GetLuminance(Color32 color)
            {
                return (0.2126f * color.r + 0.7152f * color.g + 0.0722f * color.b) / 255f;
            }
        }

        private struct PixelDifference
        {
            public float AverageRgbDelta;
            public float AverageLuminanceDelta;
            public float ChangedRatio;

            public static PixelDifference Compare(RenderCapture current, RenderCapture other)
            {
                PixelDifference difference = new PixelDifference();
                if (current == null || other == null || current.Pixels.Length == 0 || current.Pixels.Length != other.Pixels.Length)
                {
                    return difference;
                }

                float totalRgbDelta = 0f;
                float totalLuminanceDelta = 0f;
                int changed = 0;
                for (int i = 0; i < current.Pixels.Length; i++)
                {
                    Color32 left = current.Pixels[i];
                    Color32 right = other.Pixels[i];
                    float redDelta = Mathf.Abs(left.r - right.r) / 255f;
                    float greenDelta = Mathf.Abs(left.g - right.g) / 255f;
                    float blueDelta = Mathf.Abs(left.b - right.b) / 255f;
                    float rgbDelta = (redDelta + greenDelta + blueDelta) / 3f;
                    float luminanceDelta = Mathf.Abs(RenderCapture.GetLuminance(left) - RenderCapture.GetLuminance(right));
                    totalRgbDelta += rgbDelta;
                    totalLuminanceDelta += luminanceDelta;
                    if (rgbDelta > 0.02f)
                    {
                        changed++;
                    }
                }

                difference.AverageRgbDelta = totalRgbDelta / current.Pixels.Length;
                difference.AverageLuminanceDelta = totalLuminanceDelta / current.Pixels.Length;
                difference.ChangedRatio = changed / (float)current.Pixels.Length;
                return difference;
            }
        }

        #pragma warning disable 0649
        [Serializable]
        private sealed class ResumableToolLoopState
        {
            public int version;
            public string runId;
            public string prompt;
            public string model;
            public string instructionMemory;
            public string activeAgentRole;
            public string promptInterpretationMode;
            public string promptInterpretationSummary;
            public long startedAtUtcTicks;
            public int requestCount;
            public int automaticBudgetContinuationCount;
            public int appliedActions;
            public int loggedToolCalls;
            public int handoffCount;
            public int strictCompletionRetryCount;
            public int lastStrictGateAppliedActions;
            public int repeatedStrictGateWithoutMutationCount;
            public int strictCompletionRecoveryEscalationCount;
            public int consecutiveRequestFailureCount;
            public int checkpointSequence;
            public string finalMessage;
            public string lastToolSignature;
            public int repeatedToolCallCount;
            public string lastCompilerFailureSummary;
            public int repeatedCompilerFailureCount;
            public bool compilerFailureRepairEscalated;
            public int focusedRepairCodeWriteCount;
            public int focusedRepairRebuildCount;
            public string lastFocusedRepairWritePath;
            public int consecutiveWritesToSamePath;
            public bool sceneOrAssetSetupCompleted;
            public bool externalImplementationResearchAttempted;
            public string actionLog;
            public string agentLog;
            public string achievementLog;
            public string contextLog;
            public string codeSnippetLog;
            public string validationLog;
            public string issueLog;
            public AgentTaskRecord[] taskPlan;
            public string[] contextPolicyKeys;
            public string[] completedHandoffEntries;
            public OpenAIToolChatMessage[] messages;
            public ResumableSpecialistConversation[] specialistConversations;
            public OpenAIToolCall pendingHandoffToolCall;
            public string pendingHandoffRole;
            public string pendingHandoffTask;
            public long savedAtUtcTicks;
        }

        [Serializable]
        private sealed class ResumableSpecialistConversation
        {
            public string role;
            public OpenAIToolChatMessage[] messages;
        }

        [Serializable]
        private sealed class TaskPlanEnvelope
        {
            public AgentTaskRecord[] tasks;
        }

        [Serializable]
        private sealed class BackendRequest
        {
            public string prompt;
            public string context;
            public string action_schema;
        }

        [Serializable]
        private sealed class OpenAIChatRequest
        {
            public string model;
            public OpenAIResponseFormat response_format;
            public OpenAIRequestMessage[] messages;
        }

        [Serializable]
        private sealed class OpenAIToolChatRequest
        {
            public string model;
            public OpenAIToolChatMessage[] messages;
            public OpenAIToolDefinition[] tools;
            public string tool_choice;
        }

        [Serializable]
        internal sealed class OpenAIToolChatMessage
        {
            public string role;
            public string content;
            public string tool_call_id;
            public OpenAIToolCall[] tool_calls;
        }

        [Serializable]
        private sealed class OpenAIToolDefinition
        {
            public string type;
            public OpenAIToolFunctionDefinition function;
        }

        [Serializable]
        private sealed class OpenAIToolFunctionDefinition
        {
            public string name;
            public string description;
            public OpenAIToolParameters parameters;
        }

        [Serializable]
        private sealed class OpenAIToolParameters
        {
            public string type;
            public bool additionalProperties;

            public static OpenAIToolParameters Permissive()
            {
                return new OpenAIToolParameters
                {
                    type = "object",
                    additionalProperties = true
                };
            }
        }

        [Serializable]
        private sealed class OpenAIResponseFormat
        {
            public string type;

            public static OpenAIResponseFormat JsonObject()
            {
                return new OpenAIResponseFormat
                {
                    type = "json_object"
                };
            }
        }

        [Serializable]
        private sealed class OpenAIChatMessage
        {
            public string role;
            public string content;
            public OpenAIToolCall[] tool_calls;
        }

        [Serializable]
        private sealed class OpenAIRequestMessage
        {
            public string role;
            public string content;
        }

        [Serializable]
        internal sealed class OpenAIToolCall
        {
            public string id;
            public string type;
            public OpenAIToolFunctionCall function;
        }

        [Serializable]
        internal sealed class OpenAIToolFunctionCall
        {
            public string name;
            public string arguments;
        }

        [Serializable]
        private sealed class OpenAIChatResponse
        {
            public OpenAIChoice[] choices;
        }

        [Serializable]
        private sealed class OpenAIChoice
        {
            public OpenAIChatMessage message;
        }

        [Serializable]
        private sealed class OpenAIErrorEnvelope
        {
            public OpenAIError error;
        }

        [Serializable]
        private sealed class OpenAIError
        {
            public string message;
        }

        [Serializable]
        internal sealed class BackendResponse
        {
            public string message;
            public string[] plan;
            public string[] progress;
            public AgentAction[] actions;
        }

        [Serializable]
        internal sealed class AgentAction
        {
            public string type;
            public string name;
            public string query;
            public string target;
            public string parent;
            public string path;
            public string asset_path;
            public string reference_asset_path;
            public string reference_target;
            public string asset_type;
            public string scriptable_type;
            public string component;
            public string[] components;
            public string role;
            public string content;
            public string id;
            public string status;
            public string title;
            public string description;
            public string assignee;
            public string verification;
            public string[] dependsOn;
            public string[] acceptanceCriteria;
            public AgentTaskRecord[] tasks;
            public string primitive_type;
            public string light_type;
            public string menu_item;
            public string package_id;
            public string property_path;
            public string class_name;
            public string method_name;
            public string value;
            public string value_type;
            public string color;
            public string secondary_color;
            public string shape;
            public string[] paths;
            public bool[] enabled;
            public bool use_position;
            public bool use_rotation;
            public bool use_scale;
            public bool orthographic;
            public bool open_scene;
            public Vector3Value position;
            public Vector3Value rotation;
            public Vector3Value scale;
            public int sorting_order;
            public int width;
            public int height;
            public int depth;
            public int int_value;
            public float float_value;
            public float pixels_per_unit;
            public float field_of_view;
            public float orthographic_size;
            public float intensity;
            public float range;
            public bool bool_value;
        }

        [Serializable]
        private sealed class PendingScriptAttachmentState
        {
            public PendingScriptAttachment[] attachments;
        }

        [Serializable]
        private sealed class PendingScriptAttachment
        {
            public string target;
            public string component;
            public int attempts;
        }

        [Serializable]
        internal struct Vector3Value
        {
            public float x;
            public float y;
            public float z;

            public Vector3 ToVector3()
            {
                return new Vector3(x, y, z);
            }

            public Vector2 ToVector2()
            {
                return new Vector2(x, y);
            }

            public Vector4 ToVector4()
            {
                return new Vector4(x, y, z, 0f);
            }
        }
        #pragma warning restore 0649
    }
}
