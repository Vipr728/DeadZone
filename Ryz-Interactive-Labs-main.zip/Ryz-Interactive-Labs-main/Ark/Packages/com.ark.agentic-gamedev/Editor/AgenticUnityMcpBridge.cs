using System;
using System.Collections.Generic;
using System.IO;
using System.Net;
using System.Text;
using System.Threading;
using UnityEditor;
using UnityEditor.SceneManagement;
using UnityEngine;
using UnityEngine.SceneManagement;

namespace AgenticGamedev.EditorTools
{
    [InitializeOnLoad]
    internal static class AgenticUnityMcpBridge
    {
        private const string BridgeHost = "127.0.0.1";
        private const int DefaultBridgePort = 47392;
        private const int MaxBridgePort = 47420;
        private const int ProtocolVersion = 1;
        private const int RequestTimeoutMilliseconds = 300000;
        private const int MaxLogEntries = 200;
        private const int MaxCachedCommandResults = 128;
        private const string BridgeTokenEnvironmentKey = "AGENTIC_UNITY_BRIDGE_TOKEN";
        private const string BridgeTokenHeader = "X-Agentic-Unity-Token";

        private static readonly object JobLock = new object();
        private static readonly Queue<BridgeJob> MainThreadJobs = new Queue<BridgeJob>();
        private static readonly object LogLock = new object();
        private static readonly List<LogEntry> Logs = new List<LogEntry>();
        private static readonly object CommandCacheLock = new object();
        private static readonly Dictionary<string, BridgeEnvelope> CachedCommandResults = new Dictionary<string, BridgeEnvelope>(StringComparer.Ordinal);
        private static readonly Queue<string> CachedCommandKeys = new Queue<string>();
        private static readonly string[] ProtocolCapabilities =
        {
            "unity.project.context",
            "unity.schema.get",
            "unity.logs.get",
            "unity.actions.preview",
            "unity.actions.execute_readonly",
            "unity.actions.execute"
        };

        private static HttpListener listener;
        private static Thread listenerThread;
        private static bool running;
        private static int bridgePort = DefaultBridgePort;
        private static string lastStartError = string.Empty;
        private static double nextStartAttemptTime;
        private static int revision = 1;
        private static readonly string sessionId = Guid.NewGuid().ToString("N");

        static AgenticUnityMcpBridge()
        {
            Application.logMessageReceived += CaptureLog;
            EditorApplication.update += EnsureServerRunning;
            EditorApplication.update += DrainMainThreadJobs;
            EditorApplication.hierarchyChanged += MarkRevisionDirty;
            EditorApplication.projectChanged += MarkRevisionDirty;
            EditorApplication.quitting += StopServer;
            AssemblyReloadEvents.beforeAssemblyReload += StopServer;
            EditorSceneManager.activeSceneChangedInEditMode += (_, _) => MarkRevisionDirty();
            EditorSceneManager.sceneOpened += (_, _) => MarkRevisionDirty();
            EditorSceneManager.sceneSaved += _ => MarkRevisionDirty();
            EditorSceneManager.newSceneCreated += (_, _, _) => MarkRevisionDirty();
            StartServer();
            EditorApplication.delayCall += StartServer;
        }

        [MenuItem("Tools/Ark/MCP Bridge/Start")]
        private static void StartFromMenu()
        {
            StartServer();
        }

        [MenuItem("Tools/Ark/MCP Bridge/Stop")]
        private static void StopFromMenu()
        {
            StopServer();
        }

        [MenuItem("Tools/Ark/MCP Bridge/Copy URL")]
        private static void CopyBridgeUrl()
        {
            EditorGUIUtility.systemCopyBuffer = CurrentBridgeUrl;
            Debug.Log($"Copied Ark Unity MCP bridge URL: {CurrentBridgeUrl}");
        }

        internal static bool EnsureServerRunningForCurrentProject(out string bridgeUrl, out string error)
        {
            StartServer();
            bridgeUrl = CurrentBridgeUrl;
            error = lastStartError;
            return running;
        }

        internal static string CurrentBridgeUrl => BuildBridgeUrl(bridgePort).TrimEnd('/');

        private static void StartServer()
        {
            if (running)
            {
                return;
            }

            lastStartError = string.Empty;
            for (int port = DefaultBridgePort; port <= MaxBridgePort; port++)
            {
                try
                {
                    listener = new HttpListener();
                    listener.Prefixes.Add(BuildBridgeUrl(port));
                    listener.Start();
                    bridgePort = port;
                    running = true;
                    listenerThread = new Thread(ListenLoop)
                    {
                        IsBackground = true,
                        Name = "Ark Unity MCP Bridge"
                    };
                    listenerThread.Start();
                    Debug.Log($"Ark Unity MCP bridge listening at {CurrentBridgeUrl}");
                    return;
                }
                catch (Exception exception)
                {
                    running = false;
                    lastStartError = exception.Message;
                    try
                    {
                        listener?.Close();
                    }
                    catch
                    {
                        // Listener failed before startup completed.
                    }

                    listener = null;
                }
            }

            Debug.LogWarning($"Could not start Ark Unity MCP bridge on ports {DefaultBridgePort}-{MaxBridgePort}: {lastStartError}");
        }

        private static void EnsureServerRunning()
        {
            if (running || EditorApplication.isCompiling || EditorApplication.isUpdating)
            {
                return;
            }

            double now = EditorApplication.timeSinceStartup;
            if (now < nextStartAttemptTime)
            {
                return;
            }

            nextStartAttemptTime = now + 2d;
            StartServer();
        }

        private static void StopServer()
        {
            running = false;
            try
            {
                listener?.Stop();
                listener?.Close();
            }
            catch (Exception)
            {
                // Listener is already stopped or disposed.
            }

            listener = null;
            listenerThread = null;
        }

        private static string BuildBridgeUrl(int port)
        {
            return $"http://{BridgeHost}:{port}/";
        }

        private static void ListenLoop()
        {
            while (running && listener != null)
            {
                try
                {
                    HttpListenerContext context = listener.GetContext();
                    ThreadPool.QueueUserWorkItem(_ => HandleRequest(context));
                }
                catch (HttpListenerException)
                {
                    return;
                }
                catch (ObjectDisposedException)
                {
                    return;
                }
                catch (Exception exception)
                {
                    Debug.LogWarning($"Ark Unity MCP bridge listener error: {exception.Message}");
                }
            }
        }

        private static void HandleRequest(HttpListenerContext context)
        {
            try
            {
                string method = context.Request.HttpMethod.ToUpperInvariant();
                string path = context.Request.Url == null
                    ? string.Empty
                    : context.Request.Url.AbsolutePath.Trim('/').ToLowerInvariant();

                if (!IsAuthorized(context.Request))
                {
                    WriteJson(context.Response, BridgeEnvelope.Failure("Unauthorized Unity bridge request."), 401);
                    return;
                }

                BridgeEnvelope envelope;
                switch (path)
                {
                    case "":
                    case "health":
                        envelope = RunOnMainThread(BuildHealthEnvelope);
                        break;

                    case "v1/health":
                        envelope = RunOnMainThread(BuildProtocolHealthEnvelope);
                        break;

                    case "context":
                        envelope = RunOnMainThread(() => BridgeEnvelope.Success(AgenticAgentBridge.BuildContext()));
                        break;

                    case "v1/context":
                        envelope = RunOnMainThread(BuildProtocolContextEnvelope);
                        break;

                    case "schema":
                        envelope = RunOnMainThread(() => BridgeEnvelope.Success(AgenticAgentBridge.GetActionSchemaForTools()));
                        break;

                    case "v1/schema":
                        envelope = RunOnMainThread(BuildProtocolSchemaEnvelope);
                        break;

                    case "logs":
                        envelope = BuildLogsEnvelope();
                        break;

                    case "v1/logs":
                        envelope = BuildProtocolLogsEnvelope();
                        break;

                    case "agent":
                        if (method != "POST")
                        {
                            envelope = BridgeEnvelope.Failure("Use POST for /agent.");
                            break;
                        }

                        _ = ReadRequestBody(context.Request);
                        envelope = BridgeEnvelope.Failure(
                            "/agent is disabled because running the full agent loop through the MCP bridge blocks the Unity editor main thread. Use the Ark chat window for agent runs; the bridge still supports context, schema, logs, dry-run, and direct action execution.");
                        break;

                    case "dry-run":
                        if (method != "POST")
                        {
                            envelope = BridgeEnvelope.Failure("Use POST for /dry-run.");
                            break;
                        }

                        string dryRunBody = ReadRequestBody(context.Request);
                        envelope = RunOnMainThread(() => BridgeEnvelope.Success(AgenticAgentBridge.PreviewActionJson(dryRunBody)));
                        break;

                    case "execute-readonly":
                        if (method != "POST")
                        {
                            envelope = BridgeEnvelope.Failure("Use POST for /execute-readonly.");
                            break;
                        }

                        string readonlyBody = ReadRequestBody(context.Request);
                        envelope = RunOnMainThread(() => BridgeEnvelope.Success(AgenticAgentBridge.ExecuteReadOnlyActionJson(readonlyBody)));
                        break;

                    case "execute":
                        if (method != "POST")
                        {
                            envelope = BridgeEnvelope.Failure("Use POST for /execute.");
                            break;
                        }

                        string body = ReadRequestBody(context.Request);
                        envelope = RunOnMainThread(() => BridgeEnvelope.Success(AgenticAgentBridge.ExecuteActionJson(body)));
                        break;

                    case "v1/command":
                        if (method != "POST")
                        {
                            envelope = BridgeEnvelope.Failure("Use POST for /v1/command.");
                            break;
                        }

                        string commandBody = ReadRequestBody(context.Request);
                        envelope = RunOnMainThread(() => ExecuteProtocolCommand(commandBody));
                        break;

                    default:
                        envelope = BridgeEnvelope.Failure($"Unknown bridge endpoint: /{path}");
                        break;
                }

                WriteJson(context.Response, envelope, envelope.ok ? 200 : 400);
            }
            catch (Exception exception)
            {
                WriteJson(context.Response, BridgeEnvelope.Failure(exception.Message), 500);
            }
        }

        private static bool IsAuthorized(HttpListenerRequest request)
        {
            string expectedToken = Environment.GetEnvironmentVariable(BridgeTokenEnvironmentKey);
            if (string.IsNullOrWhiteSpace(expectedToken))
            {
                return true;
            }

            string headerToken = request.Headers[BridgeTokenHeader];
            if (string.Equals(headerToken, expectedToken, StringComparison.Ordinal))
            {
                return true;
            }

            string authorization = request.Headers["Authorization"];
            const string bearerPrefix = "Bearer ";
            return !string.IsNullOrWhiteSpace(authorization) &&
                authorization.StartsWith(bearerPrefix, StringComparison.OrdinalIgnoreCase) &&
                string.Equals(authorization.Substring(bearerPrefix.Length).Trim(), expectedToken, StringComparison.Ordinal);
        }

        private static BridgeEnvelope RunOnMainThread(Func<BridgeEnvelope> work)
        {
            BridgeJob job = new BridgeJob(work);
            lock (JobLock)
            {
                MainThreadJobs.Enqueue(job);
            }

            if (!job.Done.WaitOne(RequestTimeoutMilliseconds))
            {
                return BridgeEnvelope.Failure("Timed out waiting for Unity editor main thread.");
            }

            return job.Response ?? BridgeEnvelope.Failure("Unity bridge returned no response.");
        }

        private static void MarkRevisionDirty()
        {
            if (revision == int.MaxValue)
            {
                revision = 1;
                return;
            }

            revision++;
        }

        private static void DrainMainThreadJobs()
        {
            while (true)
            {
                BridgeJob job;
                lock (JobLock)
                {
                    if (MainThreadJobs.Count == 0)
                    {
                        return;
                    }

                    job = MainThreadJobs.Dequeue();
                }

                try
                {
                    job.Response = job.Work();
                }
                catch (Exception exception)
                {
                    job.Response = BridgeEnvelope.Failure(exception.Message);
                }
                finally
                {
                    job.Done.Set();
                }
            }
        }

        private static BridgeEnvelope BuildHealthEnvelope()
        {
            Scene scene = SceneManager.GetActiveScene();
            BridgeEnvelope envelope = BridgeEnvelope.Success("Unity bridge is running.");
            envelope.unity_version = Application.unityVersion;
            envelope.project = Application.productName;
            envelope.scene = scene.name;
            envelope.scene_path = scene.path;
            envelope.bridge_url = CurrentBridgeUrl;
            envelope.is_compiling = EditorApplication.isCompiling;
            envelope.is_playing = EditorApplication.isPlaying;
            return envelope;
        }

        private static BridgeEnvelope BuildProtocolHealthEnvelope()
        {
            BridgeEnvelope envelope = BuildHealthEnvelope();
            envelope.protocol_version = ProtocolVersion;
            envelope.session_id = sessionId;
            envelope.revision = revision;
            envelope.capabilities = ProtocolCapabilities;
            envelope.payload_json = JsonUtility.ToJson(new ProtocolHealthPayload
            {
                protocol_version = ProtocolVersion,
                session_id = sessionId,
                revision = revision,
                unity_version = envelope.unity_version,
                project = envelope.project,
                scene = envelope.scene,
                scene_path = envelope.scene_path,
                bridge_url = envelope.bridge_url,
                is_compiling = envelope.is_compiling,
                is_playing = envelope.is_playing,
                capabilities = ProtocolCapabilities
            });
            return envelope;
        }

        private static BridgeEnvelope BuildProtocolContextEnvelope()
        {
            BridgeEnvelope envelope = BridgeEnvelope.Success("Collected Unity project context.");
            envelope.protocol_version = ProtocolVersion;
            envelope.session_id = sessionId;
            envelope.revision = revision;
            envelope.tool = "unity.project.context";
            envelope.payload_json = JsonUtility.ToJson(new TextPayload
            {
                text = AgenticAgentBridge.BuildContext()
            });
            return envelope;
        }

        private static BridgeEnvelope BuildProtocolSchemaEnvelope()
        {
            BridgeEnvelope envelope = BridgeEnvelope.Success("Collected Unity action schema.");
            envelope.protocol_version = ProtocolVersion;
            envelope.session_id = sessionId;
            envelope.revision = revision;
            envelope.tool = "unity.schema.get";
            envelope.payload_json = JsonUtility.ToJson(new TextPayload
            {
                text = AgenticAgentBridge.GetActionSchemaForTools()
            });
            return envelope;
        }

        private static BridgeEnvelope RunAgentPrompt(string body)
        {
            return BridgeEnvelope.Failure(
                "In-Unity agent orchestration is disabled. Use AgentDaemon or another backend scripting agent, then call Unity through bridge commands.");
        }

        private static BridgeEnvelope BuildLogsEnvelope()
        {
            BridgeEnvelope envelope = BridgeEnvelope.Success("Unity log snapshot.");
            lock (LogLock)
            {
                envelope.logs = Logs.ToArray();
            }

            return envelope;
        }

        private static BridgeEnvelope BuildProtocolLogsEnvelope()
        {
            BridgeEnvelope envelope = BuildLogsEnvelope();
            envelope.protocol_version = ProtocolVersion;
            envelope.session_id = sessionId;
            envelope.revision = revision;
            envelope.tool = "unity.logs.get";
            lock (LogLock)
            {
                envelope.payload_json = JsonUtility.ToJson(new ProtocolLogsPayload
                {
                    logs = Logs.ToArray()
                });
            }

            return envelope;
        }

        private static BridgeEnvelope ExecuteProtocolCommand(string body)
        {
            BridgeCommandRequest request;
            try
            {
                request = JsonUtility.FromJson<BridgeCommandRequest>(string.IsNullOrWhiteSpace(body) ? "{}" : body);
            }
            catch (Exception exception)
            {
                return BridgeEnvelope.Failure($"Invalid /v1/command JSON: {exception.Message}");
            }

            if (request == null || string.IsNullOrWhiteSpace(request.tool))
            {
                return BridgeEnvelope.Failure("/v1/command requires tool.");
            }

            string tool = request.tool.Trim();
            string idempotencyKey = string.IsNullOrWhiteSpace(request.idempotency_key) ? string.Empty : request.idempotency_key.Trim();
            if (!string.IsNullOrWhiteSpace(idempotencyKey) && TryGetCachedCommandResult(idempotencyKey, out BridgeEnvelope cached))
            {
                return CloneEnvelope(cached);
            }

            bool isMutating = IsMutatingTool(tool);
            if (isMutating && request.expected_revision >= 0 && request.expected_revision != revision)
            {
                BridgeEnvelope mismatch = BridgeEnvelope.Failure(
                    $"Unity revision mismatch. Expected {request.expected_revision}, actual {revision}.");
                mismatch.protocol_version = ProtocolVersion;
                mismatch.session_id = sessionId;
                mismatch.revision = revision;
                mismatch.request_id = request.request_id;
                mismatch.tool = tool;
                mismatch.is_mutating = true;
                return mismatch;
            }

            string summary;
            string payloadJson = string.Empty;
            switch (tool)
            {
                case "unity.project.context":
                    return FinalizeProtocolEnvelope(request, BuildProtocolContextEnvelope(), false);

                case "unity.schema.get":
                    return FinalizeProtocolEnvelope(request, BuildProtocolSchemaEnvelope(), false);

                case "unity.logs.get":
                    return FinalizeProtocolEnvelope(request, BuildProtocolLogsEnvelope(), false);

                case "unity.actions.preview":
                    summary = AgenticAgentBridge.PreviewActionJson(request.payload_json ?? string.Empty);
                    payloadJson = JsonUtility.ToJson(new TextPayload { text = summary });
                    break;

                case "unity.actions.execute_readonly":
                    summary = AgenticAgentBridge.ExecuteReadOnlyActionJson(request.payload_json ?? string.Empty);
                    payloadJson = JsonUtility.ToJson(new TextPayload { text = summary });
                    break;

                case "unity.actions.execute":
                    summary = AgenticAgentBridge.ExecuteActionJson(request.payload_json ?? string.Empty);
                    payloadJson = JsonUtility.ToJson(new TextPayload { text = summary });
                    break;

                case "unity.agent.run":
                    BridgeEnvelope disabledAgentRun = BridgeEnvelope.Failure(
                        "unity.agent.run is disabled. Run scripting agents outside Unity through AgentDaemon, and use Unity bridge commands only for narrow Unity context/action execution.");
                    disabledAgentRun.protocol_version = ProtocolVersion;
                    disabledAgentRun.session_id = sessionId;
                    disabledAgentRun.revision = revision;
                    disabledAgentRun.request_id = request.request_id;
                    disabledAgentRun.tool = tool;
                    disabledAgentRun.is_mutating = false;
                    disabledAgentRun.capabilities = ProtocolCapabilities;
                    disabledAgentRun.payload_json = JsonUtility.ToJson(new TextPayload { text = disabledAgentRun.error });
                    return disabledAgentRun;

                default:
                    BridgeEnvelope unsupported = BridgeEnvelope.Failure($"Unknown protocol tool: {tool}");
                    unsupported.protocol_version = ProtocolVersion;
                    unsupported.session_id = sessionId;
                    unsupported.revision = revision;
                    unsupported.request_id = request.request_id;
                    unsupported.tool = tool;
                    unsupported.is_mutating = isMutating;
                    return unsupported;
            }

            if (isMutating)
            {
                MarkRevisionDirty();
            }

            BridgeEnvelope result = BridgeEnvelope.Success(summary);
            result.protocol_version = ProtocolVersion;
            result.session_id = sessionId;
            result.revision = revision;
            result.request_id = request.request_id;
            result.tool = tool;
            result.is_mutating = isMutating;
            result.payload_json = payloadJson;
            result.capabilities = ProtocolCapabilities;
            return FinalizeProtocolEnvelope(request, result, isMutating);
        }

        private static string ResolveAgentPayload(BridgeCommandRequest request)
        {
            if (!string.IsNullOrWhiteSpace(request.payload_json))
            {
                return request.payload_json;
            }

            if (!string.IsNullOrWhiteSpace(request.input))
            {
                return JsonUtility.ToJson(new AgentPromptRequest
                {
                    prompt = request.input,
                    mode = "auto_run"
                });
            }

            return "{}";
        }

        private static BridgeEnvelope FinalizeProtocolEnvelope(BridgeCommandRequest request, BridgeEnvelope envelope, bool isMutating)
        {
            envelope.protocol_version = ProtocolVersion;
            envelope.session_id = sessionId;
            envelope.revision = revision;
            envelope.request_id = request.request_id;
            envelope.tool = string.IsNullOrWhiteSpace(envelope.tool) ? request.tool?.Trim() : envelope.tool;
            envelope.is_mutating = isMutating || envelope.is_mutating;
            envelope.capabilities = envelope.capabilities == null || envelope.capabilities.Length == 0
                ? ProtocolCapabilities
                : envelope.capabilities;
            if (!string.IsNullOrWhiteSpace(request.idempotency_key))
            {
                CacheCommandResult(request.idempotency_key.Trim(), envelope);
            }

            return envelope;
        }

        private static void CacheCommandResult(string key, BridgeEnvelope envelope)
        {
            lock (CommandCacheLock)
            {
                CachedCommandResults[key] = CloneEnvelope(envelope);
                CachedCommandKeys.Enqueue(key);
                while (CachedCommandKeys.Count > MaxCachedCommandResults)
                {
                    string oldest = CachedCommandKeys.Dequeue();
                    CachedCommandResults.Remove(oldest);
                }
            }
        }

        private static bool TryGetCachedCommandResult(string key, out BridgeEnvelope envelope)
        {
            lock (CommandCacheLock)
            {
                if (CachedCommandResults.TryGetValue(key, out BridgeEnvelope cached))
                {
                    envelope = CloneEnvelope(cached);
                    return true;
                }
            }

            envelope = null;
            return false;
        }

        private static BridgeEnvelope CloneEnvelope(BridgeEnvelope source)
        {
            if (source == null)
            {
                return null;
            }

            return new BridgeEnvelope
            {
                ok = source.ok,
                result = source.result,
                error = source.error,
                unity_version = source.unity_version,
                project = source.project,
                scene = source.scene,
                scene_path = source.scene_path,
                bridge_url = source.bridge_url,
                is_compiling = source.is_compiling,
                is_playing = source.is_playing,
                logs = source.logs,
                protocol_version = source.protocol_version,
                request_id = source.request_id,
                tool = source.tool,
                session_id = source.session_id,
                revision = source.revision,
                is_mutating = source.is_mutating,
                payload_json = source.payload_json,
                capabilities = source.capabilities
            };
        }

        private static bool IsMutatingTool(string tool)
        {
            switch ((tool ?? string.Empty).Trim().ToLowerInvariant())
            {
                case "unity.actions.execute":
                    return true;
                default:
                    return false;
            }
        }

        private static string FirstNonEmpty(string first, string second)
        {
            return !string.IsNullOrWhiteSpace(first) ? first : second ?? string.Empty;
        }

        private static void CaptureLog(string condition, string stackTrace, LogType type)
        {
            lock (LogLock)
            {
                Logs.Add(new LogEntry
                {
                    type = type.ToString(),
                    message = condition,
                    stack_trace = stackTrace,
                    timestamp_utc = DateTime.UtcNow.ToString("o")
                });

                while (Logs.Count > MaxLogEntries)
                {
                    Logs.RemoveAt(0);
                }
            }
        }

        private static string ReadRequestBody(HttpListenerRequest request)
        {
            using (Stream stream = request.InputStream)
            using (StreamReader reader = new StreamReader(stream, request.ContentEncoding ?? Encoding.UTF8))
            {
                return reader.ReadToEnd();
            }
        }

        private static void WriteJson(HttpListenerResponse response, BridgeEnvelope envelope, int statusCode)
        {
            string json = JsonUtility.ToJson(envelope, true);
            byte[] bytes = Encoding.UTF8.GetBytes(json);
            response.StatusCode = statusCode;
            response.ContentType = "application/json";
            response.ContentEncoding = Encoding.UTF8;
            response.ContentLength64 = bytes.Length;
            response.Headers["Access-Control-Allow-Origin"] = "http://127.0.0.1";
            using (Stream output = response.OutputStream)
            {
                output.Write(bytes, 0, bytes.Length);
            }
        }

        private sealed class BridgeJob
        {
            public readonly Func<BridgeEnvelope> Work;
            public readonly ManualResetEvent Done = new ManualResetEvent(false);
            public BridgeEnvelope Response;

            public BridgeJob(Func<BridgeEnvelope> work)
            {
                Work = work;
            }
        }

        [Serializable]
        private sealed class BridgeEnvelope
        {
            public bool ok;
            public string result;
            public string error;
            public string unity_version;
            public string project;
            public string scene;
            public string scene_path;
            public string bridge_url;
            public bool is_compiling;
            public bool is_playing;
            public LogEntry[] logs;
            public int protocol_version;
            public string request_id;
            public string tool;
            public string session_id;
            public int revision;
            public bool is_mutating;
            public string payload_json;
            public string[] capabilities;

            public static BridgeEnvelope Success(string result)
            {
                return new BridgeEnvelope
                {
                    ok = true,
                    result = result
                };
            }

            public static BridgeEnvelope Failure(string error)
            {
                return new BridgeEnvelope
                {
                    ok = false,
                    error = error
                };
            }
        }

        [Serializable]
        private sealed class AgentPromptRequest
        {
            public string prompt;
            public string mode;
            public string role_hint;
        }

        [Serializable]
        private sealed class BridgeCommandRequest
        {
            public int protocol_version = ProtocolVersion;
            public string request_id;
            public string tool;
            public string input;
            public string payload_json;
            public int expected_revision = -1;
            public string idempotency_key;
            public string risk_level;
            public int timeout_ms;
        }

        [Serializable]
        private sealed class ProtocolHealthPayload
        {
            public int protocol_version;
            public string session_id;
            public int revision;
            public string unity_version;
            public string project;
            public string scene;
            public string scene_path;
            public string bridge_url;
            public bool is_compiling;
            public bool is_playing;
            public string[] capabilities;
        }

        [Serializable]
        private sealed class ProtocolLogsPayload
        {
            public LogEntry[] logs;
        }

        [Serializable]
        private sealed class TextPayload
        {
            public string text;
        }

        [Serializable]
        private sealed class LogEntry
        {
            public string type;
            public string message;
            public string stack_trace;
            public string timestamp_utc;
        }
    }
}
