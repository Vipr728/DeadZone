using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using UnityEditor;
using UnityEditor.ShortcutManagement;
using UnityEditor.UIElements;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UIElements;
using Object = UnityEngine.Object;

namespace AgenticGamedev.EditorTools
{
    internal sealed class AgenticChatWindow : EditorWindow
    {
        private const float WindowWidth = 580f;
        private const float WindowHeight = 540f;
        private const int OpenAIPollIntervalMs = 250;
        private const int RunningAnimationIntervalMs = 650;
        private const int AutoContinuationDelayMs = 350;
        private const long MainThreadWorkNoticeMs = 250;
        private const int InitialTranscriptChunkSize = 60;
        private const int OlderTranscriptChunkSize = 40;
        private const float TranscriptBottomThreshold = 36f;
        private const string HeaderTooltip = "Ark: prompt-driven Unity scene, asset, prefab, and code assistant.";
        private const string BackendRunIdPrefsKey = "AgenticGamedev.ActiveBackendRunId";
        private const string BackendRunEndpointPrefsKey = "AgenticGamedev.ActiveBackendRunEndpoint";
        private const string LastBackendRunIdPrefsKey = "AgenticGamedev.LastBackendRunId";
        private const string LastBackendRunEndpointPrefsKey = "AgenticGamedev.LastBackendRunEndpoint";
        private const int ReplayStepDelayMs = 650;
        private const int VisibleReplayEventCount = 6;

        private static AgenticChatWindow instance;
        private static Font codeFont;

        private ScrollView transcript;
        private TextField promptField;
        private Button sendButton;
        private Button stopButton;
        private Button jumpToLatestButton;
        private Button loadOlderButton;
        private VisualElement connectionStatusDot;
        private VisualElement runningStatusPill;
        private VisualElement runningPulseDot;
        private VisualElement runningProgressFill;
        private Label runningStatusLabel;
        private VisualElement runDashboard;
        private Label runDashboardTitle;
        private Label runDashboardMeta;
        private Label runDashboardHandoff;
        private VisualElement runDashboardTaskList;
        private Label runDashboardIssues;
        private VisualElement replayPanel;
        private Label replayStatusLabel;
        private VisualElement replayEventList;
        private Button replayButton;
        private VisualElement taggedItemsRow;
        private ObjectField tagObjectField;
        private Button tagSelectionButton;
        private Button tagObjectButton;
        private Button clearTaggedButton;
        private VisualElement mentionSuggestions;
        private bool isBusy;
        private long activeWorkId;
        private long runningAnimationWorkId;
        private int runningAnimationTick;
        private RenderedMessage activeWorkingMessage;
        private WorkLog activeWorkLog;
        private AgenticAgentBridge.ToolLoopState activeToolLoopState;
        private readonly Queue<QueuedPrompt> queuedPrompts = new Queue<QueuedPrompt>();
        private readonly List<AgenticChatStore.Message> messages = new List<AgenticChatStore.Message>();
        private readonly List<MentionCandidate> currentMentionCandidates = new List<MentionCandidate>();
        private readonly List<DeferredEditorAction> deferredEditorActions = new List<DeferredEditorAction>();
        private readonly List<AgenticAgentBridge.BackendRunEvent> replayEvents =
            new List<AgenticAgentBridge.BackendRunEvent>();
        private int firstRenderedMessageIndex;
        private bool isRenderingTranscriptBatch;
        private bool isReplayPlaying;
        private long replayPlaybackId;

        private static bool IsDarkTheme => EditorGUIUtility.isProSkin;
        private static Color WindowBackground => IsDarkTheme ? new Color(0.17f, 0.17f, 0.17f) : new Color(0.78f, 0.78f, 0.78f);
        private static Color PanelBackground => IsDarkTheme ? new Color(0.22f, 0.22f, 0.22f) : new Color(0.88f, 0.88f, 0.88f);
        private static Color PanelHover => IsDarkTheme ? new Color(0.27f, 0.27f, 0.27f) : new Color(0.94f, 0.94f, 0.94f);
        private static Color FieldBackground => IsDarkTheme ? new Color(0.13f, 0.13f, 0.13f) : new Color(0.98f, 0.98f, 0.98f);
        private static Color BorderColor => IsDarkTheme ? new Color(0.31f, 0.31f, 0.31f) : new Color(0.58f, 0.58f, 0.58f);
        private static Color PrimaryColor => IsDarkTheme ? new Color(0.18f, 0.38f, 0.64f) : new Color(0.2f, 0.42f, 0.72f);
        private static Color PrimaryHover => IsDarkTheme ? new Color(0.23f, 0.46f, 0.76f) : new Color(0.24f, 0.49f, 0.82f);
        private static Color TextColor => IsDarkTheme ? new Color(0.82f, 0.82f, 0.82f) : new Color(0.12f, 0.12f, 0.12f);
        private static Color MutedTextColor => IsDarkTheme ? new Color(0.6f, 0.6f, 0.6f) : new Color(0.36f, 0.36f, 0.36f);
        private static Color ReadyColor => new Color(0.25f, 0.78f, 0.42f);
        private static Color RunningAccent => IsDarkTheme ? new Color(0.95f, 0.56f, 0.18f) : new Color(0.86f, 0.37f, 0.12f);
        private static Color RunningAccentHot => IsDarkTheme ? new Color(1f, 0.77f, 0.31f) : new Color(1f, 0.55f, 0.22f);
        private static Color RunningPillBackground => IsDarkTheme ? new Color(0.24f, 0.17f, 0.11f) : new Color(1f, 0.9f, 0.8f);
        private static Color RunningTrackBackground => IsDarkTheme ? new Color(0.38f, 0.27f, 0.18f) : new Color(0.9f, 0.63f, 0.43f);

        [Shortcut("Ark/Toggle Chat", KeyCode.Space, ShortcutModifiers.Alt)]
        private static void ToggleChatShortcut()
        {
            if (instance != null)
            {
                instance.Close();
                return;
            }

            OpenFloating();
        }

        [MenuItem("Tools/Ark/Open Chat")]
        private static void OpenFromMenu()
        {
            OpenFloating();
        }

        [InitializeOnLoadMethod]
        private static void RestoreInterruptedRunAfterReload()
        {
            EditorApplication.delayCall += EnsureWindowForInterruptedRun;
        }

        private static void OpenFloating()
        {
            if (instance != null)
            {
                instance.Focus();
                return;
            }

            AgenticChatWindow window = CreateInstance<AgenticChatWindow>();
            window.titleContent = new GUIContent("Ark");
            window.minSize = new Vector2(520f, 480f);
            window.maxSize = new Vector2(760f, 720f);
            window.position = GetCenteredWindowRect(WindowWidth, WindowHeight);
            window.ShowUtility();
            window.Focus();
            instance = window;
        }

        private static void EnsureWindowForInterruptedRun()
        {
            if (instance != null || !AgenticAgentBridge.HasResumableToolLoopState())
            {
                return;
            }

            if (EditorApplication.isCompiling || EditorApplication.isUpdating)
            {
                EditorApplication.delayCall += EnsureWindowForInterruptedRun;
                return;
            }

            OpenFloating();
        }

        private static Rect GetCenteredWindowRect(float width, float height)
        {
            Rect mainWindow = EditorGUIUtility.GetMainWindowPosition();
            return new Rect(
                mainWindow.x + (mainWindow.width - width) * 0.5f,
                mainWindow.y + 96f,
                width,
                height);
        }

        private void OnEnable()
        {
            instance = this;
            EditorApplication.update -= OnEditorUpdate;
            EditorApplication.update += OnEditorUpdate;
            Selection.selectionChanged -= OnUnitySelectionChanged;
            Selection.selectionChanged += OnUnitySelectionChanged;
            AgenticTaggedContextStore.Changed -= OnTaggedContextChanged;
            AgenticTaggedContextStore.Changed += OnTaggedContextChanged;
            BuildInterface();
            ScheduleEditorAction(TryResumeInterruptedToolLoop, 250);
            ScheduleEditorAction(TryResumeInterruptedBackendRun, 350);
            ScheduleEditorAction(TryLoadLastBackendReplay, 500);
        }

        private void OnDestroy()
        {
            activeWorkId++;
            EditorApplication.update -= OnEditorUpdate;
            deferredEditorActions.Clear();
            Selection.selectionChanged -= OnUnitySelectionChanged;
            AgenticTaggedContextStore.Changed -= OnTaggedContextChanged;
            if (instance == this)
            {
                instance = null;
            }
        }

        private void OnEditorUpdate()
        {
            if (deferredEditorActions.Count == 0)
            {
                return;
            }

            double now = EditorApplication.timeSinceStartup;
            for (int i = deferredEditorActions.Count - 1; i >= 0; i--)
            {
                DeferredEditorAction scheduled = deferredEditorActions[i];
                if (scheduled == null || scheduled.ExecuteAtTime > now)
                {
                    continue;
                }

                deferredEditorActions.RemoveAt(i);
                try
                {
                    scheduled.Action?.Invoke();
                }
                catch (Exception exception)
                {
                    Debug.LogException(exception);
                }
            }
        }

        private void ScheduleEditorAction(Action action, int delayMs = 0)
        {
            if (action == null)
            {
                return;
            }

            deferredEditorActions.Add(new DeferredEditorAction
            {
                ExecuteAtTime = EditorApplication.timeSinceStartup + Mathf.Max(0, delayMs) / 1000d,
                Action = action
            });
        }

        private void RequestUiRefresh()
        {
            rootVisualElement?.MarkDirtyRepaint();
            Repaint();
        }

        private void BuildInterface()
        {
            VisualElement root = rootVisualElement;
            root.Clear();
            root.style.backgroundColor = WindowBackground;
            root.style.paddingLeft = 12f;
            root.style.paddingRight = 12f;
            root.style.paddingTop = 10f;
            root.style.paddingBottom = 10f;
            root.style.flexDirection = FlexDirection.Column;
            root.style.overflow = Overflow.Hidden;

            root.Add(BuildHeader());
            root.Add(BuildRunDashboard());
            root.Add(BuildReplayPanel());

            transcript = new ScrollView
            {
                mode = ScrollViewMode.Vertical
            };
            transcript.style.flexGrow = 1f;
            transcript.style.flexShrink = 1f;
            transcript.style.minHeight = 0f;
            transcript.style.marginTop = 10f;
            transcript.style.marginBottom = 10f;
            transcript.style.paddingRight = 4f;
            transcript.verticalScroller.valueChanged += OnTranscriptScrollValueChanged;
            root.Add(transcript);

            LoadTranscript();
            root.Add(BuildJumpToLatestButton());
            root.Add(BuildComposer());
            ResetStaleBusyState();

            root.RegisterCallback<KeyDownEvent>(evt =>
            {
                if (evt.keyCode == KeyCode.Escape)
                {
                    Close();
                    evt.StopPropagation();
                }
            });

            root.schedule.Execute(() => promptField.Focus()).ExecuteLater(80);
            RefreshRunDashboard();
        }

        private Button BuildJumpToLatestButton()
        {
            jumpToLatestButton = new Button(() => ScheduleScrollToBottom(force: true))
            {
                text = "Jump to latest",
                tooltip = "Scroll to the newest chat message"
            };
            jumpToLatestButton.style.alignSelf = Align.Center;
            jumpToLatestButton.style.marginTop = -6f;
            jumpToLatestButton.style.marginBottom = 6f;
            jumpToLatestButton.style.height = 24f;
            jumpToLatestButton.style.paddingLeft = 12f;
            jumpToLatestButton.style.paddingRight = 12f;
            jumpToLatestButton.style.paddingTop = 0f;
            jumpToLatestButton.style.paddingBottom = 1f;
            jumpToLatestButton.style.fontSize = 10f;
            jumpToLatestButton.style.color = Color.white;
            jumpToLatestButton.style.backgroundColor = PrimaryColor;
            jumpToLatestButton.style.display = DisplayStyle.None;
            SetBorder(jumpToLatestButton, PrimaryHover);
            SetRadius(jumpToLatestButton, 12f);
            AttachButtonHover(jumpToLatestButton, PrimaryColor, PrimaryHover);
            return jumpToLatestButton;
        }

        private VisualElement BuildHeader()
        {
            VisualElement header = new VisualElement();
            header.style.flexDirection = FlexDirection.Row;
            header.style.alignItems = Align.Center;
            header.style.minHeight = 42f;

            connectionStatusDot = new VisualElement();
            connectionStatusDot.style.width = 10f;
            connectionStatusDot.style.height = 10f;
            connectionStatusDot.tooltip = "Ark is ready.";
            SetRadius(connectionStatusDot, 5f);
            connectionStatusDot.style.backgroundColor = ReadyColor;
            connectionStatusDot.style.marginRight = 10f;
            header.Add(connectionStatusDot);

            Label title = new Label("Ark");
            title.tooltip = HeaderTooltip;
            title.style.color = TextColor;
            title.style.fontSize = 15f;
            title.style.unityFontStyleAndWeight = FontStyle.Bold;
            header.Add(title);

            string connectionMode = AgenticAgentBridge.GetConnectionModeLabel();
            Label mode = new Label(connectionMode);
            mode.style.marginLeft = 10f;
            mode.style.paddingLeft = 8f;
            mode.style.paddingRight = 8f;
            mode.style.paddingTop = 3f;
            mode.style.paddingBottom = 3f;
            mode.style.color = Color.white;
            mode.style.backgroundColor = GetModeColor(connectionMode);
            SetRadius(mode, 5f);
            mode.style.fontSize = 10f;
            mode.style.unityFontStyleAndWeight = FontStyle.Bold;
            header.Add(mode);

            header.Add(BuildRunningStatusPill());

            VisualElement spacer = new VisualElement();
            spacer.style.flexGrow = 1f;
            header.Add(spacer);

            Button settings = new Button(AgenticSettingsWindow.Open)
            {
                text = "Settings",
                tooltip = "Configure OpenAI API key and optional backend endpoint"
            };
            StyleUtilityButton(settings);
            header.Add(settings);

            Button copyAll = new Button(CopyTranscriptToClipboard)
            {
                text = "Copy All",
                tooltip = "Copy all prompts and responses"
            };
            StyleUtilityButton(copyAll);
            header.Add(copyAll);

            Button clear = new Button(ClearTranscript)
            {
                text = "Clear",
                tooltip = "Clear this chat transcript"
            };
            StyleUtilityButton(clear);
            header.Add(clear);

            Button close = new Button(Close)
            {
                text = "X",
                tooltip = "Close"
            };
            StyleIconButton(close);
            header.Add(close);

            return header;
        }

        private VisualElement BuildRunningStatusPill()
        {
            runningStatusPill = new VisualElement();
            runningStatusPill.style.flexDirection = FlexDirection.Row;
            runningStatusPill.style.alignItems = Align.Center;
            runningStatusPill.style.height = 24f;
            runningStatusPill.style.marginLeft = 10f;
            runningStatusPill.style.paddingLeft = 8f;
            runningStatusPill.style.paddingRight = 8f;
            runningStatusPill.style.backgroundColor = RunningPillBackground;
            runningStatusPill.style.display = DisplayStyle.None;
            runningStatusPill.tooltip = "Ark is running.";
            SetBorder(runningStatusPill, RunningTrackBackground);
            SetRadius(runningStatusPill, 6f);

            runningPulseDot = new VisualElement();
            runningPulseDot.style.width = 7f;
            runningPulseDot.style.height = 7f;
            runningPulseDot.style.marginRight = 7f;
            runningPulseDot.style.backgroundColor = RunningAccent;
            runningPulseDot.tooltip = "Ark is running.";
            SetRadius(runningPulseDot, 4f);
            runningStatusPill.Add(runningPulseDot);

            runningStatusLabel = new Label("Agent running");
            runningStatusLabel.tooltip = "Ark is running.";
            runningStatusLabel.style.color = TextColor;
            runningStatusLabel.style.fontSize = 10f;
            runningStatusLabel.style.unityFontStyleAndWeight = FontStyle.Bold;
            runningStatusLabel.style.minWidth = 86f;
            runningStatusPill.Add(runningStatusLabel);

            VisualElement progressTrack = new VisualElement();
            progressTrack.style.width = 58f;
            progressTrack.style.height = 3f;
            progressTrack.style.marginLeft = 8f;
            progressTrack.style.backgroundColor = RunningTrackBackground;
            progressTrack.style.overflow = Overflow.Hidden;
            SetRadius(progressTrack, 2f);

            runningProgressFill = new VisualElement();
            runningProgressFill.style.width = 18f;
            runningProgressFill.style.height = 3f;
            runningProgressFill.style.backgroundColor = RunningAccentHot;
            SetRadius(runningProgressFill, 2f);
            progressTrack.Add(runningProgressFill);

            runningStatusPill.Add(progressTrack);
            return runningStatusPill;
        }

        private VisualElement BuildRunDashboard()
        {
            runDashboard = new VisualElement();
            runDashboard.style.display = DisplayStyle.None;
            runDashboard.style.flexDirection = FlexDirection.Column;
            runDashboard.style.marginTop = 8f;
            runDashboard.style.marginBottom = 2f;
            runDashboard.style.paddingLeft = 10f;
            runDashboard.style.paddingRight = 10f;
            runDashboard.style.paddingTop = 8f;
            runDashboard.style.paddingBottom = 8f;
            runDashboard.style.backgroundColor = IsDarkTheme ? new Color(0.19f, 0.2f, 0.21f) : new Color(0.84f, 0.88f, 0.92f);
            SetBorder(runDashboard, IsDarkTheme ? new Color(0.29f, 0.35f, 0.42f) : new Color(0.58f, 0.68f, 0.78f));
            SetRadius(runDashboard, 7f);

            VisualElement header = new VisualElement();
            header.style.flexDirection = FlexDirection.Row;
            header.style.alignItems = Align.Center;
            runDashboard.Add(header);

            runDashboardTitle = new Label("Agent run");
            runDashboardTitle.style.color = TextColor;
            runDashboardTitle.style.fontSize = 11f;
            runDashboardTitle.style.unityFontStyleAndWeight = FontStyle.Bold;
            runDashboardTitle.style.flexGrow = 1f;
            header.Add(runDashboardTitle);

            Button copyState = new Button(CopyRunDashboardState)
            {
                text = "Copy",
                tooltip = "Copy live run state"
            };
            StyleMiniChipButton(copyState);
            header.Add(copyState);

            runDashboardMeta = new Label();
            runDashboardMeta.style.color = MutedTextColor;
            runDashboardMeta.style.fontSize = 10f;
            runDashboardMeta.style.whiteSpace = WhiteSpace.Normal;
            runDashboardMeta.style.marginTop = 3f;
            runDashboard.Add(runDashboardMeta);

            runDashboardHandoff = new Label();
            runDashboardHandoff.style.color = MutedTextColor;
            runDashboardHandoff.style.fontSize = 10f;
            runDashboardHandoff.style.whiteSpace = WhiteSpace.Normal;
            runDashboardHandoff.style.marginTop = 4f;
            runDashboardHandoff.style.display = DisplayStyle.None;
            runDashboard.Add(runDashboardHandoff);

            runDashboardTaskList = new VisualElement();
            runDashboardTaskList.style.flexDirection = FlexDirection.Column;
            runDashboardTaskList.style.marginTop = 6f;
            runDashboard.Add(runDashboardTaskList);

            runDashboardIssues = new Label();
            runDashboardIssues.style.color = IsDarkTheme ? new Color(1f, 0.62f, 0.44f) : new Color(0.62f, 0.18f, 0.08f);
            runDashboardIssues.style.fontSize = 10f;
            runDashboardIssues.style.whiteSpace = WhiteSpace.Normal;
            runDashboardIssues.style.marginTop = 5f;
            runDashboardIssues.style.display = DisplayStyle.None;
            runDashboard.Add(runDashboardIssues);

            return runDashboard;
        }

        private VisualElement BuildReplayPanel()
        {
            replayPanel = new VisualElement();
            replayPanel.style.display = DisplayStyle.None;
            replayPanel.style.flexDirection = FlexDirection.Column;
            replayPanel.style.marginTop = 6f;
            replayPanel.style.marginBottom = 2f;
            replayPanel.style.paddingLeft = 10f;
            replayPanel.style.paddingRight = 10f;
            replayPanel.style.paddingTop = 8f;
            replayPanel.style.paddingBottom = 8f;
            replayPanel.style.backgroundColor = IsDarkTheme
                ? new Color(0.18f, 0.21f, 0.19f)
                : new Color(0.84f, 0.91f, 0.86f);
            SetBorder(
                replayPanel,
                IsDarkTheme ? new Color(0.25f, 0.43f, 0.31f) : new Color(0.48f, 0.68f, 0.54f));
            SetRadius(replayPanel, 7f);

            VisualElement header = new VisualElement();
            header.style.flexDirection = FlexDirection.Row;
            header.style.alignItems = Align.Center;
            replayPanel.Add(header);

            Label title = new Label("Change replay");
            title.style.color = TextColor;
            title.style.fontSize = 11f;
            title.style.unityFontStyleAndWeight = FontStyle.Bold;
            title.style.flexGrow = 1f;
            header.Add(title);

            replayButton = new Button(ToggleReplayPlayback)
            {
                text = "Replay",
                tooltip = "Replay Ark's recorded Unity changes in order"
            };
            StyleMiniChipButton(replayButton);
            replayButton.SetEnabled(false);
            header.Add(replayButton);

            replayStatusLabel = new Label("No recorded Unity changes yet.");
            replayStatusLabel.style.color = MutedTextColor;
            replayStatusLabel.style.fontSize = 10f;
            replayStatusLabel.style.whiteSpace = WhiteSpace.Normal;
            replayStatusLabel.style.marginTop = 3f;
            replayPanel.Add(replayStatusLabel);

            replayEventList = new VisualElement();
            replayEventList.style.flexDirection = FlexDirection.Column;
            replayEventList.style.marginTop = 5f;
            replayPanel.Add(replayEventList);

            return replayPanel;
        }

        private void ToggleReplayPlayback()
        {
            if (isReplayPlaying)
            {
                StopReplayPlayback("Replay stopped.");
                return;
            }

            if (replayEvents.Count == 0)
            {
                return;
            }

            isReplayPlaying = true;
            long playbackId = ++replayPlaybackId;
            replayButton.text = "Stop";
            replayButton.tooltip = "Stop replay";
            RenderReplayEvents(0, true);
            ScheduleEditorAction(() => AdvanceReplayPlayback(playbackId, 0), 100);
        }

        private void AdvanceReplayPlayback(long playbackId, int eventIndex)
        {
            if (!isReplayPlaying || playbackId != replayPlaybackId)
            {
                return;
            }

            int visibleCount = Mathf.Min(eventIndex + 1, replayEvents.Count);
            RenderReplayEvents(visibleCount, true);
            if (visibleCount >= replayEvents.Count)
            {
                isReplayPlaying = false;
                replayButton.text = "Replay";
                replayButton.tooltip = "Replay Ark's recorded Unity changes in order";
                replayStatusLabel.text = $"Replay complete · {replayEvents.Count} recorded event(s).";
                return;
            }

            ScheduleEditorAction(
                () => AdvanceReplayPlayback(playbackId, eventIndex + 1),
                ReplayStepDelayMs);
        }

        private void StopReplayPlayback(string status)
        {
            isReplayPlaying = false;
            replayPlaybackId++;
            if (replayButton != null)
            {
                replayButton.text = "Replay";
                replayButton.tooltip = "Replay Ark's recorded Unity changes in order";
            }
            RenderReplayEvents(replayEvents.Count, false);
            if (replayStatusLabel != null && !string.IsNullOrWhiteSpace(status))
            {
                replayStatusLabel.text = status;
            }
        }

        private void UpdateReplayTimeline(AgenticAgentBridge.BackendRunStatus run)
        {
            if (run?.events == null)
            {
                return;
            }

            replayEvents.Clear();
            foreach (AgenticAgentBridge.BackendRunEvent runEvent in run.events)
            {
                if (IsReplayEvent(runEvent))
                {
                    replayEvents.Add(runEvent);
                }
            }

            if (replayPanel == null)
            {
                return;
            }

            bool hasReplay = replayEvents.Count > 0;
            replayPanel.style.display = hasReplay ? DisplayStyle.Flex : DisplayStyle.None;
            replayButton?.SetEnabled(hasReplay);
            if (!hasReplay || isReplayPlaying)
            {
                return;
            }

            RenderReplayEvents(replayEvents.Count, false);
            replayStatusLabel.text = run.IsTerminal
                ? $"{replayEvents.Count} Unity change/check event(s) recorded · ready to replay."
                : $"Recording live · {replayEvents.Count} Unity change/check event(s).";
        }

        private void TryLoadLastBackendReplay()
        {
            if (isBusy || replayEvents.Count > 0)
            {
                return;
            }

            string runId = EditorPrefs.GetString(LastBackendRunIdPrefsKey, string.Empty);
            if (string.IsNullOrWhiteSpace(runId))
            {
                return;
            }

            string endpoint = EditorPrefs.GetString(
                LastBackendRunEndpointPrefsKey,
                AgenticAgentBridge.DefaultEndpoint);
            AgenticAgentBridge.PreparedRequest request = new AgenticAgentBridge.PreparedRequest
            {
                DisplayName = "Backend change replay",
                Endpoint = string.IsNullOrWhiteSpace(endpoint)
                    ? AgenticAgentBridge.DefaultEndpoint
                    : endpoint,
                IncludeApiKeyHeader = false,
                Kind = AgenticAgentBridge.PreparedRequestKind.BackendJson
            };
            Task<AgenticAgentBridge.BackendRunStatus> task = Task.Run(
                () => AgenticAgentBridge.GetBackendRunReplay(request, runId));
            PollLastBackendReplay(task);
        }

        private void PollLastBackendReplay(Task<AgenticAgentBridge.BackendRunStatus> task)
        {
            if (task == null)
            {
                return;
            }

            if (!task.IsCompleted)
            {
                ScheduleEditorAction(() => PollLastBackendReplay(task), OpenAIPollIntervalMs);
                return;
            }

            if (task.IsCanceled || task.IsFaulted)
            {
                if (task.IsFaulted && AgenticAgentBridge.GetDeveloperMode())
                {
                    Debug.LogWarning(
                        $"Could not load the last Ark change replay: " +
                        $"{AgenticAgentBridge.FormatRequestException(task.Exception)}");
                }
                return;
            }

            UpdateReplayTimeline(task.Result);
            RequestUiRefresh();
        }

        private void RenderReplayEvents(int visibleCount, bool replaying)
        {
            if (replayEventList == null)
            {
                return;
            }

            replayEventList.Clear();
            int count = Mathf.Clamp(visibleCount, 0, replayEvents.Count);
            int first = Mathf.Max(0, count - VisibleReplayEventCount);
            for (int i = first; i < count; i++)
            {
                replayEventList.Add(BuildReplayEventRow(replayEvents[i], i + 1));
            }

            if (count == 0)
            {
                replayEventList.Add(CreateDashboardNote(
                    replaying ? "Replay is starting…" : "No recorded Unity changes yet."));
            }

            if (replaying && replayStatusLabel != null)
            {
                replayStatusLabel.text = $"Replaying {count}/{replayEvents.Count}";
            }
        }

        private VisualElement BuildReplayEventRow(
            AgenticAgentBridge.BackendRunEvent runEvent,
            int displayIndex)
        {
            VisualElement row = new VisualElement();
            row.style.flexDirection = FlexDirection.Row;
            row.style.alignItems = Align.FlexStart;
            row.style.marginTop = 3f;

            Label index = new Label(displayIndex.ToString());
            index.style.minWidth = 24f;
            index.style.height = 18f;
            index.style.marginRight = 6f;
            index.style.fontSize = 9f;
            index.style.unityTextAlign = TextAnchor.MiddleCenter;
            index.style.color = Color.white;
            index.style.backgroundColor = IsReplayChange(runEvent)
                ? new Color(0.18f, 0.56f, 0.32f)
                : new Color(0.28f, 0.43f, 0.62f);
            SetRadius(index, 5f);
            row.Add(index);

            string timestamp = FormatReplayTimestamp(runEvent?.timestamp);
            string summary = (runEvent?.summary ?? string.Empty).Trim();
            Label detail = new Label(string.IsNullOrWhiteSpace(timestamp)
                ? summary
                : $"{timestamp}  {summary}");
            detail.style.flexGrow = 1f;
            detail.style.minWidth = 0f;
            detail.style.color = TextColor;
            detail.style.fontSize = 10f;
            detail.style.whiteSpace = WhiteSpace.Normal;
            detail.tooltip = BuildReplayEventTooltip(runEvent);
            row.Add(detail);
            return row;
        }

        private static bool IsReplayEvent(AgenticAgentBridge.BackendRunEvent runEvent)
        {
            string type = (runEvent?.type ?? string.Empty).Trim();
            return string.Equals(type, "replay.change", StringComparison.OrdinalIgnoreCase) ||
                string.Equals(type, "replay.check", StringComparison.OrdinalIgnoreCase);
        }

        private static bool IsReplayChange(AgenticAgentBridge.BackendRunEvent runEvent)
        {
            return string.Equals(
                (runEvent?.type ?? string.Empty).Trim(),
                "replay.change",
                StringComparison.OrdinalIgnoreCase);
        }

        private static string FormatReplayTimestamp(string value)
        {
            return DateTime.TryParse(value, out DateTime parsed)
                ? parsed.ToLocalTime().ToString("HH:mm:ss")
                : string.Empty;
        }

        private static string BuildReplayEventTooltip(AgenticAgentBridge.BackendRunEvent runEvent)
        {
            AgenticAgentBridge.BackendRunEventPayload payload = runEvent?.payload;
            if (payload == null)
            {
                return runEvent?.summary ?? string.Empty;
            }

            StringBuilder builder = new StringBuilder(runEvent?.summary ?? string.Empty);
            if (!string.IsNullOrWhiteSpace(payload.action_type))
            {
                builder.AppendLine();
                builder.Append("Action: ");
                builder.Append(payload.action_type);
            }
            if (!string.IsNullOrWhiteSpace(payload.target))
            {
                builder.AppendLine();
                builder.Append("Target: ");
                builder.Append(payload.target);
            }
            if (!string.IsNullOrWhiteSpace(payload.path))
            {
                builder.AppendLine();
                builder.Append("Path: ");
                builder.Append(payload.path);
            }
            return builder.ToString();
        }

        private void RefreshRunDashboard()
        {
            if (runDashboard == null)
            {
                return;
            }

            AgenticAgentBridge.ToolLoopState state = activeToolLoopState;
            bool resumable = AgenticAgentBridge.HasResumableToolLoopState();
            if (state == null && !isBusy && !resumable)
            {
                runDashboard.style.display = DisplayStyle.None;
                return;
            }

            runDashboard.style.display = DisplayStyle.Flex;
            if (state == null)
            {
                runDashboardTitle.text = isBusy ? "Agent run starting" : "Interrupted agent run";
                runDashboardMeta.text = resumable
                    ? "Resume state is saved. The agent will continue after Unity finishes compiling or updating."
                    : "Preparing request and reading Unity context.";
                runDashboardHandoff.style.display = DisplayStyle.None;
                runDashboardTaskList.Clear();
                runDashboardTaskList.Add(CreateDashboardNote("No tool-loop task plan is active yet."));
                runDashboardIssues.style.display = DisplayStyle.None;
                return;
            }

            string agentLabel = AgenticAgentBridge.GetActiveToolLoopAgentLabel(state);
            runDashboardTitle.text = $"Live run: {agentLabel}";
            runDashboardMeta.text =
                $"Run {FormatRunId(state.RunId)} | checkpoint {state.CheckpointSequence} saved | requests {state.RequestCount} | tools {state.LoggedToolCalls} | handoffs {state.HandoffCount} | applied {state.AppliedActions}";

            string handoff = BuildHandoffDashboardText(state);
            if (string.IsNullOrWhiteSpace(handoff))
            {
                runDashboardHandoff.style.display = DisplayStyle.None;
            }
            else
            {
                runDashboardHandoff.style.display = DisplayStyle.Flex;
                runDashboardHandoff.text = handoff;
            }

            RefreshTaskPlanDashboard(state);
            RefreshIssueDashboard(state);
        }

        private void RefreshTaskPlanDashboard(AgenticAgentBridge.ToolLoopState state)
        {
            runDashboardTaskList.Clear();
            if (state == null || state.TaskPlan.Count == 0)
            {
                string note = state != null && state.HandoffCount > 0
                    ? "Task plan missing. The manager has delegated work, so strict completion will require a structured plan."
                    : "Task plan not set yet.";
                runDashboardTaskList.Add(CreateDashboardNote(note));
                return;
            }

            int completed = 0;
            int skipped = 0;
            int open = 0;
            foreach (AgenticAgentBridge.AgentTaskRecord task in state.TaskPlan)
            {
                string status = NormalizeDashboardStatus(task?.status);
                if (string.Equals(status, "completed", StringComparison.Ordinal))
                {
                    completed++;
                }
                else if (string.Equals(status, "skipped", StringComparison.Ordinal))
                {
                    skipped++;
                }
                else
                {
                    open++;
                }
            }

            Label summary = CreateDashboardNote($"Task plan: {completed} completed, {skipped} skipped, {open} open");
            summary.style.color = open > 0 ? RunningAccentHot : ReadyColor;
            runDashboardTaskList.Add(summary);

            int rendered = 0;
            foreach (AgenticAgentBridge.AgentTaskRecord task in state.TaskPlan)
            {
                if (task == null)
                {
                    continue;
                }

                if (rendered >= 6)
                {
                    runDashboardTaskList.Add(CreateDashboardNote($"+ {state.TaskPlan.Count - rendered} more task(s)"));
                    break;
                }

                runDashboardTaskList.Add(BuildTaskPlanRow(task));
                rendered++;
            }
        }

        private void RefreshIssueDashboard(AgenticAgentBridge.ToolLoopState state)
        {
            if (runDashboardIssues == null)
            {
                return;
            }

            int openTasks = CountOpenDashboardTasks(state);
            int issueCount = CountNonEmptyLogLines(state?.IssueLog);
            if (openTasks == 0 && issueCount == 0 && state != null && state.StrictCompletionRetryCount == 0)
            {
                runDashboardIssues.style.display = DisplayStyle.None;
                return;
            }

            StringBuilder builder = new StringBuilder();
            if (openTasks > 0)
            {
                builder.Append(openTasks == 1 ? "Blocker: 1 task still open." : $"Blockers: {openTasks} tasks still open.");
            }

            if (issueCount > 0)
            {
                if (builder.Length > 0)
                {
                    builder.Append(' ');
                }

                builder.Append(issueCount == 1 ? "1 issue is recorded." : $"{issueCount} issues are recorded.");
            }

            if (state != null && state.StrictCompletionRetryCount > 0)
            {
                if (builder.Length > 0)
                {
                    builder.Append(' ');
                }

                builder.Append($"Strict gate retries: {state.StrictCompletionRetryCount}.");
            }

            runDashboardIssues.text = builder.ToString();
            runDashboardIssues.style.display = DisplayStyle.Flex;
        }

        private VisualElement BuildTaskPlanRow(AgenticAgentBridge.AgentTaskRecord task)
        {
            VisualElement row = new VisualElement();
            row.style.flexDirection = FlexDirection.Row;
            row.style.alignItems = Align.Center;
            row.style.marginTop = 3f;
            row.style.minHeight = 20f;

            string status = NormalizeDashboardStatus(task.status);
            Label statusChip = new Label(status);
            statusChip.style.minWidth = 72f;
            statusChip.style.height = 18f;
            statusChip.style.marginRight = 6f;
            statusChip.style.paddingLeft = 6f;
            statusChip.style.paddingRight = 6f;
            statusChip.style.paddingTop = 1f;
            statusChip.style.paddingBottom = 1f;
            statusChip.style.fontSize = 9f;
            statusChip.style.unityTextAlign = TextAnchor.MiddleCenter;
            statusChip.style.color = Color.white;
            statusChip.style.backgroundColor = GetTaskStatusColor(status);
            SetRadius(statusChip, 5f);
            row.Add(statusChip);

            Label title = new Label(BuildTaskDashboardTitle(task));
            title.style.flexGrow = 1f;
            title.style.minWidth = 0f;
            title.style.fontSize = 10f;
            title.style.color = TextColor;
            title.style.overflow = Overflow.Hidden;
            title.style.textOverflow = TextOverflow.Ellipsis;
            title.tooltip = BuildTaskDashboardTooltip(task);
            row.Add(title);

            return row;
        }

        private Label CreateDashboardNote(string text)
        {
            Label label = new Label(text);
            label.style.color = MutedTextColor;
            label.style.fontSize = 10f;
            label.style.whiteSpace = WhiteSpace.Normal;
            return label;
        }

        private void CopyRunDashboardState()
        {
            EditorGUIUtility.systemCopyBuffer = BuildRunDashboardStateText();
        }

        private string BuildRunDashboardStateText()
        {
            AgenticAgentBridge.ToolLoopState state = activeToolLoopState;
            if (state == null)
            {
                return AgenticAgentBridge.HasResumableToolLoopState()
                    ? "Interrupted agent run: resumable state is saved."
                    : "No active agent run.";
            }

            StringBuilder builder = new StringBuilder();
            builder.AppendLine($"Run: {FormatRunId(state.RunId)}");
            builder.AppendLine($"Current agent: {AgenticAgentBridge.GetActiveToolLoopAgentLabel(state)}");
            builder.AppendLine($"Checkpoint: {state.CheckpointSequence}");
            builder.AppendLine($"Requests: {state.RequestCount}");
            builder.AppendLine($"Tools: {state.LoggedToolCalls}");
            builder.AppendLine($"Handoffs: {state.HandoffCount}");
            builder.AppendLine($"Applied actions: {state.AppliedActions}");
            string handoff = BuildHandoffDashboardText(state);
            if (!string.IsNullOrWhiteSpace(handoff))
            {
                builder.AppendLine(handoff);
            }

            if (state.TaskPlan.Count > 0)
            {
                builder.AppendLine("Task plan:");
                foreach (AgenticAgentBridge.AgentTaskRecord task in state.TaskPlan)
                {
                    builder.Append("- ");
                    builder.Append(NormalizeDashboardStatus(task?.status));
                    builder.Append(' ');
                    builder.AppendLine(BuildTaskDashboardTitle(task));
                }
            }
            else
            {
                builder.AppendLine("Task plan: not set");
            }

            int issueCount = CountNonEmptyLogLines(state.IssueLog);
            if (issueCount > 0)
            {
                builder.AppendLine($"Issues recorded: {issueCount}");
            }

            return builder.ToString().TrimEnd();
        }

        private static string BuildHandoffDashboardText(AgenticAgentBridge.ToolLoopState state)
        {
            if (state == null || string.IsNullOrWhiteSpace(state.pendingHandoffTask))
            {
                return string.Empty;
            }

            string role = string.IsNullOrWhiteSpace(state.pendingHandoffRole)
                ? AgenticAgentBridge.GetActiveToolLoopAgentLabel(state)
                : state.pendingHandoffRole.Trim();
            return $"Specialist task [{role}]: {TrimDashboardText(state.pendingHandoffTask, 180)}";
        }

        private static string BuildTaskDashboardTitle(AgenticAgentBridge.AgentTaskRecord task)
        {
            if (task == null)
            {
                return "task";
            }

            string id = string.IsNullOrWhiteSpace(task.id) ? string.Empty : task.id.Trim();
            string title = string.IsNullOrWhiteSpace(task.title) ? task.description : task.title;
            title = string.IsNullOrWhiteSpace(title) ? "task" : title.Trim();
            string assignee = string.IsNullOrWhiteSpace(task.assignee) ? string.Empty : $" [{task.assignee.Trim()}]";
            return string.IsNullOrWhiteSpace(id)
                ? TrimDashboardText(title + assignee, 140)
                : TrimDashboardText($"{id}: {title}{assignee}", 140);
        }

        private static string BuildTaskDashboardTooltip(AgenticAgentBridge.AgentTaskRecord task)
        {
            if (task == null)
            {
                return string.Empty;
            }

            StringBuilder builder = new StringBuilder();
            builder.AppendLine(BuildTaskDashboardTitle(task));
            if (!string.IsNullOrWhiteSpace(task.description))
            {
                builder.AppendLine(task.description.Trim());
            }

            if (task.dependsOn != null && task.dependsOn.Length > 0)
            {
                builder.AppendLine("Depends on: " + string.Join(", ", task.dependsOn));
            }

            if (task.acceptanceCriteria != null && task.acceptanceCriteria.Length > 0)
            {
                builder.AppendLine("Acceptance: " + string.Join("; ", task.acceptanceCriteria));
            }

            if (!string.IsNullOrWhiteSpace(task.verification))
            {
                builder.AppendLine("Verification: " + task.verification.Trim());
            }

            return builder.ToString().TrimEnd();
        }

        private static int CountOpenDashboardTasks(AgenticAgentBridge.ToolLoopState state)
        {
            if (state == null || state.TaskPlan.Count == 0)
            {
                return 0;
            }

            int count = 0;
            foreach (AgenticAgentBridge.AgentTaskRecord task in state.TaskPlan)
            {
                string status = NormalizeDashboardStatus(task?.status);
                if (!string.Equals(status, "completed", StringComparison.Ordinal) &&
                    !string.Equals(status, "skipped", StringComparison.Ordinal))
                {
                    count++;
                }
            }

            return count;
        }

        private static int CountNonEmptyLogLines(StringBuilder builder)
        {
            if (builder == null || builder.Length == 0)
            {
                return 0;
            }

            int count = 0;
            string[] lines = builder.ToString().Replace("\r\n", "\n").Replace('\r', '\n').Split('\n');
            foreach (string line in lines)
            {
                if (!string.IsNullOrWhiteSpace(line))
                {
                    count++;
                }
            }

            return count;
        }

        private static string NormalizeDashboardStatus(string status)
        {
            if (string.IsNullOrWhiteSpace(status))
            {
                return "pending";
            }

            string normalized = status.Trim().ToLowerInvariant().Replace(" ", "_").Replace("-", "_");
            switch (normalized)
            {
                case "done":
                case "complete":
                    return "completed";
                case "inprogress":
                case "running":
                case "active":
                    return "in_progress";
                case "fail":
                case "error":
                    return "failed";
                default:
                    return normalized;
            }
        }

        private static Color GetTaskStatusColor(string status)
        {
            switch (NormalizeDashboardStatus(status))
            {
                case "completed":
                    return new Color(0.18f, 0.56f, 0.32f);
                case "skipped":
                    return new Color(0.42f, 0.42f, 0.42f);
                case "blocked":
                case "failed":
                    return new Color(0.7f, 0.2f, 0.16f);
                case "in_progress":
                    return RunningAccent;
                default:
                    return IsDarkTheme ? new Color(0.28f, 0.38f, 0.52f) : new Color(0.34f, 0.5f, 0.68f);
            }
        }

        private static string FormatRunId(string runId)
        {
            if (string.IsNullOrWhiteSpace(runId))
            {
                return "unknown";
            }

            string trimmed = runId.Trim();
            return trimmed.Length <= 12 ? trimmed : trimmed.Substring(trimmed.Length - 12);
        }

        private static string TrimDashboardText(string value, int maxLength)
        {
            if (string.IsNullOrWhiteSpace(value))
            {
                return string.Empty;
            }

            string normalized = value.Trim().Replace("\r\n", " ").Replace('\r', ' ').Replace('\n', ' ');
            while (normalized.Contains("  "))
            {
                normalized = normalized.Replace("  ", " ");
            }

            if (normalized.Length <= maxLength)
            {
                return normalized;
            }

            return normalized.Substring(0, Mathf.Max(0, maxLength - 3)) + "...";
        }

        private VisualElement BuildTaggedContextPanel()
        {
            VisualElement panel = new VisualElement();
            panel.style.marginBottom = 4f;
            panel.style.minHeight = 0f;
            panel.style.flexGrow = 0f;
            panel.style.flexShrink = 0f;
            panel.style.backgroundColor = Color.clear;

            VisualElement controls = new VisualElement();
            controls.style.flexDirection = FlexDirection.Row;
            controls.style.alignItems = Align.Center;
            controls.style.flexWrap = Wrap.NoWrap;
            controls.style.height = 30f;
            controls.style.minHeight = 30f;
            controls.style.flexGrow = 0f;
            controls.style.flexShrink = 0f;
            panel.Add(controls);

            Label title = new Label("Context");
            title.style.color = TextColor;
            title.style.fontSize = 10f;
            title.style.unityFontStyleAndWeight = FontStyle.Bold;
            title.style.marginRight = 8f;
            controls.Add(title);

            tagSelectionButton = new Button(TagCurrentSelection)
            {
                text = "Selection",
                tooltip = "Add the current Hierarchy or Project selection to the agent context"
            };
            StyleContextButton(tagSelectionButton);
            tagSelectionButton.style.width = 74f;
            tagSelectionButton.style.marginBottom = 4f;
            controls.Add(tagSelectionButton);

            tagObjectField = new ObjectField
            {
                objectType = typeof(Object),
                allowSceneObjects = true,
                tooltip = "Drag a GameObject, script, prefab, material, texture, or other asset here"
            };
            tagObjectField.style.width = 148f;
            tagObjectField.style.minWidth = 112f;
            tagObjectField.style.maxWidth = 168f;
            tagObjectField.style.height = 22f;
            tagObjectField.style.marginRight = 6f;
            tagObjectField.style.marginBottom = 4f;
            tagObjectField.style.flexGrow = 0f;
            tagObjectField.style.flexShrink = 1f;
            tagObjectField.RegisterValueChangedCallback(_ => UpdateTagControlState());
            controls.Add(tagObjectField);

            tagObjectButton = new Button(TagObjectFieldValue)
            {
                text = "+",
                tooltip = "Add the dragged object or asset to the agent context"
            };
            StyleContextButton(tagObjectButton);
            tagObjectButton.style.width = 28f;
            tagObjectButton.style.marginBottom = 4f;
            controls.Add(tagObjectButton);

            clearTaggedButton = new Button(ClearTaggedContext)
            {
                text = "Clear",
                tooltip = "Remove all tagged context items"
            };
            StyleContextButton(clearTaggedButton);
            clearTaggedButton.style.width = 46f;
            clearTaggedButton.style.marginBottom = 4f;
            controls.Add(clearTaggedButton);

            taggedItemsRow = new VisualElement();
            taggedItemsRow.style.flexDirection = FlexDirection.Row;
            taggedItemsRow.style.flexWrap = Wrap.NoWrap;
            taggedItemsRow.style.alignItems = Align.Center;
            taggedItemsRow.style.height = 24f;
            taggedItemsRow.style.marginTop = 0f;
            taggedItemsRow.style.marginBottom = 4f;
            taggedItemsRow.style.flexGrow = 1f;
            taggedItemsRow.style.flexShrink = 1f;
            taggedItemsRow.style.minWidth = 0f;
            taggedItemsRow.style.overflow = Overflow.Hidden;
            controls.Add(taggedItemsRow);

            RefreshTaggedContextPanel();
            UpdateTagControlState();
            return panel;
        }

        private VisualElement BuildMentionSuggestions()
        {
            mentionSuggestions = new VisualElement();
            mentionSuggestions.style.flexDirection = FlexDirection.Row;
            mentionSuggestions.style.flexWrap = Wrap.Wrap;
            mentionSuggestions.style.marginBottom = 7f;
            mentionSuggestions.style.display = DisplayStyle.None;
            return mentionSuggestions;
        }

        private void OnUnitySelectionChanged()
        {
            UpdateTagControlState();
        }

        private void OnTaggedContextChanged()
        {
            RefreshTaggedContextPanel();
            UpdateTagControlState();
        }

        private void UpdateTagControlState()
        {
            tagSelectionButton?.SetEnabled(Selection.objects != null && Selection.objects.Length > 0);
            tagObjectButton?.SetEnabled(tagObjectField != null && tagObjectField.value != null);
        }

        private void TagCurrentSelection()
        {
            int added = AgenticTaggedContextStore.AddObjects(Selection.objects);
            RefreshTaggedContextPanel();
            UpdateTagControlState();

            if (added == 0 && Selection.objects.Length > 0)
            {
                Debug.Log("Ark tagged context was already up to date for the current selection.");
            }
        }

        private void TagObjectFieldValue()
        {
            Object value = tagObjectField == null ? null : tagObjectField.value;
            if (value == null)
            {
                return;
            }

            AgenticTaggedContextStore.AddObject(value);
            tagObjectField.value = null;
            RefreshTaggedContextPanel();
            UpdateTagControlState();
        }

        private void UpdateMentionSuggestions()
        {
            if (mentionSuggestions == null)
            {
                return;
            }

            mentionSuggestions.Clear();
            currentMentionCandidates.Clear();
            if (!TryGetActiveMentionToken(out string token))
            {
                mentionSuggestions.style.display = DisplayStyle.None;
                return;
            }

            List<MentionCandidate> candidates = FindMentionCandidates(token, 7);
            if (candidates.Count == 0)
            {
                mentionSuggestions.style.display = DisplayStyle.None;
                return;
            }

            currentMentionCandidates.AddRange(candidates);
            mentionSuggestions.style.display = DisplayStyle.Flex;
            foreach (MentionCandidate candidate in candidates)
            {
                mentionSuggestions.Add(BuildMentionSuggestionButton(candidate));
            }
        }

        private Button BuildMentionSuggestionButton(MentionCandidate candidate)
        {
            Button button = new Button(() => AcceptMentionCandidate(candidate))
            {
                text = "@" + candidate.Label,
                tooltip = candidate.Detail
            };
            StyleMentionButton(button);
            return button;
        }

        private void AcceptMentionCandidate(MentionCandidate candidate)
        {
            if (candidate == null || candidate.Target == null)
            {
                return;
            }

            AgenticTaggedContextStore.AddObject(candidate.Target);
            ReplaceActiveMention(candidate);
            RefreshTaggedContextPanel();
            UpdateTagControlState();
            HideMentionSuggestions();
            promptField?.Focus();
        }

        private bool TryAcceptFirstMentionSuggestion()
        {
            if (mentionSuggestions == null ||
                mentionSuggestions.style.display == DisplayStyle.None ||
                currentMentionCandidates.Count == 0)
            {
                return false;
            }

            AcceptMentionCandidate(currentMentionCandidates[0]);
            return true;
        }

        private void HideMentionSuggestions()
        {
            currentMentionCandidates.Clear();
            if (mentionSuggestions != null)
            {
                mentionSuggestions.Clear();
                mentionSuggestions.style.display = DisplayStyle.None;
            }
        }

        private bool TryGetActiveMentionToken(out string token)
        {
            token = string.Empty;
            string text = promptField?.value ?? string.Empty;
            int atIndex = text.LastIndexOf('@');
            if (atIndex < 0)
            {
                return false;
            }

            if (atIndex > 0 && !char.IsWhiteSpace(text[atIndex - 1]))
            {
                return false;
            }

            string after = text.Substring(atIndex + 1);
            if (after.IndexOfAny(new[] { '\n', '\r', '\t' }) >= 0)
            {
                return false;
            }

            int spaceIndex = after.IndexOf(' ');
            if (spaceIndex >= 0)
            {
                return false;
            }

            token = after.Trim();
            return true;
        }

        private void ReplaceActiveMention(MentionCandidate candidate)
        {
            string text = promptField?.value ?? string.Empty;
            int atIndex = text.LastIndexOf('@');
            if (atIndex < 0)
            {
                return;
            }

            string replacement = "@[" + candidate.Label + "]";
            promptField.value = text.Substring(0, atIndex) + replacement;
        }

        private void TagMentionReferencesInPrompt(string prompt)
        {
            foreach (string token in ExtractMentionTokens(prompt))
            {
                MentionCandidate candidate = FindBestMentionCandidate(token);
                if (candidate?.Target != null)
                {
                    AgenticTaggedContextStore.AddObject(candidate.Target);
                }
            }

            RefreshTaggedContextPanel();
            UpdateTagControlState();
        }

        private static List<string> ExtractMentionTokens(string prompt)
        {
            List<string> tokens = new List<string>();
            if (string.IsNullOrWhiteSpace(prompt))
            {
                return tokens;
            }

            for (int i = 0; i < prompt.Length; i++)
            {
                if (prompt[i] != '@')
                {
                    continue;
                }

                if (i + 1 < prompt.Length && prompt[i + 1] == '[')
                {
                    int close = prompt.IndexOf(']', i + 2);
                    if (close > i + 2)
                    {
                        tokens.Add(prompt.Substring(i + 2, close - i - 2));
                        i = close;
                    }

                    continue;
                }

                int start = i + 1;
                int end = start;
                while (end < prompt.Length && IsMentionTokenCharacter(prompt[end]))
                {
                    end++;
                }

                if (end > start)
                {
                    tokens.Add(prompt.Substring(start, end - start));
                    i = end - 1;
                }
            }

            return tokens;
        }

        private static bool IsMentionTokenCharacter(char character)
        {
            return char.IsLetterOrDigit(character) ||
                character == '_' ||
                character == '-' ||
                character == '.' ||
                character == '/';
        }

        private MentionCandidate FindBestMentionCandidate(string token)
        {
            string normalized = NormalizeMentionText(token);
            if (string.IsNullOrWhiteSpace(normalized))
            {
                return null;
            }

            List<MentionCandidate> candidates = FindMentionCandidates(token, 12);
            MentionCandidate exact = candidates.Find(candidate =>
                string.Equals(NormalizeMentionText(candidate.Label), normalized, StringComparison.Ordinal) ||
                string.Equals(NormalizeMentionText(candidate.Detail), normalized, StringComparison.Ordinal));
            if (exact != null)
            {
                return exact;
            }

            return candidates.Count == 1 && normalized.Length >= 3 ? candidates[0] : null;
        }

        private List<MentionCandidate> FindMentionCandidates(string token, int maxCount)
        {
            string normalized = NormalizeMentionText(token);
            List<MentionCandidate> candidates = new List<MentionCandidate>();
            HashSet<int> seen = new HashSet<int>();

            foreach (Object selected in Selection.objects ?? Array.Empty<Object>())
            {
                AddMentionCandidate(candidates, seen, selected, maxCount);
            }

            Scene scene = SceneManager.GetActiveScene();
            foreach (GameObject root in scene.GetRootGameObjects())
            {
                AddSceneMentionCandidates(root.transform, normalized, candidates, seen, maxCount);
                if (candidates.Count >= maxCount)
                {
                    return candidates;
                }
            }

            if (!string.IsNullOrWhiteSpace(normalized))
            {
                string[] guids = AssetDatabase.FindAssets(token, new[] { "Assets" });
                int assetCount = Mathf.Min(guids.Length, 40);
                for (int i = 0; i < assetCount && candidates.Count < maxCount; i++)
                {
                    string path = AssetDatabase.GUIDToAssetPath(guids[i]);
                    Object asset = AssetDatabase.LoadAssetAtPath<Object>(path);
                    AddMentionCandidate(candidates, seen, asset, maxCount);
                }
            }

            return candidates;
        }

        private void AddSceneMentionCandidates(
            Transform transform,
            string normalizedToken,
            List<MentionCandidate> candidates,
            HashSet<int> seen,
            int maxCount)
        {
            if (transform == null || candidates.Count >= maxCount)
            {
                return;
            }

            string label = transform.gameObject.name;
            string detail = GetHierarchyPath(transform.gameObject);
            if (string.IsNullOrWhiteSpace(normalizedToken) ||
                NormalizeMentionText(label).Contains(normalizedToken) ||
                NormalizeMentionText(detail).Contains(normalizedToken))
            {
                AddMentionCandidate(candidates, seen, transform.gameObject, maxCount);
            }

            for (int i = 0; i < transform.childCount && candidates.Count < maxCount; i++)
            {
                AddSceneMentionCandidates(transform.GetChild(i), normalizedToken, candidates, seen, maxCount);
            }
        }

        private static void AddMentionCandidate(
            List<MentionCandidate> candidates,
            HashSet<int> seen,
            Object target,
            int maxCount)
        {
            if (target == null || candidates.Count >= maxCount || !seen.Add(target.GetInstanceID()))
            {
                return;
            }

            string assetPath = AssetDatabase.GetAssetPath(target);
            string label = string.IsNullOrWhiteSpace(target.name)
                ? target.GetType().Name
                : target.name;
            string detail = target is GameObject gameObject
                ? GetHierarchyPath(gameObject)
                : string.IsNullOrWhiteSpace(assetPath) ? target.GetType().Name : assetPath;

            candidates.Add(new MentionCandidate(target, label, detail));
        }

        private static string NormalizeMentionText(string value)
        {
            if (string.IsNullOrWhiteSpace(value))
            {
                return string.Empty;
            }

            return value.Trim()
                .Replace(" ", string.Empty)
                .Replace("_", string.Empty)
                .Replace("-", string.Empty)
                .ToLowerInvariant();
        }

        private static string GetHierarchyPath(GameObject gameObject)
        {
            if (gameObject == null)
            {
                return string.Empty;
            }

            Stack<string> parts = new Stack<string>();
            Transform current = gameObject.transform;
            while (current != null)
            {
                parts.Push(current.name);
                current = current.parent;
            }

            return string.Join("/", parts.ToArray());
        }

        private void AttachTaggedContextDropTarget(VisualElement element)
        {
            if (element == null)
            {
                return;
            }

            element.RegisterCallback<DragUpdatedEvent>(OnTaggedContextDragUpdated, TrickleDown.TrickleDown);
            element.RegisterCallback<DragPerformEvent>(OnTaggedContextDragPerform, TrickleDown.TrickleDown);
        }

        private void OnTaggedContextDragUpdated(DragUpdatedEvent evt)
        {
            if (!HasDraggedUnityObjects())
            {
                return;
            }

            DragAndDrop.visualMode = DragAndDropVisualMode.Copy;
            evt.StopPropagation();
        }

        private void OnTaggedContextDragPerform(DragPerformEvent evt)
        {
            if (!HasDraggedUnityObjects())
            {
                return;
            }

            Object[] draggedObjects = DragAndDrop.objectReferences;
            DragAndDrop.AcceptDrag();
            AgenticTaggedContextStore.AddObjects(draggedObjects);
            RefreshTaggedContextPanel();
            UpdateTagControlState();
            evt.StopPropagation();
        }

        private static bool HasDraggedUnityObjects()
        {
            return DragAndDrop.objectReferences != null && DragAndDrop.objectReferences.Length > 0;
        }

        private void ClearTaggedContext()
        {
            AgenticTaggedContextStore.Clear();
            RefreshTaggedContextPanel();
            UpdateTagControlState();
        }

        private void RefreshTaggedContextPanel()
        {
            if (taggedItemsRow == null)
            {
                return;
            }

            taggedItemsRow.Clear();
            List<AgenticTaggedContextStore.TaggedItem> items = AgenticTaggedContextStore.Load();
            if (clearTaggedButton != null)
            {
                clearTaggedButton.style.display = items.Count == 0 ? DisplayStyle.None : DisplayStyle.Flex;
            }

            if (items.Count == 0)
            {
                taggedItemsRow.style.display = DisplayStyle.None;
                taggedItemsRow.style.height = 0f;
                return;
            }

            taggedItemsRow.style.display = DisplayStyle.Flex;
            taggedItemsRow.style.height = 24f;
            foreach (AgenticTaggedContextStore.TaggedItem item in items)
            {
                taggedItemsRow.Add(BuildTaggedItemChip(item));
            }
        }

        private VisualElement BuildTaggedItemChip(AgenticTaggedContextStore.TaggedItem item)
        {
            Object resolved = AgenticTaggedContextStore.Resolve(item);
            VisualElement chip = new VisualElement();
            chip.style.flexDirection = FlexDirection.Row;
            chip.style.alignItems = Align.Center;
            chip.style.alignSelf = Align.FlexStart;
            chip.style.height = 21f;
            chip.style.flexGrow = 0f;
            chip.style.flexShrink = 1f;
            chip.style.marginRight = 6f;
            chip.style.marginBottom = 4f;
            chip.style.paddingLeft = 8f;
            chip.style.paddingRight = 6f;
            chip.style.paddingTop = 2f;
            chip.style.paddingBottom = 2f;
            chip.style.backgroundColor = resolved == null ? WindowBackground : FieldBackground;
            chip.tooltip = BuildTaggedItemTooltip(item, resolved);
            SetBorder(chip, resolved == null ? RunningTrackBackground : BorderColor);
            SetRadius(chip, 6f);
            chip.RegisterCallback<MouseDownEvent>(evt =>
            {
                if (evt.button != 0 || resolved == null)
                {
                    return;
                }

                AgenticTaggedContextStore.PingAndSelect(item);
                evt.StopPropagation();
            });

            Label label = new Label(AgenticTaggedContextStore.GetDisplayText(item));
            label.style.color = resolved == null ? MutedTextColor : TextColor;
            label.style.fontSize = 10f;
            label.style.maxWidth = 170f;
            label.style.height = 16f;
            label.style.overflow = Overflow.Hidden;
            label.style.textOverflow = TextOverflow.Ellipsis;
            label.style.marginRight = 7f;
            chip.Add(label);

            Label remove = new Label("x");
            remove.tooltip = "Remove this tagged item";
            remove.style.width = 12f;
            remove.style.height = 16f;
            remove.style.unityTextAlign = TextAnchor.MiddleCenter;
            remove.style.fontSize = 10f;
            remove.style.color = MutedTextColor;
            remove.RegisterCallback<MouseDownEvent>(evt =>
            {
                if (evt.button != 0)
                {
                    return;
                }

                AgenticTaggedContextStore.Remove(item.id);
                RefreshTaggedContextPanel();
                evt.StopPropagation();
            });
            chip.Add(remove);

            return chip;
        }

        private static string BuildTaggedItemTooltip(AgenticTaggedContextStore.TaggedItem item, Object resolved)
        {
            StringBuilder builder = new StringBuilder();
            builder.AppendLine(resolved == null ? "Missing tagged reference" : "Tagged reference");
            builder.AppendLine(AgenticTaggedContextStore.GetDisplayText(item));
            if (!string.IsNullOrWhiteSpace(item.assetPath))
            {
                builder.AppendLine(item.assetPath);
            }

            if (!string.IsNullOrWhiteSpace(item.hierarchyPath))
            {
                builder.AppendLine(item.hierarchyPath);
            }

            return builder.ToString().TrimEnd();
        }

        private VisualElement BuildComposer()
        {
            VisualElement composer = new VisualElement();
            composer.style.flexDirection = FlexDirection.Column;
            composer.style.alignItems = Align.Stretch;
            composer.style.minHeight = 0f;
            composer.style.flexGrow = 0f;
            composer.style.flexShrink = 0f;
            composer.style.backgroundColor = FieldBackground;
            SetRadius(composer, 7f);
            SetBorder(composer, BorderColor);
            composer.style.paddingLeft = 10f;
            composer.style.paddingRight = 10f;
            composer.style.paddingTop = 8f;
            composer.style.paddingBottom = 9f;
            AttachTaggedContextDropTarget(composer);

            composer.Add(BuildTaggedContextPanel());
            composer.Add(BuildMentionSuggestions());

            VisualElement inputRow = new VisualElement();
            inputRow.style.flexDirection = FlexDirection.Row;
            inputRow.style.alignItems = Align.Stretch;
            inputRow.style.minHeight = 76f;
            inputRow.style.height = 76f;
            inputRow.style.flexGrow = 0f;
            inputRow.style.flexShrink = 0f;
            inputRow.style.marginTop = 4f;

            promptField = new TextField
            {
                multiline = true
            };
            promptField.style.flexGrow = 1f;
            promptField.style.height = 76f;
            promptField.style.marginRight = 10f;
            promptField.style.color = TextColor;
            promptField.style.backgroundColor = Color.clear;
            promptField.tooltip = "Type a prompt, or drag Unity objects/assets here to tag them for the agent";
            promptField.RegisterValueChangedCallback(_ => UpdateMentionSuggestions());
            promptField.RegisterCallback<KeyDownEvent>(OnPromptKeyDown, TrickleDown.TrickleDown);
            AttachTaggedContextDropTarget(promptField);
            inputRow.Add(promptField);

            sendButton = new Button(() => SubmitCommand(promptField.value))
            {
                text = "Send"
            };
            StylePrimaryButton(sendButton);
            inputRow.Add(sendButton);

            stopButton = new Button(StopActiveWork)
            {
                text = "Stop",
                tooltip = "Stop the running agent request"
            };
            StyleStopButton(stopButton);
            stopButton.style.display = DisplayStyle.None;
            inputRow.Add(stopButton);

            composer.Add(inputRow);

            return composer;
        }

        private void OnPromptKeyDown(KeyDownEvent evt)
        {
            if (evt.keyCode == KeyCode.Tab && TryAcceptFirstMentionSuggestion())
            {
                evt.StopImmediatePropagation();
                return;
            }

            if (evt.keyCode == KeyCode.Escape &&
                mentionSuggestions != null &&
                mentionSuggestions.style.display != DisplayStyle.None)
            {
                HideMentionSuggestions();
                evt.StopImmediatePropagation();
                return;
            }

            if ((evt.keyCode == KeyCode.Return || evt.keyCode == KeyCode.KeypadEnter) && !evt.shiftKey)
            {
                SubmitCommand(promptField.value);
                evt.StopImmediatePropagation();
            }
        }

        private void StyleUtilityButton(Button button)
        {
            button.style.marginRight = 8f;
            button.style.height = 28f;
            button.style.paddingLeft = 10f;
            button.style.paddingRight = 10f;
            button.style.paddingTop = 0f;
            button.style.paddingBottom = 1f;
            button.style.color = TextColor;
            button.style.fontSize = 11f;
            button.style.backgroundColor = PanelBackground;
            SetBorder(button, BorderColor);
            SetRadius(button, 5f);
            AttachButtonHover(button, PanelBackground, PanelHover);
        }

        private static Color GetModeColor(string mode)
        {
            if (mode == "OPENAI")
            {
                return new Color(0.21f, 0.5f, 0.42f);
            }

            if (mode == "BACKEND")
            {
                return PrimaryColor;
            }

            return new Color(0.42f, 0.42f, 0.42f);
        }

        private void StyleIconButton(Button button)
        {
            button.style.width = 28f;
            button.style.height = 28f;
            button.style.paddingLeft = 0f;
            button.style.paddingRight = 0f;
            button.style.paddingTop = 0f;
            button.style.paddingBottom = 2f;
            button.style.fontSize = 15f;
            button.style.color = MutedTextColor;
            button.style.backgroundColor = PanelBackground;
            SetBorder(button, BorderColor);
            SetRadius(button, 5f);
            AttachButtonHover(button, PanelBackground, PanelHover);
        }

        private void StylePrimaryButton(Button button)
        {
            button.style.width = 68f;
            button.style.marginTop = 2f;
            button.style.marginBottom = 2f;
            button.style.backgroundColor = PrimaryColor;
            button.style.color = Color.white;
            button.style.fontSize = 11f;
            button.style.unityFontStyleAndWeight = FontStyle.Bold;
            SetBorder(button, PrimaryHover);
            SetRadius(button, 5f);
            AttachButtonHover(button, PrimaryColor, PrimaryHover);
        }

        private void StyleStopButton(Button button)
        {
            Color normal = IsDarkTheme ? new Color(0.52f, 0.18f, 0.16f) : new Color(0.72f, 0.22f, 0.18f);
            Color hover = IsDarkTheme ? new Color(0.66f, 0.22f, 0.18f) : new Color(0.84f, 0.28f, 0.22f);
            button.style.width = 68f;
            button.style.marginTop = 2f;
            button.style.marginBottom = 2f;
            button.style.backgroundColor = normal;
            button.style.color = Color.white;
            button.style.fontSize = 11f;
            button.style.unityFontStyleAndWeight = FontStyle.Bold;
            SetBorder(button, hover);
            SetRadius(button, 5f);
            AttachButtonHover(button, normal, hover);
        }

        private void StyleContextButton(Button button)
        {
            button.style.height = 22f;
            button.style.marginRight = 6f;
            button.style.paddingLeft = 7f;
            button.style.paddingRight = 7f;
            button.style.paddingTop = 0f;
            button.style.paddingBottom = 1f;
            button.style.fontSize = 10f;
            button.style.color = TextColor;
            button.style.backgroundColor = PanelBackground;
            SetBorder(button, BorderColor);
            SetRadius(button, 4f);
            AttachButtonHover(button, PanelBackground, PanelHover);
        }

        private void StyleMentionButton(Button button)
        {
            Color normal = IsDarkTheme ? new Color(0.18f, 0.21f, 0.25f) : new Color(0.9f, 0.94f, 0.98f);
            button.style.height = 21f;
            button.style.marginRight = 5f;
            button.style.marginBottom = 4f;
            button.style.paddingLeft = 7f;
            button.style.paddingRight = 7f;
            button.style.paddingTop = 0f;
            button.style.paddingBottom = 1f;
            button.style.fontSize = 10f;
            button.style.color = TextColor;
            button.style.backgroundColor = normal;
            SetBorder(button, ToolCardBorder);
            SetRadius(button, 6f);
            AttachButtonHover(button, normal, PanelHover);
        }

        private void StyleCopyButton(Button button)
        {
            button.style.width = 48f;
            button.style.height = 20f;
            button.style.paddingLeft = 0f;
            button.style.paddingRight = 0f;
            button.style.paddingTop = 0f;
            button.style.paddingBottom = 1f;
            button.style.fontSize = 10f;
            button.style.color = MutedTextColor;
            button.style.backgroundColor = FieldBackground;
            SetBorder(button, BorderColor);
            SetRadius(button, 4f);
            AttachButtonHover(button, FieldBackground, PanelHover);
        }

        private void StyleMiniChipButton(Button button)
        {
            button.style.width = 34f;
            button.style.height = 19f;
            button.style.marginLeft = 3f;
            button.style.paddingLeft = 0f;
            button.style.paddingRight = 0f;
            button.style.paddingTop = 0f;
            button.style.paddingBottom = 1f;
            button.style.fontSize = 9f;
            button.style.color = MutedTextColor;
            button.style.backgroundColor = PanelBackground;
            SetBorder(button, BorderColor);
            SetRadius(button, 4f);
            AttachButtonHover(button, PanelBackground, PanelHover);
        }

        private static void SetBorder(VisualElement element, Color color)
        {
            element.style.borderTopWidth = 1f;
            element.style.borderRightWidth = 1f;
            element.style.borderBottomWidth = 1f;
            element.style.borderLeftWidth = 1f;
            element.style.borderTopColor = color;
            element.style.borderRightColor = color;
            element.style.borderBottomColor = color;
            element.style.borderLeftColor = color;
        }

        private static void SetRadius(VisualElement element, float radius)
        {
            element.style.borderTopLeftRadius = radius;
            element.style.borderTopRightRadius = radius;
            element.style.borderBottomLeftRadius = radius;
            element.style.borderBottomRightRadius = radius;
        }

        private static void AttachButtonHover(Button button, Color normal, Color hover)
        {
            button.RegisterCallback<MouseEnterEvent>(_ => button.style.backgroundColor = hover);
            button.RegisterCallback<MouseLeaveEvent>(_ => button.style.backgroundColor = normal);
        }

        private void SubmitCommand(string prompt)
        {
            if (isBusy && activeWorkingMessage == null)
            {
                ResetStaleBusyState();
            }

            if (string.IsNullOrWhiteSpace(prompt))
            {
                return;
            }

            string trimmed = prompt.Trim();
            HideMentionSuggestions();
            if (isBusy)
            {
                QueuePromptWhileBusy(trimmed);
                return;
            }

            if (IsContinuationPrompt(trimmed) && AgenticAgentBridge.HasResumableToolLoopState())
            {
                StartResumableCommandRun(trimmed);
                return;
            }

            string effectivePrompt = ResolveContinuationPrompt(trimmed);
            TagMentionReferencesInPrompt(effectivePrompt);
            StartCommandRun(effectivePrompt, addUserMessage: true, displayPrompt: trimmed);
        }

        private void StartResumableCommandRun(string displayPrompt)
        {
            promptField.value = string.Empty;
            RenderedMessage userMessage = AddUserMessage(displayPrompt);
            CapturePromptSnapshotForMessage(userMessage, displayPrompt);
            WorkLog workLog = new WorkLog();
            RenderedMessage workingMessage = AddAgentMessage(workLog.ToWorkingText(0));
            long workId = ++activeWorkId;
            SetActiveWork(workingMessage, workLog, workId);

            if (!AgenticAgentBridge.TryLoadResumableToolLoopState(
                    out AgenticAgentBridge.ToolLoopState state,
                    out string error))
            {
                FinishWorkingMessage(
                    workingMessage,
                    workLog,
                    string.IsNullOrWhiteSpace(error)
                        ? "No saved agent run is available to resume."
                        : $"Could not resume saved agent run: {error}",
                    workId);
                return;
            }

            activeToolLoopState = state;
            AgenticAgentBridge.ResetToolLoopResponsivenessBudget(state);
            RefreshRunDashboard();
            AppendProgress(workingMessage, workLog, "Resuming saved agent run");
            ScheduleEditorAction(() => DispatchOpenAIToolLoopRequest(state, workingMessage, workLog, workId, 0), 120);
        }

        private void StartCommandRun(
            string trimmed,
            bool addUserMessage,
            string displayPrompt = null,
            RenderedMessage existingUserMessage = null)
        {
            promptField.value = string.Empty;
            RenderedMessage userMessage = existingUserMessage;
            if (addUserMessage)
            {
                userMessage = AddUserMessage(string.IsNullOrWhiteSpace(displayPrompt) ? trimmed : displayPrompt);
            }

            CapturePromptSnapshotForMessage(userMessage, string.IsNullOrWhiteSpace(displayPrompt) ? trimmed : displayPrompt);

            WorkLog workLog = new WorkLog();
            RenderedMessage workingMessage = AddAgentMessage(workLog.ToWorkingText(0));
            long workId = ++activeWorkId;
            SetActiveWork(workingMessage, workLog, workId);

            AppendProgress(workingMessage, workLog, "Queued request");
            ScheduleEditorAction(() => PrepareCommandRun(trimmed, workingMessage, workLog, workId), 80);
        }

        private void QueuePromptWhileBusy(string trimmed)
        {
            promptField.value = string.Empty;
            RenderedMessage queuedMessage = AddUserMessage(trimmed, snapshotPending: true);
            queuedPrompts.Enqueue(new QueuedPrompt(trimmed, queuedMessage));

            if (activeWorkingMessage != null && activeWorkLog != null)
            {
                string detail = activeToolLoopState == null
                    ? "Queued user follow-up; it will run after the current response"
                    : "Queued user follow-up; it will be sent after the next Unity tool call";
                AppendProgress(activeWorkingMessage, activeWorkLog, detail);
            }
        }

        private string ResolveContinuationPrompt(string prompt)
        {
            if (!IsContinuationPrompt(prompt) || !TryBuildContinuationPrompt(out string continuationPrompt))
            {
                return prompt;
            }

            return continuationPrompt;
        }

        private bool TryBuildContinuationPrompt(out string continuationPrompt)
        {
            continuationPrompt = string.Empty;
            string previousUserPrompt = string.Empty;
            string recentAgentProgress = string.Empty;

            for (int i = messages.Count - 1; i >= 0; i--)
            {
                AgenticChatStore.Message message = messages[i];
                if (message == null)
                {
                    continue;
                }

                string author = message.author ?? string.Empty;
                string text = message.text ?? string.Empty;
                if (string.IsNullOrWhiteSpace(recentAgentProgress) &&
                    string.Equals(author, "Agent", StringComparison.Ordinal) &&
                    !IsIntroAgentMessage(text))
                {
                    recentAgentProgress = text.Trim();
                }

                if (string.Equals(author, "You", StringComparison.Ordinal) &&
                    !IsContinuationPrompt(text) &&
                    !string.IsNullOrWhiteSpace(text))
                {
                    previousUserPrompt = text.Trim();
                    break;
                }
            }

            if (string.IsNullOrWhiteSpace(previousUserPrompt))
            {
                return false;
            }

            StringBuilder builder = new StringBuilder();
            builder.AppendLine("Continue the previous Unity agent task. Treat this as a continuation, not a new unrelated request.");
            builder.AppendLine();
            builder.AppendLine("Previous user request:");
            builder.AppendLine(previousUserPrompt);
            if (!string.IsNullOrWhiteSpace(recentAgentProgress))
            {
                builder.AppendLine();
                builder.AppendLine("Recent agent progress before this continuation:");
                builder.AppendLine(TrimPromptContext(recentAgentProgress, 3200));
            }

            builder.AppendLine();
            builder.AppendLine("Continue from the current Unity project state. If the previous request was a change request, do not stop at analysis; implement the remaining concrete changes, then validate.");
            continuationPrompt = builder.ToString().TrimEnd();
            return true;
        }

        private static bool IsContinuationPrompt(string prompt)
        {
            string normalized = (prompt ?? string.Empty).Trim().ToLowerInvariant();
            return normalized == "continue" ||
                normalized == "continue." ||
                normalized == "continue please" ||
                normalized == "keep going" ||
                normalized == "go on" ||
                normalized == "resume" ||
                normalized == "carry on";
        }

        private static bool IsIntroAgentMessage(string text)
        {
            return (text ?? string.Empty).StartsWith("Describe the scene, project, or code change you want.", StringComparison.Ordinal);
        }

        private static string TrimPromptContext(string text, int maxCharacters)
        {
            if (string.IsNullOrWhiteSpace(text) || text.Length <= maxCharacters)
            {
                return text ?? string.Empty;
            }

            return "[earlier progress omitted]\n" + text.Substring(text.Length - maxCharacters);
        }

        private RenderedMessage AddUserMessage(string text, bool snapshotPending = false)
        {
            AgenticChatStore.Message message = new AgenticChatStore.Message("You", text)
            {
                undoSnapshotPending = snapshotPending
            };
            return AddMessage(message, true);
        }

        private RenderedMessage AddAgentMessage(string text)
        {
            return AddMessage(new AgenticChatStore.Message("Agent", text), false);
        }

        private RenderedMessage AddMessage(AgenticChatStore.Message message, bool alignRight)
        {
            messages.Add(message);
            AgenticChatStore.Save(messages);
            firstRenderedMessageIndex = Mathf.Max(0, Mathf.Min(firstRenderedMessageIndex, messages.Count - 1));
            bool shouldFollow = alignRight || IsTranscriptNearBottom();
            RenderedMessage rendered = RenderMessage(message, alignRight, scroll: false);
            if (shouldFollow)
            {
                ScheduleScrollToBottom(force: true);
            }
            else
            {
                UpdateJumpToLatestVisibility();
            }

            return rendered;
        }

        private RenderedMessage RenderMessage(AgenticChatStore.Message message, bool alignRight, bool scroll = true)
        {
            string author = message.author ?? string.Empty;
            string text = SanitizeMessageTextForCurrentMode(message.text, alignRight);

            VisualElement row = new VisualElement();
            row.style.flexDirection = FlexDirection.Row;
            row.style.justifyContent = alignRight ? Justify.FlexEnd : Justify.FlexStart;
            row.style.marginBottom = 10f;

            VisualElement bubble = new VisualElement();
            bubble.style.maxWidth = WindowWidth - 86f;
            bubble.style.backgroundColor = alignRight ? PrimaryColor : PanelBackground;
            SetBorder(bubble, alignRight ? PrimaryHover : BorderColor);
            SetRadius(bubble, 8f);
            bubble.style.paddingLeft = 12f;
            bubble.style.paddingRight = 12f;
            bubble.style.paddingTop = 9f;
            bubble.style.paddingBottom = 10f;

            VisualElement bubbleHeader = new VisualElement();
            bubbleHeader.style.flexDirection = FlexDirection.Row;
            bubbleHeader.style.alignItems = Align.Center;

            PopulateMessageHeader(bubbleHeader, message, alignRight);
            bubble.Add(bubbleHeader);

            VisualElement body = new VisualElement();
            body.style.marginTop = 3f;
            PopulateMessageBody(body, text, alignRight);
            bubble.Add(body);

            row.Add(bubble);
            transcript.Add(row);
            if (scroll)
            {
                ScheduleScrollToElement(row);
            }

            return new RenderedMessage(message, body, bubble, bubbleHeader, alignRight);
        }

        private static string SanitizeMessageTextForCurrentMode(string text, bool alignRight)
        {
            if (alignRight || AgenticAgentBridge.GetDeveloperMode())
            {
                return text ?? string.Empty;
            }

            return StripDeveloperOnlySections(text);
        }

        private static string StripDeveloperOnlySections(string text)
        {
            if (string.IsNullOrWhiteSpace(text))
            {
                return string.Empty;
            }

            string[] lines = text.Replace("\r\n", "\n").Replace('\r', '\n').Split('\n');
            StringBuilder builder = new StringBuilder();
            bool skippingDeveloperSection = false;
            bool previousBlank = false;

            foreach (string line in lines)
            {
                string trimmed = (line ?? string.Empty).Trim();
                string sectionHeader = NormalizeDisplaySectionHeader(trimmed);
                if (!string.IsNullOrEmpty(sectionHeader))
                {
                    skippingDeveloperSection = IsDeveloperOnlySection(sectionHeader);
                    if (skippingDeveloperSection)
                    {
                        previousBlank = false;
                        continue;
                    }
                }

                if (skippingDeveloperSection)
                {
                    continue;
                }

                if (IsToolDisplayLine(TrimListMarker(trimmed)))
                {
                    previousBlank = false;
                    continue;
                }

                if (trimmed.Length == 0)
                {
                    if (builder.Length > 0 && !previousBlank)
                    {
                        builder.AppendLine();
                        previousBlank = true;
                    }

                    continue;
                }

                builder.AppendLine(line.TrimEnd());
                previousBlank = false;
            }

            return builder.ToString().Trim();
        }

        private void PopulateMessageHeader(VisualElement bubbleHeader, AgenticChatStore.Message message, bool alignRight)
        {
            if (bubbleHeader == null || message == null)
            {
                return;
            }

            bubbleHeader.Clear();
            string author = message.author ?? string.Empty;

            Label authorLabel = new Label(author);
            authorLabel.style.fontSize = 10f;
            authorLabel.style.unityFontStyleAndWeight = FontStyle.Bold;
            authorLabel.style.color = alignRight ? new Color(0.82f, 0.9f, 1f) : MutedTextColor;
            bubbleHeader.Add(authorLabel);

            VisualElement spacer = new VisualElement();
            spacer.style.flexGrow = 1f;
            bubbleHeader.Add(spacer);

            if (alignRight && string.Equals(author, "You", StringComparison.Ordinal))
            {
                AddPromptUndoControl(bubbleHeader, message);
            }

            Button copy = new Button(() => CopyMessageToClipboard(message.text ?? string.Empty))
            {
                text = "Copy",
                tooltip = $"Copy {author.ToLowerInvariant()} message"
            };
            StyleCopyButton(copy);
            bubbleHeader.Add(copy);
        }

        private void AddPromptUndoControl(VisualElement bubbleHeader, AgenticChatStore.Message message)
        {
            bool hasSnapshot = !string.IsNullOrWhiteSpace(message.undoSnapshotId);
            bool restored = message.undoSnapshotRestoredUtcTicks > 0;
            bool pending = message.undoSnapshotPending && !hasSnapshot;
            bool hasError = !string.IsNullOrWhiteSpace(message.undoSnapshotError);

            if (!hasSnapshot && !pending && !hasError)
            {
                return;
            }

            Button undo = new Button(() => RestorePromptSnapshot(message))
            {
                text = restored ? "Restored" : pending ? "Undo..." : hasError ? "No Undo" : "Undo",
                tooltip = restored
                    ? "This prompt snapshot has already been restored"
                    : pending
                        ? "Snapshot will be captured when this queued prompt starts"
                        : hasError
                            ? message.undoSnapshotError
                            : "Restore Assets, Packages, and ProjectSettings to the state before this prompt ran"
            };
            StyleCopyButton(undo);
            undo.style.width = restored ? 62f : pending ? 58f : hasError ? 62f : 48f;
            undo.style.marginRight = 6f;
            undo.SetEnabled(hasSnapshot && !restored && !pending);
            bubbleHeader.Add(undo);
        }

        private void CapturePromptSnapshotForMessage(RenderedMessage renderedMessage, string prompt)
        {
            AgenticChatStore.Message message = renderedMessage?.Message;
            if (message == null || !string.Equals(message.author, "You", StringComparison.Ordinal))
            {
                return;
            }

            if (!string.IsNullOrWhiteSpace(message.undoSnapshotId) || message.undoSnapshotRestoredUtcTicks > 0)
            {
                return;
            }

            try
            {
                AgenticPromptSnapshotStore.SnapshotInfo info = AgenticPromptSnapshotStore.Capture(prompt ?? message.text ?? string.Empty);
                message.undoSnapshotId = info.id;
                message.undoSnapshotCreatedUtcTicks = info.createdUtcTicks;
                message.undoSnapshotPending = false;
                message.undoSnapshotError = string.Empty;
            }
            catch (Exception exception)
            {
                message.undoSnapshotPending = false;
                message.undoSnapshotError = "Could not capture project snapshot: " + exception.Message;
                Debug.LogWarning(message.undoSnapshotError);
            }

            AgenticChatStore.Save(messages);
            PopulateMessageHeader(renderedMessage.Header, message, renderedMessage.AlignRight);
        }

        private void RestorePromptSnapshot(AgenticChatStore.Message message)
        {
            if (message == null || string.IsNullOrWhiteSpace(message.undoSnapshotId))
            {
                return;
            }

            if (isBusy)
            {
                EditorUtility.DisplayDialog("Agent Running", "Stop or let the current agent run finish before restoring a prompt snapshot.", "OK");
                return;
            }

            if (!AgenticPromptSnapshotStore.Exists(message.undoSnapshotId))
            {
                EditorUtility.DisplayDialog("Snapshot Missing", "The project snapshot for this prompt no longer exists.", "OK");
                message.undoSnapshotError = "Snapshot is missing.";
                AgenticChatStore.Save(messages);
                LoadTranscript();
                return;
            }

            AgenticPromptSnapshotStore.SnapshotInfo info = AgenticPromptSnapshotStore.LoadInfo(message.undoSnapshotId);
            string promptPreview = TrimPromptContext(message.text ?? string.Empty, 280);
            string created = info == null || info.createdUtcTicks <= 0
                ? string.Empty
                : new DateTime(info.createdUtcTicks, DateTimeKind.Utc).ToLocalTime().ToString("g");

            bool confirmed = EditorUtility.DisplayDialog(
                "Restore Project Snapshot?",
                "This will replace the current Assets, Packages, and ProjectSettings folders with the snapshot captured before this prompt ran.\n\n" +
                (string.IsNullOrWhiteSpace(created) ? string.Empty : $"Snapshot: {created}\n") +
                $"Prompt: {promptPreview}",
                "Restore",
                "Cancel");
            if (!confirmed)
            {
                return;
            }

            try
            {
                string result = AgenticPromptSnapshotStore.Restore(message.undoSnapshotId);
                message.undoSnapshotRestoredUtcTicks = DateTime.UtcNow.Ticks;
                message.undoSnapshotError = string.Empty;
                AgenticChatStore.Save(messages);
                AddAgentMessage(result + "\n\nRolled back to before prompt:\n" + promptPreview);
                LoadTranscript();
            }
            catch (Exception exception)
            {
                Debug.LogException(exception);
                message.undoSnapshotError = "Restore failed: " + exception.Message;
                AgenticChatStore.Save(messages);
                LoadTranscript();
                EditorUtility.DisplayDialog("Restore Failed", exception.Message, "OK");
            }
        }

        private static void MakeBodyTextSelectable(Label body)
        {
            body.focusable = true;
            body.selection.isSelectable = true;
            body.selection.selectAllOnFocus = false;
            body.selection.selectAllOnMouseUp = false;
        }

        private void PrepareCommandRun(string prompt, RenderedMessage workingMessage, WorkLog workLog, long workId)
        {
            if (!IsActiveWork(workId))
            {
                return;
            }

            try
            {
                AppendProgress(workingMessage, workLog, "Reading request and current Unity state");
                if (!AgenticPrototypeBuilder.TryPrepareRun(
                        prompt,
                        step => AppendProgress(workingMessage, workLog, step),
                        out AgenticAgentBridge.PreparedRequest request,
                        out string immediateResponse))
                {
                    FinishWorkingMessage(workingMessage, workLog, AgenticAgentBridge.GetBackendRequiredMessage(), workId);
                    return;
                }

                if (request == null)
                {
                    FinishWorkingMessage(workingMessage, workLog, immediateResponse, workId);
                    return;
                }

                if (request.Kind == AgenticAgentBridge.PreparedRequestKind.OpenAIToolLoop)
                {
                    FinishWorkingMessage(workingMessage, workLog, AgenticAgentBridge.GetBackendRequiredMessage(), workId);
                    return;
                }

                DispatchPreparedRequest(request, workingMessage, workLog, workId);
            }
            catch (Exception exception)
            {
                Debug.LogException(exception);
                FinishWorkingMessage(workingMessage, workLog, $"Command failed: {exception.Message}", workId);
            }
        }

        private void DispatchPreparedRequest(
            AgenticAgentBridge.PreparedRequest request,
            RenderedMessage workingMessage,
            WorkLog workLog,
            long workId)
        {
            if (request == null)
            {
                throw new ArgumentNullException(nameof(request));
            }

            if (request.Kind == AgenticAgentBridge.PreparedRequestKind.OpenAIToolLoop)
            {
                FinishWorkingMessage(workingMessage, workLog, AgenticAgentBridge.GetBackendRequiredMessage(), workId);
                return;
            }

            if (request.Kind == AgenticAgentBridge.PreparedRequestKind.BackendJson)
            {
                AppendProgress(workingMessage, workLog, "Starting backend agent run");
                Task<AgenticAgentBridge.BackendRunStatus> startTask = Task.Run(() => AgenticAgentBridge.StartBackendRun(request));
                PollBackendRunStart(startTask, request, workingMessage, workLog, workId, 0);
                return;
            }

            AppendProgress(workingMessage, workLog, $"Prepared {request.DisplayName} request");
            Task<string> task = Task.Run(() => AgenticAgentBridge.SendPreparedRequest(request));
            PollPreparedRequest(task, request, workingMessage, workLog, workId, 0);
        }

        private void PollBackendRunStart(
            Task<AgenticAgentBridge.BackendRunStatus> task,
            AgenticAgentBridge.PreparedRequest request,
            RenderedMessage workingMessage,
            WorkLog workLog,
            long workId,
            int tick)
        {
            if (!IsActiveWork(workId))
            {
                return;
            }

            if (!task.IsCompleted)
            {
                SetQuietWaitingStatus(workingMessage, workLog, "Starting backend scripting agent", tick, persist: true);
                ScheduleEditorAction(() => PollBackendRunStart(task, request, workingMessage, workLog, workId, tick + 1), OpenAIPollIntervalMs);
                return;
            }

            if (task.IsCanceled)
            {
                FinishWorkingMessage(workingMessage, workLog, "Backend scripting agent start was canceled.", workId);
                return;
            }

            if (task.IsFaulted)
            {
                Exception exception = task.Exception;
                if (exception == null)
                {
                    exception = new InvalidOperationException("Unknown backend run start failure.");
                }

                FinishWorkingMessage(workingMessage, workLog, $"Backend scripting agent start failed: {AgenticAgentBridge.FormatRequestException(exception)}", workId);
                return;
            }

            AgenticAgentBridge.BackendRunStatus run = task.Result;
            SaveActiveBackendRun(request, run.run_id);
            AppendBackendRunEvents(workingMessage, workLog, run);
            UpdateReplayTimeline(run);
            AppendProgress(workingMessage, workLog, $"Backend run started: {run.run_id}");
            ScheduleEditorAction(() => StartBackendRunStatusPoll(request, run.run_id, workingMessage, workLog, workId, 0), 250);
        }

        private void StartBackendRunStatusPoll(
            AgenticAgentBridge.PreparedRequest request,
            string runId,
            RenderedMessage workingMessage,
            WorkLog workLog,
            long workId,
            int tick)
        {
            if (!IsActiveWork(workId))
            {
                return;
            }

            Task<AgenticAgentBridge.BackendRunStatus> statusTask = Task.Run(() => AgenticAgentBridge.GetBackendRunStatus(request, runId));
            PollBackendRunStatus(statusTask, request, runId, workingMessage, workLog, workId, tick);
        }

        private void PollBackendRunStatus(
            Task<AgenticAgentBridge.BackendRunStatus> task,
            AgenticAgentBridge.PreparedRequest request,
            string runId,
            RenderedMessage workingMessage,
            WorkLog workLog,
            long workId,
            int tick)
        {
            if (!IsActiveWork(workId))
            {
                return;
            }

            if (!task.IsCompleted)
            {
                SetQuietWaitingStatus(workingMessage, workLog, "Checking backend agent run status", tick, persist: true);
                ScheduleEditorAction(() => PollBackendRunStatus(task, request, runId, workingMessage, workLog, workId, tick + 1), OpenAIPollIntervalMs);
                return;
            }

            if (task.IsCanceled)
            {
                FinishWorkingMessage(workingMessage, workLog, "Backend scripting agent status check was canceled.", workId);
                return;
            }

            if (task.IsFaulted)
            {
                Exception exception = task.Exception;
                if (exception == null)
                {
                    exception = new InvalidOperationException("Unknown backend run status failure.");
                }

                FinishWorkingMessage(workingMessage, workLog, $"Backend scripting agent status check failed: {AgenticAgentBridge.FormatRequestException(exception)}", workId);
                return;
            }

            AgenticAgentBridge.BackendRunStatus run = task.Result;
            AppendBackendRunEvents(workingMessage, workLog, run);
            UpdateReplayTimeline(run);
            if (run.IsTerminal)
            {
                AppendProgress(workingMessage, workLog, "Finished");
                ClearActiveBackendRun();
                FinishWorkingMessage(workingMessage, workLog, AgenticAgentBridge.CompleteBackendRunResult(run), workId);
                return;
            }

            string summary = AgenticAgentBridge.GetBackendRunSummary(run);
            SetQuietWaitingStatus(workingMessage, workLog, $"Backend agent running: {summary}", tick, persist: true);
            ScheduleEditorAction(() => StartBackendRunStatusPoll(request, runId, workingMessage, workLog, workId, tick + 1), 1000);
        }

        private static void SaveActiveBackendRun(AgenticAgentBridge.PreparedRequest request, string runId)
        {
            if (request == null || string.IsNullOrWhiteSpace(runId))
            {
                return;
            }

            EditorPrefs.SetString(BackendRunIdPrefsKey, runId.Trim());
            EditorPrefs.SetString(BackendRunEndpointPrefsKey, request.Endpoint ?? string.Empty);
            EditorPrefs.SetString(LastBackendRunIdPrefsKey, runId.Trim());
            EditorPrefs.SetString(LastBackendRunEndpointPrefsKey, request.Endpoint ?? string.Empty);
        }

        private static void ClearActiveBackendRun()
        {
            EditorPrefs.DeleteKey(BackendRunIdPrefsKey);
            EditorPrefs.DeleteKey(BackendRunEndpointPrefsKey);
        }

        private void TryResumeInterruptedBackendRun()
        {
            if (isBusy)
            {
                return;
            }

            string runId = EditorPrefs.GetString(BackendRunIdPrefsKey, string.Empty);
            if (string.IsNullOrWhiteSpace(runId))
            {
                return;
            }

            string endpoint = EditorPrefs.GetString(BackendRunEndpointPrefsKey, AgenticAgentBridge.DefaultEndpoint);
            WorkLog workLog = new WorkLog();
            RenderedMessage workingMessage = AddAgentMessage(workLog.ToWorkingText(0));
            long workId = ++activeWorkId;
            SetActiveWork(workingMessage, workLog, workId);
            AppendProgress(workingMessage, workLog, "I’m reconnecting to the backend agent run that was already in progress.");

            AgenticAgentBridge.PreparedRequest request = new AgenticAgentBridge.PreparedRequest
            {
                DisplayName = "Backend scripting agent",
                Endpoint = string.IsNullOrWhiteSpace(endpoint) ? AgenticAgentBridge.DefaultEndpoint : endpoint,
                IncludeApiKeyHeader = false,
                Kind = AgenticAgentBridge.PreparedRequestKind.BackendJson
            };
            ScheduleEditorAction(() => StartBackendRunStatusPoll(request, runId, workingMessage, workLog, workId, 0), 100);
        }

        private void AppendBackendRunEvents(
            RenderedMessage workingMessage,
            WorkLog workLog,
            AgenticAgentBridge.BackendRunStatus run)
        {
            if (workingMessage == null || workLog == null || run?.events == null)
            {
                return;
            }

            bool changed = false;
            foreach (AgenticAgentBridge.BackendRunEvent runEvent in run.events)
            {
                if (runEvent == null || string.IsNullOrWhiteSpace(runEvent.summary))
                {
                    continue;
                }

                if (!ShouldShowBackendRunEvent(runEvent))
                {
                    continue;
                }

                string summary = runEvent.summary.Trim();
                if (AgenticAgentBridge.GetDeveloperMode() && !string.IsNullOrWhiteSpace(runEvent.type))
                {
                    summary = $"{FormatBackendEventType(runEvent.type)}: {summary}";
                }

                workLog.AddObservation(summary);
                changed = true;
            }

            if (changed)
            {
                UpdateRenderedMessage(workingMessage, workLog.ToWorkingText(0), persist: true);
                RequestUiRefresh();
            }
        }

        private static bool ShouldShowBackendRunEvent(AgenticAgentBridge.BackendRunEvent runEvent)
        {
            if (AgenticAgentBridge.GetDeveloperMode())
            {
                return true;
            }

            string eventType = (runEvent?.type ?? string.Empty).Trim();
            return string.Equals(eventType, "agent.progress", StringComparison.OrdinalIgnoreCase) ||
                string.Equals(eventType, "agent.message", StringComparison.OrdinalIgnoreCase) ||
                string.Equals(eventType, "runner.failed", StringComparison.OrdinalIgnoreCase) ||
                string.Equals(eventType, "runner.canceled", StringComparison.OrdinalIgnoreCase);
        }

        private static string FormatBackendEventType(string eventType)
        {
            string value = (eventType ?? string.Empty).Trim();
            if (string.IsNullOrWhiteSpace(value))
            {
                return "Backend";
            }

            switch (value)
            {
                case "runner.created":
                    return "Queued";
                case "runner.started":
                    return "Started";
                case "context.loaded":
                    return "Context";
                case "model.request":
                    return "Model";
                case "model.tool_calls":
                    return "Tools";
                case "tool.start":
                    return "Tool";
                case "tool.complete":
                    return "Tool complete";
                case "tool.failed":
                    return "Tool failed";
                case "runner.complete":
                    return "Complete";
                case "runner.failed":
                    return "Failed";
                case "runner.canceled":
                    return "Canceled";
                default:
                    return value.Replace('.', ' ');
            }
        }

        private void PollPreparedRequest(
            Task<string> task,
            AgenticAgentBridge.PreparedRequest request,
            RenderedMessage workingMessage,
            WorkLog workLog,
            long workId,
            int tick)
        {
            if (!IsActiveWork(workId))
            {
                return;
            }

            if (!task.IsCompleted)
            {
                SetQuietWaitingStatus(workingMessage, workLog, $"Waiting for {request.DisplayName} response", tick);
                ScheduleEditorAction(() => PollPreparedRequest(task, request, workingMessage, workLog, workId, tick + 1), OpenAIPollIntervalMs);
                return;
            }

            if (task.IsCanceled)
            {
                FinishWorkingMessage(workingMessage, workLog, $"{request.DisplayName} request was canceled.", workId);
                return;
            }

            if (task.IsFaulted)
            {
                Exception exception = task.Exception;
                if (exception == null)
                {
                    exception = new InvalidOperationException("Unknown request failure.");
                }

                FinishWorkingMessage(workingMessage, workLog, $"{request.DisplayName} request failed: {AgenticAgentBridge.FormatRequestException(exception)}", workId);
                return;
            }

            try
            {
                AppendProgress(workingMessage, workLog, "Received response");
                if (request.Kind == AgenticAgentBridge.PreparedRequestKind.OpenAIPlanReview)
                {
                    AppendProgress(workingMessage, workLog, "Reading response");
                    AgenticAgentBridge.PlanReviewResult plan = AgenticAgentBridge.ParsePlanReview(request, task.Result);
                    if (!plan.IsValid)
                    {
                        AppendProgress(workingMessage, workLog, "Plan parsing failed");
                        FinishWorkingMessage(workingMessage, workLog, plan.Error, workId);
                        return;
                    }

                    if (plan.ProposedActionCount == 0)
                    {
                        AppendProgress(workingMessage, workLog, "Finished");
                        FinishWorkingMessage(workingMessage, workLog, plan.ToAnswerText(), workId);
                        return;
                    }

                    if (AgenticAgentBridge.GetAutoRunActions())
                    {
                        AppendProgress(workingMessage, workLog, "Auto-run enabled");
                        AppendProgress(workingMessage, workLog, "Applying Unity actions");
                        string autoRunResponse = AgenticAgentBridge.ExecuteApprovedPlan(plan);
                        AppendProgress(workingMessage, workLog, "Finished");
                        FinishWorkingMessage(workingMessage, workLog, autoRunResponse, workId);
                        return;
                    }

                    AppendProgress(workingMessage, workLog, "Waiting for approval");
                    FinishPlanReviewMessage(workingMessage, workLog, plan, workId);
                    return;
                }

                if (request.Kind == AgenticAgentBridge.PreparedRequestKind.OpenAIAnswer)
                {
                    AppendProgress(workingMessage, workLog, "Reading answer");
                    string answer = AgenticAgentBridge.CompletePreparedRequest(request, task.Result);
                    AppendProgress(workingMessage, workLog, "Finished");
                    FinishWorkingMessage(workingMessage, workLog, answer, workId);
                    return;
                }

                AppendProgress(workingMessage, workLog, "Parsing action response");
                AppendProgress(workingMessage, workLog, "Applying Unity actions");
                string response = AgenticAgentBridge.CompletePreparedRequest(request, task.Result);
                AppendProgress(workingMessage, workLog, "Finished");
                FinishWorkingMessage(workingMessage, workLog, response, workId);
            }
            catch (Exception exception)
            {
                Debug.LogException(exception);
                FinishWorkingMessage(workingMessage, workLog, $"Command failed while applying Unity actions: {exception.Message}", workId);
            }
        }

        private void StartOpenAIToolLoop(string prompt, RenderedMessage workingMessage, WorkLog workLog, long workId)
        {
            if (!IsActiveWork(workId))
            {
                return;
            }

            try
            {
                AppendProgress(workingMessage, workLog, "Starting OpenAI tool loop");
                AgenticAgentBridge.ToolLoopState state = AgenticAgentBridge.BeginOpenAIToolLoop(
                    prompt,
                    step => AppendProgress(workingMessage, workLog, step));
                activeToolLoopState = state;
                AgenticAgentBridge.SaveResumableToolLoopState(state);
                RefreshRunDashboard();
                DispatchOpenAIToolLoopRequest(state, workingMessage, workLog, workId, 0);
            }
            catch (Exception exception)
            {
                Debug.LogException(exception);
                FinishWorkingMessage(workingMessage, workLog, $"Command failed while starting OpenAI tool loop: {exception.Message}", workId);
            }
        }

        private void TryResumeInterruptedToolLoop()
        {
            if (isBusy || !AgenticAgentBridge.HasResumableToolLoopState())
            {
                return;
            }

            if (EditorApplication.isCompiling || EditorApplication.isUpdating)
            {
                ScheduleEditorAction(TryResumeInterruptedToolLoop, 1000);
                return;
            }

            if (!AgenticAgentBridge.TryLoadResumableToolLoopState(
                    out AgenticAgentBridge.ToolLoopState state,
                    out string error))
            {
                if (!string.IsNullOrWhiteSpace(error) &&
                    !string.Equals(error, "No resumable tool-loop state exists.", StringComparison.Ordinal))
                {
                    AddAgentMessage($"Could not resume interrupted agent run: {error}");
                }

                return;
            }

            WorkLog workLog = new WorkLog();
            RenderedMessage workingMessage = AddAgentMessage(workLog.ToWorkingText(0));
            long workId = ++activeWorkId;
            SetActiveWork(workingMessage, workLog, workId);
            activeToolLoopState = state;
            RefreshRunDashboard();
            AppendProgress(workingMessage, workLog, "Resuming after Unity script reload");
            ScheduleEditorAction(() => DispatchOpenAIToolLoopRequest(state, workingMessage, workLog, workId, 0), 120);
        }

        private void DispatchOpenAIToolLoopRequest(
            AgenticAgentBridge.ToolLoopState state,
            RenderedMessage workingMessage,
            WorkLog workLog,
            long workId,
            int tick,
            bool bypassCompilationGate = false)
        {
            if (!IsActiveWork(workId))
            {
                return;
            }

            if (!bypassCompilationGate && AgenticAgentBridge.IsScriptRefreshOrCompilationPending())
            {
                if (AgenticAgentBridge.TryInjectCompilerFailureObservation(state, out string compilerSummary))
                {
                    AppendProgress(workingMessage, workLog, "Compiler errors detected; continuing repair loop");
                    AppendProgress(workingMessage, workLog, compilerSummary);
                    if (AgenticAgentBridge.TryGetRepeatedCompilerFailureStopMessage(state, out string stopMessage))
                    {
                        FinishWorkingMessage(workingMessage, workLog, stopMessage, workId);
                        return;
                    }

                    ScheduleEditorAction(() => DispatchOpenAIToolLoopRequest(state, workingMessage, workLog, workId, 0, true), 120);
                    return;
                }

                SetQuietWaitingStatus(workingMessage, workLog, "Waiting for Unity to finish compiling scripts", tick);
                ScheduleEditorAction(() => DispatchOpenAIToolLoopRequest(state, workingMessage, workLog, workId, tick + 1), 1000);
                return;
            }

            try
            {
                if (AgenticAgentBridge.TryPrepareAutomaticToolLoopBudgetContinuation(state, out string continuationSummary))
                {
                    AppendProgress(workingMessage, workLog, continuationSummary);
                    ScheduleEditorAction(() => DispatchOpenAIToolLoopRequest(state, workingMessage, workLog, workId, 0), AutoContinuationDelayMs);
                    return;
                }

                int nextStep = state.RequestCount + 1;
                string agentLabel = AgenticAgentBridge.GetActiveToolLoopAgentLabel(state);
                AppendProgress(
                    workingMessage,
                    workLog,
                    $"Calling {agentLabel} for next tool ({nextStep})");
                AppendProgress(workingMessage, workLog, "Building model request from Unity context");
                RequestUiRefresh();
                ScheduleEditorAction(() => ContinueDispatchOpenAIToolLoopRequest(state, workingMessage, workLog, workId, tick, bypassCompilationGate), 1);
            }
            catch (Exception exception)
            {
                Debug.LogException(exception);
                FinishWorkingMessage(workingMessage, workLog, $"Command failed while preparing OpenAI tool request: {exception.Message}", workId);
            }
        }

        private void ContinueDispatchOpenAIToolLoopRequest(
            AgenticAgentBridge.ToolLoopState state,
            RenderedMessage workingMessage,
            WorkLog workLog,
            long workId,
            int tick,
            bool bypassCompilationGate)
        {
            if (!IsActiveWork(workId))
            {
                return;
            }

            try
            {
                System.Diagnostics.Stopwatch prepareTimer = System.Diagnostics.Stopwatch.StartNew();
                string requestJson = AgenticAgentBridge.BuildOpenAIToolLoopRequestJson(state);
                prepareTimer.Stop();
                if (prepareTimer.ElapsedMilliseconds >= MainThreadWorkNoticeMs)
                {
                    AppendProgress(
                        workingMessage,
                        workLog,
                        $"Prepared model request after {prepareTimer.ElapsedMilliseconds}ms of Unity/editor context work");
                }

                AppendProgress(workingMessage, workLog, "Sending request to OpenAI");
                RequestUiRefresh();
                Task<string> task = Task.Run(() => AgenticAgentBridge.SendOpenAIToolLoopRequest(state, requestJson));
                PollOpenAIToolLoopRequest(task, state, workingMessage, workLog, workId, tick, bypassCompilationGate);
            }
            catch (Exception exception)
            {
                Debug.LogException(exception);
                FinishWorkingMessage(workingMessage, workLog, $"Command failed while preparing OpenAI tool request: {exception.Message}", workId);
            }
        }

        private void PollOpenAIToolLoopRequest(
            Task<string> task,
            AgenticAgentBridge.ToolLoopState state,
            RenderedMessage workingMessage,
            WorkLog workLog,
            long workId,
            int tick,
            bool bypassCompilationGate = false)
        {
            if (!IsActiveWork(workId))
            {
                return;
            }

            if (!task.IsCompleted)
            {
                SetQuietWaitingStatus(workingMessage, workLog, "Waiting for OpenAI tool response", tick);
                ScheduleEditorAction(() => PollOpenAIToolLoopRequest(task, state, workingMessage, workLog, workId, tick + 1, bypassCompilationGate), OpenAIPollIntervalMs);
                return;
            }

            if (task.IsCanceled)
            {
                FinishWorkingMessage(workingMessage, workLog, "OpenAI tool request was canceled.", workId);
                return;
            }

            if (task.IsFaulted)
            {
                Exception exception = task.Exception;
                if (exception == null)
                {
                    exception = new InvalidOperationException("Unknown tool request failure.");
                }

                if (AgenticAgentBridge.TryPrepareTransientOpenAIRetry(state, exception, out string retrySummary, out int retryDelayMs))
                {
                    AppendProgress(workingMessage, workLog, retrySummary);
                    ScheduleEditorAction(() => DispatchOpenAIToolLoopRequest(state, workingMessage, workLog, workId, 0), retryDelayMs);
                    return;
                }

                FinishWorkingMessage(workingMessage, workLog, $"OpenAI tool request failed: {AgenticAgentBridge.FormatRequestException(exception)}", workId);
                return;
            }

            if (!bypassCompilationGate && AgenticAgentBridge.IsScriptRefreshOrCompilationPending())
            {
                if (AgenticAgentBridge.TryInjectCompilerFailureObservation(state, out string compilerSummary))
                {
                    AppendProgress(workingMessage, workLog, "Compiler errors detected; continuing repair loop");
                    AppendProgress(workingMessage, workLog, compilerSummary);
                    if (AgenticAgentBridge.TryGetRepeatedCompilerFailureStopMessage(state, out string stopMessage))
                    {
                        FinishWorkingMessage(workingMessage, workLog, stopMessage, workId);
                        return;
                    }

                    ScheduleEditorAction(() => DispatchOpenAIToolLoopRequest(state, workingMessage, workLog, workId, 0, true), 120);
                    return;
                }

                SetQuietWaitingStatus(workingMessage, workLog, "Waiting for Unity to finish compiling scripts", tick);
                ScheduleEditorAction(() => PollOpenAIToolLoopRequest(task, state, workingMessage, workLog, workId, tick + 1, false), 1000);
                return;
            }

            try
            {
                string responseJson = task.Result;
                AppendProgress(workingMessage, workLog, "Applying OpenAI tool response in Unity");
                RequestUiRefresh();
                ScheduleEditorAction(() => ApplyOpenAIToolLoopResponseOnMainThread(responseJson, state, workingMessage, workLog, workId), 1);
            }
            catch (Exception exception)
            {
                Debug.LogException(exception);
                FinishWorkingMessage(workingMessage, workLog, $"Command failed while applying OpenAI tool call: {exception.Message}", workId);
            }
        }

        private void ApplyOpenAIToolLoopResponseOnMainThread(
            string responseJson,
            AgenticAgentBridge.ToolLoopState state,
            RenderedMessage workingMessage,
            WorkLog workLog,
            long workId)
        {
            if (!IsActiveWork(workId))
            {
                return;
            }

            try
            {
                AgenticAgentBridge.ClearTransientOpenAIRetryState(state);
                System.Diagnostics.Stopwatch applyTimer = System.Diagnostics.Stopwatch.StartNew();
                AgenticAgentBridge.ToolLoopTurnResult result = AgenticAgentBridge.ApplyOpenAIToolLoopResponse(
                    state,
                    responseJson,
                    step => AppendProgress(workingMessage, workLog, step));
                applyTimer.Stop();
                if (applyTimer.ElapsedMilliseconds >= MainThreadWorkNoticeMs)
                {
                    AppendProgress(
                        workingMessage,
                        workLog,
                        $"Applied tool response after {applyTimer.ElapsedMilliseconds}ms of Unity/editor work");
                }

                if (result.IsComplete)
                {
                    AppendProgress(workingMessage, workLog, "Finished");
                    FinishWorkingMessage(workingMessage, workLog, result.FinalResponse, workId);
                    return;
                }

                if (!string.IsNullOrWhiteSpace(result.ToolName))
                {
                    AppendProgress(workingMessage, workLog, $"Completed tool: {result.ToolName}");
                }

                AppendToolObservation(workingMessage, workLog, result);
                FlushQueuedPromptsIntoToolLoop(state, workingMessage, workLog);
                ScheduleEditorAction(() => DispatchOpenAIToolLoopRequest(state, workingMessage, workLog, workId, 0), 120);
            }
            catch (Exception exception)
            {
                Debug.LogException(exception);
                FinishWorkingMessage(workingMessage, workLog, $"Command failed while applying OpenAI tool call: {exception.Message}", workId);
            }
        }

        private void FlushQueuedPromptsIntoToolLoop(
            AgenticAgentBridge.ToolLoopState state,
            RenderedMessage workingMessage,
            WorkLog workLog)
        {
            if (state == null || queuedPrompts.Count == 0)
            {
                return;
            }

            int sent = 0;
            while (queuedPrompts.Count > 0)
            {
                QueuedPrompt queued = queuedPrompts.Dequeue();
                CapturePromptSnapshotForMessage(queued.RenderedMessage, queued.Prompt);
                AgenticAgentBridge.AddUserFollowUpToToolLoop(state, queued.Prompt);
                sent++;
            }

            AppendProgress(
                workingMessage,
                workLog,
                sent == 1
                    ? "Sent queued user follow-up to agent"
                    : $"Sent {sent} queued user follow-ups to agent");
        }

        private void AppendProgress(RenderedMessage workingMessage, WorkLog workLog, string step)
        {
            if (workingMessage == null || string.IsNullOrWhiteSpace(step))
            {
                return;
            }

            workLog.Add(step);
            string note = BuildProgressObservation(step);
            if (!string.IsNullOrWhiteSpace(note))
            {
                workLog.AddObservation(note);
            }

            UpdateRenderedMessage(workingMessage, workLog.ToWorkingText(0), persist: false);
            RequestUiRefresh();
        }

        private void AppendToolObservation(
            RenderedMessage workingMessage,
            WorkLog workLog,
            AgenticAgentBridge.ToolLoopTurnResult result)
        {
            if (workingMessage == null || workLog == null || result == null)
            {
                return;
            }

            string explored = BuildExploredLine(result.ToolName, result.ToolResult);
            if (!string.IsNullOrWhiteSpace(explored))
            {
                workLog.AddExplored(explored);
            }

            string note = BuildAgentObservation(result.ToolName, result.ToolResult);
            if (!string.IsNullOrWhiteSpace(note))
            {
                workLog.AddObservation(note);
            }

            if (!string.IsNullOrWhiteSpace(explored) || !string.IsNullOrWhiteSpace(note))
            {
                UpdateRenderedMessage(workingMessage, workLog.ToWorkingText(0), persist: false);
                RequestUiRefresh();
            }
        }

        private static string BuildExploredLine(string toolName, string toolResult)
        {
            string normalizedTool = NormalizeToolName(toolName);
            string result = toolResult ?? string.Empty;
            switch (normalizedTool)
            {
                case "read_text_file":
                    return PrefixIfNotEmpty("Read ", FirstMatchingPrefixValue(result, "File:"));
                case "search_project":
                    return PrefixIfNotEmpty("Search ", FirstMatchingPrefixValue(result, "Project search:"));
                case "search_unity_docs":
                    return PrefixIfNotEmpty("Search Unity docs ", FirstMatchingPrefixValue(result, "Local Unity docs search:"));
                case "search_unity_api":
                    return PrefixIfNotEmpty("Search Unity API ", FirstMatchingPrefixValue(result, "Unity API source search:"));
                case "search_web":
                    return PrefixIfNotEmpty("Search web ", FirstMatchingPrefixValue(result, "External web search:"));
                case "read_unity_doc":
                    return PrefixIfNotEmpty("Read Unity doc ", FirstNonBlankLine(result));
                case "read_unity_api":
                    return PrefixIfNotEmpty("Read API source ", FirstNonBlankLine(result));
                case "inspect_prefab":
                    return PrefixIfNotEmpty("Inspect prefab ", FirstNonBlankLine(result));
                case "inspect_runtime_state":
                    return "Inspect runtime state";
                case "read_compiler_diagnostics":
                    return "Check compiler diagnostics";
                case "validate_scene":
                    return "Validate scene";
                case "capture_game_view":
                    return "Capture Game view";
                default:
                    return string.Empty;
            }
        }

        private static string BuildAgentObservation(string toolName, string toolResult)
        {
            string normalizedTool = NormalizeToolName(toolName);
            string result = (toolResult ?? string.Empty).Trim();
            if (string.IsNullOrWhiteSpace(result))
            {
                return string.Empty;
            }

            if (result.StartsWith("Tool failed:", StringComparison.OrdinalIgnoreCase) ||
                result.StartsWith("Tool blocked:", StringComparison.OrdinalIgnoreCase))
            {
                return CompactOneLine(result, 180);
            }

            if (result.IndexOf("error CS", StringComparison.OrdinalIgnoreCase) >= 0 ||
                result.IndexOf("Tundra build failed", StringComparison.OrdinalIgnoreCase) >= 0 ||
                result.IndexOf("Script Compilation Error", StringComparison.OrdinalIgnoreCase) >= 0)
            {
                return "Compiler diagnostics found a blocker. I’m repairing that before continuing.";
            }

            if (string.Equals(normalizedTool, "validate_scene", StringComparison.OrdinalIgnoreCase))
            {
                return result.StartsWith("scene validation passed", StringComparison.OrdinalIgnoreCase)
                    ? "Scene validation is passing."
                    : "Scene validation found remaining issues. I’m using those as blockers instead of claiming completion.";
            }

            if (string.Equals(normalizedTool, "read_compiler_diagnostics", StringComparison.OrdinalIgnoreCase) &&
                (result.IndexOf("No recent C# compiler diagnostics", StringComparison.OrdinalIgnoreCase) >= 0 ||
                 result.IndexOf("Compiler diagnostics: clean", StringComparison.OrdinalIgnoreCase) >= 0))
            {
                return "Compiler diagnostics are clean.";
            }

            if (string.Equals(normalizedTool, "read_compiler_diagnostics", StringComparison.OrdinalIgnoreCase) &&
                result.IndexOf("Compiler warnings", StringComparison.OrdinalIgnoreCase) >= 0)
            {
                return "Compiler diagnostics passed with warnings. I’m continuing unless they block the requested behavior.";
            }

            if (string.Equals(normalizedTool, "rebuild_unity", StringComparison.OrdinalIgnoreCase))
            {
                return "Unity rebuild finished. I’m checking compiler diagnostics before continuing.";
            }

            if (string.Equals(normalizedTool, "capture_game_view", StringComparison.OrdinalIgnoreCase) ||
                string.Equals(normalizedTool, "capture_game_view_diagnostics", StringComparison.OrdinalIgnoreCase))
            {
                return PrefixIfNotEmpty("Captured Game view: ", FirstNonBlankLine(result));
            }

            if (string.Equals(normalizedTool, "inspect_runtime_state", StringComparison.OrdinalIgnoreCase))
            {
                return PrefixIfNotEmpty("Runtime state checked: ", FirstNonBlankLine(result));
            }

            if (string.Equals(normalizedTool, "inspect_prefab", StringComparison.OrdinalIgnoreCase))
            {
                return PrefixIfNotEmpty("Prefab inspection result: ", FirstNonBlankLine(result));
            }

            if (string.Equals(normalizedTool, "search_project", StringComparison.OrdinalIgnoreCase))
            {
                return "Project search completed. I’m using those matches to choose the next step.";
            }

            if (string.Equals(normalizedTool, "search_unity_docs", StringComparison.OrdinalIgnoreCase) ||
                string.Equals(normalizedTool, "search_unity_api", StringComparison.OrdinalIgnoreCase) ||
                string.Equals(normalizedTool, "read_unity_doc", StringComparison.OrdinalIgnoreCase) ||
                string.Equals(normalizedTool, "read_unity_api", StringComparison.OrdinalIgnoreCase))
            {
                return "Unity reference check completed. I’m applying that API context to the implementation.";
            }

            if (string.Equals(normalizedTool, "write_csharp_script", StringComparison.OrdinalIgnoreCase) ||
                string.Equals(normalizedTool, "write_text_file", StringComparison.OrdinalIgnoreCase))
            {
                return CompactOneLine(result, 180);
            }

            if (IsUnityMutationTool(normalizedTool))
            {
                return PrefixIfNotEmpty("Applied Unity change: ", FirstNonBlankLine(result));
            }

            if (IsSpecialistReturnTool(normalizedTool))
            {
                return PrefixIfNotEmpty($"{FormatSpecialistName(normalizedTool)} reported: ", FirstNonBlankLine(result));
            }

            return string.Empty;
        }

        private static string BuildProgressObservation(string step)
        {
            string trimmed = (step ?? string.Empty).Trim();
            if (string.IsNullOrWhiteSpace(trimmed))
            {
                return string.Empty;
            }

            if (trimmed.StartsWith("Tool:", StringComparison.OrdinalIgnoreCase))
            {
                return BuildToolStartObservation(NormalizeToolName(trimmed.Substring("Tool:".Length)));
            }

            if (trimmed.StartsWith("Calling ", StringComparison.OrdinalIgnoreCase) &&
                trimmed.IndexOf(" for next tool", StringComparison.OrdinalIgnoreCase) >= 0)
            {
                return CompactOneLine(trimmed + ". I’m waiting for the next concrete action.", 180);
            }

            if (trimmed.StartsWith("Prepared model request after ", StringComparison.OrdinalIgnoreCase) ||
                trimmed.StartsWith("Applied tool response after ", StringComparison.OrdinalIgnoreCase) ||
                trimmed.StartsWith("Responsiveness checkpoint ", StringComparison.OrdinalIgnoreCase) ||
                trimmed.StartsWith("Compiler errors detected", StringComparison.OrdinalIgnoreCase))
            {
                return CompactOneLine(trimmed, 180);
            }

            return string.Empty;
        }

        private static string BuildToolStartObservation(string normalizedTool)
        {
            switch (NormalizeToolName(normalizedTool))
            {
                case "handoff_to_agent":
                    return "I’m handing a scoped task to the right specialist agent.";
                case "search_project":
                    return "I’m searching the project for relevant scripts, prefabs, assets, and scene references.";
                case "read_text_file":
                    return "I’m reading an existing file so the change matches the project instead of guessing.";
                case "search_unity_docs":
                case "read_unity_doc":
                    return "I’m checking local Unity docs for the correct workflow or API behavior.";
                case "search_unity_api":
                case "read_unity_api":
                    return "I’m checking installed Unity/package API source before writing code against it.";
                case "write_csharp_script":
                    return "I’m writing C# now; after this Unity needs to compile before runtime checks are meaningful.";
                case "write_text_file":
                    return "I’m updating a project text/source asset.";
                case "rebuild_unity":
                    return "I’m asking Unity to recompile so any script errors surface before continuing.";
                case "read_compiler_diagnostics":
                    return "I’m checking compiler diagnostics before moving to scene or Play Mode validation.";
                case "validate_scene":
                    return "I’m validating scene relationships, missing references, and required wiring.";
                case "capture_game_view":
                case "capture_game_view_diagnostics":
                    return "I’m capturing the Game view to verify the visible result.";
                case "inspect_runtime_state":
                    return "I’m inspecting runtime state to verify the behavior actually exists in Play Mode.";
                case "enter_play_mode":
                    return "I’m entering Play Mode for runtime verification.";
                case "exit_play_mode":
                    return "I’m exiting Play Mode after the runtime check.";
                case "inspect_prefab":
                    return "I’m inspecting the prefab asset to verify what Unity will instantiate.";
                default:
                    return IsUnityMutationTool(normalizedTool)
                        ? "I’m applying a Unity scene, asset, prefab, or component change."
                        : string.Empty;
            }
        }

        private static bool IsUnityMutationTool(string normalizedTool)
        {
            switch (NormalizeToolName(normalizedTool))
            {
                case "add_component":
                case "apply_default_sprite":
                case "create_material_asset":
                case "create_object":
                case "create_scene":
                case "create_sprite_asset":
                case "delete_game_object":
                case "instantiate_prefab":
                case "invoke_menu_item":
                case "open_scene":
                case "remove_component":
                case "save_assets":
                case "save_scene":
                case "set_asset_property":
                case "set_component_property":
                case "set_editor_build_scenes":
                case "set_object_property":
                case "set_transform":
                    return true;
                default:
                    return false;
            }
        }

        private static bool IsSpecialistReturnTool(string normalizedTool)
        {
            switch (NormalizeToolName(normalizedTool))
            {
                case "default":
                case "worker":
                case "explorer":
                case "monitor":
                case "scene_setup":
                case "asset_management":
                    return true;
                default:
                    return false;
            }
        }

        private static string FormatSpecialistName(string normalizedTool)
        {
            switch (NormalizeToolName(normalizedTool))
            {
                case "scene_setup":
                    return "Scene Setup";
                case "asset_management":
                    return "Asset Management";
                case "worker":
                    return "Worker";
                case "explorer":
                    return "Explorer";
                case "monitor":
                    return "Monitor";
                default:
                    return "Agent";
            }
        }

        private static string PrefixIfNotEmpty(string prefix, string value)
        {
            return string.IsNullOrWhiteSpace(value) ? string.Empty : prefix + value.Trim();
        }

        private static string NormalizeToolName(string toolName)
        {
            if (string.IsNullOrWhiteSpace(toolName))
            {
                return string.Empty;
            }

            string trimmed = toolName.Trim();
            int separator = trimmed.LastIndexOf(':');
            if (separator >= 0 && separator < trimmed.Length - 1)
            {
                trimmed = trimmed.Substring(separator + 1);
            }

            return trimmed.Trim().ToLowerInvariant();
        }

        private static string FirstMatchingPrefixValue(string text, string prefix)
        {
            if (string.IsNullOrWhiteSpace(text) || string.IsNullOrWhiteSpace(prefix))
            {
                return string.Empty;
            }

            string[] lines = text.Replace("\r\n", "\n").Replace('\r', '\n').Split('\n');
            foreach (string line in lines)
            {
                string trimmed = line.Trim();
                if (trimmed.StartsWith(prefix, StringComparison.OrdinalIgnoreCase))
                {
                    return CompactOneLine(trimmed.Substring(prefix.Length).Trim(), 120);
                }
            }

            return string.Empty;
        }

        private static string FirstNonBlankLine(string text)
        {
            if (string.IsNullOrWhiteSpace(text))
            {
                return string.Empty;
            }

            string[] lines = text.Replace("\r\n", "\n").Replace('\r', '\n').Split('\n');
            foreach (string line in lines)
            {
                string trimmed = line.Trim();
                if (!string.IsNullOrWhiteSpace(trimmed))
                {
                    return CompactOneLine(trimmed, 120);
                }
            }

            return string.Empty;
        }

        private static string CompactOneLine(string text, int maxChars)
        {
            if (string.IsNullOrWhiteSpace(text))
            {
                return string.Empty;
            }

            string compact = text.Replace("\r\n", " ").Replace('\r', ' ').Replace('\n', ' ').Trim();
            while (compact.IndexOf("  ", StringComparison.Ordinal) >= 0)
            {
                compact = compact.Replace("  ", " ");
            }

            if (maxChars <= 0 || compact.Length <= maxChars)
            {
                return compact;
            }

            return compact.Substring(0, Math.Max(0, maxChars - 1)).TrimEnd() + "…";
        }

        private void FinishWorkingMessage(
            RenderedMessage workingMessage,
            WorkLog workLog,
            string response,
            long workId,
            bool clearResumableState = true)
        {
            if (!IsActiveWork(workId))
            {
                return;
            }

            UpdateRenderedMessage(workingMessage, workLog.ToFinalText(response));
            ClearActiveWork(workId, clearResumableState);
            SetBusy(false);
            if (TryStartQueuedPromptAfterCurrentRun())
            {
                return;
            }

            promptField.Focus();
        }

        private void FinishPlanReviewMessage(RenderedMessage workingMessage, WorkLog workLog, AgenticAgentBridge.PlanReviewResult plan, long workId)
        {
            if (!IsActiveWork(workId))
            {
                return;
            }

            UpdateRenderedMessage(workingMessage, workLog.ToPlanReviewText(plan));
            if (plan.ProposedActionCount > 0)
            {
                AddApprovalControls(workingMessage, plan);
            }

            ClearActiveWork(workId);
            SetBusy(false);
            if (TryStartQueuedPromptAfterCurrentRun())
            {
                return;
            }

            promptField.Focus();
        }

        private void AddApprovalControls(RenderedMessage renderedMessage, AgenticAgentBridge.PlanReviewResult plan)
        {
            VisualElement controls = new VisualElement();
            controls.style.flexDirection = FlexDirection.Row;
            controls.style.marginTop = 10f;
            controls.style.paddingTop = 8f;
            SetBorderTop(controls, BorderColor);

            Button approve = new Button(() =>
            {
                controls.RemoveFromHierarchy();
                StartApprovedExecution(plan);
            })
            {
                text = "Approve & Run",
                tooltip = "Approve this plan and let the agent modify the Unity project"
            };
            StylePrimaryButton(approve);
            approve.style.width = 116f;
            controls.Add(approve);

            Button cancel = new Button(() =>
            {
                controls.RemoveFromHierarchy();
                UpdateRenderedMessage(renderedMessage, $"{renderedMessage.Message.text}\n\nStatus: canceled. No Unity actions were applied.");
            })
            {
                text = "Cancel",
                tooltip = "Reject this plan without changing the project"
            };
            StyleUtilityButton(cancel);
            controls.Add(cancel);

            renderedMessage.Bubble.Add(controls);
        }

        private void StartApprovedExecution(AgenticAgentBridge.PlanReviewResult plan)
        {
            if (isBusy)
            {
                return;
            }

            WorkLog workLog = new WorkLog();
            RenderedMessage workingMessage = AddAgentMessage(workLog.ToWorkingText(0));
            long workId = ++activeWorkId;
            SetActiveWork(workingMessage, workLog, workId);

            AppendProgress(workingMessage, workLog, "Plan approved");

            try
            {
                if (AgenticAgentBridge.CanExecuteApprovedPlanLocally(plan))
                {
                    AppendProgress(workingMessage, workLog, "Applying approved Unity actions");
                    string response = AgenticAgentBridge.ExecuteApprovedPlan(plan);
                    AppendProgress(workingMessage, workLog, "Finished");
                    FinishWorkingMessage(workingMessage, workLog, response, workId);
                    return;
                }

                if (AgenticAgentBridge.TryBuildApprovedExecutionRequest(plan, out AgenticAgentBridge.PreparedRequest request, out string error))
                {
                    AppendProgress(workingMessage, workLog, "Preparing approved execution");
                    DispatchPreparedRequest(request, workingMessage, workLog, workId);
                    return;
                }

                FinishWorkingMessage(
                    workingMessage,
                    workLog,
                    string.IsNullOrWhiteSpace(error)
                        ? "No executable actions were stored with this plan, so nothing was run. Ask again with the concrete change you want, or answer the agent's question if it asked for missing details.\n\nApplied actions: 0"
                        : $"Approved execution could not start: {error}",
                    workId);
            }
            catch (Exception exception)
            {
                Debug.LogException(exception);
                FinishWorkingMessage(workingMessage, workLog, $"Command failed: {exception.Message}", workId);
            }
        }

        private void SetQuietWaitingStatus(RenderedMessage workingMessage, WorkLog workLog, string step, int tick, bool persist = false)
        {
            if (workingMessage == null || workLog == null)
            {
                return;
            }

            workLog.SetCurrent(step);
            SetRunningTooltip(step);
            UpdateRenderedMessage(workingMessage, workLog.ToWorkingText(tick), persist: persist);
            RequestUiRefresh();
        }

        private void SetRunningTooltip(string detail)
        {
            string tooltip = string.IsNullOrWhiteSpace(detail)
                ? HeaderTooltip
                : HeaderTooltip + "\n\n" + detail.Trim();

            if (connectionStatusDot != null)
            {
                connectionStatusDot.tooltip = tooltip;
            }

            if (runningStatusPill != null)
            {
                runningStatusPill.tooltip = tooltip;
            }

            if (runningPulseDot != null)
            {
                runningPulseDot.tooltip = tooltip;
            }

            if (runningStatusLabel != null)
            {
                runningStatusLabel.tooltip = tooltip;
            }
        }

        private void UpdateRenderedMessage(
            RenderedMessage renderedMessage,
            string text,
            bool persist = true,
            bool scroll = true,
            bool refreshDashboard = true)
        {
            if (renderedMessage == null)
            {
                return;
            }

            bool shouldFollow = scroll && IsTranscriptNearBottom();
            string nextText = SanitizeMessageTextForCurrentMode(text, renderedMessage.AlignRight);
            bool changed = !string.Equals(renderedMessage.Message.text, nextText, StringComparison.Ordinal);
            renderedMessage.Message.text = nextText;
            if (changed)
            {
                PopulateMessageBody(renderedMessage.Body, renderedMessage.Message.text, renderedMessage.AlignRight);
            }

            if (persist)
            {
                AgenticChatStore.Save(messages);
            }

            if (refreshDashboard)
            {
                RefreshRunDashboard();
            }

            if (changed)
            {
                if (shouldFollow)
                {
                    ScheduleScrollToBottom();
                }
                else
                {
                    UpdateJumpToLatestVisibility();
                }
            }
        }

        private void ScheduleScrollToElement(VisualElement target)
        {
            if (transcript == null || target == null)
            {
                return;
            }

            VisualElement scheduledTarget = target;
            transcript.schedule.Execute(() =>
            {
                if (transcript == null ||
                    scheduledTarget == null ||
                    transcript.panel == null ||
                    scheduledTarget.panel == null ||
                    transcript.contentContainer == null ||
                    !IsDescendantOf(scheduledTarget, transcript.contentContainer))
                {
                    return;
                }

                transcript.ScrollTo(scheduledTarget);
                UpdateJumpToLatestVisibility();
            }).ExecuteLater(20);
        }

        private void ScheduleScrollToBottom(bool force = false)
        {
            if (transcript == null)
            {
                return;
            }

            transcript.schedule.Execute(() =>
            {
                if (transcript == null || transcript.panel == null || transcript.contentContainer == null)
                {
                    return;
                }

                int childCount = transcript.contentContainer.childCount;
                if (childCount > 0)
                {
                    transcript.ScrollTo(transcript.contentContainer[childCount - 1]);
                }

                transcript.verticalScroller.value = transcript.verticalScroller.highValue;
                UpdateJumpToLatestVisibility();
            }).ExecuteLater(force ? 20 : 60);
        }

        private void OnTranscriptScrollValueChanged(float value)
        {
            if (isRenderingTranscriptBatch)
            {
                return;
            }

            UpdateJumpToLatestVisibility();
        }

        private bool IsTranscriptNearBottom()
        {
            if (transcript == null || transcript.verticalScroller == null)
            {
                return true;
            }

            float highValue = transcript.verticalScroller.highValue;
            if (highValue <= 0.5f)
            {
                return true;
            }

            return highValue - transcript.verticalScroller.value <= TranscriptBottomThreshold;
        }

        private void UpdateJumpToLatestVisibility()
        {
            if (jumpToLatestButton == null)
            {
                return;
            }

            bool show = transcript != null &&
                transcript.verticalScroller != null &&
                transcript.verticalScroller.highValue > 0.5f &&
                !IsTranscriptNearBottom();
            jumpToLatestButton.style.display = show ? DisplayStyle.Flex : DisplayStyle.None;
        }

        private static bool IsDescendantOf(VisualElement child, VisualElement ancestor)
        {
            for (VisualElement current = child; current != null; current = current.parent)
            {
                if (current == ancestor)
                {
                    return true;
                }
            }

            return false;
        }

        private void PopulateMessageBody(VisualElement container, string text, bool alignRight)
        {
            container.Clear();
            if (string.IsNullOrWhiteSpace(text))
            {
                return;
            }

            string normalized = text.Replace("\r\n", "\n").Replace('\r', '\n');
            string[] lines = normalized.Split('\n');
            string currentSection = string.Empty;
            VisualElement currentToolSection = null;
            bool lastWasBlank = false;
            bool suppressDeveloperOnlySection = false;
            for (int i = 0; i < lines.Length; i++)
            {
                if (IsCodeFenceLine(lines[i], out string language))
                {
                    StringBuilder code = new StringBuilder();
                    i++;
                    while (i < lines.Length && !IsCodeFenceLine(lines[i], out _))
                    {
                        if (code.Length > 0)
                        {
                            code.AppendLine();
                        }

                        code.Append(lines[i]);
                        i++;
                    }

                    if (suppressDeveloperOnlySection)
                    {
                        continue;
                    }

                    AddCodeBlock(
                        currentToolSection ?? container,
                        language,
                        code.ToString(),
                        alignRight,
                        lastWasBlank);
                    lastWasBlank = false;
                    continue;
                }

                AddFormattedDisplayLine(
                    container,
                    lines[i],
                    ref currentSection,
                    ref currentToolSection,
                    ref suppressDeveloperOnlySection,
                    alignRight,
                    ref lastWasBlank);
            }
        }

        private void AddFormattedDisplayLine(
            VisualElement container,
            string line,
            ref string currentSection,
            ref VisualElement currentToolSection,
            ref bool suppressDeveloperOnlySection,
            bool alignRight,
            ref bool lastWasBlank)
        {
            string trimmed = (line ?? string.Empty).Trim();
            if (trimmed.Length == 0)
            {
                lastWasBlank = true;
                return;
            }

            string sectionHeader = NormalizeDisplaySectionHeader(trimmed);
            if (!string.IsNullOrEmpty(sectionHeader))
            {
                currentSection = sectionHeader;
                suppressDeveloperOnlySection = IsDeveloperOnlySection(sectionHeader) && !ShouldShowDeveloperDetails();
                if (suppressDeveloperOnlySection)
                {
                    currentToolSection = null;
                    lastWasBlank = false;
                    return;
                }

                if (IsToolCallsSectionHeader(sectionHeader))
                {
                    currentToolSection = AddToolCallsSection(container, sectionHeader, alignRight, container.childCount > 0 || lastWasBlank);
                }
                else
                {
                    currentToolSection = null;
                    AddSectionHeader(container, sectionHeader, alignRight, container.childCount > 0 || lastWasBlank);
                }

                lastWasBlank = false;
                return;
            }

            if (suppressDeveloperOnlySection)
            {
                lastWasBlank = false;
                return;
            }

            if (!ShouldShowDeveloperDetails() && IsToolDisplayLine(TrimListMarker(trimmed)))
            {
                lastWasBlank = false;
                return;
            }

            if (trimmed.StartsWith("Working", StringComparison.Ordinal))
            {
                AddTextLabel(container, FormatColoredBold(HeaderRichColor, trimmed), alignRight, true, false, lastWasBlank);
                lastWasBlank = false;
                return;
            }

            bool isToolSection = IsToolCallsSectionHeader(currentSection);
            if ((isToolSection || IsToolDisplayLine(TrimListMarker(trimmed))) &&
                TryParseToolCallLine(trimmed, out string toolName, out string toolDetails))
            {
                AddToolCallCard(currentToolSection ?? container, toolName, toolDetails, alignRight);
                lastWasBlank = false;
                return;
            }

            bool isListLine = IsListLine(trimmed);
            AddTextLabel(
                isToolSection && currentToolSection != null ? currentToolSection : container,
                FormatRegularDisplayLine(trimmed),
                alignRight,
                false,
                isListLine,
                lastWasBlank);
            lastWasBlank = false;
        }

        private static int GetNumberedListDotIndex(string value)
        {
            int dotIndex = value.IndexOf('.');
            if (dotIndex <= 0 || dotIndex >= value.Length - 1 || !char.IsWhiteSpace(value[dotIndex + 1]))
            {
                return -1;
            }

            for (int i = 0; i < dotIndex; i++)
            {
                if (!char.IsDigit(value[i]))
                {
                    return -1;
                }
            }

            return dotIndex;
        }

        private static bool IsListLine(string trimmed)
        {
            return trimmed.StartsWith("- ", StringComparison.Ordinal) ||
                GetNumberedListDotIndex(trimmed) > 0;
        }

        private static bool IsToolDisplayLine(string content)
        {
            if (string.IsNullOrWhiteSpace(content))
            {
                return false;
            }

            return content.StartsWith("Tool:", StringComparison.OrdinalIgnoreCase) ||
                content.StartsWith("Completed tool:", StringComparison.OrdinalIgnoreCase) ||
                IsAgentToolRequestStep(content);
        }

        private static bool TryParseToolCallLine(string line, out string toolName, out string details)
        {
            string trimmed = TrimListMarker(line);
            toolName = string.Empty;
            details = string.Empty;

            if (trimmed.StartsWith("Tool:", StringComparison.OrdinalIgnoreCase))
            {
                toolName = trimmed.Substring("Tool:".Length).Trim();
                details = "Tool call started.";
                return !string.IsNullOrWhiteSpace(toolName);
            }

            if (trimmed.StartsWith("Completed tool:", StringComparison.OrdinalIgnoreCase))
            {
                toolName = trimmed.Substring("Completed tool:".Length).Trim();
                details = "Tool call completed.";
                return !string.IsNullOrWhiteSpace(toolName);
            }

            if (IsAgentToolRequestStep(trimmed))
            {
                toolName = "Agent tool request";
                details = trimmed;
                return true;
            }

            int separator = trimmed.IndexOf(" - ", StringComparison.Ordinal);
            if (separator > 0)
            {
                toolName = trimmed.Substring(0, separator).Trim();
                details = trimmed.Substring(separator + 3).Trim();
                return !string.IsNullOrWhiteSpace(toolName);
            }

            if (IsToolDisplayLine(trimmed))
            {
                toolName = trimmed;
                return true;
            }

            return false;
        }

        private static bool IsAgentToolRequestStep(string value)
        {
            return !string.IsNullOrWhiteSpace(value) &&
                value.StartsWith("Calling ", StringComparison.OrdinalIgnoreCase) &&
                value.IndexOf(" for next tool", StringComparison.OrdinalIgnoreCase) >= 0;
        }

        private void AddSectionHeader(VisualElement container, string header, bool alignRight, bool addTopMargin)
        {
            Label label = CreateSelectableLabel(header, alignRight ? Color.white : TextColor, 11f);
            label.style.unityFontStyleAndWeight = FontStyle.Bold;
            label.style.marginTop = addTopMargin ? 9f : 0f;
            label.style.marginBottom = 2f;
            container.Add(label);
        }

        private VisualElement AddToolCallsSection(VisualElement container, string header, bool alignRight, bool addTopMargin)
        {
            VisualElement section = new VisualElement();
            section.style.marginTop = addTopMargin ? 9f : 2f;
            section.style.marginBottom = 3f;
            section.style.paddingLeft = 10f;
            section.style.paddingRight = 10f;
            section.style.paddingTop = 8f;
            section.style.paddingBottom = 9f;
            section.style.backgroundColor = ToolSectionBackground;
            SetBorder(section, ToolSectionBorder);
            SetRadius(section, 8f);

            Label label = CreateSelectableLabel(header, alignRight ? Color.white : TextColor, 11f);
            label.enableRichText = true;
            label.text = FormatColoredBold(ToolRichColor, header);
            label.style.unityFontStyleAndWeight = FontStyle.Bold;
            label.style.marginBottom = 2f;
            section.Add(label);

            container.Add(section);
            return section;
        }

        private void AddTextLabel(
            VisualElement container,
            string richText,
            bool alignRight,
            bool bold,
            bool indent,
            bool addTopMargin)
        {
            Label label = CreateSelectableLabel(richText, alignRight ? Color.white : TextColor, 12f);
            label.enableRichText = true;
            label.style.marginTop = addTopMargin ? 6f : 2f;
            label.style.marginLeft = indent ? 8f : 0f;
            label.style.unityFontStyleAndWeight = bold ? FontStyle.Bold : FontStyle.Normal;
            container.Add(label);
        }

        private void AddToolCallCard(VisualElement container, string toolName, string details, bool alignRight)
        {
            VisualElement card = new VisualElement();
            card.style.marginTop = 7f;
            card.style.marginBottom = 2f;
            card.style.paddingLeft = 10f;
            card.style.paddingRight = 10f;
            card.style.paddingTop = 8f;
            card.style.paddingBottom = 8f;
            card.style.backgroundColor = ToolCardBackground;
            SetBorder(card, ToolCardBorder);
            SetRadius(card, 8f);

            VisualElement header = new VisualElement();
            header.style.flexDirection = FlexDirection.Row;
            header.style.alignItems = Align.Center;

            VisualElement icon = new VisualElement();
            icon.style.width = 12f;
            icon.style.height = 12f;
            icon.style.marginRight = 8f;
            icon.style.backgroundColor = ToolAccentColor;
            SetRadius(icon, 3f);
            header.Add(icon);

            Label title = CreateSelectableLabel(FormatToolTitle(toolName), alignRight ? Color.white : TextColor, 12f);
            title.enableRichText = true;
            title.style.unityFontStyleAndWeight = FontStyle.Bold;
            header.Add(title);
            card.Add(header);

            if (!string.IsNullOrWhiteSpace(details))
            {
                Label detail = CreateSelectableLabel(FormatInline(details), alignRight ? new Color(0.9f, 0.94f, 1f) : MutedTextColor, 11f);
                detail.enableRichText = true;
                detail.style.marginTop = 4f;
                detail.style.marginLeft = 20f;
                card.Add(detail);
            }

            container.Add(card);
        }

        private void AddCodeBlock(VisualElement container, string language, string code, bool alignRight, bool addTopMargin)
        {
            VisualElement block = new VisualElement();
            block.style.marginTop = addTopMargin ? 8f : 6f;
            block.style.marginBottom = 6f;
            block.style.paddingLeft = 10f;
            block.style.paddingRight = 10f;
            block.style.paddingTop = 8f;
            block.style.paddingBottom = 9f;
            block.style.backgroundColor = CodeBlockBackground;
            SetBorder(block, CodeBlockBorder);
            SetRadius(block, 7f);

            if (!string.IsNullOrWhiteSpace(language))
            {
                Label languageLabel = CreateSelectableLabel(language.Trim(), CodeLanguageColor, 10f);
                languageLabel.style.unityFontStyleAndWeight = FontStyle.Bold;
                languageLabel.style.marginBottom = 5f;
                block.Add(languageLabel);
            }

            TextField codeField = new TextField
            {
                multiline = true,
                isReadOnly = true,
                value = string.IsNullOrEmpty(code) ? string.Empty : code.TrimEnd()
            };
            codeField.style.flexGrow = 1f;
            codeField.style.minHeight = 22f;
            codeField.style.marginLeft = 0f;
            codeField.style.marginRight = 0f;
            codeField.style.marginTop = 0f;
            codeField.style.marginBottom = 0f;
            codeField.style.paddingLeft = 0f;
            codeField.style.paddingRight = 0f;
            codeField.style.paddingTop = 0f;
            codeField.style.paddingBottom = 0f;
            codeField.style.backgroundColor = Color.clear;
            codeField.style.color = alignRight ? Color.white : CodeTextColor;
            codeField.style.fontSize = 11f;
            codeField.style.unityFont = GetCodeFont();
            codeField.style.whiteSpace = WhiteSpace.Normal;
            codeField.style.borderTopWidth = 0f;
            codeField.style.borderRightWidth = 0f;
            codeField.style.borderBottomWidth = 0f;
            codeField.style.borderLeftWidth = 0f;
            block.Add(codeField);

            container.Add(block);
        }

        private static string FormatToolTitle(string toolName)
        {
            string trimmed = string.IsNullOrWhiteSpace(toolName) ? "Unity tool call" : toolName.Trim();
            return FormatColoredBold(ToolRichColor, trimmed);
        }

        private static string FormatRegularDisplayLine(string text)
        {
            string trimmed = (text ?? string.Empty).Trim();
            int dotIndex = GetNumberedListDotIndex(trimmed);
            if (dotIndex > 0)
            {
                string number = trimmed.Substring(0, dotIndex);
                string content = trimmed.Substring(dotIndex + 1).Trim();
                return EscapeRichText(number) + ". " + FormatInline(content);
            }

            if (trimmed.StartsWith("- ", StringComparison.Ordinal))
            {
                return "- " + FormatInline(trimmed.Substring(2).Trim());
            }

            return FormatInline(trimmed);
        }

        private static string FormatInline(string text)
        {
            StringBuilder builder = new StringBuilder();
            string trimmed = (text ?? string.Empty).Trim();
            int colonIndex = GetLabelColonIndex(trimmed);
            if (colonIndex > 0)
            {
                builder.Append("<b>");
                AppendEscaped(builder, trimmed.Substring(0, colonIndex + 1));
                builder.Append("</b>");
                AppendEscaped(builder, trimmed.Substring(colonIndex + 1));
                return builder.ToString();
            }

            AppendEscaped(builder, trimmed);
            return builder.ToString();
        }

        private static int GetLabelColonIndex(string value)
        {
            int colonIndex = value.IndexOf(':');
            if (colonIndex <= 0 || colonIndex > 48 || value.IndexOf("://", StringComparison.Ordinal) >= 0)
            {
                return -1;
            }

            for (int i = 0; i < colonIndex; i++)
            {
                char character = value[i];
                if (!char.IsLetterOrDigit(character) &&
                    character != ' ' &&
                    character != '_' &&
                    character != '-' &&
                    character != '/' &&
                    character != '(' &&
                    character != ')')
                {
                    return -1;
                }
            }

            return colonIndex;
        }

        private static string FormatColoredBold(string color, string text)
        {
            StringBuilder builder = new StringBuilder();
            AppendColoredBold(builder, color, text);
            return builder.ToString();
        }

        private static void AppendColoredBold(StringBuilder builder, string color, string text)
        {
            builder.Append("<color=");
            builder.Append(color);
            builder.Append("><b>");
            AppendEscaped(builder, text);
            builder.Append("</b></color>");
        }

        private static void AppendEscaped(StringBuilder builder, string value)
        {
            builder.Append(EscapeRichText(value));
        }

        private static string HeaderRichColor => IsDarkTheme ? "#D8D8D8" : "#1E1E1E";
        private static string ToolRichColor => IsDarkTheme ? "#7FB4FF" : "#0B5CAD";
        private static Color ToolSectionBackground => IsDarkTheme ? new Color(0.12f, 0.13f, 0.15f) : new Color(0.94f, 0.96f, 0.99f);
        private static Color ToolSectionBorder => IsDarkTheme ? new Color(0.27f, 0.29f, 0.33f) : new Color(0.7f, 0.77f, 0.88f);
        private static Color ToolCardBackground => IsDarkTheme ? new Color(0.15f, 0.17f, 0.2f) : new Color(0.91f, 0.94f, 0.98f);
        private static Color ToolCardBorder => IsDarkTheme ? new Color(0.28f, 0.34f, 0.42f) : new Color(0.67f, 0.75f, 0.86f);
        private static Color ToolAccentColor => IsDarkTheme ? new Color(0.38f, 0.62f, 0.95f) : new Color(0.13f, 0.36f, 0.68f);
        private static Color CodeBlockBackground => IsDarkTheme ? new Color(0.08f, 0.09f, 0.11f) : new Color(0.96f, 0.97f, 0.99f);
        private static Color CodeBlockBorder => IsDarkTheme ? new Color(0.24f, 0.28f, 0.34f) : new Color(0.68f, 0.74f, 0.82f);
        private static Color CodeTextColor => IsDarkTheme ? new Color(0.84f, 0.88f, 0.92f) : new Color(0.12f, 0.14f, 0.17f);
        private static Color CodeLanguageColor => IsDarkTheme ? new Color(0.52f, 0.72f, 1f) : new Color(0.12f, 0.34f, 0.62f);

        private static bool IsCodeFenceLine(string line, out string language)
        {
            language = string.Empty;
            string trimmed = (line ?? string.Empty).Trim();
            if (!trimmed.StartsWith("```", StringComparison.Ordinal))
            {
                return false;
            }

            language = trimmed.Length <= 3 ? string.Empty : trimmed.Substring(3).Trim();
            return true;
        }

        private static Font GetCodeFont()
        {
            if (codeFont != null)
            {
                return codeFont;
            }

            codeFont = Font.CreateDynamicFontFromOSFont(
                new[] { "Menlo", "Monaco", "Consolas", "Courier New" },
                11);
            return codeFont != null ? codeFont : EditorStyles.textField.font;
        }

        private static string TrimListMarker(string value)
        {
            string trimmed = (value ?? string.Empty).Trim();
            if (trimmed.StartsWith("- ", StringComparison.Ordinal))
            {
                return trimmed.Substring(2).Trim();
            }

            int dotIndex = GetNumberedListDotIndex(trimmed);
            if (dotIndex > 0)
            {
                return trimmed.Substring(dotIndex + 1).Trim();
            }

            return trimmed;
        }

        private static Label CreateSelectableLabel(string text, Color color, float fontSize)
        {
            Label label = new Label(text);
            label.style.fontSize = fontSize;
            label.style.whiteSpace = WhiteSpace.Normal;
            label.style.color = color;
            MakeBodyTextSelectable(label);
            return label;
        }

        private static bool IsDisplaySectionHeader(string line)
        {
            return !string.IsNullOrEmpty(NormalizeDisplaySectionHeader(line));
        }

        private static bool IsToolCallsSectionHeader(string section)
        {
            string normalized = NormalizeDisplaySectionHeader(section);
            return string.Equals(normalized, "Tool calls", StringComparison.Ordinal) ||
                string.Equals(normalized, "Agent handoffs", StringComparison.Ordinal) ||
                string.Equals(normalized, "Executed tool calls", StringComparison.Ordinal);
        }

        private static bool IsDeveloperOnlySection(string section)
        {
            string normalized = NormalizeDisplaySectionHeader(section);
            return string.Equals(normalized, "Activity", StringComparison.Ordinal) ||
                string.Equals(normalized, "Explored", StringComparison.Ordinal) ||
                string.Equals(normalized, "Context checked", StringComparison.Ordinal) ||
                string.Equals(normalized, "Tool calls", StringComparison.Ordinal) ||
                string.Equals(normalized, "Agent handoffs", StringComparison.Ordinal) ||
                string.Equals(normalized, "Executed tool calls", StringComparison.Ordinal);
        }

        private static bool ShouldShowDeveloperDetails()
        {
            return AgenticAgentBridge.GetDeveloperMode();
        }

        private static string NormalizeDisplaySectionHeader(string line)
        {
            string trimmed = (line ?? string.Empty).Trim();
            if (trimmed.EndsWith(":", StringComparison.Ordinal))
            {
                trimmed = trimmed.Substring(0, trimmed.Length - 1).TrimEnd();
            }

            if (string.Equals(trimmed, "Activity", StringComparison.Ordinal) ||
                string.Equals(trimmed, "Status", StringComparison.Ordinal) ||
                string.Equals(trimmed, "Result", StringComparison.Ordinal) ||
                string.Equals(trimmed, "Summary", StringComparison.Ordinal) ||
                string.Equals(trimmed, "What changed", StringComparison.Ordinal) ||
                string.Equals(trimmed, "Explored", StringComparison.Ordinal) ||
                string.Equals(trimmed, "Context checked", StringComparison.Ordinal) ||
                string.Equals(trimmed, "Code snippets", StringComparison.Ordinal) ||
                string.Equals(trimmed, "Validation", StringComparison.Ordinal) ||
                string.Equals(trimmed, "Issues", StringComparison.Ordinal) ||
                string.Equals(trimmed, "Actions", StringComparison.Ordinal) ||
                string.Equals(trimmed, "Agent handoffs", StringComparison.Ordinal) ||
                string.Equals(trimmed, "Tool calls", StringComparison.Ordinal) ||
                string.Equals(trimmed, "Executed tool calls", StringComparison.Ordinal) ||
                string.Equals(trimmed, "Plan", StringComparison.Ordinal) ||
                string.Equals(trimmed, "Notes", StringComparison.Ordinal))
            {
                return trimmed;
            }

            return string.Empty;
        }

        private static string EscapeRichText(string value)
        {
            if (string.IsNullOrEmpty(value))
            {
                return string.Empty;
            }

            return value
                .Replace("&", "&amp;")
                .Replace("<", "&lt;")
                .Replace(">", "&gt;");
        }

        private void SetBusy(bool busy)
        {
            bool wasBusy = isBusy;
            isBusy = busy;
            promptField?.SetEnabled(true);
            if (sendButton != null)
            {
                sendButton.SetEnabled(true);
                sendButton.text = busy ? "Queue" : "Send";
                sendButton.tooltip = busy
                    ? "Queue this message for the running agent"
                    : "Send message";
            }

            if (stopButton != null)
            {
                stopButton.style.display = busy ? DisplayStyle.Flex : DisplayStyle.None;
                stopButton.SetEnabled(busy);
            }

            if (busy && !wasBusy)
            {
                StartRunningAnimation();
            }
            else if (!busy)
            {
                StopRunningAnimation();
            }

            RefreshRunDashboard();
        }

        private void StartRunningAnimation()
        {
            runningAnimationWorkId = activeWorkId;
            runningAnimationTick = 0;
            if (runningStatusPill != null)
            {
                runningStatusPill.style.display = DisplayStyle.Flex;
            }

            UpdateRunningStatusVisuals();
            ScheduleRunningAnimation(runningAnimationWorkId);
            RequestUiRefresh();
        }

        private void StopRunningAnimation()
        {
            runningAnimationWorkId++;
            runningAnimationTick = 0;
            if (runningStatusPill != null)
            {
                runningStatusPill.style.display = DisplayStyle.None;
            }

            if (connectionStatusDot != null)
            {
                connectionStatusDot.style.width = 10f;
                connectionStatusDot.style.height = 10f;
                connectionStatusDot.style.backgroundColor = ReadyColor;
                connectionStatusDot.tooltip = "Ark is ready.";
                SetRadius(connectionStatusDot, 5f);
            }

            if (runningPulseDot != null)
            {
                runningPulseDot.style.width = 7f;
                runningPulseDot.style.height = 7f;
                runningPulseDot.style.backgroundColor = RunningAccent;
                SetRadius(runningPulseDot, 4f);
            }

            if (runningProgressFill != null)
            {
                runningProgressFill.style.marginLeft = 0f;
            }

            RequestUiRefresh();
        }

        private void ScheduleRunningAnimation(long animationWorkId)
        {
            ScheduleEditorAction(() =>
            {
                if (!isBusy || runningAnimationWorkId != animationWorkId)
                {
                    return;
                }

                runningAnimationTick++;
                UpdateRunningStatusVisuals();
                ScheduleRunningAnimation(animationWorkId);
            }, RunningAnimationIntervalMs);
        }

        private void UpdateRunningStatusVisuals()
        {
            int dots = runningAnimationTick % 4;
            bool hot = runningAnimationTick % 2 == 0;

            if (connectionStatusDot != null)
            {
                connectionStatusDot.style.backgroundColor = hot ? RunningAccentHot : RunningAccent;
            }

            if (runningPulseDot != null)
            {
                runningPulseDot.style.backgroundColor = hot ? RunningAccentHot : RunningAccent;
            }

            if (runningStatusLabel != null)
            {
                runningStatusLabel.text = "Agent running" + new string('.', dots);
            }

            if (runningProgressFill != null)
            {
                runningProgressFill.style.backgroundColor = hot ? RunningAccentHot : RunningAccent;
            }

            RequestUiRefresh();
        }

        private void ResetStaleBusyState()
        {
            activeWorkingMessage = null;
            activeWorkLog = null;
            activeToolLoopState = null;
            activeWorkId++;
            SetBusy(false);
            RefreshRunDashboard();
        }

        private void SetActiveWork(RenderedMessage workingMessage, WorkLog workLog, long workId)
        {
            activeWorkingMessage = workingMessage;
            activeWorkLog = workLog;
            activeToolLoopState = null;
            activeWorkId = workId;
            SetBusy(true);
            RefreshRunDashboard();
        }

        private void ClearActiveWork(long workId, bool clearResumableState = true)
        {
            if (activeWorkId != workId)
            {
                return;
            }

            activeWorkingMessage = null;
            activeWorkLog = null;
            activeToolLoopState = null;
            if (clearResumableState)
            {
                AgenticAgentBridge.ClearResumableToolLoopState();
            }

            RefreshRunDashboard();
        }

        private void StopActiveWork()
        {
            if (!isBusy)
            {
                return;
            }

            RenderedMessage stoppedMessage = activeWorkingMessage;
            WorkLog stoppedLog = activeWorkLog;
            int discardedQueuedPrompts = queuedPrompts.Count;
            foreach (QueuedPrompt queued in queuedPrompts)
            {
                AgenticChatStore.Message message = queued.RenderedMessage?.Message;
                if (message == null)
                {
                    continue;
                }

                message.undoSnapshotPending = false;
                if (string.IsNullOrWhiteSpace(message.undoSnapshotId))
                {
                    message.undoSnapshotError = "Prompt was discarded before it ran; no snapshot was captured.";
                }

                PopulateMessageHeader(queued.RenderedMessage.Header, message, queued.RenderedMessage.AlignRight);
            }

            if (discardedQueuedPrompts > 0)
            {
                AgenticChatStore.Save(messages);
            }

            queuedPrompts.Clear();
            activeWorkId++;
            activeWorkingMessage = null;
            activeWorkLog = null;
            activeToolLoopState = null;
            ClearActiveBackendRun();
            AgenticAgentBridge.ClearResumableToolLoopState();
            SetBusy(false);
            RefreshRunDashboard();

            if (stoppedMessage != null && stoppedLog != null)
            {
                stoppedLog.Add("Stopped by user");
                string queuedNote = discardedQueuedPrompts > 0
                    ? $" {discardedQueuedPrompts} queued follow-up(s) were not sent."
                    : string.Empty;
                UpdateRenderedMessage(
                    stoppedMessage,
                    stoppedLog.ToFinalText("Stopped by user. Any Unity tool call that already finished remains applied; pending model responses and future tool calls from this run will be ignored." + queuedNote));
            }

            promptField?.Focus();
        }

        private bool TryStartQueuedPromptAfterCurrentRun()
        {
            if (isBusy || queuedPrompts.Count == 0)
            {
                return false;
            }

            QueuedPrompt nextPrompt = queuedPrompts.Dequeue();
            string effectivePrompt = ResolveContinuationPrompt(nextPrompt.Prompt);
            ScheduleEditorAction(
                () => StartCommandRun(effectivePrompt, addUserMessage: false, existingUserMessage: nextPrompt.RenderedMessage),
                80);
            return true;
        }

        private bool IsActiveWork(long workId)
        {
            return this != null && activeWorkId == workId;
        }

        private static void SetBorderTop(VisualElement element, Color color)
        {
            element.style.borderTopWidth = 1f;
            element.style.borderTopColor = color;
        }

        private void LoadTranscript()
        {
            messages.Clear();
            transcript.Clear();
            firstRenderedMessageIndex = 0;

            List<AgenticChatStore.Message> savedMessages = AgenticChatStore.Load();
            if (savedMessages.Count == 0)
            {
                AddAgentMessage("Describe the scene, project, or code change you want. Use Settings to add an API key, and use the copy controls on any prompt or response when you want to move context elsewhere.");
                return;
            }

            messages.AddRange(savedMessages);
            firstRenderedMessageIndex = Mathf.Max(0, messages.Count - InitialTranscriptChunkSize);
            RenderTranscriptWindow(scrollToBottom: true);
        }

        private void RenderTranscriptWindow(bool scrollToBottom, int anchorMessageIndex = -1)
        {
            if (transcript == null)
            {
                return;
            }

            isRenderingTranscriptBatch = true;
            transcript.Clear();
            UpdateLoadOlderButton();

            RenderedMessage anchor = null;
            for (int i = firstRenderedMessageIndex; i < messages.Count; i++)
            {
                AgenticChatStore.Message message = messages[i];
                RenderedMessage rendered = RenderMessage(
                    message,
                    string.Equals(message.author, "You", StringComparison.Ordinal),
                    scroll: false);
                if (i == anchorMessageIndex)
                {
                    anchor = rendered;
                }
            }

            isRenderingTranscriptBatch = false;

            if (scrollToBottom)
            {
                ScheduleScrollToBottom(force: true);
            }
            else if (anchor != null)
            {
                ScheduleScrollToElement(anchor.Bubble);
            }
            else
            {
                UpdateJumpToLatestVisibility();
            }
        }

        private void UpdateLoadOlderButton()
        {
            if (transcript == null)
            {
                return;
            }

            if (firstRenderedMessageIndex <= 0)
            {
                loadOlderButton = null;
                return;
            }

            loadOlderButton = new Button(LoadOlderTranscriptChunk)
            {
                text = $"Load {Mathf.Min(OlderTranscriptChunkSize, firstRenderedMessageIndex)} older messages",
                tooltip = "Render the next older chunk of chat history"
            };
            loadOlderButton.style.alignSelf = Align.Center;
            loadOlderButton.style.marginBottom = 10f;
            loadOlderButton.style.height = 24f;
            loadOlderButton.style.paddingLeft = 12f;
            loadOlderButton.style.paddingRight = 12f;
            loadOlderButton.style.paddingTop = 0f;
            loadOlderButton.style.paddingBottom = 1f;
            loadOlderButton.style.fontSize = 10f;
            loadOlderButton.style.color = TextColor;
            loadOlderButton.style.backgroundColor = PanelBackground;
            SetBorder(loadOlderButton, BorderColor);
            SetRadius(loadOlderButton, 12f);
            AttachButtonHover(loadOlderButton, PanelBackground, PanelHover);
            transcript.Add(loadOlderButton);
        }

        private void LoadOlderTranscriptChunk()
        {
            if (messages.Count == 0 || firstRenderedMessageIndex <= 0)
            {
                return;
            }

            int anchorIndex = firstRenderedMessageIndex;
            firstRenderedMessageIndex = Mathf.Max(0, firstRenderedMessageIndex - OlderTranscriptChunkSize);
            RenderTranscriptWindow(scrollToBottom: false, anchorMessageIndex: anchorIndex);
        }

        private void CopyMessageToClipboard(string text)
        {
            EditorGUIUtility.systemCopyBuffer = text;
        }

        private void CopyTranscriptToClipboard()
        {
            StringBuilder builder = new StringBuilder();
            foreach (AgenticChatStore.Message message in messages)
            {
                builder.AppendLine($"{message.author}:");
                builder.AppendLine(message.text);
                builder.AppendLine();
            }

            EditorGUIUtility.systemCopyBuffer = builder.ToString().TrimEnd();
        }

        private void ClearTranscript()
        {
            messages.Clear();
            AgenticChatStore.Clear();
            transcript?.Clear();
            firstRenderedMessageIndex = 0;
            UpdateJumpToLatestVisibility();
        }

        private sealed class RenderedMessage
        {
            public readonly AgenticChatStore.Message Message;
            public readonly VisualElement Body;
            public readonly VisualElement Bubble;
            public readonly VisualElement Header;
            public readonly bool AlignRight;

            public RenderedMessage(
                AgenticChatStore.Message message,
                VisualElement body,
                VisualElement bubble,
                VisualElement header,
                bool alignRight)
            {
                Message = message;
                Body = body;
                Bubble = bubble;
                Header = header;
                AlignRight = alignRight;
            }
        }

        private sealed class QueuedPrompt
        {
            public readonly string Prompt;
            public readonly RenderedMessage RenderedMessage;

            public QueuedPrompt(string prompt, RenderedMessage renderedMessage)
            {
                Prompt = prompt ?? string.Empty;
                RenderedMessage = renderedMessage;
            }
        }

        private sealed class MentionCandidate
        {
            public readonly Object Target;
            public readonly string Label;
            public readonly string Detail;

            public MentionCandidate(Object target, string label, string detail)
            {
                Target = target;
                Label = string.IsNullOrWhiteSpace(label) ? "Object" : label;
                Detail = string.IsNullOrWhiteSpace(detail) ? Label : detail;
            }
        }

        private sealed class WorkLog
        {
            private const int MaxObservationCount = 8;
            private const int VisibleObservationCount = 6;
            private const int MaxExploredCount = 6;
            private readonly List<string> steps = new List<string>();
            private readonly List<string> observations = new List<string>();
            private readonly List<string> explored = new List<string>();
            private string currentStep;

            public void Add(string step)
            {
                string normalized = step.Trim();
                if (steps.Count == 0 || steps[steps.Count - 1] != normalized)
                {
                    steps.Add(normalized);
                }

                currentStep = string.Empty;
            }

            public void AddObservation(string note)
            {
                AddBoundedUnique(observations, note, MaxObservationCount);
            }

            public void AddExplored(string line)
            {
                AddBoundedUnique(explored, line, MaxExploredCount);
            }

            public void SetCurrent(string step)
            {
                currentStep = step.Trim();
            }

            public string ToWorkingText(int tick)
            {
                StringBuilder builder = new StringBuilder();
                builder.Append("Working");
                builder.Append(new string('.', tick % 4));
                string status = GetUserFacingCurrentStatus();
                if (!string.IsNullOrWhiteSpace(status))
                {
                    builder.AppendLine();
                    builder.AppendLine();
                    AppendSectionHeader(builder, "Status");
                    builder.AppendLine(status);
                }

                if (!ShouldShowActivity())
                {
                    AppendUserProgress(builder, status);
                    return builder.ToString().TrimEnd();
                }

                AppendObservations(builder);
                builder.AppendLine();
                AppendActivity(builder, includeCurrent: true, tick: tick);
                return builder.ToString().TrimEnd();
            }

            private void AppendUserProgress(StringBuilder builder, string currentStatus)
            {
                if (observations.Count == 0)
                {
                    return;
                }

                int firstObservation = Math.Max(0, observations.Count - VisibleObservationCount);
                bool wroteHeader = false;
                for (int i = firstObservation; i < observations.Count; i++)
                {
                    string observation = observations[i];
                    if (string.IsNullOrWhiteSpace(observation) ||
                        string.Equals(observation.Trim(), (currentStatus ?? string.Empty).Trim(), StringComparison.Ordinal))
                    {
                        continue;
                    }

                    if (!wroteHeader)
                    {
                        builder.AppendLine();
                        builder.AppendLine();
                        AppendSectionHeader(builder, "Progress");
                        wroteHeader = true;
                    }

                    builder.AppendLine("- " + observation.Trim());
                }
            }

            public string ToFinalText(string response)
            {
                string body = (response ?? string.Empty).Trim();
                if (IsCodexStyleFinalResponse(body))
                {
                    return body;
                }

                StringBuilder builder = new StringBuilder();
                if (ShouldShowActivity())
                {
                    AppendFinalActivity(builder);
                    builder.AppendLine();
                    builder.AppendLine();
                }

                AppendSectionHeader(builder, "Status");
                builder.AppendLine(GetFinalStatus(response));

                if (!string.IsNullOrWhiteSpace(body))
                {
                    builder.AppendLine();
                    builder.AppendLine();
                    if (!StartsWithKnownSection(body))
                    {
                        AppendSectionHeader(builder, "Result");
                    }

                    builder.Append(body);
                }

                return builder.ToString().TrimEnd();
            }

            private static bool IsCodexStyleFinalResponse(string response)
            {
                return !string.IsNullOrWhiteSpace(response) &&
                    response.TrimStart().StartsWith("• ", StringComparison.Ordinal);
            }

            public string ToPlanReviewText(AgenticAgentBridge.PlanReviewResult plan)
            {
                StringBuilder builder = new StringBuilder();
                if (ShouldShowActivity())
                {
                    AppendActivity(builder, includeCurrent: false, tick: 0);
                    builder.AppendLine();
                    builder.AppendLine();
                }

                AppendSectionHeader(builder, "Status");
                builder.AppendLine("Waiting for approval. No Unity actions have been applied.");

                if (!string.IsNullOrWhiteSpace(plan.Message))
                {
                    builder.AppendLine();
                    builder.AppendLine();
                    AppendSectionHeader(builder, "Summary");
                    builder.AppendLine(plan.Message.Trim());
                }

                AppendList(builder, "Plan", plan.Plan);
                AppendList(builder, "Notes", plan.Progress);

                builder.AppendLine();
                builder.AppendLine();
                AppendSectionHeader(builder, "Actions");
                if (plan.ProposedActionCount > 0)
                {
                    builder.AppendLine($"Proposed: {plan.ProposedActionCount}");
                    if (plan.ActionSummaries != null && plan.ActionSummaries.Length > 0)
                    {
                        foreach (string actionSummary in plan.ActionSummaries)
                        {
                            if (!string.IsNullOrWhiteSpace(actionSummary))
                            {
                                builder.AppendLine("- " + actionSummary.Trim());
                            }
                        }
                    }
                }
                else
                {
                    builder.AppendLine("Proposed: 0");
                    builder.AppendLine("No approval button is shown because there are no executable Unity actions to run.");
                }
                return builder.ToString().TrimEnd();
            }

            private static void AddBoundedUnique(List<string> values, string value, int maxCount)
            {
                string normalized = (value ?? string.Empty).Trim();
                if (string.IsNullOrWhiteSpace(normalized))
                {
                    return;
                }

                for (int i = values.Count - 1; i >= 0; i--)
                {
                    if (string.Equals(values[i], normalized, StringComparison.Ordinal))
                    {
                        values.RemoveAt(i);
                        break;
                    }
                }

                values.Add(normalized);
                while (values.Count > maxCount)
                {
                    values.RemoveAt(0);
                }
            }

            private void AppendObservations(StringBuilder builder)
            {
                if (!ShouldShowActivity())
                {
                    return;
                }

                int firstObservation = Math.Max(0, observations.Count - VisibleObservationCount);
                for (int i = firstObservation; i < observations.Count; i++)
                {
                    builder.AppendLine();
                    builder.AppendLine("• " + observations[i]);
                }

                if (explored.Count == 0)
                {
                    return;
                }

                builder.AppendLine();
                builder.AppendLine();
                AppendSectionHeader(builder, "Explored");
                for (int i = 0; i < explored.Count; i++)
                {
                    builder.Append(i == 0 ? "└ " : "  ");
                    builder.AppendLine(explored[i]);
                }
            }

            private static bool ShouldShowActivity()
            {
                return AgenticAgentBridge.GetDeveloperMode();
            }

            private string GetUserFacingCurrentStatus()
            {
                string latest = !string.IsNullOrWhiteSpace(currentStep)
                    ? currentStep
                    : steps.Count > 0
                        ? steps[steps.Count - 1]
                        : string.Empty;

                string observation = observations.Count > 0
                    ? observations[observations.Count - 1]
                    : string.Empty;

                if (!string.IsNullOrWhiteSpace(observation))
                {
                    return observation.Trim();
                }

                if (string.IsNullOrWhiteSpace(latest))
                {
                    return "Starting the backend agent.";
                }

                if (latest.IndexOf("Backend scripting agent", StringComparison.OrdinalIgnoreCase) >= 0)
                {
                    return latest.IndexOf("Waiting", StringComparison.OrdinalIgnoreCase) >= 0
                        ? "Waiting for the backend scripting agent to finish."
                        : "The backend scripting agent is running.";
                }

                if (latest.IndexOf("Queued request", StringComparison.OrdinalIgnoreCase) >= 0)
                {
                    return "Request queued.";
                }

                if (latest.IndexOf("Reading request", StringComparison.OrdinalIgnoreCase) >= 0)
                {
                    return "Reading the request and current Unity state.";
                }

                if (latest.IndexOf("Prepared", StringComparison.OrdinalIgnoreCase) >= 0 &&
                    latest.IndexOf("request", StringComparison.OrdinalIgnoreCase) >= 0)
                {
                    return "Prepared the backend request.";
                }

                if (latest.IndexOf("Waiting", StringComparison.OrdinalIgnoreCase) >= 0)
                {
                    return latest.Trim().TrimEnd('.') + ".";
                }

                if (latest.IndexOf("Received response", StringComparison.OrdinalIgnoreCase) >= 0)
                {
                    return "Received a backend response and preparing the result.";
                }

                if (latest.IndexOf("Parsing action response", StringComparison.OrdinalIgnoreCase) >= 0 ||
                    latest.IndexOf("Applying Unity actions", StringComparison.OrdinalIgnoreCase) >= 0)
                {
                    return "Processing the backend result.";
                }

                return latest.Trim().TrimEnd('.') + ".";
            }

            private void AppendFinalActivity(StringBuilder builder)
            {
                AppendSectionHeader(builder, "Activity");
                int toolCount = 0;
                List<string> filtered = new List<string>();
                foreach (string step in steps)
                {
                    if (string.IsNullOrWhiteSpace(step))
                    {
                        continue;
                    }

                    if (step.StartsWith("Tool: ", StringComparison.Ordinal))
                    {
                        toolCount++;
                        continue;
                    }

                    if (IsToolLoopDetailStep(step))
                    {
                        continue;
                    }

                    filtered.Add(step);
                }

                bool wroteToolSummary = false;
                foreach (string step in filtered)
                {
                    builder.AppendLine($"- {step}");
                    if (!wroteToolSummary &&
                        toolCount > 0 &&
                        string.Equals(step, "Starting OpenAI tool loop", StringComparison.Ordinal))
                    {
                        builder.AppendLine($"- Ran {toolCount} agent tool call(s)");
                        wroteToolSummary = true;
                    }
                }

                if (!wroteToolSummary && toolCount > 0)
                {
                    builder.AppendLine($"- Ran {toolCount} agent tool call(s)");
                }
            }

            private static bool IsToolLoopDetailStep(string step)
            {
                return IsAgentToolRequestStep(step) ||
                    string.Equals(step, "Received response", StringComparison.Ordinal) ||
                    string.Equals(step, "Received tool response", StringComparison.Ordinal) ||
                    string.Equals(step, "Inspecting updated Unity state", StringComparison.Ordinal) ||
                    step.StartsWith("Completed tool:", StringComparison.Ordinal);
            }

            private void AppendActivity(StringBuilder builder, bool includeCurrent, int tick)
            {
                AppendSectionHeader(builder, "Activity");
                foreach (string step in steps)
                {
                    if (IsToolLoopDetailStep(step))
                    {
                        continue;
                    }

                    builder.AppendLine($"- {step}");
                }

                if (includeCurrent && !string.IsNullOrWhiteSpace(currentStep))
                {
                    builder.Append("- ");
                    builder.Append(currentStep);
                    builder.Append(new string('.', tick % 4));
                    builder.AppendLine();
                }
            }

            private static string GetFinalStatus(string response)
            {
                if (string.IsNullOrWhiteSpace(response))
                {
                    return "Finished.";
                }

                if (HasIncompleteOutcome(response))
                {
                    return response.IndexOf("Applied actions: 0", StringComparison.OrdinalIgnoreCase) < 0
                        ? "Incomplete. Unity actions were applied, but validation or issues remain."
                        : "Incomplete. Validation or issues remain.";
                }

                if (response.IndexOf("Applied actions:", StringComparison.OrdinalIgnoreCase) >= 0)
                {
                    return response.IndexOf("Applied actions: 0", StringComparison.OrdinalIgnoreCase) < 0
                        ? "Finished. Unity actions were applied."
                        : "Finished. No Unity actions were applied.";
                }

                if (response.IndexOf("failed", StringComparison.OrdinalIgnoreCase) >= 0 ||
                    response.IndexOf("error", StringComparison.OrdinalIgnoreCase) >= 0 ||
                    response.IndexOf("invalid", StringComparison.OrdinalIgnoreCase) >= 0)
                {
                    return "Finished.";
                }

                return "Answered.";
            }

            private static bool HasIncompleteOutcome(string response)
            {
                if (string.IsNullOrWhiteSpace(response))
                {
                    return false;
                }

                return response.IndexOf("\nIssues\n", StringComparison.OrdinalIgnoreCase) >= 0 ||
                    response.IndexOf("\nIssues:\n", StringComparison.OrdinalIgnoreCase) >= 0 ||
                    response.IndexOf("scene validation found", StringComparison.OrdinalIgnoreCase) >= 0 ||
                    response.IndexOf("validation still reports", StringComparison.OrdinalIgnoreCase) >= 0 ||
                    response.IndexOf("not fully finished", StringComparison.OrdinalIgnoreCase) >= 0 ||
                    response.IndexOf("target not found", StringComparison.OrdinalIgnoreCase) >= 0 ||
                    response.IndexOf("Tool failed:", StringComparison.OrdinalIgnoreCase) >= 0 ||
                    response.IndexOf("Tool blocked:", StringComparison.OrdinalIgnoreCase) >= 0;
            }

            private static void AppendList(StringBuilder builder, string title, string[] values)
            {
                if (values == null || values.Length == 0)
                {
                    return;
                }

                bool wroteHeader = false;
                foreach (string value in values)
                {
                    if (string.IsNullOrWhiteSpace(value))
                    {
                        continue;
                    }

                    if (!wroteHeader)
                    {
                        builder.AppendLine();
                        builder.AppendLine();
                        AppendSectionHeader(builder, title);
                        wroteHeader = true;
                    }

                    builder.AppendLine($"- {value.Trim()}");
                }
            }

            private static void AppendSectionHeader(StringBuilder builder, string title)
            {
                builder.AppendLine(title);
            }

        private static bool StartsWithKnownSection(string text)
        {
            string trimmed = (text ?? string.Empty).TrimStart();
            return trimmed.StartsWith("Summary\n", StringComparison.Ordinal) ||
                    trimmed.StartsWith("What changed\n", StringComparison.Ordinal) ||
                    trimmed.StartsWith("What changed:\n", StringComparison.Ordinal) ||
                    trimmed.StartsWith("Explored\n", StringComparison.Ordinal) ||
                    trimmed.StartsWith("Explored:\n", StringComparison.Ordinal) ||
                    trimmed.StartsWith("Context checked\n", StringComparison.Ordinal) ||
                    trimmed.StartsWith("Context checked:\n", StringComparison.Ordinal) ||
                    trimmed.StartsWith("Code snippets\n", StringComparison.Ordinal) ||
                    trimmed.StartsWith("Code snippets:\n", StringComparison.Ordinal) ||
                    trimmed.StartsWith("Validation\n", StringComparison.Ordinal) ||
                    trimmed.StartsWith("Validation:\n", StringComparison.Ordinal) ||
                    trimmed.StartsWith("Issues\n", StringComparison.Ordinal) ||
                    trimmed.StartsWith("Issues:\n", StringComparison.Ordinal) ||
                    trimmed.StartsWith("Actions\n", StringComparison.Ordinal) ||
                    trimmed.StartsWith("Agent handoffs\n", StringComparison.Ordinal) ||
                    trimmed.StartsWith("Agent handoffs:\n", StringComparison.Ordinal) ||
                    trimmed.StartsWith("Tool calls\n", StringComparison.Ordinal) ||
                    trimmed.StartsWith("Tool calls:\n", StringComparison.Ordinal) ||
                    trimmed.StartsWith("Executed tool calls\n", StringComparison.Ordinal) ||
                    trimmed.StartsWith("Executed tool calls:\n", StringComparison.Ordinal) ||
                    trimmed.StartsWith("Plan\n", StringComparison.Ordinal) ||
                    trimmed.StartsWith("Notes\n", StringComparison.Ordinal);
        }

        }

        private sealed class DeferredEditorAction
        {
            public double ExecuteAtTime;
            public Action Action;
        }
    }
}
