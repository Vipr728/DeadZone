using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Text;
using System.Text.RegularExpressions;
using UnityEditor;
using UnityEngine;
using UnityEngine.SceneManagement;
using Object = UnityEngine.Object;

namespace AgenticGamedev.EditorTools
{
    internal static class AgenticProjectContextIndexStore
    {
        private const int CurrentVersion = 1;
        private const int MaxChunks = 12000;
        private const int MaxContextChunks = 16;
        private const int MaxContextEdges = 24;
        private const int MaxChunkText = 2600;
        private const int MaxReadableFile = 180000;
        private const int MaxVectorTerms = 48;

        private static readonly Regex TokenRegex = new Regex(@"[a-z0-9][a-z0-9_-]{2,}", RegexOptions.IgnoreCase | RegexOptions.Compiled);
        private static readonly Regex ClassRegex = new Regex(@"\b(?:class|struct|interface|enum)\s+([A-Za-z_][A-Za-z0-9_]*)", RegexOptions.Compiled);
        private static readonly Regex MethodRegex = new Regex(@"\b(?:public|private|internal|protected|static|virtual|override|sealed|async|\s)+[A-Za-z_][A-Za-z0-9_<>,\[\].?]*\s+([A-Za-z_][A-Za-z0-9_]*)\s*\([^;{}]*\)\s*(?:where\s+[^{]+)?\{", RegexOptions.Compiled);
        private static readonly Regex SerializedFieldRegex = new Regex(@"\[(?:SerializeField|field:\s*SerializeField)\]\s*(?:private|protected|public|internal)?\s*[A-Za-z_][A-Za-z0-9_<>,\[\].?]*\s+([A-Za-z_][A-Za-z0-9_]*)", RegexOptions.Compiled);
        private static readonly Regex GuidRegex = new Regex(@"guid:\s*([0-9a-fA-F]{32})", RegexOptions.Compiled);
        private static readonly Regex SensitiveRegex = new Regex(@"\b(?:api[_ -]?key|access[_ -]?token|refresh[_ -]?token|password|passwd|secret|bearer\s+[a-z0-9._-]+|sk-[a-z0-9_-]{12,}|gh[pousr]_[a-z0-9_]{12,})\b", RegexOptions.IgnoreCase | RegexOptions.Compiled);

        private static readonly HashSet<string> StopWords = new HashSet<string>(StringComparer.OrdinalIgnoreCase)
        {
            "the", "and", "for", "with", "that", "this", "from", "into", "what", "when", "where", "which",
            "while", "would", "could", "should", "there", "their", "about", "your", "have", "has", "had",
            "are", "was", "were", "will", "can", "not", "but", "all", "any", "you", "our", "out", "use",
            "using", "used", "then", "than", "them", "they", "just", "like", "also", "true", "false",
            "public", "private", "internal", "protected", "class", "void", "float", "string", "int", "bool"
        };

        [MenuItem("Tools/Ark/Project RAG/Copy Retrieved Context")]
        private static void CopyContextMenu()
        {
            EditorGUIUtility.systemCopyBuffer = BuildContextSection(string.Empty);
            Debug.Log("Copied Ark project RAG context.");
        }

        [MenuItem("Tools/Ark/Project RAG/Rebuild Index")]
        private static void RebuildMenu()
        {
            ProjectContextIndex index = BuildIndex();
            Save(index);
            Debug.Log($"Rebuilt Ark project RAG index: {SafeLength(index.chunks)} chunks.");
        }

        public static string BuildContextSection(string currentPrompt)
        {
            ProjectContextIndex index = BuildIndex();
            Save(index);
            RetrievedContext retrieved = Retrieve(index, currentPrompt);
            return FormatContext(index, retrieved);
        }

        private static ProjectContextIndex BuildIndex()
        {
            IndexBuilder builder = new IndexBuilder();
            Scene activeScene = SceneManager.GetActiveScene();
            builder.Index.version = CurrentVersion;
            builder.Index.projectName = Application.productName;
            builder.Index.unityVersion = Application.unityVersion;
            builder.Index.projectRoot = GetProjectRoot();
            builder.Index.activeScene = activeScene.name;
            builder.Index.activeScenePath = activeScene.path;
            builder.Index.updatedAtUtcTicks = DateTime.UtcNow.Ticks;

            AddProjectDocs(builder);

            string[] assetPaths = AssetDatabase.GetAllAssetPaths();
            Array.Sort(assetPaths, StringComparer.Ordinal);
            AddSourceChunks(builder, assetPaths);
            AddAssetChunks(builder, assetPaths);
            AddLoadedSceneChunks(builder);
            AddRunLedgerChunks(builder);

            builder.FinalizeIndex();
            return builder.Index;
        }

        private static void AddProjectDocs(IndexBuilder builder)
        {
            string projectRoot = GetProjectRoot();
            string[] roots =
            {
                Path.Combine(projectRoot, "Assets", "Agent"),
                Path.Combine(projectRoot, "Agent")
            };

            foreach (string root in roots)
            {
                if (!Directory.Exists(root))
                {
                    continue;
                }

                string[] files = Directory.GetFiles(root, "*.md", SearchOption.AllDirectories);
                Array.Sort(files, StringComparer.Ordinal);
                foreach (string file in files)
                {
                    string relativePath = ToProjectRelativePath(file);
                    string text = CleanText(ReadFilePrefix(file, MaxReadableFile), MaxChunkText);
                    if (string.IsNullOrWhiteSpace(text))
                    {
                        continue;
                    }

                    builder.AddChunk("project_doc", relativePath, Path.GetFileName(file), relativePath, string.Empty, string.Empty, text, "human-readable project memory or roadmap");
                }
            }
        }

        private static void AddSourceChunks(IndexBuilder builder, string[] assetPaths)
        {
            foreach (string assetPath in assetPaths)
            {
                if (!assetPath.EndsWith(".cs", StringComparison.OrdinalIgnoreCase) || !IsIndexableAssetPath(assetPath))
                {
                    continue;
                }

                string source = ReadAssetText(assetPath, MaxReadableFile);
                if (string.IsNullOrWhiteSpace(source))
                {
                    continue;
                }

                source = Redact(source);
                string guid = AssetDatabase.AssetPathToGUID(assetPath);
                string symbols = JoinLimited(ExtractSymbols(source), 24);
                string summary = BuildSourceSummary(assetPath, source, symbols);
                builder.AddChunk("source_file", assetPath, Path.GetFileName(assetPath), assetPath, guid, string.Empty, summary, symbols);

                foreach (Match match in ClassRegex.Matches(source))
                {
                    string className = match.Groups[1].Value;
                    string classText = ExtractWindow(source, match.Index, 3000);
                    string classSummary = BuildClassSummary(assetPath, className, classText);
                    builder.AddChunk("source_symbol", $"{assetPath}#{className}", className, assetPath, guid, string.Empty, classSummary, symbols);
                }
            }
        }

        private static string[] ExtractSymbols(string source)
        {
            List<string> symbols = new List<string>();
            foreach (Match match in ClassRegex.Matches(source))
            {
                AddUnique(symbols, match.Groups[1].Value, 64);
            }

            foreach (Match match in MethodRegex.Matches(source))
            {
                AddUnique(symbols, match.Groups[1].Value, 64);
            }

            foreach (Match match in SerializedFieldRegex.Matches(source))
            {
                AddUnique(symbols, match.Groups[1].Value, 64);
            }

            return symbols.ToArray();
        }

        private static string BuildSourceSummary(string assetPath, string source, string symbols)
        {
            StringBuilder builder = new StringBuilder();
            builder.AppendLine($"Script: {assetPath}");
            if (!string.IsNullOrWhiteSpace(symbols))
            {
                builder.AppendLine($"Symbols: {symbols}");
            }

            string references = BuildGuidReferenceSummary(assetPath, source, 8);
            if (!string.IsNullOrWhiteSpace(references))
            {
                builder.AppendLine($"Asset refs: {references}");
            }

            builder.AppendLine("Excerpt:");
            builder.AppendLine(CleanText(source, 1400));
            return builder.ToString().TrimEnd();
        }

        private static string BuildClassSummary(string assetPath, string className, string classText)
        {
            StringBuilder builder = new StringBuilder();
            builder.AppendLine($"Source symbol: {className}");
            builder.AppendLine($"Script: {assetPath}");
            builder.AppendLine("Local excerpt:");
            builder.AppendLine(CleanText(classText, 1600));
            return builder.ToString().TrimEnd();
        }

        private static void AddAssetChunks(IndexBuilder builder, string[] assetPaths)
        {
            foreach (string assetPath in assetPaths)
            {
                if (!IsIndexableAssetPath(assetPath))
                {
                    continue;
                }

                string extension = Path.GetExtension(assetPath).ToLowerInvariant();
                if (extension == ".cs" || extension == ".unity")
                {
                    continue;
                }

                string guid = AssetDatabase.AssetPathToGUID(assetPath);
                if (extension == ".prefab")
                {
                    AddPrefabChunk(builder, assetPath, guid);
                }
                else if (extension == ".mat")
                {
                    Material material = AssetDatabase.LoadAssetAtPath<Material>(assetPath);
                    if (material != null)
                    {
                        string shaderName = material.shader == null ? "none" : material.shader.name;
                        builder.AddChunk("material", assetPath, material.name, assetPath, guid, string.Empty, $"Material: {assetPath}\nShader: {shaderName}", shaderName);
                    }
                }
                else if (extension == ".inputactions")
                {
                    string text = CleanText(ReadAssetText(assetPath, 40000), MaxChunkText);
                    builder.AddChunk("input_actions", assetPath, Path.GetFileNameWithoutExtension(assetPath), assetPath, guid, string.Empty, $"Input actions: {assetPath}\n{text}", string.Empty);
                }
                else if (extension == ".asset")
                {
                    Object asset = AssetDatabase.LoadMainAssetAtPath(assetPath);
                    if (asset is ScriptableObject)
                    {
                        builder.AddChunk("scriptable_object", assetPath, asset.name, assetPath, guid, string.Empty, BuildObjectSummary("ScriptableObject", asset, assetPath), asset.GetType().FullName);
                    }
                }
                else if (extension == ".controller" || extension == ".anim" || extension == ".shader" || extension == ".shadergraph")
                {
                    Object asset = AssetDatabase.LoadMainAssetAtPath(assetPath);
                    string type = asset == null ? extension.TrimStart('.') : asset.GetType().Name;
                    builder.AddChunk("asset", assetPath, Path.GetFileNameWithoutExtension(assetPath), assetPath, guid, string.Empty, $"Asset: {assetPath}\nType: {type}", type);
                }
            }
        }

        private static void AddPrefabChunk(IndexBuilder builder, string assetPath, string guid)
        {
            GameObject prefab = AssetDatabase.LoadAssetAtPath<GameObject>(assetPath);
            if (prefab == null)
            {
                return;
            }

            StringBuilder summary = new StringBuilder();
            summary.AppendLine($"Prefab: {assetPath}");
            summary.AppendLine($"Root: {prefab.name}");
            AppendGameObjectTree(summary, prefab, 0, 3);
            builder.AddChunk("prefab", assetPath, prefab.name, assetPath, guid, string.Empty, summary.ToString().TrimEnd(), "prefab GameObject components serialized references");
        }

        private static void AddLoadedSceneChunks(IndexBuilder builder)
        {
            for (int i = 0; i < SceneManager.sceneCount; i++)
            {
                Scene scene = SceneManager.GetSceneAt(i);
                if (!scene.isLoaded)
                {
                    continue;
                }

                string sceneGuid = string.IsNullOrWhiteSpace(scene.path) ? string.Empty : AssetDatabase.AssetPathToGUID(scene.path);
                StringBuilder sceneSummary = new StringBuilder();
                sceneSummary.AppendLine($"Scene: {scene.name}");
                sceneSummary.AppendLine($"Path: {scene.path}");
                sceneSummary.AppendLine($"Dirty: {scene.isDirty}");
                GameObject[] roots = scene.GetRootGameObjects();
                int rootCount = Mathf.Min(roots.Length, 40);
                for (int rootIndex = 0; rootIndex < rootCount; rootIndex++)
                {
                    sceneSummary.AppendLine($"Root: {roots[rootIndex].name}");
                }

                builder.AddChunk("scene", string.IsNullOrWhiteSpace(scene.path) ? $"scene:{scene.name}" : scene.path, scene.name, scene.path, sceneGuid, string.Empty, sceneSummary.ToString().TrimEnd(), "loaded scene roots");

                foreach (GameObject root in roots)
                {
                    AddSceneObjectChunks(builder, scene, root, 0);
                }
            }
        }

        private static void AddSceneObjectChunks(IndexBuilder builder, Scene scene, GameObject gameObject, int depth)
        {
            if (gameObject == null || depth > 5)
            {
                return;
            }

            string hierarchyPath = GetHierarchyPath(gameObject);
            string scenePath = scene.path;
            string id = $"{scenePath}#{hierarchyPath}";
            StringBuilder summary = new StringBuilder();
            summary.AppendLine($"Scene object: {hierarchyPath}");
            summary.AppendLine($"Scene: {scene.name} path={scenePath}");
            summary.AppendLine($"Active: self={gameObject.activeSelf} hierarchy={gameObject.activeInHierarchy}");
            summary.AppendLine($"Transform: position={FormatVector(gameObject.transform.position)} scale={FormatVector(gameObject.transform.localScale)}");
            summary.AppendLine("Components:");
            foreach (Component component in gameObject.GetComponents<Component>())
            {
                if (component == null)
                {
                    continue;
                }

                summary.AppendLine($"- {component.GetType().FullName}");
                string refs = BuildSerializedReferenceSummary(component, 6);
                if (!string.IsNullOrWhiteSpace(refs))
                {
                    summary.AppendLine($"  refs: {refs}");
                }
            }

            builder.AddChunk("scene_object", id, gameObject.name, scenePath, string.Empty, hierarchyPath, summary.ToString().TrimEnd(), hierarchyPath);

            for (int i = 0; i < gameObject.transform.childCount; i++)
            {
                AddSceneObjectChunks(builder, scene, gameObject.transform.GetChild(i).gameObject, depth + 1);
            }
        }

        private static void AddRunLedgerChunks(IndexBuilder builder)
        {
            string runDir = Path.Combine(GetProjectRoot(), "Library", "AgenticGamedev", "AgentDaemonRuns");
            if (!Directory.Exists(runDir))
            {
                return;
            }

            string[] files = Directory.GetFiles(runDir, "*.json", SearchOption.TopDirectoryOnly);
            Array.Sort(files, (left, right) => File.GetLastWriteTimeUtc(right).CompareTo(File.GetLastWriteTimeUtc(left)));
            int count = Mathf.Min(files.Length, 12);
            for (int i = 0; i < count; i++)
            {
                string file = files[i];
                string text = CleanText(ReadFilePrefix(file, 24000), MaxChunkText);
                if (!string.IsNullOrWhiteSpace(text))
                {
                    builder.AddChunk("run_evidence", ToProjectRelativePath(file), Path.GetFileNameWithoutExtension(file), ToProjectRelativePath(file), string.Empty, string.Empty, text, "agent run evidence validation blockers");
                }
            }
        }

        private static void AppendGameObjectTree(StringBuilder builder, GameObject gameObject, int depth, int maxDepth)
        {
            if (gameObject == null || depth > maxDepth)
            {
                return;
            }

            string indent = new string(' ', depth * 2);
            builder.Append(indent);
            builder.Append("- ");
            builder.Append(gameObject.name);
            builder.Append(" components=");
            List<string> components = new List<string>();
            foreach (Component component in gameObject.GetComponents<Component>())
            {
                if (component != null)
                {
                    components.Add(component.GetType().Name);
                }
            }

            builder.AppendLine(string.Join(",", components.ToArray()));
            for (int i = 0; i < gameObject.transform.childCount; i++)
            {
                AppendGameObjectTree(builder, gameObject.transform.GetChild(i).gameObject, depth + 1, maxDepth);
            }
        }

        private static string BuildObjectSummary(string label, Object unityObject, string assetPath)
        {
            StringBuilder builder = new StringBuilder();
            builder.AppendLine($"{label}: {assetPath}");
            builder.AppendLine($"Name: {unityObject.name}");
            builder.AppendLine($"Type: {unityObject.GetType().FullName}");
            string refs = BuildSerializedReferenceSummary(unityObject, 16);
            if (!string.IsNullOrWhiteSpace(refs))
            {
                builder.AppendLine($"References: {refs}");
            }

            return builder.ToString().TrimEnd();
        }

        private static string BuildSerializedReferenceSummary(Object unityObject, int limit)
        {
            try
            {
                SerializedObject serializedObject = new SerializedObject(unityObject);
                SerializedProperty iterator = serializedObject.GetIterator();
                List<string> refs = new List<string>();
                bool enterChildren = true;
                while (iterator.NextVisible(enterChildren))
                {
                    enterChildren = false;
                    if (iterator.propertyType != SerializedPropertyType.ObjectReference)
                    {
                        continue;
                    }

                    Object reference = iterator.objectReferenceValue;
                    if (reference == null)
                    {
                        continue;
                    }

                    string path = AssetDatabase.GetAssetPath(reference);
                    AddUnique(refs, $"{iterator.propertyPath}->{reference.name}{(string.IsNullOrWhiteSpace(path) ? string.Empty : $" {path}")}", limit);
                    if (refs.Count >= limit)
                    {
                        break;
                    }
                }

                return string.Join("; ", refs.ToArray());
            }
            catch
            {
                return string.Empty;
            }
        }

        private static string BuildGuidReferenceSummary(string sourcePath, string text, int limit)
        {
            List<string> refs = new List<string>();
            foreach (Match match in GuidRegex.Matches(text ?? string.Empty))
            {
                string path = AssetDatabase.GUIDToAssetPath(match.Groups[1].Value);
                if (!string.IsNullOrWhiteSpace(path) && !string.Equals(path, sourcePath, StringComparison.Ordinal))
                {
                    AddUnique(refs, path, limit);
                    if (refs.Count >= limit)
                    {
                        break;
                    }
                }
            }

            return string.Join(", ", refs.ToArray());
        }

        private static RetrievedContext Retrieve(ProjectContextIndex index, string currentPrompt)
        {
            string query = string.Join(" ", new[]
            {
                currentPrompt ?? string.Empty,
                index.activeScene ?? string.Empty,
                index.activeScenePath ?? string.Empty,
                index.projectName ?? string.Empty
            });

            Dictionary<string, float> queryVector = BuildVector(query);
            List<ScoredChunk> scored = new List<ScoredChunk>();
            foreach (ProjectContextChunk chunk in index.chunks ?? new ProjectContextChunk[0])
            {
                if (chunk == null)
                {
                    continue;
                }

                float score = ScoreChunk(chunk, queryVector, currentPrompt);
                if (score > 0)
                {
                    scored.Add(new ScoredChunk(chunk, score));
                }
            }

            scored.Sort((left, right) =>
            {
                int scoreCompare = right.score.CompareTo(left.score);
                return scoreCompare != 0 ? scoreCompare : string.Compare(left.chunk.id, right.chunk.id, StringComparison.Ordinal);
            });

            RetrievedContext retrieved = new RetrievedContext();
            int max = Mathf.Min(scored.Count, MaxContextChunks);
            for (int i = 0; i < max; i++)
            {
                ProjectContextChunk chunk = scored[i].chunk;
                chunk.lastScore = scored[i].score;
                retrieved.chunks.Add(chunk);
            }

            HashSet<string> included = new HashSet<string>(StringComparer.Ordinal);
            foreach (ProjectContextChunk chunk in retrieved.chunks)
            {
                included.Add(chunk.id);
            }

            foreach (ProjectContextEdge edge in index.edges ?? new ProjectContextEdge[0])
            {
                if (edge == null)
                {
                    continue;
                }

                if (included.Contains(edge.from) || included.Contains(edge.to))
                {
                    retrieved.edges.Add(edge);
                    if (retrieved.edges.Count >= MaxContextEdges)
                    {
                        break;
                    }
                }
            }

            return retrieved;
        }

        private static float ScoreChunk(ProjectContextChunk chunk, Dictionary<string, float> queryVector, string prompt)
        {
            float score = DotProduct(queryVector, ParseVector(chunk.vector));
            if (score <= 0 && !ContainsPromptPhrase(chunk, prompt))
            {
                return 0;
            }

            if (ContainsPromptPhrase(chunk, prompt))
            {
                score += 3f;
            }

            if (string.Equals(chunk.type, "project_doc", StringComparison.OrdinalIgnoreCase) ||
                string.Equals(chunk.type, "scene_object", StringComparison.OrdinalIgnoreCase) ||
                string.Equals(chunk.type, "source_file", StringComparison.OrdinalIgnoreCase))
            {
                score += 0.35f;
            }

            if (!string.IsNullOrWhiteSpace(chunk.scenePath) &&
                string.Equals(chunk.scenePath, SceneManager.GetActiveScene().path, StringComparison.Ordinal))
            {
                score += 0.5f;
            }

            return score;
        }

        private static bool ContainsPromptPhrase(ProjectContextChunk chunk, string prompt)
        {
            List<string> tokens = Tokenize(prompt, 8);
            if (tokens.Count == 0)
            {
                return false;
            }

            string haystack = $"{chunk.title} {chunk.path} {chunk.hierarchyPath} {chunk.summary}".ToLowerInvariant();
            foreach (string token in tokens)
            {
                if (haystack.IndexOf(token, StringComparison.OrdinalIgnoreCase) >= 0)
                {
                    return true;
                }
            }

            return false;
        }

        private static string FormatContext(ProjectContextIndex index, RetrievedContext retrieved)
        {
            StringBuilder builder = new StringBuilder();
            builder.AppendLine("Project RAG context index:");
            builder.AppendLine($"- store: {RelativeStorePath()}");
            builder.AppendLine($"- generated: {FormatTicks(index.updatedAtUtcTicks)}");
            builder.AppendLine($"- chunks: {SafeLength(index.chunks)}, edges: {SafeLength(index.edges)}");
            builder.AppendLine("- contract: this is retrieval context assembled from project docs, source, assets, prefabs, loaded scenes, and run evidence; use it to choose what to inspect next, but current Unity/file state and compiler/runtime validation remain authoritative.");
            AppendTypeCounts(builder, index.chunkTypeCounts);

            builder.AppendLine("- retrieved chunks:");
            if (retrieved.chunks.Count == 0)
            {
                builder.AppendLine("  - none");
            }
            else
            {
                foreach (ProjectContextChunk chunk in retrieved.chunks)
                {
                    builder.AppendLine($"  - [{chunk.type}] {chunk.title} score={chunk.lastScore.ToString("0.###", CultureInfo.InvariantCulture)}{Optional(" path", chunk.path)}{Optional(" object", chunk.hierarchyPath)}");
                    builder.AppendLine($"    {OneLine(chunk.summary, 360)}");
                }
            }

            if (retrieved.edges.Count > 0)
            {
                builder.AppendLine("- nearby chunk edges:");
                foreach (ProjectContextEdge edge in retrieved.edges)
                {
                    builder.AppendLine($"  - {edge.from} -[{edge.type}]-> {edge.to}{Optional(" evidence", edge.evidence)}");
                }
            }

            return builder.ToString().TrimEnd();
        }

        private static void AppendTypeCounts(StringBuilder builder, ContextTypeCount[] counts)
        {
            if (counts == null || counts.Length == 0)
            {
                return;
            }

            builder.Append("- chunk types: ");
            int max = Mathf.Min(counts.Length, 12);
            for (int i = 0; i < max; i++)
            {
                if (i > 0)
                {
                    builder.Append(", ");
                }

                builder.Append(counts[i].type);
                builder.Append('=');
                builder.Append(counts[i].count);
            }

            if (counts.Length > max)
            {
                builder.Append($", +{counts.Length - max} more");
            }

            builder.AppendLine();
        }

        private static Dictionary<string, float> BuildVector(string text)
        {
            Dictionary<string, int> counts = new Dictionary<string, int>(StringComparer.OrdinalIgnoreCase);
            foreach (string token in Tokenize(text, 4000))
            {
                counts[token] = counts.TryGetValue(token, out int count) ? count + 1 : 1;
            }

            List<KeyValuePair<string, int>> pairs = new List<KeyValuePair<string, int>>(counts);
            pairs.Sort((left, right) =>
            {
                int compare = right.Value.CompareTo(left.Value);
                return compare != 0 ? compare : string.Compare(left.Key, right.Key, StringComparison.Ordinal);
            });

            Dictionary<string, float> vector = new Dictionary<string, float>(StringComparer.OrdinalIgnoreCase);
            int max = Mathf.Min(pairs.Count, MaxVectorTerms);
            for (int i = 0; i < max; i++)
            {
                vector[pairs[i].Key] = 1f + Mathf.Log(1 + pairs[i].Value);
            }

            return vector;
        }

        private static string SerializeVector(Dictionary<string, float> vector)
        {
            List<string> values = new List<string>();
            foreach (KeyValuePair<string, float> pair in vector)
            {
                values.Add($"{pair.Key}:{pair.Value.ToString("0.###", CultureInfo.InvariantCulture)}");
            }

            values.Sort(StringComparer.Ordinal);
            return string.Join(" ", values.ToArray());
        }

        private static Dictionary<string, float> ParseVector(string value)
        {
            Dictionary<string, float> vector = new Dictionary<string, float>(StringComparer.OrdinalIgnoreCase);
            if (string.IsNullOrWhiteSpace(value))
            {
                return vector;
            }

            string[] parts = value.Split(' ');
            foreach (string part in parts)
            {
                int colon = part.LastIndexOf(':');
                if (colon <= 0 || colon >= part.Length - 1)
                {
                    continue;
                }

                string token = part.Substring(0, colon);
                if (float.TryParse(part.Substring(colon + 1), NumberStyles.Float, CultureInfo.InvariantCulture, out float weight))
                {
                    vector[token] = weight;
                }
            }

            return vector;
        }

        private static float DotProduct(Dictionary<string, float> left, Dictionary<string, float> right)
        {
            float score = 0;
            foreach (KeyValuePair<string, float> pair in left)
            {
                if (right.TryGetValue(pair.Key, out float weight))
                {
                    score += pair.Value * weight;
                }
            }

            return score;
        }

        private static List<string> Tokenize(string text, int limit)
        {
            MatchCollection matches = TokenRegex.Matches((text ?? string.Empty).ToLowerInvariant());
            List<string> tokens = new List<string>();
            foreach (Match match in matches)
            {
                string token = match.Value;
                if (StopWords.Contains(token))
                {
                    continue;
                }

                tokens.Add(token);
                if (tokens.Count >= limit)
                {
                    break;
                }
            }

            return tokens;
        }

        private static string ReadAssetText(string assetPath, int limit)
        {
            string fullPath = Path.Combine(GetProjectRoot(), assetPath);
            if (File.Exists(fullPath))
            {
                return ReadFilePrefix(fullPath, limit);
            }

            TextAsset textAsset = AssetDatabase.LoadAssetAtPath<TextAsset>(assetPath);
            if (textAsset == null || string.IsNullOrEmpty(textAsset.text))
            {
                return string.Empty;
            }

            return textAsset.text.Length <= limit ? textAsset.text : textAsset.text.Substring(0, limit);
        }

        private static string ReadFilePrefix(string path, int limit)
        {
            try
            {
                using (FileStream stream = File.OpenRead(path))
                using (StreamReader reader = new StreamReader(stream, Encoding.UTF8, true))
                {
                    char[] buffer = new char[Mathf.Max(1, limit)];
                    int count = reader.Read(buffer, 0, buffer.Length);
                    return new string(buffer, 0, count);
                }
            }
            catch
            {
                return string.Empty;
            }
        }

        private static string CleanText(string value, int limit)
        {
            string text = (value ?? string.Empty).Replace("\r\n", "\n").Replace('\r', '\n').Trim();
            if (SensitiveRegex.IsMatch(text))
            {
                text = SensitiveRegex.Replace(text, "[redacted]");
            }

            if (text.Length > limit)
            {
                text = text.Substring(0, limit).TrimEnd();
            }

            return text;
        }

        private static string Redact(string value)
        {
            return SensitiveRegex.IsMatch(value ?? string.Empty) ? SensitiveRegex.Replace(value, "[redacted]") : value ?? string.Empty;
        }

        private static string ExtractWindow(string value, int index, int length)
        {
            if (string.IsNullOrEmpty(value))
            {
                return string.Empty;
            }

            int start = Mathf.Max(0, index);
            int count = Mathf.Min(length, value.Length - start);
            return count <= 0 ? string.Empty : value.Substring(start, count);
        }

        private static void AddUnique(List<string> values, string value, int limit)
        {
            if (string.IsNullOrWhiteSpace(value) || values.Count >= limit)
            {
                return;
            }

            foreach (string existing in values)
            {
                if (string.Equals(existing, value, StringComparison.OrdinalIgnoreCase))
                {
                    return;
                }
            }

            values.Add(value.Trim());
        }

        private static string JoinLimited(string[] values, int limit)
        {
            if (values == null || values.Length == 0)
            {
                return string.Empty;
            }

            int count = Mathf.Min(values.Length, limit);
            string[] copy = new string[count];
            Array.Copy(values, copy, count);
            return string.Join(", ", copy);
        }

        private static string GetHierarchyPath(GameObject gameObject)
        {
            Stack<string> parts = new Stack<string>();
            Transform current = gameObject == null ? null : gameObject.transform;
            while (current != null)
            {
                parts.Push(current.name);
                current = current.parent;
            }

            return string.Join("/", parts.ToArray());
        }

        private static string FormatVector(Vector3 value)
        {
            return $"({value.x.ToString("0.###", CultureInfo.InvariantCulture)},{value.y.ToString("0.###", CultureInfo.InvariantCulture)},{value.z.ToString("0.###", CultureInfo.InvariantCulture)})";
        }

        private static bool IsIndexableAssetPath(string path)
        {
            return !string.IsNullOrWhiteSpace(path) &&
                (path.StartsWith("Assets/", StringComparison.Ordinal) || path.StartsWith("Packages/", StringComparison.Ordinal));
        }

        private static string GetProjectRoot()
        {
            return Path.GetDirectoryName(Application.dataPath) ?? Directory.GetCurrentDirectory();
        }

        private static string ToProjectRelativePath(string fullPath)
        {
            string projectRoot = GetProjectRoot().Replace('\\', '/').TrimEnd('/');
            string normalized = (fullPath ?? string.Empty).Replace('\\', '/');
            return normalized.StartsWith(projectRoot + "/", StringComparison.Ordinal)
                ? normalized.Substring(projectRoot.Length + 1)
                : normalized;
        }

        private static string GetStorePath()
        {
            return Path.Combine(GetProjectRoot(), "Library", "AgenticGamedev", "context", "project-context-index.json");
        }

        private static string RelativeStorePath()
        {
            return "Library/AgenticGamedev/context/project-context-index.json";
        }

        private static void Save(ProjectContextIndex index)
        {
            try
            {
                string path = GetStorePath();
                Directory.CreateDirectory(Path.GetDirectoryName(path) ?? string.Empty);
                File.WriteAllText(path, JsonUtility.ToJson(index, true), Encoding.UTF8);
            }
            catch (Exception exception)
            {
                Debug.LogWarning($"Could not save Ark project RAG index: {exception.Message}");
            }
        }

        private static string OneLine(string value, int limit)
        {
            string text = Regex.Replace(value ?? string.Empty, @"\s+", " ").Trim();
            return text.Length <= limit ? text : text.Substring(0, limit).TrimEnd();
        }

        private static string Optional(string label, string value)
        {
            return string.IsNullOrWhiteSpace(value) ? string.Empty : $"{label}={value}";
        }

        private static string FormatTicks(long ticks)
        {
            return ticks <= 0 ? "unknown" : new DateTime(ticks, DateTimeKind.Utc).ToString("yyyy-MM-dd HH:mm:ss 'UTC'");
        }

        private static int SafeLength(Array values)
        {
            return values == null ? 0 : values.Length;
        }

        private sealed class IndexBuilder
        {
            private readonly List<ProjectContextChunk> chunks = new List<ProjectContextChunk>();
            private readonly List<ProjectContextEdge> edges = new List<ProjectContextEdge>();
            private readonly HashSet<string> chunkIds = new HashSet<string>(StringComparer.Ordinal);
            private readonly HashSet<string> edgeKeys = new HashSet<string>(StringComparer.Ordinal);

            public ProjectContextIndex Index { get; } = new ProjectContextIndex();

            public void AddChunk(string type, string id, string title, string path, string guid, string hierarchyPath, string summary, string symbols)
            {
                if (chunks.Count >= MaxChunks || string.IsNullOrWhiteSpace(id) || string.IsNullOrWhiteSpace(summary) || !chunkIds.Add(id))
                {
                    return;
                }

                string vectorText = string.Join("\n", new[] { type, title, path, hierarchyPath, summary, symbols });
                chunks.Add(new ProjectContextChunk
                {
                    id = id,
                    type = type ?? string.Empty,
                    title = title ?? string.Empty,
                    path = path ?? string.Empty,
                    guid = guid ?? string.Empty,
                    scenePath = path != null && path.EndsWith(".unity", StringComparison.OrdinalIgnoreCase) ? path : string.Empty,
                    hierarchyPath = hierarchyPath ?? string.Empty,
                    summary = CleanText(summary, MaxChunkText),
                    symbols = symbols ?? string.Empty,
                    vector = SerializeVector(BuildVector(vectorText))
                });
            }

            public void AddEdge(string from, string to, string type, string evidence)
            {
                string key = $"{from}\n{type}\n{to}\n{evidence}";
                if (string.IsNullOrWhiteSpace(from) || string.IsNullOrWhiteSpace(to) || !edgeKeys.Add(key))
                {
                    return;
                }

                edges.Add(new ProjectContextEdge
                {
                    from = from,
                    to = to,
                    type = type ?? string.Empty,
                    evidence = evidence ?? string.Empty
                });
            }

            public void FinalizeIndex()
            {
                BuildEdgesFromChunks();
                Index.chunks = chunks.ToArray();
                Index.edges = edges.ToArray();
                Index.chunkTypeCounts = CountTypes(chunks);
            }

            private void BuildEdgesFromChunks()
            {
                Dictionary<string, List<ProjectContextChunk>> byPath = new Dictionary<string, List<ProjectContextChunk>>(StringComparer.OrdinalIgnoreCase);
                foreach (ProjectContextChunk chunk in chunks)
                {
                    if (string.IsNullOrWhiteSpace(chunk.path))
                    {
                        continue;
                    }

                    if (!byPath.TryGetValue(chunk.path, out List<ProjectContextChunk> list))
                    {
                        list = new List<ProjectContextChunk>();
                        byPath[chunk.path] = list;
                    }

                    list.Add(chunk);
                }

                foreach (ProjectContextChunk chunk in chunks)
                {
                    if (string.IsNullOrWhiteSpace(chunk.summary))
                    {
                        continue;
                    }

                    foreach (KeyValuePair<string, List<ProjectContextChunk>> pair in byPath)
                    {
                        if (string.Equals(pair.Key, chunk.path, StringComparison.OrdinalIgnoreCase))
                        {
                            continue;
                        }

                        if (chunk.summary.IndexOf(pair.Key, StringComparison.OrdinalIgnoreCase) < 0)
                        {
                            continue;
                        }

                        AddEdge(chunk.id, pair.Value[0].id, "mentions_path", pair.Key);
                    }
                }
            }

            private static ContextTypeCount[] CountTypes(List<ProjectContextChunk> values)
            {
                Dictionary<string, int> counts = new Dictionary<string, int>(StringComparer.Ordinal);
                foreach (ProjectContextChunk value in values)
                {
                    counts[value.type] = counts.TryGetValue(value.type, out int count) ? count + 1 : 1;
                }

                List<ContextTypeCount> output = new List<ContextTypeCount>();
                foreach (KeyValuePair<string, int> pair in counts)
                {
                    output.Add(new ContextTypeCount { type = pair.Key, count = pair.Value });
                }

                output.Sort((left, right) =>
                {
                    int compare = right.count.CompareTo(left.count);
                    return compare != 0 ? compare : string.Compare(left.type, right.type, StringComparison.Ordinal);
                });
                return output.ToArray();
            }
        }

        private sealed class ScoredChunk
        {
            public readonly ProjectContextChunk chunk;
            public readonly float score;

            public ScoredChunk(ProjectContextChunk chunk, float score)
            {
                this.chunk = chunk;
                this.score = score;
            }
        }

        private sealed class RetrievedContext
        {
            public readonly List<ProjectContextChunk> chunks = new List<ProjectContextChunk>();
            public readonly List<ProjectContextEdge> edges = new List<ProjectContextEdge>();
        }

        [Serializable]
        private sealed class ProjectContextIndex
        {
            public int version;
            public string projectName;
            public string unityVersion;
            public string projectRoot;
            public string activeScene;
            public string activeScenePath;
            public ProjectContextChunk[] chunks;
            public ProjectContextEdge[] edges;
            public ContextTypeCount[] chunkTypeCounts;
            public long updatedAtUtcTicks;
        }

        [Serializable]
        private sealed class ProjectContextChunk
        {
            public string id;
            public string type;
            public string title;
            public string path;
            public string guid;
            public string scenePath;
            public string hierarchyPath;
            public string summary;
            public string symbols;
            public string vector;
            public float lastScore;
        }

        [Serializable]
        private sealed class ProjectContextEdge
        {
            public string from;
            public string to;
            public string type;
            public string evidence;
        }

        [Serializable]
        private sealed class ContextTypeCount
        {
            public string type;
            public int count;
        }
    }
}
