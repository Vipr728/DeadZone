using System;
using System.Collections.Generic;
using System.IO;
using System.Text;
using UnityEditor;
using UnityEngine;

namespace AgenticGamedev.EditorTools
{
    internal static class AgenticRoleDocsMemoryStore
    {
        private const int CurrentVersion = 1;
        private const int CacheLifetimeSeconds = 300;

        [MenuItem("Tools/Ark/Memory/Copy Role Docs Memory")]
        private static void CopyRoleDocsMemory()
        {
            EditorGUIUtility.systemCopyBuffer = BuildContextSection("manager", string.Empty);
            Debug.Log("Copied Ark role docs memory context.");
        }

        public static string BuildContextSection(string role, string prompt)
        {
            string normalizedRole = NormalizeRole(role);
            string normalizedPrompt = Clean(prompt, 1600);
            string cacheKey = normalizedRole + ":" + StableHash(normalizedPrompt);
            RoleDocsMemoryState state = Load();
            RoleDocsMemory roleMemory = GetOrCreateRoleMemory(state, normalizedRole);

            if (string.Equals(roleMemory.cacheKey, cacheKey, StringComparison.Ordinal) &&
                !string.IsNullOrWhiteSpace(roleMemory.cachedContext) &&
                (DateTime.UtcNow - TicksToUtc(roleMemory.cachedAtUtcTicks)).TotalSeconds < CacheLifetimeSeconds)
            {
                return roleMemory.cachedContext;
            }

            string context = BuildFreshContext(normalizedRole, normalizedPrompt, roleMemory);
            roleMemory.cacheKey = cacheKey;
            roleMemory.cachedContext = context;
            roleMemory.cachedAtUtcTicks = DateTime.UtcNow.Ticks;
            roleMemory.lastPrompt = normalizedPrompt;
            roleMemory.lastQueries = BuildQuerySummaries(normalizedRole, normalizedPrompt).ToArray();
            roleMemory.updatedAtUtcTicks = DateTime.UtcNow.Ticks;
            Save(state);
            return context;
        }

        private static string BuildFreshContext(string role, string prompt, RoleDocsMemory roleMemory)
        {
            StringBuilder builder = new StringBuilder();
            builder.AppendLine("Role-scoped docs memory:");
            builder.AppendLine($"- store: {RelativeStorePath()}");
            builder.AppendLine($"- role: {role}");
            builder.AppendLine($"- soft context budget: {BuildSoftContextBudget(role)}");
            builder.AppendLine("- contract: this is retrieval memory, not authority by itself; current Unity state, compiler diagnostics, and direct docs/API reads override stale recall.");

            if (IsManagerRole(role))
            {
                AppendManagerDocsRouter(builder, prompt);
            }
            else if (string.Equals(role, "worker", StringComparison.Ordinal))
            {
                AppendWorkerProgrammingRag(builder, prompt);
            }
            else
            {
                AppendSpecialistDocsRouter(builder, role, prompt);
            }

            if (roleMemory != null && roleMemory.lastQueries != null && roleMemory.lastQueries.Length > 0)
            {
                builder.AppendLine("- previous retrievals for this role:");
                for (int i = 0; i < roleMemory.lastQueries.Length && i < 6; i++)
                {
                    if (!string.IsNullOrWhiteSpace(roleMemory.lastQueries[i]))
                    {
                        builder.AppendLine($"  - {roleMemory.lastQueries[i]}");
                    }
                }
            }

            return builder.ToString().TrimEnd();
        }

        private static void AppendManagerDocsRouter(StringBuilder builder, string prompt)
        {
            builder.AppendLine("- orchestrator memory:");
            builder.AppendLine("  - keep only compact workflow guidance in manager context; delegate deep API/doc reads to worker, scene_setup, asset_management, or monitor.");
            builder.AppendLine("  - use full Unity docs through search_unity_docs as a router/index before planning unfamiliar workflows.");
            builder.AppendLine("  - if a task touches code/API members, route to worker with a requirement to search_unity_api/read_unity_api before writing.");
            builder.AppendLine("  - if a task touches prefabs/materials/profiles/controllers/importers/assets, route asset creation and verification to asset_management before code depends on it.");
            builder.AppendLine("  - if a task touches hierarchy, cameras, UI, lights, transforms, or object wiring, route live scene setup to scene_setup before runtime code.");

            List<QuerySpec> queries = BuildManagerQueries(prompt);
            AppendQueryHints(builder, "suggested manager docs searches", queries);
            AppendCompactDocsResults(builder, queries, includeApi: false);
        }

        private static void AppendWorkerProgrammingRag(StringBuilder builder, string prompt)
        {
            builder.AppendLine("- worker programming memory:");
            builder.AppendLine("  - use local Unity docs/API source as the first repair loop for exact type names, public members, setters, overloads, serialized field paths, lifecycle methods, and package-specific APIs.");
            builder.AppendLine("  - before writing Unity C# that depends on uncertain API shape, search_unity_api with the exact type/member names and read the returned source.");
            builder.AppendLine("  - do not treat Inspector labels or old examples as proof of assignable C# members; installed source wins.");
            builder.AppendLine("  - when code depends on scene/prefab references, return missing setup as a blocker for scene_setup or asset_management instead of papering over it in scripts.");

            List<QuerySpec> queries = BuildWorkerQueries(prompt);
            AppendQueryHints(builder, "programming RAG queries", queries);
            AppendCompactDocsResults(builder, queries, includeApi: true);
        }

        private static void AppendSpecialistDocsRouter(StringBuilder builder, string role, string prompt)
        {
            builder.AppendLine("- specialist docs memory:");
            if (string.Equals(role, "asset_management", StringComparison.Ordinal))
            {
                builder.AppendLine("  - prioritize prefab/material/profile/controller/importer docs and verify actual asset values after mutation.");
            }
            else if (string.Equals(role, "scene_setup", StringComparison.Ordinal))
            {
                builder.AppendLine("  - prioritize scene hierarchy, component wiring, camera, UI, light, collider, and transform docs.");
            }
            else if (string.Equals(role, "monitor", StringComparison.Ordinal))
            {
                builder.AppendLine("  - prioritize Play Mode, runtime inspection, exceptions, spawned objects, UI state, and observable gameplay validation.");
            }
            else
            {
                builder.AppendLine("  - use docs retrieval only when current Unity context and project source are insufficient.");
            }

            List<QuerySpec> queries = BuildSpecialistQueries(role, prompt);
            AppendQueryHints(builder, "suggested specialist docs searches", queries);
        }

        private static void AppendQueryHints(StringBuilder builder, string title, List<QuerySpec> queries)
        {
            if (queries == null || queries.Count == 0)
            {
                return;
            }

            builder.AppendLine($"- {title}:");
            foreach (QuerySpec query in queries)
            {
                builder.AppendLine($"  - {query.Tool}: {query.Query}");
            }
        }

        private static void AppendCompactDocsResults(StringBuilder builder, List<QuerySpec> queries, bool includeApi)
        {
            if (queries == null || queries.Count == 0)
            {
                return;
            }

            int written = 0;
            foreach (QuerySpec query in queries)
            {
                if (!includeApi && query.IsApi)
                {
                    continue;
                }

                string raw = query.IsApi
                    ? AgenticUnityDocsIndex.SearchApi(query.Query, 3)
                    : AgenticUnityDocsIndex.Search(query.Query, 3);
                string compact = CompactSearchOutput(raw, query.IsApi ? 12 : 10);
                if (string.IsNullOrWhiteSpace(compact))
                {
                    continue;
                }

                if (written == 0)
                {
                    builder.AppendLine("- retrieved docs memory:");
                }

                builder.AppendLine($"  - query: {query.Tool} {query.Query}");
                foreach (string line in SplitLines(compact))
                {
                    builder.AppendLine("    " + line);
                }

                written++;
                if (written >= (includeApi ? 3 : 2))
                {
                    return;
                }
            }
        }

        private static string CompactSearchOutput(string raw, int maxLines)
        {
            if (string.IsNullOrWhiteSpace(raw) || maxLines <= 0)
            {
                return string.Empty;
            }

            List<string> lines = new List<string>();
            foreach (string line in SplitLines(raw))
            {
                string trimmed = line.Trim();
                if (string.IsNullOrWhiteSpace(trimmed))
                {
                    continue;
                }

                if (trimmed.StartsWith("Local Unity docs search:", StringComparison.Ordinal) ||
                    trimmed.StartsWith("Installed Unity/package API source search:", StringComparison.Ordinal) ||
                    trimmed.StartsWith("Index:", StringComparison.Ordinal) ||
                    trimmed.StartsWith("Scanned:", StringComparison.Ordinal) ||
                    trimmed.StartsWith("Results:", StringComparison.Ordinal) ||
                    trimmed.StartsWith("- id=", StringComparison.Ordinal) ||
                    trimmed.StartsWith("- path=", StringComparison.Ordinal) ||
                    trimmed.StartsWith("title:", StringComparison.Ordinal) ||
                    trimmed.StartsWith("path:", StringComparison.Ordinal) ||
                    trimmed.StartsWith("package:", StringComparison.Ordinal) ||
                    trimmed.StartsWith("read:", StringComparison.Ordinal))
                {
                    lines.Add(trimmed);
                }

                if (lines.Count >= maxLines)
                {
                    break;
                }
            }

            return string.Join("\n", lines.ToArray());
        }

        private static List<QuerySpec> BuildManagerQueries(string prompt)
        {
            List<QuerySpec> queries = new List<QuerySpec>();
            string domain = BuildDomainQuery(prompt, 8);
            AddQuery(queries, "search_unity_docs", "Unity workflow setup validation " + domain, false);
            if (ContainsAny(prompt, "post", "processing", "bloom", "vignette", "volume", "urp", "render", "camera", "cinemachine"))
            {
                AddQuery(queries, "search_unity_docs", "Unity render pipeline camera volume post processing workflow", false);
            }
            else if (ContainsAny(prompt, "prefab", "material", "asset", "controller", "sprite", "clip", "animation"))
            {
                AddQuery(queries, "search_unity_docs", "Unity prefab asset material controller workflow verification", false);
            }
            else if (ContainsAny(prompt, "play", "runtime", "spawn", "enemy", "bullet", "health", "wave", "combat"))
            {
                AddQuery(queries, "search_unity_docs", "Unity gameplay runtime prefab Instantiate scene reference validation", false);
            }

            return queries;
        }

        private static List<QuerySpec> BuildWorkerQueries(string prompt)
        {
            List<QuerySpec> queries = new List<QuerySpec>();
            string domain = BuildDomainQuery(prompt, 10);
            AddQuery(queries, "search_unity_docs", "Unity scripting serialization MonoBehaviour lifecycle " + domain, false);
            AddQuery(queries, "search_unity_api", "Unity C# API public members setters " + domain, true);

            if (ContainsAny(prompt, "compiler", "compile", "error", "cs0103", "cs0104", "cs0305", "cs0618", "cs1061", "ambiguous"))
            {
                AddQuery(queries, "search_unity_api", "compiler error Unity C# member type " + domain, true);
            }
            else if (ContainsAny(prompt, "prefab", "instantiate", "resources", "assetdatabase"))
            {
                AddQuery(queries, "search_unity_api", "PrefabUtility AssetDatabase Resources Instantiate GameObject", true);
            }
            else if (ContainsAny(prompt, "input", "keyboard", "mouse", "playerinput"))
            {
                AddQuery(queries, "search_unity_api", "Unity Input System Keyboard Mouse PlayerInput", true);
            }

            return queries;
        }

        private static List<QuerySpec> BuildSpecialistQueries(string role, string prompt)
        {
            List<QuerySpec> queries = new List<QuerySpec>();
            string domain = BuildDomainQuery(prompt, 8);
            if (string.Equals(role, "asset_management", StringComparison.Ordinal))
            {
                AddQuery(queries, "search_unity_docs", "Unity prefab asset material profile controller import workflow " + domain, false);
            }
            else if (string.Equals(role, "scene_setup", StringComparison.Ordinal))
            {
                AddQuery(queries, "search_unity_docs", "Unity scene GameObject component camera UI light setup " + domain, false);
            }
            else if (string.Equals(role, "monitor", StringComparison.Ordinal))
            {
                AddQuery(queries, "search_unity_docs", "Unity Play Mode runtime validation exceptions spawned objects " + domain, false);
            }

            return queries;
        }

        private static List<string> BuildQuerySummaries(string role, string prompt)
        {
            List<string> summaries = new List<string>();
            List<QuerySpec> queries = IsManagerRole(role)
                ? BuildManagerQueries(prompt)
                : string.Equals(role, "worker", StringComparison.Ordinal)
                    ? BuildWorkerQueries(prompt)
                    : BuildSpecialistQueries(role, prompt);
            foreach (QuerySpec query in queries)
            {
                summaries.Add(query.Tool + " " + query.Query);
            }

            return summaries;
        }

        private static void AddQuery(List<QuerySpec> queries, string tool, string query, bool isApi)
        {
            query = Clean(query, 240);
            if (queries == null || string.IsNullOrWhiteSpace(query))
            {
                return;
            }

            foreach (QuerySpec existing in queries)
            {
                if (string.Equals(existing.Tool, tool, StringComparison.Ordinal) &&
                    string.Equals(existing.Query, query, StringComparison.OrdinalIgnoreCase))
                {
                    return;
                }
            }

            queries.Add(new QuerySpec
            {
                Tool = tool,
                Query = query,
                IsApi = isApi
            });
        }

        private static string BuildDomainQuery(string prompt, int maxTokens)
        {
            List<string> tokens = Tokenize(prompt, maxTokens);
            return tokens.Count == 0 ? "Unity" : string.Join(" ", tokens.ToArray());
        }

        private static List<string> Tokenize(string value, int maxTokens)
        {
            List<string> tokens = new List<string>();
            if (string.IsNullOrWhiteSpace(value) || maxTokens <= 0)
            {
                return tokens;
            }

            StringBuilder current = new StringBuilder();
            foreach (char character in value)
            {
                if (char.IsLetterOrDigit(character) || character == '_' || character == '-')
                {
                    current.Append(char.ToLowerInvariant(character));
                    continue;
                }

                AddToken(tokens, current, maxTokens);
            }

            AddToken(tokens, current, maxTokens);
            return tokens;
        }

        private static void AddToken(List<string> tokens, StringBuilder current, int maxTokens)
        {
            if (current.Length == 0 || tokens.Count >= maxTokens)
            {
                current.Length = 0;
                return;
            }

            string token = current.ToString().Trim('_', '-');
            current.Length = 0;
            if (token.Length < 3 || IsStopWord(token) || tokens.Contains(token))
            {
                return;
            }

            tokens.Add(token);
        }

        private static bool IsStopWord(string token)
        {
            switch (token)
            {
                case "the":
                case "and":
                case "for":
                case "with":
                case "that":
                case "this":
                case "should":
                case "could":
                case "would":
                case "please":
                case "make":
                case "change":
                case "create":
                case "fix":
                case "add":
                case "remove":
                case "using":
                case "from":
                case "into":
                case "work":
                case "works":
                case "want":
                case "need":
                case "unity":
                case "agent":
                case "project":
                case "scene":
                    return true;
                default:
                    return false;
            }
        }

        private static bool ContainsAny(string value, params string[] needles)
        {
            if (string.IsNullOrWhiteSpace(value) || needles == null)
            {
                return false;
            }

            string normalized = value.ToLowerInvariant();
            foreach (string needle in needles)
            {
                if (!string.IsNullOrWhiteSpace(needle) && normalized.Contains(needle.ToLowerInvariant()))
                {
                    return true;
                }
            }

            return false;
        }

        private static string BuildSoftContextBudget(string role)
        {
            if (IsManagerRole(role))
            {
                return "orchestrator keeps docs memory compact (<2k tokens) and delegates detailed retrieval";
            }

            if (string.Equals(role, "worker", StringComparison.Ordinal))
            {
                return "worker keeps programming/API retrieval memory focused (<4k tokens) and reads exact docs/source on demand";
            }

            return "specialist keeps only role-relevant docs hints and retrieves details on demand";
        }

        private static bool IsManagerRole(string role)
        {
            return string.Equals(NormalizeRole(role), "manager", StringComparison.Ordinal);
        }

        private static string NormalizeRole(string role)
        {
            if (string.IsNullOrWhiteSpace(role))
            {
                return "default";
            }

            string normalized = role.Trim().ToLowerInvariant().Replace("-", "_").Replace(" ", "_");
            switch (normalized)
            {
                case "orchestrator":
                case "manager":
                    return "manager";
                case "programmer":
                case "programming":
                case "coder":
                case "code":
                    return "worker";
                default:
                    return normalized;
            }
        }

        private static string Clean(string value, int maxLength)
        {
            if (string.IsNullOrWhiteSpace(value))
            {
                return string.Empty;
            }

            string cleaned = value.Replace("\r", " ").Replace("\n", " ").Trim();
            while (cleaned.IndexOf("  ", StringComparison.Ordinal) >= 0)
            {
                cleaned = cleaned.Replace("  ", " ");
            }

            if (cleaned.Length > maxLength)
            {
                cleaned = cleaned.Substring(0, maxLength).TrimEnd();
            }

            return cleaned;
        }

        private static string[] SplitLines(string value)
        {
            return string.IsNullOrWhiteSpace(value)
                ? Array.Empty<string>()
                : value.Replace("\r\n", "\n").Replace('\r', '\n').Split('\n');
        }

        private static long StableHash(string value)
        {
            unchecked
            {
                long hash = 1469598103934665603L;
                foreach (char character in value ?? string.Empty)
                {
                    hash ^= character;
                    hash *= 1099511628211L;
                }

                return hash;
            }
        }

        private static DateTime TicksToUtc(long ticks)
        {
            return ticks <= 0 ? DateTime.MinValue : new DateTime(ticks, DateTimeKind.Utc);
        }

        private static RoleDocsMemoryState Load()
        {
            string path = GetStorePath();
            if (!File.Exists(path))
            {
                return CreateEmptyState();
            }

            try
            {
                RoleDocsMemoryState state = JsonUtility.FromJson<RoleDocsMemoryState>(File.ReadAllText(path, Encoding.UTF8));
                if (state == null || state.version != CurrentVersion)
                {
                    return CreateEmptyState();
                }

                state.roles = state.roles ?? Array.Empty<RoleDocsMemory>();
                return state;
            }
            catch (Exception exception)
            {
                Debug.LogWarning($"Could not load Agentic role docs memory: {exception.Message}");
                return CreateEmptyState();
            }
        }

        private static void Save(RoleDocsMemoryState state)
        {
            try
            {
                string path = GetStorePath();
                Directory.CreateDirectory(Path.GetDirectoryName(path) ?? string.Empty);
                state.version = CurrentVersion;
                state.updatedAtUtcTicks = DateTime.UtcNow.Ticks;
                File.WriteAllText(path, JsonUtility.ToJson(state, true), Encoding.UTF8);
            }
            catch (Exception exception)
            {
                Debug.LogWarning($"Could not save Agentic role docs memory: {exception.Message}");
            }
        }

        private static RoleDocsMemory GetOrCreateRoleMemory(RoleDocsMemoryState state, string role)
        {
            state.roles = state.roles ?? Array.Empty<RoleDocsMemory>();
            foreach (RoleDocsMemory memory in state.roles)
            {
                if (memory != null && string.Equals(memory.role, role, StringComparison.Ordinal))
                {
                    return memory;
                }
            }

            RoleDocsMemory created = new RoleDocsMemory
            {
                role = role,
                lastQueries = Array.Empty<string>(),
                createdAtUtcTicks = DateTime.UtcNow.Ticks,
                updatedAtUtcTicks = DateTime.UtcNow.Ticks
            };
            List<RoleDocsMemory> roles = new List<RoleDocsMemory>(state.roles) { created };
            state.roles = roles.ToArray();
            return created;
        }

        private static RoleDocsMemoryState CreateEmptyState()
        {
            long now = DateTime.UtcNow.Ticks;
            return new RoleDocsMemoryState
            {
                version = CurrentVersion,
                createdAtUtcTicks = now,
                updatedAtUtcTicks = now,
                roles = Array.Empty<RoleDocsMemory>()
            };
        }

        private static string GetStorePath()
        {
            string projectRoot = Directory.GetParent(Application.dataPath)?.FullName ?? Application.dataPath;
            return Path.Combine(projectRoot, "Library", "AgenticGamedev", "role-docs-memory.json");
        }

        private static string RelativeStorePath()
        {
            return "Library/AgenticGamedev/role-docs-memory.json";
        }

        [Serializable]
        private sealed class RoleDocsMemoryState
        {
            public int version;
            public long createdAtUtcTicks;
            public long updatedAtUtcTicks;
            public RoleDocsMemory[] roles;
        }

        [Serializable]
        private sealed class RoleDocsMemory
        {
            public string role;
            public string lastPrompt;
            public string[] lastQueries;
            public string cacheKey;
            public string cachedContext;
            public long cachedAtUtcTicks;
            public long createdAtUtcTicks;
            public long updatedAtUtcTicks;
        }

        private sealed class QuerySpec
        {
            public string Tool;
            public string Query;
            public bool IsApi;
        }
    }
}
