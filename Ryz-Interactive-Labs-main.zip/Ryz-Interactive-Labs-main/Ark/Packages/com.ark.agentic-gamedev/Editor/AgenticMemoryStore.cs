using System;
using System.Collections.Generic;
using System.IO;
using System.Text;
using System.Text.RegularExpressions;
using UnityEditor;
using UnityEngine;
using UnityEngine.SceneManagement;

namespace AgenticGamedev.EditorTools
{
    internal static class AgenticMemoryStore
    {
        private const int CurrentVersion = 1;
        private const int MaxEvents = 500;
        private const int MaxMemories = 2500;
        private const int MaxRecentMessages = 18;
        private const int MaxRelevantMemories = 12;
        private const int MaxMemoryContent = 900;

        private static readonly Regex SensitiveRegex = new Regex(@"\b(?:api[_ -]?key|access[_ -]?token|refresh[_ -]?token|password|passwd|secret|bearer\s+[a-z0-9._-]+|sk-[a-z0-9_-]{12,}|gh[pousr]_[a-z0-9_]{12,})\b", RegexOptions.IgnoreCase | RegexOptions.Compiled);
        private static readonly Regex PromptInjectionRegex = new Regex(@"\b(?:(?:ignore|override|bypass|disable|forget).{0,80}(?:system|developer|instruction|policy|safety)|reveal.{0,40}secret|exfiltrate|send.{0,40}(?:password|token|secret|api[_ -]?key))\b", RegexOptions.IgnoreCase | RegexOptions.Compiled);
        private static readonly Regex FollowUpRegex = new Regex(@"\b(?:continue|keep going|same|as before|that|this|it|above|previous|earlier|also|actually|instead|change|revise|update|one more|next|now|follow[- ]?up)\b", RegexOptions.IgnoreCase | RegexOptions.Compiled);

        private static readonly HashSet<string> StopWords = new HashSet<string>(StringComparer.OrdinalIgnoreCase)
        {
            "the", "and", "for", "with", "that", "this", "from", "into", "what", "when", "where", "which", "while",
            "would", "could", "should", "there", "their", "about", "your", "have", "has", "had", "are", "was",
            "were", "will", "can", "not", "but", "all", "any", "you", "our", "out", "use", "using", "used",
            "scene", "project", "unity", "agent", "file", "then", "than", "them", "they", "just", "like", "also"
        };

        [MenuItem("Tools/Ark/Memory/Copy Memory Context")]
        private static void CopyMemoryContext()
        {
            EditorGUIUtility.systemCopyBuffer = BuildContextSection(string.Empty);
            Debug.Log("Copied Ark local memory context.");
        }

        [MenuItem("Tools/Ark/Memory/Clear Memory")]
        private static void ClearMemoryMenu()
        {
            Clear();
            Debug.Log("Cleared Ark local memory.");
        }

        public static string BuildContextSection(string currentPrompt)
        {
            MemoryState state = Load();
            bool changed = SyncChatHistory(state);
            if (changed)
            {
                Save(state);
            }

            RecallBundle bundle = Recall(state, currentPrompt);
            StringBuilder builder = new StringBuilder();
            builder.AppendLine("Local memory:");
            builder.AppendLine($"- store: {RelativeStorePath()}");
            builder.AppendLine($"- events: {SafeLength(state.events)}, memories: {SafeLength(state.memories)}");
            builder.AppendLine("- contract: use local memory as project and personalization context; current prompt and live Unity context override older memory; explicit user corrections override prior memory; do not reveal private memory unless the user asks what you remember; verify stale or conflicting memory through Unity tools.");

            ActiveTask task = bundle.activeTask ?? new ActiveTask();
            builder.AppendLine("- active task:");
            AppendMemoryLine(builder, "  status", task.status);
            AppendMemoryLine(builder, "  goal", task.goal);
            AppendMemoryLine(builder, "  current state", task.currentState);
            AppendMemoryList(builder, "  constraints", task.importantConstraints, 6);
            AppendMemoryList(builder, "  decisions", task.decisions, 6);
            AppendMemoryList(builder, "  open threads", bundle.openThreads, 8);
            AppendMemoryList(builder, "  recently tried", task.recentlyTried, 6);
            AppendMemoryLine(builder, "  next step", task.nextStep);

            builder.AppendLine("- relevant memories:");
            if (bundle.relevantMemories.Count == 0)
            {
                builder.AppendLine("  - none recalled");
            }
            else
            {
                foreach (ScoredMemory memory in bundle.relevantMemories)
                {
                    builder.AppendLine($"  - [{memory.record.type}] {memory.record.content} (entity={memory.record.entity}, confidence={FormatNumber(memory.record.confidence)}, score={FormatNumber(memory.score)}, updated={FormatTicks(memory.record.updatedAtUtcTicks)})");
                }
            }

            AppendRecentChat(builder, state.ignoreChatHistoryBeforeUtcTicks);
            return builder.ToString().TrimEnd();
        }

        public static void Clear()
        {
            MemoryState state = CreateEmptyState();
            state.ignoreChatHistoryBeforeUtcTicks = DateTime.UtcNow.Ticks;
            Save(state);
        }

        private static RecallBundle Recall(MemoryState state, string currentPrompt)
        {
            string query = CleanBlock(string.Join("\n", new[]
            {
                currentPrompt,
                state.activeTask?.goal,
                state.activeTask?.currentState,
                state.activeTask?.nextStep,
                Application.productName,
                SceneManager.GetActiveScene().name,
                SceneManager.GetActiveScene().path
            }), 5000);
            HashSet<string> queryTokens = new HashSet<string>(Tokenize(query, 300), StringComparer.OrdinalIgnoreCase);
            string projectEntity = EntityId("project", Application.productName);
            string sceneEntity = EntityId("scene", SceneManager.GetActiveScene().name);

            List<ScoredMemory> scored = new List<ScoredMemory>();
            foreach (MemoryRecord memory in state.memories ?? new MemoryRecord[0])
            {
                if (memory == null || string.IsNullOrWhiteSpace(memory.content) || memory.deleted)
                {
                    continue;
                }

                double score = ScoreMemory(memory, queryTokens, projectEntity, sceneEntity);
                if (score <= 0 && !ContainsEntity(memory, projectEntity) && !ContainsEntity(memory, sceneEntity))
                {
                    continue;
                }

                scored.Add(new ScoredMemory(memory, score));
            }

            scored.Sort((left, right) =>
            {
                int scoreCompare = right.score.CompareTo(left.score);
                return scoreCompare != 0 ? scoreCompare : right.record.updatedAtUtcTicks.CompareTo(left.record.updatedAtUtcTicks);
            });

            if (scored.Count > MaxRelevantMemories)
            {
                scored.RemoveRange(MaxRelevantMemories, scored.Count - MaxRelevantMemories);
            }

            ActiveTask task = NormalizeTask(state.activeTask);
            List<string> openThreads = new List<string>(Unique(task.openThreads, 10));
            foreach (ScoredMemory memory in scored)
            {
                if (string.Equals(memory.record.type, "blocker", StringComparison.OrdinalIgnoreCase) ||
                    string.Equals(memory.record.type, "active_goal", StringComparison.OrdinalIgnoreCase) ||
                    string.Equals(memory.record.type, "correction", StringComparison.OrdinalIgnoreCase))
                {
                    AddUnique(openThreads, memory.record.content, 10);
                }
            }

            return new RecallBundle
            {
                activeTask = task,
                relevantMemories = scored,
                openThreads = openThreads.ToArray()
            };
        }

        private static double ScoreMemory(MemoryRecord memory, HashSet<string> queryTokens, string projectEntity, string sceneEntity)
        {
            List<string> memoryTokens = Tokenize(string.Join(" ", new[]
            {
                memory.content,
                memory.type,
                memory.entity,
                string.Join(" ", memory.entities ?? new string[0]),
                string.Join(" ", memory.tags ?? new string[0])
            }), 2500);

            if (memoryTokens.Count == 0)
            {
                return 0;
            }

            Dictionary<string, int> counts = new Dictionary<string, int>(StringComparer.OrdinalIgnoreCase);
            foreach (string token in memoryTokens)
            {
                counts[token] = counts.TryGetValue(token, out int count) ? count + 1 : 1;
            }

            double overlap = 0;
            foreach (string token in queryTokens)
            {
                if (counts.TryGetValue(token, out int count))
                {
                    overlap += 1 + Math.Min(count, 5) * 0.25;
                }
            }

            double entityBoost = ContainsEntity(memory, projectEntity) ? 1.5 : 0;
            entityBoost += ContainsEntity(memory, sceneEntity) ? 1.0 : 0;
            double confidenceBoost = Math.Max(0, Math.Min(1, memory.confidence));
            double seenBoost = Math.Min(1.2, Math.Log(Math.Max(1, memory.seenCount) + 1, 2) * 0.25);
            double recencyBoost = RecencyBoost(memory.updatedAtUtcTicks);
            return Math.Round(overlap + entityBoost + confidenceBoost + seenBoost + recencyBoost, 4);
        }

        private static double RecencyBoost(long ticks)
        {
            if (ticks <= 0)
            {
                return 0;
            }

            TimeSpan age = DateTime.UtcNow - new DateTime(ticks, DateTimeKind.Utc);
            return Math.Max(0, 1.5 - age.TotalDays / 45.0);
        }

        private static bool SyncChatHistory(MemoryState state)
        {
            bool changed = false;
            List<AgenticChatStore.Message> messages = AgenticChatStore.Load();
            HashSet<string> existing = new HashSet<string>(StringComparer.Ordinal);
            foreach (MemoryEvent memoryEvent in state.events ?? new MemoryEvent[0])
            {
                if (!string.IsNullOrWhiteSpace(memoryEvent?.id))
                {
                    existing.Add(memoryEvent.id);
                }
            }

            for (int i = 0; i < messages.Count; i++)
            {
                AgenticChatStore.Message message = messages[i];
                string text = CleanBlock(message?.text, 6000);
                if (string.IsNullOrWhiteSpace(text))
                {
                    continue;
                }

                if (state.ignoreChatHistoryBeforeUtcTicks > 0 &&
                    message != null &&
                    message.timestampUtcTicks > 0 &&
                    message.timestampUtcTicks <= state.ignoreChatHistoryBeforeUtcTicks)
                {
                    continue;
                }

                string id = BuildChatEventId(message, i, text);
                if (existing.Contains(id))
                {
                    continue;
                }

                MemoryEvent memoryEvent = CreateEventFromChatMessage(id, message, text);
                ObserveEvent(state, memoryEvent);
                existing.Add(id);
                changed = true;
            }

            return changed;
        }

        private static string BuildChatEventId(AgenticChatStore.Message message, int index, string text)
        {
            long ticks = message == null ? 0 : message.timestampUtcTicks;
            return $"chat_{ticks}_{index}_{StableHash((message?.author ?? string.Empty) + "\n" + text)}";
        }

        private static MemoryEvent CreateEventFromChatMessage(string id, AgenticChatStore.Message message, string text)
        {
            string author = message?.author ?? string.Empty;
            bool isUser = string.Equals(author, "You", StringComparison.OrdinalIgnoreCase) ||
                string.Equals(author, "User", StringComparison.OrdinalIgnoreCase);
            Scene scene = SceneManager.GetActiveScene();
            return new MemoryEvent
            {
                id = id,
                role = isUser ? "user" : "agent",
                kind = isUser ? "user_prompt" : "agent_response",
                source = "chat-history",
                chatId = "unity-editor",
                projectId = Application.productName,
                sceneName = scene.name,
                scenePath = scene.path,
                prompt = isUser ? text : string.Empty,
                summary = isUser ? string.Empty : text,
                outcome = isUser ? string.Empty : ExtractOutcomeSummary(text),
                text = text,
                createdAtUtcTicks = message == null || message.timestampUtcTicks <= 0 ? DateTime.UtcNow.Ticks : message.timestampUtcTicks
            };
        }

        private static void ObserveEvent(MemoryState state, MemoryEvent memoryEvent)
        {
            if (state == null || memoryEvent == null)
            {
                return;
            }

            memoryEvent.text = SafeMemoryBlock(memoryEvent.text, 5000);
            memoryEvent.prompt = SafeMemoryBlock(memoryEvent.prompt, 3000);
            memoryEvent.summary = SafeMemoryBlock(memoryEvent.summary, 2200);
            memoryEvent.outcome = SafeMemoryBlock(memoryEvent.outcome, 2200);
            memoryEvent.createdAtUtcTicks = memoryEvent.createdAtUtcTicks <= 0 ? DateTime.UtcNow.Ticks : memoryEvent.createdAtUtcTicks;

            List<MemoryEvent> events = new List<MemoryEvent>(state.events ?? new MemoryEvent[0]) { memoryEvent };
            TrimFromStart(events, MaxEvents);
            state.events = events.ToArray();

            ActiveTask activeTask = UpdateActiveTask(state.activeTask, memoryEvent);
            state.activeTask = activeTask;

            List<MemoryRecord> memories = new List<MemoryRecord>(state.memories ?? new MemoryRecord[0]);
            foreach (MemoryRecord candidate in ExtractMemoryCandidates(memoryEvent, activeTask))
            {
                UpsertMemory(memories, candidate);
            }

            TrimFromStart(memories, MaxMemories);
            state.memories = memories.ToArray();
            state.updatedAtUtcTicks = DateTime.UtcNow.Ticks;
        }

        private static ActiveTask UpdateActiveTask(ActiveTask existing, MemoryEvent memoryEvent)
        {
            ActiveTask task = NormalizeTask(existing);
            string text = EventText(memoryEvent);
            long now = DateTime.UtcNow.Ticks;

            if (string.Equals(memoryEvent.role, "user", StringComparison.OrdinalIgnoreCase))
            {
                bool startFresh = string.IsNullOrWhiteSpace(task.goal) ||
                    ((string.Equals(task.status, "done", StringComparison.OrdinalIgnoreCase) ||
                      string.Equals(task.status, "blocked", StringComparison.OrdinalIgnoreCase)) &&
                     !FollowUpRegex.IsMatch(text));

                if (startFresh)
                {
                    task = new ActiveTask
                    {
                        status = "active",
                        goal = CleanText(text, 700),
                        currentState = "Latest user request: " + CleanText(text, 700),
                        importantConstraints = ExtractConstraintSignals(text, 8),
                        openThreads = new[] { "Resolve latest request: " + CleanText(text, 500) },
                        decisions = new string[0],
                        recentlyTried = new string[0],
                        nextStep = "Answer or complete the latest Unity request.",
                        createdAtUtcTicks = now,
                        updatedAtUtcTicks = now
                    };
                }
                else
                {
                    task.status = "active";
                    task.currentState = "Latest user request: " + CleanText(text, 700);
                    task.openThreads = AddUnique(task.openThreads, "Resolve latest request: " + CleanText(text, 500), 8);
                    task.importantConstraints = MergeUnique(task.importantConstraints, ExtractConstraintSignals(text, 8), 8);
                    task.nextStep = "Answer or complete the latest Unity request.";
                    task.updatedAtUtcTicks = now;
                }
            }
            else if (!string.IsNullOrWhiteSpace(text))
            {
                string lower = text.ToLowerInvariant();
                if (lower.Contains("status: waiting for your approval") || lower.Contains("waiting for approval"))
                {
                    task.status = "waiting_for_approval";
                    task.currentState = CleanText(ExtractOutcomeSummary(text), 700);
                    task.recentlyTried = AddUnique(task.recentlyTried, task.currentState, 8);
                    task.nextStep = "Wait for user approval or a revised instruction.";
                }
                else if (lower.Contains("failed") || lower.Contains("error") || lower.Contains("exception") || lower.Contains("blocked"))
                {
                    task.status = "blocked";
                    task.currentState = CleanText(ExtractOutcomeSummary(text), 700);
                    task.openThreads = AddUnique(task.openThreads, task.currentState, 8);
                    task.nextStep = "Use the failure details to choose a different repair path.";
                }
                else if (lower.Contains("status: finished") || lower.Contains("executed ") || lower.Contains("applied actions:") || lower.Contains("status\nfinished"))
                {
                    task.status = "done";
                    task.currentState = CleanText(ExtractOutcomeSummary(text), 700);
                    task.openThreads = new string[0];
                    task.recentlyTried = AddUnique(task.recentlyTried, task.currentState, 8);
                    task.nextStep = "No active next step unless the user follows up.";
                }
                else
                {
                    task.status = "active";
                    task.currentState = CleanText(ExtractOutcomeSummary(text), 700);
                    task.recentlyTried = AddUnique(task.recentlyTried, task.currentState, 8);
                    task.nextStep = "Use this result when choosing the next step.";
                }

                task.decisions = MergeUnique(task.decisions, ExtractDecisionSignals(text, 8), 8);
                task.updatedAtUtcTicks = now;
            }

            return NormalizeTask(task);
        }

        private static List<MemoryRecord> ExtractMemoryCandidates(MemoryEvent memoryEvent, ActiveTask activeTask)
        {
            List<MemoryRecord> candidates = new List<MemoryRecord>();
            string text = EventText(memoryEvent);
            if (string.IsNullOrWhiteSpace(text) || SensitiveRegex.IsMatch(text))
            {
                return candidates;
            }

            string projectEntity = EntityId("project", memoryEvent.projectId);
            string sceneEntity = EntityId("scene", memoryEvent.sceneName);
            string userEntity = "user:default";
            string[] baseEntities = Unique(new[] { projectEntity, sceneEntity, userEntity, "global" }, 8);

            if (string.Equals(memoryEvent.role, "user", StringComparison.OrdinalIgnoreCase))
            {
                foreach (string signal in ExtractPreferenceSignals(text, 8))
                {
                    candidates.Add(CreateMemory("user_preference", signal, userEntity, baseEntities, memoryEvent, 0.82));
                }

                foreach (string signal in ExtractConstraintSignals(text, 10))
                {
                    candidates.Add(CreateMemory("constraint", signal, projectEntity, baseEntities, memoryEvent, 0.8));
                }

                foreach (string signal in ExtractCorrectionSignals(text, 8))
                {
                    candidates.Add(CreateMemory("correction", signal, projectEntity, baseEntities, memoryEvent, 0.86));
                }
            }
            else
            {
                string outcome = ExtractOutcomeSummary(text);
                if (!string.IsNullOrWhiteSpace(outcome) &&
                    !IsLowValueOutcome(outcome) &&
                    !Regex.IsMatch(outcome, @"^(ok|done|complete|finished)\.?$", RegexOptions.IgnoreCase))
                {
                    string type = Regex.IsMatch(outcome, @"\b(?:failed|error|exception|blocked|no actions|nothing was changed|applied actions:\s*0)\b", RegexOptions.IgnoreCase)
                        ? "blocker"
                        : "project_fact";
                    if (type == "blocker" || !IsGenericAgentProjectSummary(outcome))
                    {
                        candidates.Add(CreateMemory(type, outcome, projectEntity, baseEntities, memoryEvent, type == "blocker" ? 0.82 : 0.68));
                    }
                }

                foreach (string signal in ExtractDecisionSignals(outcome, 8))
                {
                    candidates.Add(CreateMemory("decision", signal, projectEntity, baseEntities, memoryEvent, 0.78));
                }
            }

            return candidates;
        }

        private static bool IsGenericAgentProjectSummary(string text)
        {
            if (string.IsNullOrWhiteSpace(text))
            {
                return false;
            }

            return Regex.IsMatch(
                text,
                @"\b(?:this is|this unity project is|the project is|the current prototype is|the active scene is|the unity project root is)\b",
                RegexOptions.IgnoreCase);
        }

        private static MemoryRecord CreateMemory(string type, string content, string entity, string[] entities, MemoryEvent memoryEvent, double confidence)
        {
            string safeContent = SafeMemoryText(content, MaxMemoryContent);
            if (string.IsNullOrWhiteSpace(safeContent) || PromptInjectionRegex.IsMatch(safeContent))
            {
                return null;
            }

            return new MemoryRecord
            {
                id = Guid.NewGuid().ToString("N"),
                type = CleanText(type, 40),
                entity = string.IsNullOrWhiteSpace(entity) ? "global" : entity,
                entities = Unique(entities, 12),
                scope = "personal",
                content = safeContent,
                source = CleanText(memoryEvent.source ?? memoryEvent.kind, 80),
                confidence = confidence,
                tags = Unique(TopTokens(safeContent, 8), 12),
                evidence = Unique(new[] { memoryEvent.id, memoryEvent.chatId, memoryEvent.scenePath }, 6),
                createdAtUtcTicks = DateTime.UtcNow.Ticks,
                updatedAtUtcTicks = DateTime.UtcNow.Ticks,
                seenCount = 1
            };
        }

        private static void UpsertMemory(List<MemoryRecord> memories, MemoryRecord candidate)
        {
            if (candidate == null || string.IsNullOrWhiteSpace(candidate.content))
            {
                return;
            }

            string key = NormalizedContentKey(candidate.content);
            foreach (MemoryRecord existing in memories)
            {
                if (existing == null || existing.deleted || !string.Equals(existing.type, candidate.type, StringComparison.OrdinalIgnoreCase))
                {
                    continue;
                }

                if (!string.Equals(NormalizedContentKey(existing.content), key, StringComparison.Ordinal))
                {
                    continue;
                }

                existing.updatedAtUtcTicks = DateTime.UtcNow.Ticks;
                existing.confidence = Math.Max(existing.confidence, candidate.confidence);
                existing.tags = MergeUnique(existing.tags, candidate.tags, 16);
                existing.entities = MergeUnique(existing.entities, candidate.entities, 24);
                existing.evidence = MergeUnique(existing.evidence, candidate.evidence, 12);
                existing.seenCount = Math.Max(1, existing.seenCount) + 1;
                return;
            }

            memories.Add(candidate);
        }

        private static string[] ExtractPreferenceSignals(string text, int limit)
        {
            return SentenceCandidates(text, 14, 420)
                .FindAll(item => Regex.IsMatch(item, @"\b(?:i prefer|prefer|prefers|likes|dislikes|please keep|always|don't|do not|avoid|use .+ for me|my preference|be concise|be direct|sleek|unity color scheme)\b", RegexOptions.IgnoreCase))
                .GetRangeSafe(0, limit)
                .ToArray();
        }

        private static string[] ExtractConstraintSignals(string text, int limit)
        {
            return SentenceCandidates(text, 16, 500)
                .FindAll(item => Regex.IsMatch(item, @"\b(?:must|always|never|don't|do not|only|keep|prefer|avoid|without|before|after|unless|required?|constraint|important|should|shouldn't|it should|agent should|needs to|has to)\b", RegexOptions.IgnoreCase))
                .GetRangeSafe(0, limit)
                .ToArray();
        }

        private static string[] ExtractCorrectionSignals(string text, int limit)
        {
            return SentenceCandidates(text, 16, 500)
                .FindAll(item => Regex.IsMatch(item, @"\b(?:when i said|not just|shouldn't|should not|terrible idea|wrong|instead|don't|do not|never|still not|doesn't|does not|isn't|is not|incomplete|nothing was changed|no actions|this is(?:n't| not)? .{0,80}\bproject|it is(?:n't| not)? .{0,80}\bproject)\b", RegexOptions.IgnoreCase))
                .GetRangeSafe(0, limit)
                .ToArray();
        }

        private static string[] ExtractDecisionSignals(string text, int limit)
        {
            return SentenceCandidates(text, 16, 500)
                .FindAll(item => Regex.IsMatch(item, @"\b(?:decided|decision|chose|chosen|switch(?:ed)? to|use .+ over|settled on|architecture|implemented|added|removed|created|fixed|updated|changed)\b", RegexOptions.IgnoreCase))
                .GetRangeSafe(0, limit)
                .ToArray();
        }

        private static List<string> SentenceCandidates(string value, int sentenceLimit, int textLimit)
        {
            string block = CleanBlock(value, 5000);
            string[] parts = Regex.Split(block, @"(?:\n+|(?<=[.!?])\s+)");
            List<string> output = new List<string>();
            foreach (string part in parts)
            {
                string cleaned = CleanText(part, textLimit);
                if (string.IsNullOrWhiteSpace(cleaned))
                {
                    continue;
                }

                output.Add(cleaned);
                if (output.Count >= sentenceLimit)
                {
                    break;
                }
            }

            return output;
        }

        private static string ExtractOutcomeSummary(string text)
        {
            string normalized = CleanBlock(text, 5000);
            if (string.IsNullOrWhiteSpace(normalized))
            {
                return string.Empty;
            }

            string[] preferredHeaders = { "Summary", "Status", "Message", "Actions", "Notes" };
            foreach (string header in preferredHeaders)
            {
                string section = ExtractSection(normalized, header);
                if (!string.IsNullOrWhiteSpace(section))
                {
                    return CleanText(section, 700);
                }
            }

            string[] lines = normalized.Split('\n');
            foreach (string line in lines)
            {
                string cleaned = CleanText(line, 700);
                if (!string.IsNullOrWhiteSpace(cleaned) &&
                    !cleaned.StartsWith("Activity", StringComparison.OrdinalIgnoreCase) &&
                    !cleaned.StartsWith("-", StringComparison.Ordinal))
                {
                    return cleaned;
                }
            }

            return CleanText(normalized, 700);
        }

        private static string ExtractSection(string text, string header)
        {
            string[] lines = text.Split('\n');
            for (int i = 0; i < lines.Length; i++)
            {
                string trimmedLine = lines[i].Trim();
                string inlinePrefix = header + ":";
                if (trimmedLine.StartsWith(inlinePrefix, StringComparison.OrdinalIgnoreCase))
                {
                    string inlineValue = trimmedLine.Substring(inlinePrefix.Length).Trim();
                    if (!string.IsNullOrWhiteSpace(inlineValue))
                    {
                        return inlineValue;
                    }
                }

                if (!string.Equals(trimmedLine.TrimEnd(':'), header, StringComparison.OrdinalIgnoreCase))
                {
                    continue;
                }

                StringBuilder builder = new StringBuilder();
                for (int j = i + 1; j < lines.Length; j++)
                {
                    string trimmed = lines[j].Trim();
                    if (trimmed.Length == 0)
                    {
                        if (builder.Length > 0)
                        {
                            break;
                        }

                        continue;
                    }

                    if (IsLikelyHeader(trimmed) && builder.Length > 0)
                    {
                        break;
                    }

                    builder.AppendLine(trimmed);
                }

                return builder.ToString().Trim();
            }

            return string.Empty;
        }

        private static bool IsLowValueOutcome(string value)
        {
            string text = CleanText(value, 700);
            if (string.IsNullOrWhiteSpace(text))
            {
                return true;
            }

            if (string.Equals(text, "[sensitive redacted]", StringComparison.OrdinalIgnoreCase))
            {
                return true;
            }

            if (Regex.IsMatch(text, @"^(status:\s*)?(answered|finished|canceled)\.?$", RegexOptions.IgnoreCase))
            {
                return true;
            }

            if (Regex.IsMatch(text, @"^(status:\s*)?waiting for your approval\b", RegexOptions.IgnoreCase))
            {
                return true;
            }

            if (Regex.IsMatch(text, @"^(status:\s*)?(finished\.\s*)?(no unity actions (?:were|have been) applied|unity actions were applied)\.?$", RegexOptions.IgnoreCase))
            {
                return true;
            }

            if (Regex.IsMatch(text, @"please specify what you would like me to do", RegexOptions.IgnoreCase))
            {
                return true;
            }

            return false;
        }

        private static bool IsLikelyHeader(string value)
        {
            string trimmed = value.Trim().TrimEnd(':');
            return Regex.IsMatch(trimmed, @"^(Activity|Status|Summary|Plan|Progress|Actions|Tool calls|Executed tool calls|Notes)$", RegexOptions.IgnoreCase);
        }

        private static void AppendRecentChat(StringBuilder builder, long ignoreBeforeUtcTicks)
        {
            List<AgenticChatStore.Message> messages = AgenticChatStore.Load();
            builder.AppendLine("- recent chat history:");
            List<AgenticChatStore.Message> visibleMessages = new List<AgenticChatStore.Message>();
            foreach (AgenticChatStore.Message message in messages)
            {
                if (ignoreBeforeUtcTicks > 0 &&
                    message != null &&
                    message.timestampUtcTicks > 0 &&
                    message.timestampUtcTicks <= ignoreBeforeUtcTicks)
                {
                    continue;
                }

                visibleMessages.Add(message);
            }

            if (visibleMessages.Count == 0)
            {
                builder.AppendLine("  - none");
                return;
            }

            int start = Math.Max(0, visibleMessages.Count - MaxRecentMessages);
            for (int i = start; i < visibleMessages.Count; i++)
            {
                AgenticChatStore.Message message = visibleMessages[i];
                string author = CleanText(message?.author, 40);
                string text = CleanText(message?.text, 700);
                if (!string.IsNullOrWhiteSpace(text))
                {
                    builder.AppendLine($"  - {author}: {RedactSensitive(text)}");
                }
            }
        }

        private static void AppendMemoryLine(StringBuilder builder, string label, string value)
        {
            if (!string.IsNullOrWhiteSpace(value))
            {
                builder.AppendLine($"  - {label}: {value}");
            }
        }

        private static void AppendMemoryList(StringBuilder builder, string label, string[] values, int limit)
        {
            values = Unique(values, limit);
            if (values.Length == 0)
            {
                return;
            }

            builder.AppendLine($"  - {label}:");
            foreach (string value in values)
            {
                builder.AppendLine($"    - {value}");
            }
        }

        private static MemoryState Load()
        {
            string path = GetStorePath();
            if (!File.Exists(path))
            {
                return CreateEmptyState();
            }

            try
            {
                MemoryState parsed = JsonUtility.FromJson<MemoryState>(File.ReadAllText(path));
                if (parsed == null)
                {
                    return CreateEmptyState();
                }

            parsed.events = parsed.events ?? new MemoryEvent[0];
            parsed.memories = parsed.memories ?? new MemoryRecord[0];
            parsed.activeTask = NormalizeTask(parsed.activeTask);
            parsed.ignoreChatHistoryBeforeUtcTicks = Math.Max(0, parsed.ignoreChatHistoryBeforeUtcTicks);
            return parsed;
            }
            catch (Exception exception)
            {
                Debug.LogWarning($"Could not load Ark memory: {exception.Message}");
                return CreateEmptyState();
            }
        }

        private static void Save(MemoryState state)
        {
            string path = GetStorePath();
            Directory.CreateDirectory(Path.GetDirectoryName(path) ?? string.Empty);
            state.version = CurrentVersion;
            state.updatedAtUtcTicks = DateTime.UtcNow.Ticks;
            File.WriteAllText(path, JsonUtility.ToJson(state, true));
        }

        private static MemoryState CreateEmptyState()
        {
            long now = DateTime.UtcNow.Ticks;
            return new MemoryState
            {
                version = CurrentVersion,
                createdAtUtcTicks = now,
                updatedAtUtcTicks = now,
                events = new MemoryEvent[0],
                memories = new MemoryRecord[0],
                activeTask = NormalizeTask(null)
            };
        }

        private static ActiveTask NormalizeTask(ActiveTask task)
        {
            long now = DateTime.UtcNow.Ticks;
            if (task == null)
            {
                return new ActiveTask
                {
                    status = "idle",
                    goal = string.Empty,
                    currentState = string.Empty,
                    importantConstraints = new string[0],
                    decisions = new string[0],
                    openThreads = new string[0],
                    recentlyTried = new string[0],
                    nextStep = "Wait for the next user request.",
                    createdAtUtcTicks = now,
                    updatedAtUtcTicks = now
                };
            }

            task.status = CleanText(task.status, 40);
            task.goal = SafeMemoryText(task.goal, 700);
            task.currentState = SafeMemoryText(task.currentState, 700);
            task.importantConstraints = Unique(task.importantConstraints, 8);
            task.decisions = Unique(task.decisions, 8);
            task.openThreads = Unique(task.openThreads, 8);
            task.recentlyTried = Unique(task.recentlyTried, 8);
            task.nextStep = SafeMemoryText(task.nextStep, 500);
            task.createdAtUtcTicks = task.createdAtUtcTicks <= 0 ? now : task.createdAtUtcTicks;
            task.updatedAtUtcTicks = task.updatedAtUtcTicks <= 0 ? now : task.updatedAtUtcTicks;
            return task;
        }

        private static string EventText(MemoryEvent memoryEvent)
        {
            return CleanBlock(string.Join("\n", new[]
            {
                memoryEvent.text,
                memoryEvent.prompt,
                memoryEvent.summary,
                memoryEvent.outcome
            }), 5000);
        }

        private static List<string> Tokenize(string value, int limit)
        {
            MatchCollection matches = Regex.Matches((value ?? string.Empty).ToLowerInvariant(), @"[a-z0-9][a-z0-9_-]{2,}");
            List<string> tokens = new List<string>();
            foreach (Match match in matches)
            {
                string token = match.Value;
                if (StopWords.Contains(token))
                {
                    continue;
                }

                tokens.Add(token);
                if (tokens.Count >= limit)
                {
                    break;
                }
            }

            return tokens;
        }

        private static string[] TopTokens(string value, int limit)
        {
            Dictionary<string, int> counts = new Dictionary<string, int>(StringComparer.OrdinalIgnoreCase);
            foreach (string token in Tokenize(value, 3000))
            {
                counts[token] = counts.TryGetValue(token, out int count) ? count + 1 : 1;
            }

            List<KeyValuePair<string, int>> pairs = new List<KeyValuePair<string, int>>(counts);
            pairs.Sort((left, right) => right.Value.CompareTo(left.Value));
            List<string> output = new List<string>();
            foreach (KeyValuePair<string, int> pair in pairs)
            {
                output.Add(pair.Key);
                if (output.Count >= limit)
                {
                    break;
                }
            }

            return output.ToArray();
        }

        private static string EntityId(string type, string value)
        {
            string cleanType = Slugify(type, "entity");
            string cleanValue = Slugify(value, "default");
            return $"{cleanType}:{cleanValue}";
        }

        private static string Slugify(string value, string fallback)
        {
            string slug = CleanText(value, 240).ToLowerInvariant();
            slug = Regex.Replace(slug, @"['""]", string.Empty);
            slug = Regex.Replace(slug, @"[^a-z0-9._-]+", "-");
            slug = slug.Trim('-');
            if (slug.Length > 120)
            {
                slug = slug.Substring(0, 120);
            }

            return string.IsNullOrWhiteSpace(slug) ? fallback : slug;
        }

        private static bool ContainsEntity(MemoryRecord memory, string entity)
        {
            if (string.IsNullOrWhiteSpace(entity) || memory == null)
            {
                return false;
            }

            if (string.Equals(memory.entity, entity, StringComparison.OrdinalIgnoreCase))
            {
                return true;
            }

            foreach (string candidate in memory.entities ?? new string[0])
            {
                if (string.Equals(candidate, entity, StringComparison.OrdinalIgnoreCase))
                {
                    return true;
                }
            }

            return false;
        }

        private static string[] MergeUnique(string[] first, string[] second, int limit)
        {
            List<string> values = new List<string>();
            if (first != null)
            {
                values.AddRange(first);
            }

            if (second != null)
            {
                values.AddRange(second);
            }

            return Unique(values, limit);
        }

        private static string[] AddUnique(string[] values, string value, int limit)
        {
            List<string> list = new List<string>(values ?? new string[0]);
            AddUnique(list, value, limit);
            return list.ToArray();
        }

        private static void AddUnique(List<string> values, string value, int limit)
        {
            string text = SafeMemoryText(value, 500);
            if (string.IsNullOrWhiteSpace(text))
            {
                return;
            }

            string key = NormalizedContentKey(text);
            values.RemoveAll(item => string.Equals(NormalizedContentKey(item), key, StringComparison.Ordinal));
            values.Add(text);
            TrimFromStart(values, limit);
        }

        private static string[] Unique(IEnumerable<string> values, int limit)
        {
            HashSet<string> seen = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
            List<string> output = new List<string>();
            if (values == null)
            {
                return output.ToArray();
            }

            foreach (string value in values)
            {
                string clean = SafeMemoryText(value, 500);
                string key = NormalizedContentKey(clean);
                if (string.IsNullOrWhiteSpace(clean) || seen.Contains(key))
                {
                    continue;
                }

                seen.Add(key);
                output.Add(clean);
                if (output.Count >= limit)
                {
                    break;
                }
            }

            return output.ToArray();
        }

        private static void TrimFromStart<T>(List<T> values, int max)
        {
            if (values.Count > max)
            {
                values.RemoveRange(0, values.Count - max);
            }
        }

        private static string NormalizedContentKey(string value)
        {
            string clean = CleanText(value, 1000).ToLowerInvariant();
            clean = Regex.Replace(clean, @"[^a-z0-9]+", " ");
            return clean.Trim();
        }

        private static string SafeMemoryText(string value, int limit)
        {
            string text = CleanText(value, limit);
            if (string.IsNullOrWhiteSpace(text))
            {
                return string.Empty;
            }

            return SensitiveRegex.IsMatch(text) ? "[sensitive redacted]" : RedactSensitive(text);
        }

        private static string SafeMemoryBlock(string value, int limit)
        {
            string text = CleanBlock(value, limit);
            if (string.IsNullOrWhiteSpace(text))
            {
                return string.Empty;
            }

            return SensitiveRegex.IsMatch(text) ? "[sensitive redacted]" : RedactSensitive(text);
        }

        private static string RedactSensitive(string value)
        {
            string text = value ?? string.Empty;
            text = Regex.Replace(text, @"\b(?:sk|pk|rk|xox[baprs]?|gh[pousr]|github_pat)_[A-Za-z0-9_=-]{12,}\b", "[redacted-token]");
            text = Regex.Replace(text, @"\b(?:api[_ -]?key|access[_ -]?token|refresh[_ -]?token|password|passwd|secret)\s*[:=]\s*[""']?[^""'\s]{6,}", "$1: [redacted]", RegexOptions.IgnoreCase);
            text = Regex.Replace(text, @"\b\d{13,19}\b", "[redacted-number]");
            text = Regex.Replace(text, @"\b\d{3}-\d{2}-\d{4}\b", "[redacted-ssn]");
            return text;
        }

        private static string CleanText(string value, int limit)
        {
            string text = Regex.Replace(value ?? string.Empty, @"\s+", " ").Trim();
            return text.Length > limit ? text.Substring(0, limit) : text;
        }

        private static string CleanBlock(string value, int limit)
        {
            string text = (value ?? string.Empty).Replace("\r\n", "\n").Replace('\r', '\n').Replace("\0", string.Empty);
            text = Regex.Replace(text, @"\n{4,}", "\n\n\n").Trim();
            return text.Length > limit ? text.Substring(0, limit) : text;
        }

        private static int SafeLength<T>(T[] values)
        {
            return values == null ? 0 : values.Length;
        }

        private static string StableHash(string value)
        {
            unchecked
            {
                uint hash = 2166136261;
                foreach (char character in value ?? string.Empty)
                {
                    hash ^= character;
                    hash *= 16777619;
                }

                return hash.ToString("x8");
            }
        }

        private static string FormatNumber(double value)
        {
            return value.ToString("0.###", System.Globalization.CultureInfo.InvariantCulture);
        }

        private static string FormatTicks(long ticks)
        {
            if (ticks <= 0)
            {
                return "unknown";
            }

            return new DateTime(ticks, DateTimeKind.Utc).ToString("yyyy-MM-dd HH:mm:ss 'UTC'");
        }

        private static string GetStorePath()
        {
            string projectRoot = Path.GetDirectoryName(Application.dataPath) ?? Directory.GetCurrentDirectory();
            return Path.Combine(projectRoot, "Library", "AgenticGamedev", "memory.json");
        }

        private static string RelativeStorePath()
        {
            return "Library/AgenticGamedev/memory.json";
        }

        private sealed class RecallBundle
        {
            public ActiveTask activeTask;
            public List<ScoredMemory> relevantMemories = new List<ScoredMemory>();
            public string[] openThreads = new string[0];
        }

        private sealed class ScoredMemory
        {
            public readonly MemoryRecord record;
            public readonly double score;

            public ScoredMemory(MemoryRecord record, double score)
            {
                this.record = record;
                this.score = score;
            }
        }

        [Serializable]
        private sealed class MemoryState
        {
            public int version;
            public long createdAtUtcTicks;
            public long updatedAtUtcTicks;
            public long ignoreChatHistoryBeforeUtcTicks;
            public MemoryEvent[] events;
            public MemoryRecord[] memories;
            public ActiveTask activeTask;
        }

        [Serializable]
        private sealed class MemoryEvent
        {
            public string id;
            public string role;
            public string kind;
            public string source;
            public string chatId;
            public string projectId;
            public string sceneName;
            public string scenePath;
            public string text;
            public string prompt;
            public string summary;
            public string outcome;
            public long createdAtUtcTicks;
        }

        [Serializable]
        private sealed class MemoryRecord
        {
            public string id;
            public string type;
            public string entity;
            public string[] entities;
            public string scope;
            public string content;
            public string source;
            public double confidence;
            public string[] tags;
            public string[] evidence;
            public long createdAtUtcTicks;
            public long updatedAtUtcTicks;
            public int seenCount;
            public bool deleted = false;
        }

        [Serializable]
        private sealed class ActiveTask
        {
            public string status;
            public string goal;
            public string currentState;
            public string[] importantConstraints;
            public string[] decisions;
            public string[] openThreads;
            public string[] recentlyTried;
            public string nextStep;
            public long createdAtUtcTicks;
            public long updatedAtUtcTicks;
        }
    }

    internal static class AgenticMemoryListExtensions
    {
        public static List<T> GetRangeSafe<T>(this List<T> source, int index, int count)
        {
            if (source == null || source.Count == 0 || count <= 0 || index >= source.Count)
            {
                return new List<T>();
            }

            int safeIndex = Math.Max(0, index);
            int safeCount = Math.Min(count, source.Count - safeIndex);
            return source.GetRange(safeIndex, safeCount);
        }
    }
}
