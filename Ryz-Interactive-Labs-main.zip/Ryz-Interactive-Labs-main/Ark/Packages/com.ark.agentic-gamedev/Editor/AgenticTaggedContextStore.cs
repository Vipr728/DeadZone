using System;
using System.Collections.Generic;
using System.IO;
using System.Text;
using UnityEditor;
using UnityEngine;
using UnityEngine.SceneManagement;
using Object = UnityEngine.Object;

namespace AgenticGamedev.EditorTools
{
    internal static class AgenticTaggedContextStore
    {
        private const int CurrentVersion = 1;
        private const int MaxTaggedItems = 32;

        public static event Action Changed;

        [MenuItem("Tools/Ark/Context/Tag Selection")]
        private static void TagSelectionFromMenu()
        {
            int added = AddObjects(Selection.objects);
            Debug.Log(added == 1
                ? "Tagged 1 item for Ark context."
                : $"Tagged {added} items for Ark context.");
        }

        [MenuItem("Tools/Ark/Context/Tag Selection", true)]
        private static bool CanTagSelectionFromMenu()
        {
            return Selection.objects != null && Selection.objects.Length > 0;
        }

        [MenuItem("Tools/Ark/Context/Clear Tagged Context")]
        private static void ClearFromMenu()
        {
            Clear();
            Debug.Log("Cleared Ark tagged context.");
        }

        public static List<TaggedItem> Load()
        {
            string path = GetStorePath();
            if (!File.Exists(path))
            {
                return new List<TaggedItem>();
            }

            try
            {
                TaggedContextState state = JsonUtility.FromJson<TaggedContextState>(File.ReadAllText(path));
                if (state?.items == null)
                {
                    return new List<TaggedItem>();
                }

                return new List<TaggedItem>(state.items);
            }
            catch (Exception exception)
            {
                Debug.LogWarning($"Could not load Ark tagged context: {exception.Message}");
                return new List<TaggedItem>();
            }
        }

        public static int AddObjects(IEnumerable<Object> objects)
        {
            if (objects == null)
            {
                return 0;
            }

            List<TaggedItem> items = Load();
            int added = 0;
            foreach (Object unityObject in objects)
            {
                if (unityObject == null)
                {
                    continue;
                }

                TaggedItem item = CreateItem(unityObject);
                if (string.IsNullOrWhiteSpace(item.id))
                {
                    continue;
                }

                int existingIndex = items.FindIndex(existing => string.Equals(existing.id, item.id, StringComparison.Ordinal));
                if (existingIndex >= 0)
                {
                    items[existingIndex] = item;
                }
                else
                {
                    items.Insert(0, item);
                    added++;
                }
            }

            if (items.Count > MaxTaggedItems)
            {
                items.RemoveRange(MaxTaggedItems, items.Count - MaxTaggedItems);
            }

            Save(items);
            NotifyChanged();
            return added;
        }

        public static bool AddObject(Object unityObject)
        {
            return AddObjects(new[] { unityObject }) > 0;
        }

        public static void Remove(string id)
        {
            if (string.IsNullOrWhiteSpace(id))
            {
                return;
            }

            List<TaggedItem> items = Load();
            items.RemoveAll(item => string.Equals(item.id, id, StringComparison.Ordinal));
            Save(items);
            NotifyChanged();
        }

        public static void Clear()
        {
            string path = GetStorePath();
            if (File.Exists(path))
            {
                File.Delete(path);
            }

            NotifyChanged();
        }

        public static Object Resolve(TaggedItem item)
        {
            if (item == null)
            {
                return null;
            }

            if (!string.IsNullOrWhiteSpace(item.guid))
            {
                string path = AssetDatabase.GUIDToAssetPath(item.guid);
                Object resolved = ResolveAssetAtPath(path, item);
                if (resolved != null)
                {
                    return resolved;
                }
            }

            if (!string.IsNullOrWhiteSpace(item.assetPath))
            {
                Object resolved = ResolveAssetAtPath(item.assetPath, item);
                if (resolved != null)
                {
                    return resolved;
                }
            }

            if (!string.IsNullOrWhiteSpace(item.globalObjectId) &&
                GlobalObjectId.TryParse(item.globalObjectId, out GlobalObjectId globalObjectId))
            {
                Object resolved = GlobalObjectId.GlobalObjectIdentifierToObjectSlow(globalObjectId);
                if (resolved != null)
                {
                    return resolved;
                }
            }

            if (!string.IsNullOrWhiteSpace(item.hierarchyPath))
            {
                GameObject gameObject = FindSceneObject(item.hierarchyPath);
                if (gameObject != null)
                {
                    return gameObject;
                }
            }

            return null;
        }

        public static bool PingAndSelect(TaggedItem item)
        {
            Object resolved = Resolve(item);
            if (resolved == null)
            {
                return false;
            }

            Selection.activeObject = resolved;
            EditorGUIUtility.PingObject(resolved);
            return true;
        }

        public static string BuildContextSection()
        {
            List<TaggedItem> items = Load();
            StringBuilder builder = new StringBuilder();
            builder.AppendLine("Tagged context:");
            builder.AppendLine("- contract: these are user-tagged objects/assets for the agent to prioritize when the prompt is ambiguous; do not treat them as Unity tag/layer changes.");

            if (items.Count == 0)
            {
                builder.AppendLine("- none");
                return builder.ToString().TrimEnd();
            }

            int count = Mathf.Min(items.Count, MaxTaggedItems);
            for (int i = 0; i < count; i++)
            {
                TaggedItem item = items[i];
                Object resolved = Resolve(item);
                builder.AppendLine(FormatContextLine(item, resolved));
            }

            if (items.Count > count)
            {
                builder.AppendLine($"- ... {items.Count - count} more tagged item(s)");
            }

            return builder.ToString().TrimEnd();
        }

        public static string GetDisplayText(TaggedItem item)
        {
            if (item == null)
            {
                return "Missing";
            }

            string name = string.IsNullOrWhiteSpace(item.displayName) ? "Unnamed" : item.displayName;
            string kind = string.IsNullOrWhiteSpace(item.kind) ? "Object" : item.kind;
            return $"{kind}: {name}";
        }

        private static TaggedItem CreateItem(Object unityObject)
        {
            string assetPath = AssetDatabase.GetAssetPath(unityObject);
            bool isAsset = !string.IsNullOrWhiteSpace(assetPath);
            TaggedItem item = new TaggedItem
            {
                displayName = unityObject.name,
                objectType = unityObject.GetType().FullName,
                assetPath = assetPath,
                guid = isAsset ? AssetDatabase.AssetPathToGUID(assetPath) : string.Empty,
                scenePath = string.Empty,
                hierarchyPath = string.Empty,
                globalObjectId = string.Empty,
                kind = GetKind(unityObject, assetPath),
                timestampUtcTicks = DateTime.UtcNow.Ticks
            };

            if (isAsset)
            {
                string guidPart = string.IsNullOrWhiteSpace(item.guid) ? assetPath : item.guid;
                item.id = $"asset:{guidPart}:{item.objectType}:{item.displayName}";
                return item;
            }

            if (unityObject is Component component)
            {
                item.scenePath = component.gameObject.scene.path;
                item.hierarchyPath = GetHierarchyPath(component.gameObject);
            }
            else if (unityObject is GameObject gameObject)
            {
                item.scenePath = gameObject.scene.path;
                item.hierarchyPath = GetHierarchyPath(gameObject);
            }

            GlobalObjectId globalObjectId = GlobalObjectId.GetGlobalObjectIdSlow(unityObject);
            item.globalObjectId = globalObjectId.ToString();
            item.id = string.IsNullOrWhiteSpace(item.globalObjectId)
                ? $"scene:{item.scenePath}:{item.hierarchyPath}:{item.objectType}:{item.displayName}"
                : $"scene:{item.globalObjectId}";
            return item;
        }

        private static string GetKind(Object unityObject, string assetPath)
        {
            if (unityObject is MonoScript)
            {
                return "Script";
            }

            if (unityObject is Component)
            {
                return "Scene Component";
            }

            if (unityObject is GameObject gameObject)
            {
                if (!string.IsNullOrWhiteSpace(assetPath))
                {
                    PrefabAssetType prefabType = PrefabUtility.GetPrefabAssetType(gameObject);
                    return prefabType == PrefabAssetType.NotAPrefab ? "GameObject Asset" : "Prefab";
                }

                return "Scene GameObject";
            }

            if (!string.IsNullOrWhiteSpace(assetPath))
            {
                if (assetPath.EndsWith(".unity", StringComparison.OrdinalIgnoreCase))
                {
                    return "Scene Asset";
                }

                return "Asset";
            }

            return "Object";
        }

        private static Object ResolveAssetAtPath(string path, TaggedItem item)
        {
            if (string.IsNullOrWhiteSpace(path))
            {
                return null;
            }

            Object direct = AssetDatabase.LoadAssetAtPath<Object>(path);
            if (Matches(direct, item))
            {
                return direct;
            }

            Object[] assets = AssetDatabase.LoadAllAssetsAtPath(path);
            foreach (Object asset in assets)
            {
                if (Matches(asset, item))
                {
                    return asset;
                }
            }

            return direct;
        }

        private static bool Matches(Object unityObject, TaggedItem item)
        {
            if (unityObject == null || item == null)
            {
                return false;
            }

            bool nameMatches = string.IsNullOrWhiteSpace(item.displayName) ||
                string.Equals(unityObject.name, item.displayName, StringComparison.Ordinal);
            bool typeMatches = string.IsNullOrWhiteSpace(item.objectType) ||
                string.Equals(unityObject.GetType().FullName, item.objectType, StringComparison.Ordinal);
            return nameMatches && typeMatches;
        }

        private static string FormatContextLine(TaggedItem item, Object resolved)
        {
            string prefix = resolved == null ? "- [Missing] " : "- ";
            StringBuilder builder = new StringBuilder(prefix);
            builder.Append('[');
            builder.Append(string.IsNullOrWhiteSpace(item.kind) ? "Object" : item.kind);
            builder.Append("] ");
            builder.Append(string.IsNullOrWhiteSpace(item.displayName) ? "Unnamed" : item.displayName);

            if (!string.IsNullOrWhiteSpace(item.assetPath))
            {
                builder.Append($" path={item.assetPath}");
            }

            if (!string.IsNullOrWhiteSpace(item.scenePath))
            {
                builder.Append($" scene={item.scenePath}");
            }

            if (!string.IsNullOrWhiteSpace(item.hierarchyPath))
            {
                builder.Append($" hierarchy={item.hierarchyPath}");
            }

            if (!string.IsNullOrWhiteSpace(item.objectType))
            {
                builder.Append($" type={item.objectType}");
            }

            if (resolved is GameObject gameObject)
            {
                builder.Append(FormatGameObjectSummary(gameObject));
            }
            else if (resolved is Component component)
            {
                builder.Append($" componentHost={GetHierarchyPath(component.gameObject)}");
            }
            else if (resolved is MonoScript monoScript)
            {
                Type scriptClass = monoScript.GetClass();
                if (scriptClass != null)
                {
                    builder.Append($" class={scriptClass.FullName}");
                }
            }

            return builder.ToString();
        }

        private static string FormatGameObjectSummary(GameObject gameObject)
        {
            List<string> components = new List<string>();
            foreach (Component component in gameObject.GetComponents<Component>())
            {
                if (component == null || component is Transform)
                {
                    continue;
                }

                components.Add(component.GetType().Name);
            }

            string active = $" activeSelf={gameObject.activeSelf} activeInHierarchy={gameObject.activeInHierarchy}";
            string componentSummary = components.Count == 0 ? string.Empty : $" components={string.Join(",", components.ToArray())}";
            return active + componentSummary;
        }

        private static GameObject FindSceneObject(string hierarchyPath)
        {
            if (string.IsNullOrWhiteSpace(hierarchyPath))
            {
                return null;
            }

            Scene scene = SceneManager.GetActiveScene();
            foreach (GameObject root in scene.GetRootGameObjects())
            {
                GameObject found = FindInChildren(root.transform, hierarchyPath);
                if (found != null)
                {
                    return found;
                }
            }

            return null;
        }

        private static GameObject FindInChildren(Transform transform, string hierarchyPath)
        {
            if (string.Equals(transform.name, hierarchyPath, StringComparison.OrdinalIgnoreCase) ||
                string.Equals(GetHierarchyPath(transform.gameObject), hierarchyPath, StringComparison.OrdinalIgnoreCase))
            {
                return transform.gameObject;
            }

            for (int i = 0; i < transform.childCount; i++)
            {
                GameObject found = FindInChildren(transform.GetChild(i), hierarchyPath);
                if (found != null)
                {
                    return found;
                }
            }

            return null;
        }

        private static string GetHierarchyPath(GameObject gameObject)
        {
            if (gameObject == null)
            {
                return string.Empty;
            }

            Stack<string> parts = new Stack<string>();
            Transform current = gameObject.transform;
            while (current != null)
            {
                parts.Push(current.name);
                current = current.parent;
            }

            return string.Join("/", parts.ToArray());
        }

        private static void Save(IReadOnlyList<TaggedItem> items)
        {
            string path = GetStorePath();
            Directory.CreateDirectory(Path.GetDirectoryName(path) ?? string.Empty);
            TaggedContextState state = new TaggedContextState
            {
                version = CurrentVersion,
                items = CopyItems(items)
            };

            File.WriteAllText(path, JsonUtility.ToJson(state, true));
        }

        private static TaggedItem[] CopyItems(IReadOnlyList<TaggedItem> items)
        {
            TaggedItem[] copy = new TaggedItem[items.Count];
            for (int i = 0; i < items.Count; i++)
            {
                copy[i] = items[i];
            }

            return copy;
        }

        private static string GetStorePath()
        {
            string projectRoot = Path.GetDirectoryName(Application.dataPath) ?? Directory.GetCurrentDirectory();
            return Path.Combine(projectRoot, "Library", "AgenticGamedev", "tagged-context.json");
        }

        private static void NotifyChanged()
        {
            Changed?.Invoke();
        }

        [Serializable]
        public sealed class TaggedItem
        {
            public string id;
            public string displayName;
            public string kind;
            public string objectType;
            public string assetPath;
            public string guid;
            public string scenePath;
            public string hierarchyPath;
            public string globalObjectId;
            public long timestampUtcTicks;
        }

        [Serializable]
        private sealed class TaggedContextState
        {
            public int version;
            public TaggedItem[] items;
        }
    }
}
