using System;
using System.Collections.Generic;
using System.IO;
using UnityEngine;

namespace AgenticGamedev.EditorTools
{
    internal static class AgenticChatStore
    {
        private const int CurrentVersion = 2;

        public static List<Message> Load()
        {
            string path = GetStorePath();
            if (!File.Exists(path))
            {
                return new List<Message>();
            }

            try
            {
                ChatState state = JsonUtility.FromJson<ChatState>(File.ReadAllText(path));
                if (state?.messages == null)
                {
                    return new List<Message>();
                }

                return new List<Message>(state.messages);
            }
            catch (Exception exception)
            {
                Debug.LogWarning($"Could not load Ark chat history: {exception.Message}");
                return new List<Message>();
            }
        }

        public static void Save(IReadOnlyList<Message> messages)
        {
            string path = GetStorePath();
            Directory.CreateDirectory(Path.GetDirectoryName(path) ?? string.Empty);

            ChatState state = new ChatState
            {
                version = CurrentVersion,
                messages = CopyMessages(messages)
            };

            File.WriteAllText(path, JsonUtility.ToJson(state, true));
        }

        public static void Clear()
        {
            string path = GetStorePath();
            if (File.Exists(path))
            {
                File.Delete(path);
            }
        }

        private static Message[] CopyMessages(IReadOnlyList<Message> messages)
        {
            Message[] copy = new Message[messages.Count];
            for (int i = 0; i < messages.Count; i++)
            {
                copy[i] = messages[i];
            }

            return copy;
        }

        private static string GetStorePath()
        {
            string projectRoot = Path.GetDirectoryName(Application.dataPath) ?? Directory.GetCurrentDirectory();
            return Path.Combine(projectRoot, "Library", "AgenticGamedev", "chat-history.json");
        }

        [Serializable]
        public sealed class Message
        {
            public string author;
            public string text;
            public long timestampUtcTicks;
            public string undoSnapshotId;
            public long undoSnapshotCreatedUtcTicks;
            public long undoSnapshotRestoredUtcTicks;
            public bool undoSnapshotPending;
            public string undoSnapshotError;

            public Message()
            {
            }

            public Message(string author, string text)
            {
                this.author = author;
                this.text = text;
                timestampUtcTicks = DateTime.UtcNow.Ticks;
            }
        }

        [Serializable]
        private sealed class ChatState
        {
            public int version;
            public Message[] messages;
        }
    }
}
