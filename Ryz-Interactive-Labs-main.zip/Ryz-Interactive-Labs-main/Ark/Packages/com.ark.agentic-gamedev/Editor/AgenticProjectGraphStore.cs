using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Globalization;
using System.IO;
using System.Text;
using System.Text.RegularExpressions;
using UnityEditor;
using UnityEditor.Animations;
using UnityEngine;
using UnityEngine.SceneManagement;
using Debug = UnityEngine.Debug;
using Object = UnityEngine.Object;

namespace AgenticGamedev.EditorTools
{
    internal static class AgenticProjectGraphStore
    {
        private const int CurrentVersion = 1;
        private const int MaxContextNodes = 28;
        private const int MaxContextEdges = 42;
        private const int MaxGraphNodes = 20000;
        private const int MaxGraphEdges = 60000;
        private const int GitCommitLimit = 30;
        private const int SourceReadLimit = 240000;

        private static readonly Regex ClassRegex = new Regex(@"\b(?:public|private|internal|protected|sealed|abstract|partial|static|\s)*\b(?:class|struct|interface|enum)\s+([A-Za-z_][A-Za-z0-9_]*)", RegexOptions.Compiled);
        private static readonly Regex MethodRegex = new Regex(@"\b(?:public|private|internal|protected|static|virtual|override|sealed|async|extern|unsafe|new|\s)+[A-Za-z_][A-Za-z0-9_<>,\[\].?]*\s+([A-Za-z_][A-Za-z0-9_]*)\s*\([^;{}]*\)\s*(?:where\s+[^{]+)?\{", RegexOptions.Compiled);
        private static readonly Regex UnityEventFieldRegex = new Regex(@"\b(?:UnityEvent|UnityEvent<[^>]+>)\s+([A-Za-z_][A-Za-z0-9_]*)\b", RegexOptions.Compiled);
        private static readonly Regex AddressablesLoadRegex = new Regex(@"\bAddressables\.(?:LoadAssetAsync|LoadAssetsAsync|InstantiateAsync|DownloadDependenciesAsync|LoadResourceLocationsAsync)\s*(?:<[^>]+>)?\s*\(\s*[""']([^""']+)[""']", RegexOptions.Compiled);
        private static readonly Regex InputActionNameRegex = new Regex(@"""name""\s*:\s*""([^""]+)""", RegexOptions.Compiled);
        private static readonly Regex GuidRegex = new Regex(@"guid:\s*([0-9a-fA-F]{32})", RegexOptions.Compiled);
        private static readonly Regex SensitiveRegex = new Regex(@"\b(?:api[_ -]?key|access[_ -]?token|refresh[_ -]?token|password|passwd|secret|bearer\s+[a-z0-9._-]+|sk-[a-z0-9_-]{12,}|gh[pousr]_[a-z0-9_]{12,})\b", RegexOptions.IgnoreCase | RegexOptions.Compiled);

        [MenuItem("Tools/Ark/Project Graph/Copy Context")]
        private static void CopyProjectGraphContext()
        {
            EditorGUIUtility.systemCopyBuffer = BuildContextSection(string.Empty);
            Debug.Log("Copied Ark deterministic project graph context.");
        }

        [MenuItem("Tools/Ark/Project Graph/Rebuild")]
        private static void RebuildProjectGraph()
        {
            ProjectGraph graph = BuildGraph();
            Save(graph);
            Debug.Log($"Rebuilt Ark deterministic project graph: {SafeLength(graph.nodes)} nodes, {SafeLength(graph.edges)} edges.");
        }

        public static string BuildContextSection(string currentPrompt)
        {
            ProjectGraph graph = BuildGraph();
            Save(graph);
            return FormatContext(graph, currentPrompt);
        }

        private static ProjectGraph BuildGraph()
        {
            GraphBuilder builder = new GraphBuilder();
            string projectRoot = GetProjectRoot();
            Scene activeScene = SceneManager.GetActiveScene();

            builder.Graph.version = CurrentVersion;
            builder.Graph.projectName = Application.productName;
            builder.Graph.unityVersion = Application.unityVersion;
            builder.Graph.projectRoot = projectRoot;
            builder.Graph.activeScene = activeScene.name;
            builder.Graph.activeScenePath = activeScene.path;
            builder.Graph.updatedAtUtcTicks = DateTime.UtcNow.Ticks;

            string projectNode = builder.AddNode("Project", $"project:{Slug(Application.productName)}", Application.productName, string.Empty, string.Empty, "Unity project root");
            BuildPackageGraph(builder);

            string[] assetPaths = AssetDatabase.GetAllAssetPaths();
            Array.Sort(assetPaths, StringComparer.Ordinal);
            foreach (string assetPath in assetPaths)
            {
                if (!IsProjectAssetPath(assetPath))
                {
                    continue;
                }

                string guid = AssetDatabase.AssetPathToGUID(assetPath);
                string extension = Path.GetExtension(assetPath).ToLowerInvariant();
                string nodeId = AddAssetNode(builder, assetPath, guid, extension);
                if (!string.IsNullOrWhiteSpace(nodeId))
                {
                    builder.AddEdge(projectNode, nodeId, "contains_asset", assetPath);
                }
            }

            BuildScriptGraph(builder, assetPaths);
            BuildPrefabGraph(builder, assetPaths);
            BuildLoadedSceneGraph(builder, projectNode);
            BuildSceneYamlPrefabEdges(builder, assetPaths);
            BuildAnimationGraph(builder, assetPaths);
            BuildInputActionGraph(builder, assetPaths);
            BuildMaterialShaderGraph(builder, assetPaths);
            BuildTestCoverageGraph(builder);
            BuildGitCommitGraph(builder, projectRoot);

            builder.FinalizeGraph();
            return builder.Graph;
        }

        private static string AddAssetNode(GraphBuilder builder, string assetPath, string guid, string extension)
        {
            string type = string.Empty;
            string name = Path.GetFileNameWithoutExtension(assetPath);
            if (string.Equals(extension, ".cs", StringComparison.OrdinalIgnoreCase))
            {
                type = "Script";
            }
            else if (string.Equals(extension, ".unity", StringComparison.OrdinalIgnoreCase))
            {
                type = "Scene";
            }
            else if (string.Equals(extension, ".prefab", StringComparison.OrdinalIgnoreCase))
            {
                GameObject prefab = AssetDatabase.LoadAssetAtPath<GameObject>(assetPath);
                PrefabAssetType prefabType = prefab == null ? PrefabAssetType.NotAPrefab : PrefabUtility.GetPrefabAssetType(prefab);
                type = prefabType == PrefabAssetType.Variant ? "Prefab Variant" : "Prefab";
            }
            else if (string.Equals(extension, ".mat", StringComparison.OrdinalIgnoreCase))
            {
                type = "Material";
            }
            else if (string.Equals(extension, ".shader", StringComparison.OrdinalIgnoreCase) || string.Equals(extension, ".shadergraph", StringComparison.OrdinalIgnoreCase))
            {
                type = "Shader";
            }
            else if (string.Equals(extension, ".asset", StringComparison.OrdinalIgnoreCase))
            {
                Object asset = AssetDatabase.LoadMainAssetAtPath(assetPath);
                type = asset is ScriptableObject ? "ScriptableObject" : "Asset";
            }
            else if (string.Equals(extension, ".inputactions", StringComparison.OrdinalIgnoreCase))
            {
                type = "Input Actions";
            }
            else if (string.Equals(extension, ".controller", StringComparison.OrdinalIgnoreCase) || string.Equals(extension, ".overridecontroller", StringComparison.OrdinalIgnoreCase))
            {
                type = "Animator";
            }
            else if (string.Equals(extension, ".anim", StringComparison.OrdinalIgnoreCase))
            {
                type = "AnimationClip";
            }
            else if (IsTestPath(assetPath))
            {
                type = "Test";
            }

            if (string.IsNullOrWhiteSpace(type))
            {
                return string.Empty;
            }

            return builder.AddNode(type, AssetId(type, assetPath, guid), name, assetPath, guid, string.Empty);
        }

        private static void BuildPackageGraph(GraphBuilder builder)
        {
            try
            {
                UnityEditor.PackageManager.PackageInfo[] packages = UnityEditor.PackageManager.PackageInfo.GetAllRegisteredPackages();
                if (packages == null)
                {
                    return;
                }

                Array.Sort(packages, (left, right) => string.Compare(left?.name, right?.name, StringComparison.Ordinal));
                foreach (UnityEditor.PackageManager.PackageInfo package in packages)
                {
                    if (package == null || string.IsNullOrWhiteSpace(package.name))
                    {
                        continue;
                    }

                    string details = JoinNonEmpty(" ", package.version, package.source.ToString(), package.resolvedPath);
                    builder.AddNode("Package", $"package:{Slug(package.name)}", package.name, package.assetPath ?? string.Empty, string.Empty, details);
                }
            }
            catch (Exception exception)
            {
                Debug.LogWarning($"Could not build Ark package graph: {exception.Message}");
            }
        }

        private static void BuildScriptGraph(GraphBuilder builder, string[] assetPaths)
        {
            foreach (string assetPath in assetPaths)
            {
                if (!assetPath.EndsWith(".cs", StringComparison.OrdinalIgnoreCase) || !IsProjectAssetPath(assetPath))
                {
                    continue;
                }

                string guid = AssetDatabase.AssetPathToGUID(assetPath);
                string scriptId = AssetId("Script", assetPath, guid);
                string source = ReadAssetText(assetPath, SourceReadLimit);
                if (string.IsNullOrWhiteSpace(source))
                {
                    continue;
                }

                if (SensitiveRegex.IsMatch(source))
                {
                    source = SensitiveRegex.Replace(source, "[redacted]");
                }

                List<ClassMatch> classMatches = new List<ClassMatch>();
                foreach (Match match in ClassRegex.Matches(source))
                {
                    string className = match.Groups[1].Value;
                    string classId = $"class:{Slug(className)}";
                    classMatches.Add(new ClassMatch { id = classId, index = match.Index });
                    builder.AddNode("Class", classId, className, assetPath, guid, string.Empty);
                    builder.AddEdge(scriptId, classId, "defines", assetPath);
                }

                foreach (Match match in MethodRegex.Matches(source))
                {
                    string methodName = match.Groups[1].Value;
                    if (IsControlKeyword(methodName))
                    {
                        continue;
                    }

                    string owningClassId = FindOwnerClassId(classMatches, match.Index, scriptId);
                    string methodId = $"{owningClassId}.method:{Slug(methodName)}";
                    builder.AddNode("Method", methodId, methodName, assetPath, guid, string.Empty);
                    builder.AddEdge(owningClassId, methodId, "declares", assetPath);
                }

                foreach (Match match in UnityEventFieldRegex.Matches(source))
                {
                    string eventName = match.Groups[1].Value;
                    string eventId = $"unityevent:{Slug(assetPath)}:{Slug(eventName)}";
                    string owningClassId = FindOwnerClassId(classMatches, match.Index, scriptId);
                    builder.AddNode("UnityEvent", eventId, eventName, assetPath, guid, string.Empty);
                    builder.AddEdge(owningClassId, eventId, "declares_unity_event", assetPath);
                }

                AddUnityEventInvocationEdges(builder, classMatches, scriptId, assetPath, guid, source);
                AddAddressableLoadEdges(builder, scriptId, assetPath, guid, source);
            }
        }

        private static string FindOwnerClassId(List<ClassMatch> classMatches, int sourceIndex, string fallback)
        {
            string owner = fallback;
            foreach (ClassMatch classMatch in classMatches)
            {
                if (classMatch.index <= sourceIndex)
                {
                    owner = classMatch.id;
                }
                else
                {
                    break;
                }
            }

            return owner;
        }

        private static void AddUnityEventInvocationEdges(GraphBuilder builder, List<ClassMatch> classMatches, string scriptId, string assetPath, string guid, string source)
        {
            string currentMethodId = string.Empty;
            int sourceOffset = 0;
            string[] lines = source.Replace("\r\n", "\n").Replace('\r', '\n').Split('\n');
            foreach (string rawLine in lines)
            {
                string line = rawLine.Trim();
                Match methodMatch = MethodRegex.Match(line);
                if (methodMatch.Success)
                {
                    string owningClassId = FindOwnerClassId(classMatches, sourceOffset, scriptId);
                    currentMethodId = $"{owningClassId}.method:{Slug(methodMatch.Groups[1].Value)}";
                }

                Match invokeMatch = Regex.Match(line, @"\b([A-Za-z_][A-Za-z0-9_]*)\.Invoke\s*\(");
                if (!invokeMatch.Success || string.IsNullOrWhiteSpace(currentMethodId))
                {
                    sourceOffset += rawLine.Length + 1;
                    continue;
                }

                string eventName = invokeMatch.Groups[1].Value;
                string eventId = $"unityevent:{Slug(assetPath)}:{Slug(eventName)}";
                builder.AddNode("UnityEvent", eventId, eventName, assetPath, guid, string.Empty);
                builder.AddEdge(currentMethodId, eventId, "invokes", assetPath);
                sourceOffset += rawLine.Length + 1;
            }
        }

        private static void AddAddressableLoadEdges(GraphBuilder builder, string scriptId, string assetPath, string guid, string source)
        {
            foreach (Match match in AddressablesLoadRegex.Matches(source))
            {
                string key = match.Groups[1].Value;
                if (string.IsNullOrWhiteSpace(key))
                {
                    continue;
                }

                string addressableId = $"addressable:{Slug(key)}";
                builder.AddNode("Addressable", addressableId, key, string.Empty, string.Empty, "Loaded by source code");
                builder.AddEdge(scriptId, addressableId, "loads_addressable", assetPath);
            }
        }

        private static void BuildPrefabGraph(GraphBuilder builder, string[] assetPaths)
        {
            foreach (string assetPath in assetPaths)
            {
                if (!assetPath.EndsWith(".prefab", StringComparison.OrdinalIgnoreCase) || !IsProjectAssetPath(assetPath))
                {
                    continue;
                }

                string guid = AssetDatabase.AssetPathToGUID(assetPath);
                GameObject prefab = AssetDatabase.LoadAssetAtPath<GameObject>(assetPath);
                if (prefab == null)
                {
                    continue;
                }

                string prefabId = AssetId(PrefabUtility.GetPrefabAssetType(prefab) == PrefabAssetType.Variant ? "Prefab Variant" : "Prefab", assetPath, guid);
                GameObject source = PrefabUtility.GetCorrespondingObjectFromSource(prefab);
                string sourcePath = source == null ? string.Empty : AssetDatabase.GetAssetPath(source);
                if (!string.IsNullOrWhiteSpace(sourcePath))
                {
                    builder.AddEdge(prefabId, AssetId("Prefab", sourcePath, AssetDatabase.AssetPathToGUID(sourcePath)), "variant_of", assetPath);
                }

                TraverseGameObject(builder, prefabId, prefab, assetPath, guid, "prefab");
            }
        }

        private static void BuildLoadedSceneGraph(GraphBuilder builder, string projectNode)
        {
            for (int i = 0; i < SceneManager.sceneCount; i++)
            {
                Scene scene = SceneManager.GetSceneAt(i);
                if (!scene.isLoaded)
                {
                    continue;
                }

                string sceneGuid = string.IsNullOrWhiteSpace(scene.path) ? string.Empty : AssetDatabase.AssetPathToGUID(scene.path);
                string sceneId = string.IsNullOrWhiteSpace(scene.path)
                    ? $"scene:loaded:{Slug(scene.name)}"
                    : AssetId("Scene", scene.path, sceneGuid);
                builder.AddNode("Scene", sceneId, scene.name, scene.path, sceneGuid, scene == SceneManager.GetActiveScene() ? "active loaded scene" : "loaded scene");
                builder.AddEdge(projectNode, sceneId, "loads_scene", scene.path);
                foreach (GameObject root in scene.GetRootGameObjects())
                {
                    TraverseGameObject(builder, sceneId, root, scene.path, sceneGuid, "scene");
                }
            }
        }

        private static void BuildSceneYamlPrefabEdges(GraphBuilder builder, string[] assetPaths)
        {
            foreach (string assetPath in assetPaths)
            {
                if (!assetPath.EndsWith(".unity", StringComparison.OrdinalIgnoreCase) || !IsProjectAssetPath(assetPath))
                {
                    continue;
                }

                string sceneGuid = AssetDatabase.AssetPathToGUID(assetPath);
                string sceneId = AssetId("Scene", assetPath, sceneGuid);
                string text = ReadAssetText(assetPath, SourceReadLimit);
                foreach (Match match in GuidRegex.Matches(text))
                {
                    string guid = match.Groups[1].Value;
                    string referencedPath = AssetDatabase.GUIDToAssetPath(guid);
                    if (!referencedPath.EndsWith(".prefab", StringComparison.OrdinalIgnoreCase))
                    {
                        continue;
                    }

                    builder.AddEdge(sceneId, AssetId("Prefab", referencedPath, guid), "instantiates", assetPath);
                }
            }
        }

        private static void TraverseGameObject(GraphBuilder builder, string ownerId, GameObject gameObject, string assetPath, string guid, string scope)
        {
            if (gameObject == null)
            {
                return;
            }

            string hierarchyPath = GetHierarchyPath(gameObject);
            string gameObjectId = $"{scope}-gameobject:{Slug(assetPath)}:{Slug(hierarchyPath)}";
            builder.AddNode("GameObject", gameObjectId, gameObject.name, assetPath, guid, $"hierarchy={hierarchyPath}");
            builder.AddEdge(ownerId, gameObjectId, "contains_gameobject", assetPath);

            GameObject prefabSource = PrefabUtility.GetCorrespondingObjectFromSource(gameObject);
            string prefabPath = prefabSource == null ? string.Empty : AssetDatabase.GetAssetPath(prefabSource);
            if (!string.IsNullOrWhiteSpace(prefabPath))
            {
                builder.AddEdge(ownerId, AssetId("Prefab", prefabPath, AssetDatabase.AssetPathToGUID(prefabPath)), "instantiates", assetPath);
            }

            Component[] components = gameObject.GetComponents<Component>();
            foreach (Component component in components)
            {
                if (component == null)
                {
                    continue;
                }

                string componentType = component.GetType().FullName;
                string componentId = $"component:{Slug(componentType)}";
                builder.AddNode("Component", componentId, component.GetType().Name, string.Empty, string.Empty, componentType);
                builder.AddEdge(gameObjectId, componentId, "has_component", assetPath);
                if (ownerId.IndexOf("prefab:", StringComparison.Ordinal) >= 0)
                {
                    builder.AddEdge(ownerId, componentId, "contains_component", assetPath);
                }

                if (component is MonoBehaviour monoBehaviour)
                {
                    MonoScript script = MonoScript.FromMonoBehaviour(monoBehaviour);
                    string scriptPath = script == null ? string.Empty : AssetDatabase.GetAssetPath(script);
                    if (!string.IsNullOrWhiteSpace(scriptPath))
                    {
                        string scriptGuid = AssetDatabase.AssetPathToGUID(scriptPath);
                        string classId = $"class:{Slug(script.GetClass()?.Name ?? script.name)}";
                        builder.AddEdge(componentId, AssetId("Script", scriptPath, scriptGuid), "implemented_by_script", assetPath);
                        builder.AddEdge(componentId, classId, "implemented_by_class", assetPath);
                    }
                }

                AddSerializedReferenceEdges(builder, componentId, component, assetPath);
            }

            for (int i = 0; i < gameObject.transform.childCount; i++)
            {
                TraverseGameObject(builder, gameObjectId, gameObject.transform.GetChild(i).gameObject, assetPath, guid, scope);
            }
        }

        private static void AddSerializedReferenceEdges(GraphBuilder builder, string fromId, Object source, string evidence)
        {
            try
            {
                SerializedObject serializedObject = new SerializedObject(source);
                SerializedProperty iterator = serializedObject.GetIterator();
                bool enterChildren = true;
                while (iterator.NextVisible(enterChildren))
                {
                    enterChildren = false;
                    if (iterator.propertyType != SerializedPropertyType.ObjectReference)
                    {
                        continue;
                    }

                    Object referenced = iterator.objectReferenceValue;
                    if (referenced == null)
                    {
                        continue;
                    }

                    string path = AssetDatabase.GetAssetPath(referenced);
                    if (string.IsNullOrWhiteSpace(path))
                    {
                        continue;
                    }

                    string guid = AssetDatabase.AssetPathToGUID(path);
                    string targetId = AssetId(GetReferenceNodeType(referenced, path), path, guid);
                    if (referenced is ScriptableObject)
                    {
                        builder.AddEdge(fromId, targetId, "references_scriptable_object", $"{evidence}:{iterator.propertyPath}");
                    }
                    else
                    {
                        builder.AddEdge(fromId, targetId, "references_asset", $"{evidence}:{iterator.propertyPath}");
                    }
                }
            }
            catch
            {
                // Some native objects cannot be serialized outside their editor path.
            }
        }

        private static string GetReferenceNodeType(Object referenced, string path)
        {
            if (referenced is ScriptableObject)
            {
                return "ScriptableObject";
            }

            if (referenced is Material)
            {
                return "Material";
            }

            if (referenced is Shader)
            {
                return "Shader";
            }

            if (referenced is AnimationClip)
            {
                return "AnimationClip";
            }

            if (path.EndsWith(".prefab", StringComparison.OrdinalIgnoreCase))
            {
                return "Prefab";
            }

            return "Asset";
        }

        private static void BuildAnimationGraph(GraphBuilder builder, string[] assetPaths)
        {
            foreach (string assetPath in assetPaths)
            {
                if (!assetPath.EndsWith(".controller", StringComparison.OrdinalIgnoreCase) || !IsProjectAssetPath(assetPath))
                {
                    continue;
                }

                string guid = AssetDatabase.AssetPathToGUID(assetPath);
                AnimatorController controller = AssetDatabase.LoadAssetAtPath<AnimatorController>(assetPath);
                if (controller == null)
                {
                    continue;
                }

                string animatorId = AssetId("Animator", assetPath, guid);
                foreach (AnimatorControllerLayer layer in controller.layers)
                {
                    if (layer?.stateMachine == null)
                    {
                        continue;
                    }

                    AddAnimatorStateMachine(builder, animatorId, layer.stateMachine, assetPath, guid);
                }
            }
        }

        private static void AddAnimatorStateMachine(GraphBuilder builder, string animatorId, AnimatorStateMachine stateMachine, string assetPath, string guid)
        {
            foreach (ChildAnimatorState childState in stateMachine.states)
            {
                AnimatorState state = childState.state;
                if (state == null)
                {
                    continue;
                }

                string stateId = $"animation-state:{Slug(assetPath)}:{Slug(state.name)}";
                builder.AddNode("Animation State", stateId, state.name, assetPath, guid, string.Empty);
                builder.AddEdge(animatorId, stateId, "contains_animation_state", assetPath);
                if (state.motion is AnimationClip clip)
                {
                    string clipPath = AssetDatabase.GetAssetPath(clip);
                    builder.AddEdge(animatorId, AssetId("AnimationClip", clipPath, AssetDatabase.AssetPathToGUID(clipPath)), "uses_animation_clip", assetPath);
                    builder.AddEdge(stateId, AssetId("AnimationClip", clipPath, AssetDatabase.AssetPathToGUID(clipPath)), "uses_animation_clip", assetPath);
                }
            }

            foreach (ChildAnimatorStateMachine child in stateMachine.stateMachines)
            {
                if (child.stateMachine != null)
                {
                    AddAnimatorStateMachine(builder, animatorId, child.stateMachine, assetPath, guid);
                }
            }
        }

        private static void BuildInputActionGraph(GraphBuilder builder, string[] assetPaths)
        {
            foreach (string assetPath in assetPaths)
            {
                if (!assetPath.EndsWith(".inputactions", StringComparison.OrdinalIgnoreCase) || !IsProjectAssetPath(assetPath))
                {
                    continue;
                }

                string guid = AssetDatabase.AssetPathToGUID(assetPath);
                string assetId = AssetId("Input Actions", assetPath, guid);
                string text = ReadAssetText(assetPath, SourceReadLimit);
                foreach (Match match in InputActionNameRegex.Matches(text))
                {
                    string actionName = match.Groups[1].Value;
                    if (string.IsNullOrWhiteSpace(actionName))
                    {
                        continue;
                    }

                    string actionId = $"input-action:{Slug(assetPath)}:{Slug(actionName)}";
                    builder.AddNode("Input Action", actionId, actionName, assetPath, guid, string.Empty);
                    builder.AddEdge(assetId, actionId, "contains_input_action", assetPath);
                }
            }
        }

        private static void BuildMaterialShaderGraph(GraphBuilder builder, string[] assetPaths)
        {
            foreach (string assetPath in assetPaths)
            {
                if (!assetPath.EndsWith(".mat", StringComparison.OrdinalIgnoreCase) || !IsProjectAssetPath(assetPath))
                {
                    continue;
                }

                Material material = AssetDatabase.LoadAssetAtPath<Material>(assetPath);
                if (material == null || material.shader == null)
                {
                    continue;
                }

                string shaderPath = AssetDatabase.GetAssetPath(material.shader);
                string shaderGuid = string.IsNullOrWhiteSpace(shaderPath) ? string.Empty : AssetDatabase.AssetPathToGUID(shaderPath);
                string shaderId = string.IsNullOrWhiteSpace(shaderPath)
                    ? $"shader:builtin:{Slug(material.shader.name)}"
                    : AssetId("Shader", shaderPath, shaderGuid);
                builder.AddNode("Shader", shaderId, material.shader.name, shaderPath, shaderGuid, string.Empty);
                builder.AddEdge(AssetId("Material", assetPath, AssetDatabase.AssetPathToGUID(assetPath)), shaderId, "uses_shader", assetPath);
            }
        }

        private static void BuildTestCoverageGraph(GraphBuilder builder)
        {
            List<ProjectGraphNode> classes = new List<ProjectGraphNode>();
            List<ProjectGraphNode> tests = new List<ProjectGraphNode>();
            foreach (ProjectGraphNode node in builder.Nodes)
            {
                if (node == null)
                {
                    continue;
                }

                if (string.Equals(node.type, "Class", StringComparison.Ordinal))
                {
                    classes.Add(node);
                }
                else if (string.Equals(node.type, "Script", StringComparison.Ordinal) && IsTestPath(node.path))
                {
                    tests.Add(node);
                    builder.AddNode("Test", $"test:{Slug(node.path)}", Path.GetFileNameWithoutExtension(node.path), node.path, node.guid, "test script");
                }
            }

            foreach (ProjectGraphNode test in tests)
            {
                string testText = $"{test.name} {test.path}".ToLowerInvariant();
                foreach (ProjectGraphNode classNode in classes)
                {
                    if (string.IsNullOrWhiteSpace(classNode.name) || test.path == classNode.path)
                    {
                        continue;
                    }

                    string classSlug = Slug(classNode.name).Replace("-", string.Empty);
                    string compactTest = Regex.Replace(testText, @"[^a-z0-9]+", string.Empty);
                    if (compactTest.Contains(classSlug))
                    {
                        builder.AddEdge($"test:{Slug(test.path)}", classNode.id, "covers", test.path);
                    }
                }
            }
        }

        private static void BuildGitCommitGraph(GraphBuilder builder, string projectRoot)
        {
            string gitOutput = RunGit(projectRoot, $"log --name-only --pretty=format:%H%x09%s -n {GitCommitLimit.ToString(CultureInfo.InvariantCulture)}");
            if (string.IsNullOrWhiteSpace(gitOutput))
            {
                return;
            }

            string currentCommitId = string.Empty;
            foreach (string rawLine in gitOutput.Replace("\r\n", "\n").Replace('\r', '\n').Split('\n'))
            {
                string line = rawLine.Trim();
                if (string.IsNullOrWhiteSpace(line))
                {
                    continue;
                }

                if (Regex.IsMatch(line, @"^[0-9a-f]{40}\t", RegexOptions.IgnoreCase))
                {
                    string[] parts = line.Split(new[] { '\t' }, 2);
                    string sha = parts[0];
                    string subject = parts.Length > 1 ? parts[1] : sha.Substring(0, 8);
                    currentCommitId = $"commit:{sha}";
                    builder.AddNode("Git Commit", currentCommitId, sha.Substring(0, 8), string.Empty, string.Empty, subject);
                    continue;
                }

                if (string.IsNullOrWhiteSpace(currentCommitId))
                {
                    continue;
                }

                string assetPath = NormalizeGitAssetPath(line);
                if (string.IsNullOrWhiteSpace(assetPath))
                {
                    continue;
                }

                string guid = AssetDatabase.AssetPathToGUID(assetPath);
                string type = InferAssetTypeFromPath(assetPath);
                string targetId = AssetId(type, assetPath, guid);
                builder.AddNode(type, targetId, Path.GetFileNameWithoutExtension(assetPath), assetPath, guid, string.Empty);
                builder.AddEdge(currentCommitId, targetId, "changed_asset", line);
            }
        }

        private static string FormatContext(ProjectGraph graph, string currentPrompt)
        {
            GraphRecall recall = Recall(graph, currentPrompt);
            StringBuilder builder = new StringBuilder();
            builder.AppendLine("Deterministic Unity project graph:");
            builder.AppendLine($"- store: {RelativeStorePath()}");
            builder.AppendLine($"- generated: {FormatTicks(graph.updatedAtUtcTicks)}");
            builder.AppendLine($"- scope: scripts, classes, methods, scenes, game objects, prefabs, prefab variants, components, scriptable objects, materials, shaders, addressable loads, input actions, animation states, packages, tests, recent git commits");
            builder.AppendLine($"- graph size: {SafeLength(graph.nodes)} nodes, {SafeLength(graph.edges)} edges");
            builder.AppendLine("- contract: this graph is derived deterministically from Unity assets, loaded scenes, source text, package metadata, and git history; use it for dependency, coverage, inclusion, and blast-radius questions; verify destructive changes with live inspection.");

            AppendTypeCounts(builder, "node types", graph.nodeTypeCounts);
            AppendTypeCounts(builder, "edge types", graph.edgeTypeCounts);

            builder.AppendLine("- relevant nodes:");
            if (recall.nodes.Count == 0)
            {
                builder.AppendLine("  - none matched");
            }
            else
            {
                foreach (ProjectGraphNode node in recall.nodes)
                {
                    builder.AppendLine($"  - {node.type}: {node.name} id={node.id}{FormatOptional(" path", node.path)} in={node.inbound} out={node.outbound}");
                }
            }

            builder.AppendLine("- relevant edges:");
            if (recall.edges.Count == 0)
            {
                builder.AppendLine("  - none matched");
            }
            else
            {
                Dictionary<string, ProjectGraphNode> nodesById = IndexNodes(graph);
                foreach (ProjectGraphEdge edge in recall.edges)
                {
                    builder.AppendLine($"  - {DescribeNode(edge.from, nodesById)} -[{edge.type}]-> {DescribeNode(edge.to, nodesById)}{FormatOptional(" evidence", edge.evidence)}");
                }
            }

            builder.AppendLine("- supported graph questions:");
            builder.AppendLine("  - what depends on a node before deletion: inspect inbound references and git-changed assets");
            builder.AppendLine("  - why an asset is included: follow scene/build/prefab/material/component/reference edges");
            builder.AppendLine("  - system dependencies: follow script/class/method/component/reference/addressable edges");
            builder.AppendLine("  - untested gameplay code: classes without incoming Test covers edges");
            return builder.ToString().TrimEnd();
        }

        private static GraphRecall Recall(ProjectGraph graph, string currentPrompt)
        {
            HashSet<string> queryTokens = new HashSet<string>(Tokenize(currentPrompt), StringComparer.OrdinalIgnoreCase);
            if (queryTokens.Count == 0)
            {
                queryTokens.UnionWith(new[] { "player", "game", "scene", "prefab", "test", "health" });
            }

            List<ScoredNode> scoredNodes = new List<ScoredNode>();
            foreach (ProjectGraphNode node in graph.nodes ?? new ProjectGraphNode[0])
            {
                double score = ScoreNode(node, queryTokens);
                if (score > 0)
                {
                    scoredNodes.Add(new ScoredNode(node, score));
                }
            }

            scoredNodes.Sort((left, right) =>
            {
                int compare = right.score.CompareTo(left.score);
                return compare != 0 ? compare : string.Compare(left.node.id, right.node.id, StringComparison.Ordinal);
            });

            List<ProjectGraphNode> recalledNodes = new List<ProjectGraphNode>();
            HashSet<string> recalledIds = new HashSet<string>(StringComparer.Ordinal);
            foreach (ScoredNode scored in scoredNodes)
            {
                recalledNodes.Add(scored.node);
                recalledIds.Add(scored.node.id);
                if (recalledNodes.Count >= MaxContextNodes)
                {
                    break;
                }
            }

            List<ProjectGraphEdge> recalledEdges = new List<ProjectGraphEdge>();
            foreach (ProjectGraphEdge edge in graph.edges ?? new ProjectGraphEdge[0])
            {
                if (edge == null)
                {
                    continue;
                }

                bool nodeMatched = recalledIds.Contains(edge.from) || recalledIds.Contains(edge.to);
                bool textMatched = ContainsAnyToken(edge.type + " " + edge.evidence + " " + edge.from + " " + edge.to, queryTokens);
                if (nodeMatched || textMatched)
                {
                    recalledEdges.Add(edge);
                    if (recalledEdges.Count >= MaxContextEdges)
                    {
                        break;
                    }
                }
            }

            return new GraphRecall
            {
                nodes = recalledNodes,
                edges = recalledEdges
            };
        }

        private static double ScoreNode(ProjectGraphNode node, HashSet<string> queryTokens)
        {
            if (node == null)
            {
                return 0;
            }

            string haystack = $"{node.type} {node.name} {node.id} {node.path} {node.details}";
            double score = 0;
            foreach (string token in queryTokens)
            {
                if (haystack.IndexOf(token, StringComparison.OrdinalIgnoreCase) >= 0)
                {
                    score += 1;
                }
            }

            if (score <= 0)
            {
                return 0;
            }

            score += Math.Min(2, (node.inbound + node.outbound) * 0.05);
            if (string.Equals(node.type, "Class", StringComparison.Ordinal) ||
                string.Equals(node.type, "Script", StringComparison.Ordinal) ||
                string.Equals(node.type, "Prefab", StringComparison.Ordinal) ||
                string.Equals(node.type, "ScriptableObject", StringComparison.Ordinal))
            {
                score += 0.5;
            }

            return score;
        }

        private static void AppendTypeCounts(StringBuilder builder, string label, GraphTypeCount[] counts)
        {
            if (counts == null || counts.Length == 0)
            {
                return;
            }

            builder.Append($"- {label}: ");
            int count = Mathf.Min(counts.Length, 14);
            for (int i = 0; i < count; i++)
            {
                if (i > 0)
                {
                    builder.Append(", ");
                }

                builder.Append(counts[i].type);
                builder.Append('=');
                builder.Append(counts[i].count);
            }

            if (counts.Length > count)
            {
                builder.Append($", +{counts.Length - count} more");
            }

            builder.AppendLine();
        }

        private static Dictionary<string, ProjectGraphNode> IndexNodes(ProjectGraph graph)
        {
            Dictionary<string, ProjectGraphNode> nodes = new Dictionary<string, ProjectGraphNode>(StringComparer.Ordinal);
            foreach (ProjectGraphNode node in graph.nodes ?? new ProjectGraphNode[0])
            {
                if (node != null && !string.IsNullOrWhiteSpace(node.id))
                {
                    nodes[node.id] = node;
                }
            }

            return nodes;
        }

        private static string DescribeNode(string id, Dictionary<string, ProjectGraphNode> nodesById)
        {
            if (nodesById.TryGetValue(id ?? string.Empty, out ProjectGraphNode node))
            {
                return $"{node.type}:{node.name}";
            }

            return id ?? string.Empty;
        }

        private static string AssetId(string type, string assetPath, string guid)
        {
            string stable = string.IsNullOrWhiteSpace(guid) ? assetPath : guid;
            return $"{Slug(type)}:{Slug(stable)}";
        }

        private static string InferAssetTypeFromPath(string assetPath)
        {
            string extension = Path.GetExtension(assetPath).ToLowerInvariant();
            if (extension == ".cs")
            {
                return IsTestPath(assetPath) ? "Test" : "Script";
            }

            if (extension == ".unity")
            {
                return "Scene";
            }

            if (extension == ".prefab")
            {
                return "Prefab";
            }

            if (extension == ".asset")
            {
                return "ScriptableObject";
            }

            if (extension == ".mat")
            {
                return "Material";
            }

            if (extension == ".shader" || extension == ".shadergraph")
            {
                return "Shader";
            }

            if (extension == ".inputactions")
            {
                return "Input Actions";
            }

            if (extension == ".controller")
            {
                return "Animator";
            }

            return "Asset";
        }

        private static bool IsProjectAssetPath(string path)
        {
            return !string.IsNullOrWhiteSpace(path) &&
                (path.StartsWith("Assets/", StringComparison.Ordinal) ||
                 path.StartsWith("Packages/", StringComparison.Ordinal));
        }

        private static bool IsTestPath(string path)
        {
            if (string.IsNullOrWhiteSpace(path))
            {
                return false;
            }

            return path.IndexOf("/Tests/", StringComparison.OrdinalIgnoreCase) >= 0 ||
                path.IndexOf(".Tests.", StringComparison.OrdinalIgnoreCase) >= 0 ||
                path.EndsWith("Test.cs", StringComparison.OrdinalIgnoreCase) ||
                path.EndsWith("Tests.cs", StringComparison.OrdinalIgnoreCase);
        }

        private static bool IsControlKeyword(string value)
        {
            return string.Equals(value, "if", StringComparison.Ordinal) ||
                string.Equals(value, "for", StringComparison.Ordinal) ||
                string.Equals(value, "foreach", StringComparison.Ordinal) ||
                string.Equals(value, "while", StringComparison.Ordinal) ||
                string.Equals(value, "switch", StringComparison.Ordinal) ||
                string.Equals(value, "catch", StringComparison.Ordinal) ||
                string.Equals(value, "using", StringComparison.Ordinal);
        }

        private static string GetHierarchyPath(GameObject gameObject)
        {
            if (gameObject == null)
            {
                return string.Empty;
            }

            Stack<string> parts = new Stack<string>();
            Transform current = gameObject.transform;
            while (current != null)
            {
                parts.Push(current.name);
                current = current.parent;
            }

            return string.Join("/", parts.ToArray());
        }

        private static string NormalizeGitAssetPath(string path)
        {
            if (string.IsNullOrWhiteSpace(path))
            {
                return string.Empty;
            }

            string normalized = path.Replace('\\', '/').Trim();
            int assetsIndex = normalized.IndexOf("Assets/", StringComparison.Ordinal);
            if (assetsIndex >= 0)
            {
                return normalized.Substring(assetsIndex);
            }

            int packagesIndex = normalized.IndexOf("Packages/", StringComparison.Ordinal);
            if (packagesIndex >= 0)
            {
                return normalized.Substring(packagesIndex);
            }

            return string.Empty;
        }

        private static string RunGit(string projectRoot, string arguments)
        {
            try
            {
                ProcessStartInfo startInfo = new ProcessStartInfo
                {
                    FileName = "git",
                    Arguments = arguments,
                    WorkingDirectory = projectRoot,
                    CreateNoWindow = true,
                    UseShellExecute = false,
                    RedirectStandardOutput = true,
                    RedirectStandardError = true
                };
                using (Process process = Process.Start(startInfo))
                {
                    if (process == null)
                    {
                        return string.Empty;
                    }

                    if (!process.WaitForExit(1400))
                    {
                        try
                        {
                            process.Kill();
                        }
                        catch
                        {
                            // ignored
                        }

                        return string.Empty;
                    }

                    return process.ExitCode == 0 ? process.StandardOutput.ReadToEnd() : string.Empty;
                }
            }
            catch
            {
                return string.Empty;
            }
        }

        private static string ReadAssetText(string assetPath, int limit)
        {
            string fullPath = GetProjectFullPath(assetPath);
            if (File.Exists(fullPath))
            {
                return ReadFilePrefix(fullPath, limit);
            }

            TextAsset textAsset = AssetDatabase.LoadAssetAtPath<TextAsset>(assetPath);
            if (textAsset == null || string.IsNullOrEmpty(textAsset.text))
            {
                return string.Empty;
            }

            return textAsset.text.Length <= limit ? textAsset.text : textAsset.text.Substring(0, limit);
        }

        private static string ReadFilePrefix(string path, int limit)
        {
            try
            {
                using (FileStream stream = File.OpenRead(path))
                using (StreamReader reader = new StreamReader(stream, Encoding.UTF8, true))
                {
                    char[] buffer = new char[Mathf.Max(1, limit)];
                    int count = reader.Read(buffer, 0, buffer.Length);
                    return new string(buffer, 0, count);
                }
            }
            catch
            {
                return string.Empty;
            }
        }

        private static List<string> Tokenize(string value)
        {
            MatchCollection matches = Regex.Matches((value ?? string.Empty).ToLowerInvariant(), @"[a-z0-9][a-z0-9_-]{2,}");
            List<string> tokens = new List<string>();
            foreach (Match match in matches)
            {
                string token = match.Value;
                if (tokens.Contains(token))
                {
                    continue;
                }

                tokens.Add(token);
                if (tokens.Count >= 32)
                {
                    break;
                }
            }

            return tokens;
        }

        private static bool ContainsAnyToken(string value, HashSet<string> tokens)
        {
            foreach (string token in tokens)
            {
                if ((value ?? string.Empty).IndexOf(token, StringComparison.OrdinalIgnoreCase) >= 0)
                {
                    return true;
                }
            }

            return false;
        }

        private static string GetProjectFullPath(string assetPath)
        {
            return Path.GetFullPath(Path.Combine(GetProjectRoot(), assetPath));
        }

        private static string GetProjectRoot()
        {
            return Path.GetDirectoryName(Application.dataPath) ?? Directory.GetCurrentDirectory();
        }

        private static string GetStorePath()
        {
            return Path.Combine(GetProjectRoot(), "Library", "AgenticGamedev", "project-graph.json");
        }

        private static string RelativeStorePath()
        {
            return "Library/AgenticGamedev/project-graph.json";
        }

        private static void Save(ProjectGraph graph)
        {
            try
            {
                string path = GetStorePath();
                Directory.CreateDirectory(Path.GetDirectoryName(path) ?? string.Empty);
                File.WriteAllText(path, JsonUtility.ToJson(graph, true), Encoding.UTF8);
            }
            catch (Exception exception)
            {
                Debug.LogWarning($"Could not save Ark deterministic project graph: {exception.Message}");
            }
        }

        private static string Slug(string value)
        {
            string slug = (value ?? string.Empty).Trim().ToLowerInvariant();
            slug = Regex.Replace(slug, @"['""]", string.Empty);
            slug = Regex.Replace(slug, @"[^a-z0-9._/-]+", "-");
            slug = slug.Replace("/", ":").Trim('-', ':');
            return string.IsNullOrWhiteSpace(slug) ? "unknown" : slug;
        }

        private static string JoinNonEmpty(string separator, params string[] values)
        {
            List<string> parts = new List<string>();
            foreach (string value in values)
            {
                if (!string.IsNullOrWhiteSpace(value))
                {
                    parts.Add(value.Trim());
                }
            }

            return string.Join(separator, parts.ToArray());
        }

        private static string FormatTicks(long ticks)
        {
            if (ticks <= 0)
            {
                return "unknown";
            }

            return new DateTime(ticks, DateTimeKind.Utc).ToString("yyyy-MM-dd HH:mm:ss 'UTC'");
        }

        private static string FormatOptional(string label, string value)
        {
            return string.IsNullOrWhiteSpace(value) ? string.Empty : $"{label}={value}";
        }

        private static int SafeLength(Array values)
        {
            return values == null ? 0 : values.Length;
        }

        private sealed class GraphBuilder
        {
            private readonly Dictionary<string, ProjectGraphNode> nodes = new Dictionary<string, ProjectGraphNode>(StringComparer.Ordinal);
            private readonly HashSet<string> edgeKeys = new HashSet<string>(StringComparer.Ordinal);
            private readonly List<ProjectGraphEdge> edges = new List<ProjectGraphEdge>();

            public ProjectGraph Graph { get; } = new ProjectGraph();

            public IEnumerable<ProjectGraphNode> Nodes => nodes.Values;

            public string AddNode(string type, string id, string name, string path, string guid, string details)
            {
                if (string.IsNullOrWhiteSpace(id) || nodes.Count >= MaxGraphNodes)
                {
                    return id;
                }

                if (nodes.TryGetValue(id, out ProjectGraphNode existing))
                {
                    existing.type = string.IsNullOrWhiteSpace(existing.type) ? type : existing.type;
                    existing.name = string.IsNullOrWhiteSpace(existing.name) ? name : existing.name;
                    existing.path = string.IsNullOrWhiteSpace(existing.path) ? path : existing.path;
                    existing.guid = string.IsNullOrWhiteSpace(existing.guid) ? guid : existing.guid;
                    existing.details = string.IsNullOrWhiteSpace(existing.details) ? details : existing.details;
                    return id;
                }

                nodes[id] = new ProjectGraphNode
                {
                    id = id,
                    type = type ?? string.Empty,
                    name = name ?? string.Empty,
                    path = path ?? string.Empty,
                    guid = guid ?? string.Empty,
                    details = details ?? string.Empty
                };
                return id;
            }

            public void AddEdge(string from, string to, string type, string evidence)
            {
                if (string.IsNullOrWhiteSpace(from) ||
                    string.IsNullOrWhiteSpace(to) ||
                    string.IsNullOrWhiteSpace(type) ||
                    edges.Count >= MaxGraphEdges)
                {
                    return;
                }

                string key = $"{from}\n{type}\n{to}\n{evidence}";
                if (!edgeKeys.Add(key))
                {
                    return;
                }

                edges.Add(new ProjectGraphEdge
                {
                    id = $"edge:{edgeKeys.Count.ToString(CultureInfo.InvariantCulture)}",
                    from = from,
                    to = to,
                    type = type,
                    evidence = evidence ?? string.Empty
                });
            }

            public void FinalizeGraph()
            {
                foreach (ProjectGraphEdge edge in edges)
                {
                    if (nodes.TryGetValue(edge.from, out ProjectGraphNode from))
                    {
                        from.outbound++;
                    }

                    if (nodes.TryGetValue(edge.to, out ProjectGraphNode to))
                    {
                        to.inbound++;
                    }
                }

                List<ProjectGraphNode> nodeList = new List<ProjectGraphNode>(nodes.Values);
                nodeList.Sort((left, right) => string.Compare(left.id, right.id, StringComparison.Ordinal));
                edges.Sort((left, right) =>
                {
                    int compare = string.Compare(left.from, right.from, StringComparison.Ordinal);
                    if (compare != 0)
                    {
                        return compare;
                    }

                    compare = string.Compare(left.type, right.type, StringComparison.Ordinal);
                    return compare != 0 ? compare : string.Compare(left.to, right.to, StringComparison.Ordinal);
                });

                Graph.nodes = nodeList.ToArray();
                Graph.edges = edges.ToArray();
                Graph.nodeTypeCounts = CountTypes(nodeList, node => node.type);
                Graph.edgeTypeCounts = CountTypes(edges, edge => edge.type);
            }

            private static GraphTypeCount[] CountTypes<T>(IEnumerable<T> values, Func<T, string> selector)
            {
                Dictionary<string, int> counts = new Dictionary<string, int>(StringComparer.Ordinal);
                foreach (T value in values)
                {
                    string type = selector(value) ?? string.Empty;
                    counts[type] = counts.TryGetValue(type, out int count) ? count + 1 : 1;
                }

                List<GraphTypeCount> output = new List<GraphTypeCount>();
                foreach (KeyValuePair<string, int> pair in counts)
                {
                    output.Add(new GraphTypeCount { type = pair.Key, count = pair.Value });
                }

                output.Sort((left, right) =>
                {
                    int compare = right.count.CompareTo(left.count);
                    return compare != 0 ? compare : string.Compare(left.type, right.type, StringComparison.Ordinal);
                });
                return output.ToArray();
            }
        }

        private sealed class ScoredNode
        {
            public readonly ProjectGraphNode node;
            public readonly double score;

            public ScoredNode(ProjectGraphNode node, double score)
            {
                this.node = node;
                this.score = score;
            }
        }

        private sealed class GraphRecall
        {
            public List<ProjectGraphNode> nodes;
            public List<ProjectGraphEdge> edges;
        }

        private sealed class ClassMatch
        {
            public string id;
            public int index;
        }

        [Serializable]
        private sealed class ProjectGraph
        {
            public int version;
            public string projectName;
            public string unityVersion;
            public string projectRoot;
            public string activeScene;
            public string activeScenePath;
            public ProjectGraphNode[] nodes;
            public ProjectGraphEdge[] edges;
            public GraphTypeCount[] nodeTypeCounts;
            public GraphTypeCount[] edgeTypeCounts;
            public long updatedAtUtcTicks;
        }

        [Serializable]
        private sealed class ProjectGraphNode
        {
            public string id;
            public string type;
            public string name;
            public string path;
            public string guid;
            public string details;
            public int inbound;
            public int outbound;
        }

        [Serializable]
        private sealed class ProjectGraphEdge
        {
            public string id;
            public string from;
            public string to;
            public string type;
            public string evidence;
        }

        [Serializable]
        private sealed class GraphTypeCount
        {
            public string type;
            public int count;
        }
    }
}
