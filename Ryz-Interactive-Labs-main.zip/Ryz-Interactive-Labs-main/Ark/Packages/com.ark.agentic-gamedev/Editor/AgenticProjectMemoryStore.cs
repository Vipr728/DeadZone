using System;
using System.Collections.Generic;
using System.IO;
using System.Text;
using UnityEditor;
using UnityEngine;
using UnityEngine.SceneManagement;

namespace AgenticGamedev.EditorTools
{
    internal static class AgenticProjectMemoryStore
    {
        private const int CurrentVersion = 1;
        private const int MaxBulletCount = 12;
        private const int MaxTextLength = 1200;

        public static void ObserveLiveState(string prompt)
        {
            Snapshot snapshot = Load();
            Scene scene = SceneManager.GetActiveScene();
            snapshot.version = CurrentVersion;
            snapshot.projectName = Application.productName;
            snapshot.unityVersion = Application.unityVersion;
            snapshot.sceneName = scene.name;
            snapshot.scenePath = scene.path;
            snapshot.lastPrompt = Clean(prompt, 600);
            snapshot.updatedAtUtcTicks = DateTime.UtcNow.Ticks;
            Save(snapshot);
        }

        public static void ObserveToolLoopState(AgenticAgentBridge.ToolLoopState state)
        {
            if (state == null)
            {
                return;
            }

            Snapshot snapshot = Load();
            Scene scene = SceneManager.GetActiveScene();
            snapshot.version = CurrentVersion;
            snapshot.projectName = Application.productName;
            snapshot.unityVersion = Application.unityVersion;
            snapshot.sceneName = scene.name;
            snapshot.scenePath = scene.path;
            snapshot.lastPrompt = Clean(state.Prompt, 900);
            snapshot.instructionMemory = Clean(state.InstructionMemory, 1200);
            snapshot.runId = Clean(state.RunId, 80);
            snapshot.activeAgentRole = Clean(state.ActiveAgentRole, 80);
            snapshot.finalMessage = Clean(state.FinalMessage, 900);
            snapshot.promptInterpretationMode = Clean(state.PromptInterpretationMode, 40);
            snapshot.promptInterpretationSummary = Clean(state.PromptInterpretationSummary, 240);
            snapshot.achievements = ExtractBullets(state.AchievementLog.ToString(), MaxBulletCount);
            snapshot.validation = ExtractBullets(state.ValidationLog.ToString(), MaxBulletCount);
            snapshot.issues = ExtractBullets(state.IssueLog.ToString(), MaxBulletCount);
            snapshot.contextChecks = ExtractBullets(state.ContextLog.ToString(), MaxBulletCount);
            snapshot.codeArtifacts = ExtractCodeArtifacts(state.CodeSnippetLog.ToString(), MaxBulletCount);
            snapshot.taskPlan = ExtractTaskPlan(state.TaskPlan, MaxBulletCount);
            snapshot.appliedActions = state.AppliedActions;
            snapshot.loggedToolCalls = state.LoggedToolCalls;
            snapshot.updatedAtUtcTicks = DateTime.UtcNow.Ticks;
            Save(snapshot);
        }

        public static string BuildContextSection()
        {
            Snapshot snapshot = Load();
            StringBuilder builder = new StringBuilder();
            builder.AppendLine("Project memory snapshot:");
            builder.AppendLine($"- store: {RelativeStorePath()}");
            builder.AppendLine("- contract: this is durable project/run memory persisted across Unity reloads; use it as prior project context, but prefer fresh live Unity state when they conflict.");

            if (snapshot.version != CurrentVersion || string.IsNullOrWhiteSpace(snapshot.projectName))
            {
                builder.AppendLine("- none saved yet");
                return builder.ToString().TrimEnd();
            }

            AppendLine(builder, "project", snapshot.projectName);
            AppendLine(builder, "unity", snapshot.unityVersion);
            AppendLine(builder, "scene", JoinNonEmpty(" ", snapshot.sceneName, FormatPath(snapshot.scenePath)));
            AppendLine(builder, "updated", FormatTicks(snapshot.updatedAtUtcTicks));
            AppendLine(builder, "last prompt", snapshot.lastPrompt);
            AppendLine(builder, "last run pinned instructions", snapshot.instructionMemory);
            AppendLine(builder, "run id", snapshot.runId);
            AppendLine(builder, "active role", snapshot.activeAgentRole);
            AppendLine(builder, "prompt mode", snapshot.promptInterpretationMode);
            AppendLine(builder, "mode summary", snapshot.promptInterpretationSummary);
            AppendLine(builder, "last final message", snapshot.finalMessage);
            builder.AppendLine($"- applied actions: {snapshot.appliedActions}, logged tools: {snapshot.loggedToolCalls}");
            AppendList(builder, "task plan", snapshot.taskPlan);
            AppendList(builder, "achievements", snapshot.achievements);
            AppendList(builder, "validation", snapshot.validation);
            AppendList(builder, "issues", snapshot.issues);
            AppendList(builder, "context checks", snapshot.contextChecks);
            AppendList(builder, "code artifacts", snapshot.codeArtifacts);
            return builder.ToString().TrimEnd();
        }

        private static void AppendLine(StringBuilder builder, string label, string value)
        {
            if (!string.IsNullOrWhiteSpace(value))
            {
                builder.AppendLine($"- {label}: {value.Trim()}");
            }
        }

        private static void AppendList(StringBuilder builder, string label, string[] values)
        {
            if (values == null || values.Length == 0)
            {
                return;
            }

            builder.AppendLine($"- {label}:");
            foreach (string value in values)
            {
                if (!string.IsNullOrWhiteSpace(value))
                {
                    builder.AppendLine($"  - {value.Trim()}");
                }
            }
        }

        private static string[] ExtractBullets(string value, int maxCount)
        {
            if (string.IsNullOrWhiteSpace(value))
            {
                return Array.Empty<string>();
            }

            string[] lines = value.Replace("\r\n", "\n").Replace('\r', '\n').Split('\n');
            List<string> bullets = new List<string>();
            foreach (string line in lines)
            {
                string cleaned = Clean(line.Trim().TrimStart('-', ' '), 220);
                if (string.IsNullOrWhiteSpace(cleaned))
                {
                    continue;
                }

                bullets.Add(cleaned);
                if (bullets.Count >= maxCount)
                {
                    break;
                }
            }

            return bullets.ToArray();
        }

        private static string[] ExtractCodeArtifacts(string value, int maxCount)
        {
            if (string.IsNullOrWhiteSpace(value))
            {
                return Array.Empty<string>();
            }

            string[] lines = value.Replace("\r\n", "\n").Replace('\r', '\n').Split('\n');
            List<string> artifacts = new List<string>();
            foreach (string rawLine in lines)
            {
                string line = rawLine.Trim();
                if (line.StartsWith("Script path:", StringComparison.OrdinalIgnoreCase))
                {
                    artifacts.Add(Clean(line.Substring("Script path:".Length).Trim(), 220));
                }
                else if (line.EndsWith(".cs", StringComparison.OrdinalIgnoreCase) ||
                         line.EndsWith(".json", StringComparison.OrdinalIgnoreCase) ||
                         line.EndsWith(".shader", StringComparison.OrdinalIgnoreCase))
                {
                    artifacts.Add(Clean(line, 220));
                }

                if (artifacts.Count >= maxCount)
                {
                    break;
                }
            }

            return artifacts.ToArray();
        }

        private static string[] ExtractTaskPlan(List<AgenticAgentBridge.AgentTaskRecord> tasks, int maxCount)
        {
            if (tasks == null || tasks.Count == 0)
            {
                return Array.Empty<string>();
            }

            List<string> entries = new List<string>();
            foreach (AgenticAgentBridge.AgentTaskRecord task in tasks)
            {
                if (task == null)
                {
                    continue;
                }

                string status = string.IsNullOrWhiteSpace(task.status) ? "pending" : task.status.Trim();
                string title = Clean(string.IsNullOrWhiteSpace(task.title) ? task.description : task.title, 180);
                string id = Clean(task.id, 60);
                string assignee = Clean(task.assignee, 60);
                entries.Add($"{status} {id}: {title}" + (string.IsNullOrWhiteSpace(assignee) ? string.Empty : $" [{assignee}]"));
                if (entries.Count >= maxCount)
                {
                    break;
                }
            }

            return entries.ToArray();
        }

        private static string JoinNonEmpty(string separator, params string[] values)
        {
            List<string> parts = new List<string>();
            foreach (string value in values)
            {
                if (!string.IsNullOrWhiteSpace(value))
                {
                    parts.Add(value.Trim());
                }
            }

            return parts.Count == 0 ? string.Empty : string.Join(separator, parts.ToArray());
        }

        private static string Clean(string value, int maxLength)
        {
            if (string.IsNullOrWhiteSpace(value))
            {
                return string.Empty;
            }

            string cleaned = value.Replace("\r", " ").Replace("\n", " ").Trim();
            while (cleaned.IndexOf("  ", StringComparison.Ordinal) >= 0)
            {
                cleaned = cleaned.Replace("  ", " ");
            }

            if (cleaned.Length > Math.Min(maxLength, MaxTextLength))
            {
                cleaned = cleaned.Substring(0, Math.Min(maxLength, MaxTextLength)).TrimEnd();
            }

            return cleaned;
        }

        private static string FormatPath(string path)
        {
            return string.IsNullOrWhiteSpace(path) ? string.Empty : $"path={path.Trim()}";
        }

        private static string FormatTicks(long ticks)
        {
            if (ticks <= 0)
            {
                return "unknown";
            }

            return new DateTime(ticks, DateTimeKind.Utc).ToString("yyyy-MM-dd HH:mm:ss 'UTC'");
        }

        private static Snapshot Load()
        {
            string path = GetStorePath();
            if (!File.Exists(path))
            {
                return new Snapshot { version = CurrentVersion };
            }

            try
            {
                Snapshot snapshot = JsonUtility.FromJson<Snapshot>(File.ReadAllText(path, Encoding.UTF8));
                return snapshot ?? new Snapshot { version = CurrentVersion };
            }
            catch (Exception exception)
            {
                Debug.LogWarning($"Could not load Agentic project memory snapshot: {exception.Message}");
                return new Snapshot { version = CurrentVersion };
            }
        }

        private static void Save(Snapshot snapshot)
        {
            try
            {
                string path = GetStorePath();
                Directory.CreateDirectory(Path.GetDirectoryName(path) ?? string.Empty);
                File.WriteAllText(path, JsonUtility.ToJson(snapshot, true), Encoding.UTF8);
            }
            catch (Exception exception)
            {
                Debug.LogWarning($"Could not save Agentic project memory snapshot: {exception.Message}");
            }
        }

        private static string GetStorePath()
        {
            string projectRoot = Path.GetDirectoryName(Application.dataPath) ?? Directory.GetCurrentDirectory();
            return Path.Combine(projectRoot, "Library", "AgenticGamedev", "project-memory.json");
        }

        private static string RelativeStorePath()
        {
            return "Library/AgenticGamedev/project-memory.json";
        }

        [Serializable]
        private sealed class Snapshot
        {
            public int version;
            public string projectName;
            public string unityVersion;
            public string sceneName;
            public string scenePath;
            public string lastPrompt;
            public string instructionMemory;
            public string runId;
            public string activeAgentRole;
            public string promptInterpretationMode;
            public string promptInterpretationSummary;
            public string finalMessage;
            public string[] taskPlan;
            public string[] achievements;
            public string[] validation;
            public string[] issues;
            public string[] contextChecks;
            public string[] codeArtifacts;
            public int appliedActions;
            public int loggedToolCalls;
            public long updatedAtUtcTicks;
        }
    }
}
