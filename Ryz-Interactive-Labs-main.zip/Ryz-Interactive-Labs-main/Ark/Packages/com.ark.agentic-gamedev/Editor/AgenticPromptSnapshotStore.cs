using System;
using System.IO;
using System.Text;
using UnityEditor;
using UnityEditor.SceneManagement;
using UnityEngine;
using UnityEngine.SceneManagement;

namespace AgenticGamedev.EditorTools
{
    internal static class AgenticPromptSnapshotStore
    {
        private const int CurrentVersion = 1;
        private const int MaxSnapshotsToKeep = 40;
        private static readonly string[] SnapshotRoots = { "Assets", "Packages", "ProjectSettings" };

        public static SnapshotInfo Capture(string prompt)
        {
            if (EditorApplication.isCompiling || EditorApplication.isUpdating)
            {
                throw new InvalidOperationException("Unity is compiling or importing assets. Try again after Unity is idle.");
            }

            string id = CreateSnapshotId();
            string snapshotRoot = GetSnapshotRoot(id);
            Directory.CreateDirectory(snapshotRoot);

            AssetDatabase.SaveAssets();
            EditorSceneManager.SaveOpenScenes();

            string projectRoot = GetProjectRoot();
            foreach (string rootName in SnapshotRoots)
            {
                string source = Path.Combine(projectRoot, rootName);
                string destination = Path.Combine(snapshotRoot, rootName);
                if (Directory.Exists(source))
                {
                    CopyDirectory(source, destination);
                }
                else if (File.Exists(source))
                {
                    Directory.CreateDirectory(Path.GetDirectoryName(destination) ?? snapshotRoot);
                    File.Copy(source, destination, true);
                }
            }

            SnapshotInfo info = new SnapshotInfo
            {
                version = CurrentVersion,
                id = id,
                prompt = Truncate(prompt, 1000),
                createdUtcTicks = DateTime.UtcNow.Ticks,
                unityVersion = Application.unityVersion,
                activeScenePath = SceneManager.GetActiveScene().path
            };
            File.WriteAllText(GetManifestPath(id), JsonUtility.ToJson(info, true), Encoding.UTF8);
            PruneOldSnapshots();
            return info;
        }

        public static bool Exists(string id)
        {
            return !string.IsNullOrWhiteSpace(id) &&
                Directory.Exists(GetSnapshotRoot(id)) &&
                File.Exists(GetManifestPath(id));
        }

        public static SnapshotInfo LoadInfo(string id)
        {
            if (!Exists(id))
            {
                return null;
            }

            try
            {
                return JsonUtility.FromJson<SnapshotInfo>(File.ReadAllText(GetManifestPath(id), Encoding.UTF8));
            }
            catch (Exception)
            {
                return null;
            }
        }

        public static string Restore(string id)
        {
            if (EditorApplication.isPlayingOrWillChangePlaymode)
            {
                throw new InvalidOperationException("Exit Play Mode before restoring a prompt snapshot.");
            }

            if (EditorApplication.isCompiling || EditorApplication.isUpdating)
            {
                throw new InvalidOperationException("Unity is compiling or importing assets. Try again after Unity is idle.");
            }

            if (!Exists(id))
            {
                throw new FileNotFoundException("Prompt snapshot not found.", id);
            }

            SnapshotInfo info = LoadInfo(id) ?? new SnapshotInfo { id = id };
            string projectRoot = GetProjectRoot();
            string snapshotRoot = GetSnapshotRoot(id);
            string backupRoot = GetRestoreBackupRoot(id);
            DeleteIfExists(backupRoot);
            Directory.CreateDirectory(backupRoot);

            try
            {
                AssetDatabase.SaveAssets();
                MoveCurrentRootsToBackup(projectRoot, backupRoot);
                CopySnapshotRootsToProject(snapshotRoot, projectRoot);
                DeleteIfExists(backupRoot);
            }
            catch
            {
                RestoreBackupRoots(projectRoot, backupRoot);
                throw;
            }

            AssetDatabase.Refresh(ImportAssetOptions.ForceSynchronousImport | ImportAssetOptions.ForceUpdate);
            if (!string.IsNullOrWhiteSpace(info.activeScenePath) && File.Exists(Path.Combine(projectRoot, info.activeScenePath)))
            {
                EditorSceneManager.OpenScene(info.activeScenePath, OpenSceneMode.Single);
            }

            return $"Restored project files to snapshot {id}.";
        }

        private static void MoveCurrentRootsToBackup(string projectRoot, string backupRoot)
        {
            foreach (string rootName in SnapshotRoots)
            {
                string source = Path.Combine(projectRoot, rootName);
                string backup = Path.Combine(backupRoot, rootName);
                if (Directory.Exists(source))
                {
                    Directory.Move(source, backup);
                }
                else if (File.Exists(source))
                {
                    Directory.CreateDirectory(Path.GetDirectoryName(backup) ?? backupRoot);
                    File.Move(source, backup);
                }
            }
        }

        private static void CopySnapshotRootsToProject(string snapshotRoot, string projectRoot)
        {
            foreach (string rootName in SnapshotRoots)
            {
                string source = Path.Combine(snapshotRoot, rootName);
                string destination = Path.Combine(projectRoot, rootName);
                if (Directory.Exists(source))
                {
                    CopyDirectory(source, destination);
                }
                else if (File.Exists(source))
                {
                    Directory.CreateDirectory(Path.GetDirectoryName(destination) ?? projectRoot);
                    File.Copy(source, destination, true);
                }
            }
        }

        private static void RestoreBackupRoots(string projectRoot, string backupRoot)
        {
            foreach (string rootName in SnapshotRoots)
            {
                DeleteIfExists(Path.Combine(projectRoot, rootName));
                string backup = Path.Combine(backupRoot, rootName);
                string destination = Path.Combine(projectRoot, rootName);
                if (Directory.Exists(backup))
                {
                    Directory.Move(backup, destination);
                }
                else if (File.Exists(backup))
                {
                    File.Move(backup, destination);
                }
            }
        }

        private static void CopyDirectory(string sourceDirectory, string destinationDirectory)
        {
            Directory.CreateDirectory(destinationDirectory);
            foreach (string directory in Directory.GetDirectories(sourceDirectory, "*", SearchOption.AllDirectories))
            {
                string relative = GetRelativePath(sourceDirectory, directory);
                Directory.CreateDirectory(Path.Combine(destinationDirectory, relative));
            }

            foreach (string file in Directory.GetFiles(sourceDirectory, "*", SearchOption.AllDirectories))
            {
                string relative = GetRelativePath(sourceDirectory, file);
                string destination = Path.Combine(destinationDirectory, relative);
                Directory.CreateDirectory(Path.GetDirectoryName(destination) ?? destinationDirectory);
                File.Copy(file, destination, true);
            }
        }

        private static void DeleteIfExists(string path)
        {
            if (Directory.Exists(path))
            {
                Directory.Delete(path, true);
            }
            else if (File.Exists(path))
            {
                File.Delete(path);
            }
        }

        private static void PruneOldSnapshots()
        {
            string root = GetSnapshotsDirectory();
            if (!Directory.Exists(root))
            {
                return;
            }

            DirectoryInfo[] directories = new DirectoryInfo(root).GetDirectories();
            Array.Sort(directories, (left, right) => right.CreationTimeUtc.CompareTo(left.CreationTimeUtc));
            for (int i = MaxSnapshotsToKeep; i < directories.Length; i++)
            {
                try
                {
                    directories[i].Delete(true);
                }
                catch (Exception exception)
                {
                    Debug.LogWarning($"Could not prune prompt snapshot {directories[i].Name}: {exception.Message}");
                }
            }
        }

        private static string CreateSnapshotId()
        {
            return DateTime.UtcNow.ToString("yyyyMMdd-HHmmss-fff") + "-" + Guid.NewGuid().ToString("N").Substring(0, 8);
        }

        private static string GetSnapshotRoot(string id)
        {
            return Path.Combine(GetSnapshotsDirectory(), SanitizePathName(id));
        }

        private static string GetManifestPath(string id)
        {
            return Path.Combine(GetSnapshotRoot(id), "snapshot.json");
        }

        private static string GetSnapshotsDirectory()
        {
            return Path.Combine(GetProjectRoot(), "Library", "AgenticGamedev", "PromptSnapshots");
        }

        private static string GetRestoreBackupRoot(string id)
        {
            return Path.Combine(GetProjectRoot(), "Library", "AgenticGamedev", "RestoreBackups", SanitizePathName(id) + "-" + DateTime.UtcNow.ToString("yyyyMMdd-HHmmss"));
        }

        private static string GetProjectRoot()
        {
            return Path.GetDirectoryName(Application.dataPath) ?? Directory.GetCurrentDirectory();
        }

        private static string GetRelativePath(string root, string path)
        {
            Uri rootUri = new Uri(AppendDirectorySeparator(Path.GetFullPath(root)));
            Uri pathUri = new Uri(Path.GetFullPath(path));
            return Uri.UnescapeDataString(rootUri.MakeRelativeUri(pathUri).ToString()).Replace('/', Path.DirectorySeparatorChar);
        }

        private static string AppendDirectorySeparator(string path)
        {
            return path.EndsWith(Path.DirectorySeparatorChar.ToString(), StringComparison.Ordinal)
                ? path
                : path + Path.DirectorySeparatorChar;
        }

        private static string SanitizePathName(string value)
        {
            if (string.IsNullOrWhiteSpace(value))
            {
                return "snapshot";
            }

            foreach (char invalid in Path.GetInvalidFileNameChars())
            {
                value = value.Replace(invalid, '_');
            }

            return value;
        }

        private static string Truncate(string value, int maxLength)
        {
            if (string.IsNullOrEmpty(value) || value.Length <= maxLength)
            {
                return value ?? string.Empty;
            }

            return value.Substring(0, maxLength);
        }

        [Serializable]
        internal sealed class SnapshotInfo
        {
            public int version;
            public string id;
            public string prompt;
            public long createdUtcTicks;
            public string unityVersion;
            public string activeScenePath;
        }
    }
}
