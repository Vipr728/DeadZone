using System;
using System.Collections.Generic;
using System.IO;
using System.Text;
using UnityEngine;

namespace AgenticGamedev.EditorTools
{
    internal static class AgenticUnityDocsIndex
    {
        private const int MaxIndexedCharsPerFile = 180000;
        private const int MaxIndexedCharsPerApiFile = 90000;
        private const int MaxReadChars = 24000;
        private const int MaxSnippetChars = 420;
        private const int CacheLifetimeSeconds = 300;
        private const int MaxApiSourceFilesToScan = 12000;

        private static readonly string[] ProjectDocRoots =
        {
            "Assets/Docs",
            "Assets/docs",
            "Assets/Documentation",
            "Assets/Documentation~",
            "Docs",
            "docs",
            "Documentation",
            "mcp"
        };

        private static readonly string[] RootDocFiles =
        {
            "README.md",
            "CHANGELOG.md",
            "AGENTS.md"
        };

        private static List<DocEntry> cachedEntries;
        private static DateTime cacheBuiltAtUtc;
        private static string cachedProjectRoot;
        private static string cachedDocsSignature;

        public static string Search(string query, int maxResults)
        {
            query = string.IsNullOrWhiteSpace(query) ? string.Empty : query.Trim();
            if (string.IsNullOrWhiteSpace(query))
            {
                return "search_unity_docs missing query.";
            }

            maxResults = maxResults <= 0 ? 8 : Math.Min(maxResults, 12);
            List<DocEntry> entries = GetEntries();
            List<string> tokens = Tokenize(query);
            if (tokens.Count == 0)
            {
                return "search_unity_docs query has no searchable terms.";
            }

            List<SearchHit> hits = new List<SearchHit>();
            foreach (DocEntry entry in entries)
            {
                int score = ScoreEntry(entry, query, tokens);
                if (score <= 0)
                {
                    continue;
                }

                hits.Add(new SearchHit
                {
                    Entry = entry,
                    Score = score
                });
            }

            hits.Sort((left, right) =>
            {
                int scoreCompare = right.Score.CompareTo(left.Score);
                return scoreCompare != 0
                    ? scoreCompare
                    : string.Compare(left.Entry.RelativePath, right.Entry.RelativePath, StringComparison.OrdinalIgnoreCase);
            });

            StringBuilder builder = new StringBuilder();
            builder.AppendLine($"Local Unity docs search: {query}");
            builder.AppendLine($"Index: {entries.Count} local doc file(s) from package cache, embedded packages, and project docs.");
            if (hits.Count == 0)
            {
                builder.AppendLine("Results: none");
                builder.AppendLine("Try a Unity API class name, package name, feature name, or serialized property term.");
                return builder.ToString().TrimEnd();
            }

            builder.AppendLine($"Results: {Math.Min(maxResults, hits.Count)} of {hits.Count}");
            for (int i = 0; i < hits.Count && i < maxResults; i++)
            {
                SearchHit hit = hits[i];
                DocEntry entry = hit.Entry;
                builder.AppendLine();
                builder.AppendLine($"- id={entry.Id} score={hit.Score} source={entry.Source}");
                builder.AppendLine($"  title: {entry.Title}");
                builder.AppendLine($"  path: {entry.RelativePath}");
                if (!string.IsNullOrWhiteSpace(entry.PackageName))
                {
                    builder.AppendLine($"  package: {entry.PackageName}");
                }

                builder.AppendLine("  read: call read_unity_doc with path/id \"" + entry.Id + "\"");
                string snippets = BuildSnippets(entry.Content, query, tokens, 2);
                if (!string.IsNullOrWhiteSpace(snippets))
                {
                    builder.Append(snippets);
                }
            }

            return builder.ToString().TrimEnd();
        }

        public static string Read(string idOrPath)
        {
            idOrPath = string.IsNullOrWhiteSpace(idOrPath) ? string.Empty : idOrPath.Trim();
            if (string.IsNullOrWhiteSpace(idOrPath))
            {
                return "read_unity_doc missing path/id. Use search_unity_docs first, then pass the result id or path.";
            }

            List<DocEntry> entries = GetEntries();
            List<DocEntry> matches = FindMatches(entries, idOrPath);
            if (matches.Count == 0)
            {
                return $"read_unity_doc could not find a local Unity doc matching: {idOrPath}";
            }

            if (matches.Count > 1)
            {
                StringBuilder ambiguous = new StringBuilder();
                ambiguous.AppendLine($"read_unity_doc matched {matches.Count} docs. Use a more specific id or path:");
                int count = Math.Min(matches.Count, 8);
                for (int i = 0; i < count; i++)
                {
                    ambiguous.AppendLine($"- id={matches[i].Id} path={matches[i].RelativePath}");
                }

                return ambiguous.ToString().TrimEnd();
            }

            DocEntry entry = matches[0];
            string content = ReadFilePrefix(entry.FullPath, MaxReadChars + 1);
            bool truncated = content.Length > MaxReadChars;
            if (truncated)
            {
                content = content.Substring(0, MaxReadChars);
            }

            StringBuilder builder = new StringBuilder();
            builder.AppendLine($"Local Unity doc: {entry.Title}");
            builder.AppendLine($"id: {entry.Id}");
            builder.AppendLine($"source: {entry.Source}");
            if (!string.IsNullOrWhiteSpace(entry.PackageName))
            {
                builder.AppendLine($"package: {entry.PackageName}");
            }

            builder.AppendLine($"path: {entry.RelativePath}");
            builder.AppendLine(truncated
                ? $"Content truncated to {MaxReadChars} characters."
                : $"Content length: {content.Length} characters.");
            builder.AppendLine("```");
            builder.Append(content);
            if (!content.EndsWith("\n", StringComparison.Ordinal))
            {
                builder.AppendLine();
            }

            builder.Append("```");
            return builder.ToString();
        }

        public static string SearchApi(string query, int maxResults)
        {
            query = string.IsNullOrWhiteSpace(query) ? string.Empty : query.Trim();
            if (string.IsNullOrWhiteSpace(query))
            {
                return "search_unity_api missing query.";
            }

            maxResults = maxResults <= 0 ? 8 : Math.Min(maxResults, 12);
            List<string> tokens = Tokenize(query);
            if (tokens.Count == 0)
            {
                return "search_unity_api query has no searchable terms.";
            }

            string projectRoot = GetProjectRoot();
            List<SearchHit> hits = new List<SearchHit>();
            HashSet<string> seenFullPaths = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
            int scanned = 0;

            AddApiSourceHits(projectRoot, Path.Combine(projectRoot, "Library", "PackageCache"), "package-source", query, tokens, hits, seenFullPaths, ref scanned);
            AddApiSourceHits(projectRoot, Path.Combine(projectRoot, "Packages"), "embedded-package-source", query, tokens, hits, seenFullPaths, ref scanned);
            AddApiSourceHits(projectRoot, Path.Combine(projectRoot, "Assets"), "project-source", query, tokens, hits, seenFullPaths, ref scanned);

            hits.Sort((left, right) =>
            {
                int scoreCompare = right.Score.CompareTo(left.Score);
                return scoreCompare != 0
                    ? scoreCompare
                    : string.Compare(left.Entry.RelativePath, right.Entry.RelativePath, StringComparison.OrdinalIgnoreCase);
            });

            StringBuilder builder = new StringBuilder();
            builder.AppendLine($"Installed Unity/package API source search: {query}");
            builder.AppendLine($"Scanned: {scanned} C# source file(s) from Library/PackageCache, Packages, and Assets.");
            if (hits.Count == 0)
            {
                builder.AppendLine("Results: none");
                builder.AppendLine("Try an exact type name, member name, namespace, compiler error symbol, or package name.");
                return builder.ToString().TrimEnd();
            }

            builder.AppendLine($"Results: {Math.Min(maxResults, hits.Count)} of {hits.Count}");
            for (int i = 0; i < hits.Count && i < maxResults; i++)
            {
                SearchHit hit = hits[i];
                DocEntry entry = hit.Entry;
                builder.AppendLine();
                builder.AppendLine($"- path={entry.RelativePath} score={hit.Score} source={entry.Source}");
                builder.AppendLine($"  title: {entry.Title}");
                if (!string.IsNullOrWhiteSpace(entry.PackageName))
                {
                    builder.AppendLine($"  package: {entry.PackageName}");
                }

                builder.AppendLine("  read: call read_unity_api or read_text_file with path \"" + entry.RelativePath + "\"");
                string snippets = BuildSnippets(entry.Content, query, tokens, 3);
                if (!string.IsNullOrWhiteSpace(snippets))
                {
                    builder.Append(snippets);
                }
            }

            return builder.ToString().TrimEnd();
        }

        private static List<DocEntry> GetEntries()
        {
            string projectRoot = GetProjectRoot();
            DateTime now = DateTime.UtcNow;
            string docsSignature = BuildDocsSignature(projectRoot);
            if (cachedEntries != null &&
                string.Equals(cachedProjectRoot, projectRoot, StringComparison.Ordinal) &&
                string.Equals(cachedDocsSignature, docsSignature, StringComparison.Ordinal) &&
                (now - cacheBuiltAtUtc).TotalSeconds < CacheLifetimeSeconds)
            {
                return cachedEntries;
            }

            cachedProjectRoot = projectRoot;
            cachedDocsSignature = docsSignature;
            cacheBuiltAtUtc = now;
            cachedEntries = BuildIndex(projectRoot);
            return cachedEntries;
        }

        private static string BuildDocsSignature(string projectRoot)
        {
            long latestWriteTicks = 0;
            int fileCount = 0;
            HashSet<string> seen = new HashSet<string>(StringComparer.OrdinalIgnoreCase);

            AddPackageCacheSignature(projectRoot, seen, ref fileCount, ref latestWriteTicks);
            AddEmbeddedPackageSignature(projectRoot, seen, ref fileCount, ref latestWriteTicks);
            AddProjectDocsSignature(projectRoot, seen, ref fileCount, ref latestWriteTicks);

            return fileCount + ":" + latestWriteTicks;
        }

        private static void AddPackageCacheSignature(string projectRoot, HashSet<string> seen, ref int fileCount, ref long latestWriteTicks)
        {
            string packageCacheRoot = Path.Combine(projectRoot, "Library", "PackageCache");
            if (!Directory.Exists(packageCacheRoot))
            {
                return;
            }

            foreach (string packageDirectory in SafeEnumerateDirectories(packageCacheRoot))
            {
                AddPackageRootSignature(packageDirectory, seen, ref fileCount, ref latestWriteTicks);
                AddDocsSignature(Path.Combine(packageDirectory, "Documentation~"), seen, ref fileCount, ref latestWriteTicks);
                AddDocsSignature(Path.Combine(packageDirectory, "Documentation"), seen, ref fileCount, ref latestWriteTicks);
            }
        }

        private static void AddEmbeddedPackageSignature(string projectRoot, HashSet<string> seen, ref int fileCount, ref long latestWriteTicks)
        {
            string packagesRoot = Path.Combine(projectRoot, "Packages");
            if (!Directory.Exists(packagesRoot))
            {
                return;
            }

            foreach (string packageDirectory in SafeEnumerateDirectories(packagesRoot))
            {
                AddPackageRootSignature(packageDirectory, seen, ref fileCount, ref latestWriteTicks);
                AddDocsSignature(Path.Combine(packageDirectory, "Documentation~"), seen, ref fileCount, ref latestWriteTicks);
                AddDocsSignature(Path.Combine(packageDirectory, "Documentation"), seen, ref fileCount, ref latestWriteTicks);
            }
        }

        private static void AddProjectDocsSignature(string projectRoot, HashSet<string> seen, ref int fileCount, ref long latestWriteTicks)
        {
            foreach (string relativeRoot in ProjectDocRoots)
            {
                AddDocsSignature(Path.Combine(projectRoot, relativeRoot), seen, ref fileCount, ref latestWriteTicks);
            }

            foreach (string relativeFile in RootDocFiles)
            {
                AddSignatureFile(Path.Combine(projectRoot, relativeFile), seen, ref fileCount, ref latestWriteTicks);
            }
        }

        private static void AddPackageRootSignature(string packageDirectory, HashSet<string> seen, ref int fileCount, ref long latestWriteTicks)
        {
            AddSignatureFile(Path.Combine(packageDirectory, "README.md"), seen, ref fileCount, ref latestWriteTicks);
            AddSignatureFile(Path.Combine(packageDirectory, "CHANGELOG.md"), seen, ref fileCount, ref latestWriteTicks);
            AddSignatureFile(Path.Combine(packageDirectory, "package.json"), seen, ref fileCount, ref latestWriteTicks);
        }

        private static void AddDocsSignature(string docsRoot, HashSet<string> seen, ref int fileCount, ref long latestWriteTicks)
        {
            if (!Directory.Exists(docsRoot))
            {
                return;
            }

            foreach (string filePath in SafeEnumerateFiles(docsRoot))
            {
                AddSignatureFile(filePath, seen, ref fileCount, ref latestWriteTicks);
            }
        }

        private static void AddSignatureFile(string fullPath, HashSet<string> seen, ref int fileCount, ref long latestWriteTicks)
        {
            if (string.IsNullOrWhiteSpace(fullPath) || !File.Exists(fullPath))
            {
                return;
            }

            string normalizedFullPath = Path.GetFullPath(fullPath);
            if (!seen.Add(normalizedFullPath) || !IsDocFile(normalizedFullPath))
            {
                return;
            }

            fileCount++;
            try
            {
                latestWriteTicks = Math.Max(latestWriteTicks, File.GetLastWriteTimeUtc(normalizedFullPath).Ticks);
            }
            catch (Exception)
            {
            }
        }

        private static List<DocEntry> BuildIndex(string projectRoot)
        {
            List<DocEntry> entries = new List<DocEntry>();
            HashSet<string> seenFullPaths = new HashSet<string>(StringComparer.OrdinalIgnoreCase);

            AddPackageCacheDocs(projectRoot, entries, seenFullPaths);
            AddEmbeddedPackageDocs(projectRoot, entries, seenFullPaths);
            AddProjectDocs(projectRoot, entries, seenFullPaths);

            entries.Sort((left, right) => string.Compare(left.RelativePath, right.RelativePath, StringComparison.OrdinalIgnoreCase));
            return entries;
        }

        private static void AddApiSourceHits(
            string projectRoot,
            string root,
            string source,
            string query,
            List<string> tokens,
            List<SearchHit> hits,
            HashSet<string> seenFullPaths,
            ref int scanned)
        {
            if (!Directory.Exists(root) || scanned >= MaxApiSourceFilesToScan)
            {
                return;
            }

            foreach (string fullPath in SafeEnumerateFiles(root))
            {
                if (scanned >= MaxApiSourceFilesToScan)
                {
                    return;
                }

                if (!string.Equals(Path.GetExtension(fullPath), ".cs", StringComparison.OrdinalIgnoreCase) ||
                    !IsApiSourcePath(fullPath))
                {
                    continue;
                }

                string normalizedFullPath = Path.GetFullPath(fullPath);
                if (!seenFullPaths.Add(normalizedFullPath))
                {
                    continue;
                }

                scanned++;
                string content = ReadFilePrefix(normalizedFullPath, MaxIndexedCharsPerApiFile);
                if (string.IsNullOrWhiteSpace(content))
                {
                    continue;
                }

                string relativePath = ToProjectRelativePath(projectRoot, normalizedFullPath);
                string title = Path.GetFileNameWithoutExtension(relativePath);
                string packageName = GetPackageNameFromRelativePath(relativePath);
                DocEntry entry = new DocEntry
                {
                    Id = "api-" + StableHash(relativePath),
                    FullPath = normalizedFullPath,
                    RelativePath = relativePath,
                    PackageName = packageName,
                    Source = source,
                    Title = title,
                    Content = content,
                    SearchText = BuildSearchText(relativePath, packageName, source, title, content)
                };

                int score = ScoreApiEntry(entry, query, tokens);
                if (score <= 0)
                {
                    continue;
                }

                hits.Add(new SearchHit
                {
                    Entry = entry,
                    Score = score
                });
            }
        }

        private static bool IsApiSourcePath(string fullPath)
        {
            string normalized = fullPath.Replace("\\", "/");
            return normalized.IndexOf("/Runtime/", StringComparison.OrdinalIgnoreCase) >= 0 ||
                normalized.IndexOf("/Editor/", StringComparison.OrdinalIgnoreCase) >= 0 ||
                normalized.IndexOf("/Scripts/", StringComparison.OrdinalIgnoreCase) >= 0;
        }

        private static int ScoreApiEntry(DocEntry entry, string query, List<string> tokens)
        {
            int score = ScoreEntry(entry, query, tokens);
            string content = entry.Content ?? string.Empty;
            string queryLower = query.ToLowerInvariant();
            string contentLower = content.ToLowerInvariant();

            if (contentLower.Contains(queryLower))
            {
                score += 80;
            }

            foreach (string token in tokens)
            {
                if (LooksLikeTypeName(token) && ContainsTypeDeclaration(content, token))
                {
                    score += 160;
                }

                if (ContainsPublicMemberDeclaration(content, token))
                {
                    score += 110;
                }

                if (ContainsSerializedOrInternalMemberDeclaration(content, token))
                {
                    score += 45;
                }
            }

            return score;
        }

        private static bool LooksLikeTypeName(string token)
        {
            return !string.IsNullOrWhiteSpace(token) && token.Length >= 4 && char.IsLetter(token[0]);
        }

        private static bool ContainsTypeDeclaration(string content, string token)
        {
            return ContainsAny(content, token,
                "class ",
                "struct ",
                "interface ",
                "enum ");
        }

        private static bool ContainsPublicMemberDeclaration(string content, string token)
        {
            return ContainsAny(content, token,
                "public ",
                "public static ",
                "public readonly ",
                "public virtual ",
                "public override ");
        }

        private static bool ContainsSerializedOrInternalMemberDeclaration(string content, string token)
        {
            return ContainsAny(content, token,
                "[SerializeField]",
                "internal ",
                "private ",
                "SerializedProperty ");
        }

        private static bool ContainsAny(string content, string token, params string[] prefixes)
        {
            if (string.IsNullOrWhiteSpace(content) || string.IsNullOrWhiteSpace(token))
            {
                return false;
            }

            foreach (string prefix in prefixes)
            {
                if (content.IndexOf(prefix + token, StringComparison.OrdinalIgnoreCase) >= 0)
                {
                    return true;
                }
            }

            return false;
        }

        private static void AddPackageCacheDocs(string projectRoot, List<DocEntry> entries, HashSet<string> seenFullPaths)
        {
            string packageCacheRoot = Path.Combine(projectRoot, "Library", "PackageCache");
            if (!Directory.Exists(packageCacheRoot))
            {
                return;
            }

            foreach (string packageDirectory in SafeEnumerateDirectories(packageCacheRoot))
            {
                string packageName = ExtractPackageName(Path.GetFileName(packageDirectory));
                AddPackageRootDocs(projectRoot, packageDirectory, packageName, "package-cache", entries, seenFullPaths);

                AddDocsUnder(projectRoot, Path.Combine(packageDirectory, "Documentation~"), packageName, "package-cache", entries, seenFullPaths);
                AddDocsUnder(projectRoot, Path.Combine(packageDirectory, "Documentation"), packageName, "package-cache", entries, seenFullPaths);
            }
        }

        private static void AddEmbeddedPackageDocs(string projectRoot, List<DocEntry> entries, HashSet<string> seenFullPaths)
        {
            string packagesRoot = Path.Combine(projectRoot, "Packages");
            if (!Directory.Exists(packagesRoot))
            {
                return;
            }

            foreach (string packageDirectory in SafeEnumerateDirectories(packagesRoot))
            {
                string packageName = Path.GetFileName(packageDirectory);
                AddPackageRootDocs(projectRoot, packageDirectory, packageName, "embedded-package", entries, seenFullPaths);
                AddDocsUnder(projectRoot, Path.Combine(packageDirectory, "Documentation~"), packageName, "embedded-package", entries, seenFullPaths);
                AddDocsUnder(projectRoot, Path.Combine(packageDirectory, "Documentation"), packageName, "embedded-package", entries, seenFullPaths);
            }
        }

        private static void AddProjectDocs(string projectRoot, List<DocEntry> entries, HashSet<string> seenFullPaths)
        {
            foreach (string relativeRoot in ProjectDocRoots)
            {
                AddDocsUnder(projectRoot, Path.Combine(projectRoot, relativeRoot), string.Empty, "project-docs", entries, seenFullPaths);
            }

            foreach (string relativeFile in RootDocFiles)
            {
                AddDocFile(projectRoot, Path.Combine(projectRoot, relativeFile), string.Empty, "project-docs", entries, seenFullPaths);
            }
        }

        private static void AddPackageRootDocs(
            string projectRoot,
            string packageDirectory,
            string packageName,
            string source,
            List<DocEntry> entries,
            HashSet<string> seenFullPaths)
        {
            AddDocFile(projectRoot, Path.Combine(packageDirectory, "README.md"), packageName, source, entries, seenFullPaths);
            AddDocFile(projectRoot, Path.Combine(packageDirectory, "CHANGELOG.md"), packageName, source, entries, seenFullPaths);
            AddDocFile(projectRoot, Path.Combine(packageDirectory, "package.json"), packageName, source, entries, seenFullPaths);
        }

        private static void AddDocsUnder(
            string projectRoot,
            string docsRoot,
            string packageName,
            string source,
            List<DocEntry> entries,
            HashSet<string> seenFullPaths)
        {
            if (!Directory.Exists(docsRoot))
            {
                return;
            }

            foreach (string filePath in SafeEnumerateFiles(docsRoot))
            {
                AddDocFile(projectRoot, filePath, packageName, source, entries, seenFullPaths);
            }
        }

        private static void AddDocFile(
            string projectRoot,
            string fullPath,
            string packageName,
            string source,
            List<DocEntry> entries,
            HashSet<string> seenFullPaths)
        {
            if (string.IsNullOrWhiteSpace(fullPath) || !File.Exists(fullPath))
            {
                return;
            }

            string normalizedFullPath = Path.GetFullPath(fullPath);
            if (!seenFullPaths.Add(normalizedFullPath) || !IsDocFile(normalizedFullPath))
            {
                return;
            }

            string content = ReadFilePrefix(normalizedFullPath, MaxIndexedCharsPerFile);
            if (string.IsNullOrWhiteSpace(content))
            {
                return;
            }

            string relativePath = ToProjectRelativePath(projectRoot, normalizedFullPath);
            string title = ExtractTitle(content, relativePath);
            entries.Add(new DocEntry
            {
                Id = "doc-" + StableHash(relativePath),
                FullPath = normalizedFullPath,
                RelativePath = relativePath,
                PackageName = packageName ?? string.Empty,
                Source = source ?? string.Empty,
                Title = title,
                Content = content,
                SearchText = BuildSearchText(relativePath, packageName, source, title, content)
            });
        }

        private static bool IsDocFile(string fullPath)
        {
            string fileName = Path.GetFileName(fullPath);
            if (string.IsNullOrWhiteSpace(fileName) || fileName.EndsWith(".meta", StringComparison.OrdinalIgnoreCase))
            {
                return false;
            }

            string lowerName = fileName.ToLowerInvariant();
            if (lowerName.StartsWith("license", StringComparison.Ordinal) ||
                lowerName.StartsWith("third party", StringComparison.Ordinal) ||
                lowerName.StartsWith("thirdparty", StringComparison.Ordinal) ||
                lowerName.Contains("notices"))
            {
                return false;
            }

            switch (Path.GetExtension(fullPath).ToLowerInvariant())
            {
                case ".asmdef":
                case ".cginc":
                case ".compute":
                case ".cs":
                case ".css":
                case ".hlsl":
                case ".htm":
                case ".html":
                case ".json":
                case ".md":
                case ".shader":
                case ".txt":
                case ".uss":
                case ".uxml":
                case ".xml":
                case ".yaml":
                case ".yml":
                    return true;
                default:
                    return false;
            }
        }

        private static int ScoreEntry(DocEntry entry, string query, List<string> tokens)
        {
            int score = 0;
            string queryLower = query.ToLowerInvariant();
            string pathLower = entry.RelativePath.ToLowerInvariant();
            string titleLower = entry.Title.ToLowerInvariant();
            string packageLower = entry.PackageName.ToLowerInvariant();

            if (string.Equals(entry.Source, "project-docs", StringComparison.Ordinal))
            {
                score += 40;
            }

            if (titleLower.Contains(queryLower))
            {
                score += 120;
            }

            if (pathLower.Contains(queryLower))
            {
                score += 90;
            }

            if (entry.SearchText.Contains(queryLower))
            {
                score += 45;
            }

            foreach (string token in tokens)
            {
                if (titleLower.Contains(token))
                {
                    score += 35;
                }

                if (Path.GetFileNameWithoutExtension(pathLower).Contains(token))
                {
                    score += 26;
                }

                if (pathLower.Contains(token))
                {
                    score += 18;
                }

                if (!string.IsNullOrWhiteSpace(packageLower) && packageLower.Contains(token))
                {
                    score += 16;
                }

                score += Math.Min(CountOccurrences(entry.SearchText, token), 30);
            }

            return score;
        }

        private static string BuildSnippets(string content, string query, List<string> tokens, int maxSnippets)
        {
            if (string.IsNullOrWhiteSpace(content))
            {
                return string.Empty;
            }

            List<int> starts = new List<int>();
            string lowerContent = content.ToLowerInvariant();
            string queryLower = query.ToLowerInvariant();
            int phraseIndex = lowerContent.IndexOf(queryLower, StringComparison.Ordinal);
            if (phraseIndex >= 0)
            {
                starts.Add(phraseIndex);
            }

            foreach (string token in tokens)
            {
                if (starts.Count >= maxSnippets)
                {
                    break;
                }

                int index = lowerContent.IndexOf(token, StringComparison.Ordinal);
                if (index >= 0 && !IsNearExisting(starts, index))
                {
                    starts.Add(index);
                }
            }

            if (starts.Count == 0)
            {
                return string.Empty;
            }

            StringBuilder builder = new StringBuilder();
            for (int i = 0; i < starts.Count && i < maxSnippets; i++)
            {
                string snippet = ExtractSnippet(content, starts[i], MaxSnippetChars);
                if (!string.IsNullOrWhiteSpace(snippet))
                {
                    builder.AppendLine("  snippet: " + snippet);
                }
            }

            return builder.ToString();
        }

        private static string ExtractSnippet(string content, int index, int maxChars)
        {
            int start = Math.Max(0, index - maxChars / 3);
            int end = Math.Min(content.Length, start + maxChars);
            string snippet = content.Substring(start, end - start);
            snippet = CollapseWhitespace(snippet);
            if (start > 0)
            {
                snippet = "..." + snippet;
            }

            if (end < content.Length)
            {
                snippet += "...";
            }

            return snippet;
        }

        private static bool IsNearExisting(List<int> starts, int index)
        {
            foreach (int start in starts)
            {
                if (Math.Abs(start - index) < MaxSnippetChars)
                {
                    return true;
                }
            }

            return false;
        }

        private static List<DocEntry> FindMatches(List<DocEntry> entries, string idOrPath)
        {
            string normalized = NormalizePath(idOrPath);
            List<DocEntry> exact = new List<DocEntry>();
            foreach (DocEntry entry in entries)
            {
                if (string.Equals(entry.Id, idOrPath, StringComparison.OrdinalIgnoreCase) ||
                    string.Equals(entry.RelativePath, normalized, StringComparison.OrdinalIgnoreCase))
                {
                    exact.Add(entry);
                }
            }

            if (exact.Count > 0)
            {
                return exact;
            }

            List<DocEntry> partial = new List<DocEntry>();
            foreach (DocEntry entry in entries)
            {
                if (entry.RelativePath.IndexOf(normalized, StringComparison.OrdinalIgnoreCase) >= 0 ||
                    entry.Title.IndexOf(idOrPath, StringComparison.OrdinalIgnoreCase) >= 0)
                {
                    partial.Add(entry);
                }
            }

            partial.Sort((left, right) => string.Compare(left.RelativePath, right.RelativePath, StringComparison.OrdinalIgnoreCase));
            return partial;
        }

        private static List<string> Tokenize(string value)
        {
            List<string> tokens = new List<string>();
            HashSet<string> seen = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
            StringBuilder token = new StringBuilder();
            for (int i = 0; i < value.Length; i++)
            {
                char character = char.ToLowerInvariant(value[i]);
                if (char.IsLetterOrDigit(character) || character == '_' || character == '.')
                {
                    token.Append(character);
                    continue;
                }

                AddToken(tokens, seen, token);
            }

            AddToken(tokens, seen, token);
            return tokens;
        }

        private static void AddToken(List<string> tokens, HashSet<string> seen, StringBuilder token)
        {
            if (token.Length == 0)
            {
                return;
            }

            string value = token.ToString();
            token.Length = 0;
            if (value.Length < 2 || IsStopWord(value) || !seen.Add(value))
            {
                return;
            }

            tokens.Add(value);
        }

        private static bool IsStopWord(string token)
        {
            switch (token)
            {
                case "a":
                case "an":
                case "and":
                case "are":
                case "for":
                case "how":
                case "in":
                case "is":
                case "it":
                case "of":
                case "on":
                case "or":
                case "the":
                case "to":
                case "use":
                case "with":
                    return true;
                default:
                    return false;
            }
        }

        private static int CountOccurrences(string text, string token)
        {
            int count = 0;
            int index = 0;
            while (count < 50)
            {
                index = text.IndexOf(token, index, StringComparison.Ordinal);
                if (index < 0)
                {
                    break;
                }

                count++;
                index += token.Length;
            }

            return count;
        }

        private static string BuildSearchText(string relativePath, string packageName, string source, string title, string content)
        {
            return (relativePath + "\n" + packageName + "\n" + source + "\n" + title + "\n" + content).ToLowerInvariant();
        }

        private static string ExtractTitle(string content, string relativePath)
        {
            using (StringReader reader = new StringReader(content))
            {
                string line;
                while ((line = reader.ReadLine()) != null)
                {
                    string trimmed = line.Trim();
                    if (trimmed.StartsWith("#", StringComparison.Ordinal))
                    {
                        return CollapseWhitespace(trimmed.TrimStart('#').Trim());
                    }
                }
            }

            return Path.GetFileNameWithoutExtension(relativePath);
        }

        private static string CollapseWhitespace(string value)
        {
            if (string.IsNullOrWhiteSpace(value))
            {
                return string.Empty;
            }

            StringBuilder builder = new StringBuilder(value.Length);
            bool lastWasWhitespace = false;
            foreach (char character in value)
            {
                if (char.IsWhiteSpace(character))
                {
                    if (!lastWasWhitespace)
                    {
                        builder.Append(' ');
                        lastWasWhitespace = true;
                    }

                    continue;
                }

                builder.Append(character);
                lastWasWhitespace = false;
            }

            return builder.ToString().Trim();
        }

        private static IEnumerable<string> SafeEnumerateDirectories(string root)
        {
            string[] directories;
            try
            {
                directories = Directory.Exists(root) ? Directory.GetDirectories(root) : new string[0];
            }
            catch (Exception)
            {
                directories = new string[0];
            }

            foreach (string directory in directories)
            {
                if (!ShouldSkipDirectory(directory))
                {
                    yield return directory;
                }
            }
        }

        private static IEnumerable<string> SafeEnumerateFiles(string root)
        {
            Stack<string> pending = new Stack<string>();
            if (Directory.Exists(root))
            {
                pending.Push(root);
            }

            while (pending.Count > 0)
            {
                string directory = pending.Pop();
                string[] files;
                try
                {
                    files = Directory.GetFiles(directory);
                }
                catch (Exception)
                {
                    files = new string[0];
                }

                foreach (string file in files)
                {
                    yield return file;
                }

                string[] directories;
                try
                {
                    directories = Directory.GetDirectories(directory);
                }
                catch (Exception)
                {
                    directories = new string[0];
                }

                foreach (string child in directories)
                {
                    if (!ShouldSkipDirectory(child))
                    {
                        pending.Push(child);
                    }
                }
            }
        }

        private static bool ShouldSkipDirectory(string path)
        {
            string name = Path.GetFileName(path);
            return string.IsNullOrWhiteSpace(name) ||
                string.Equals(name, ".git", StringComparison.OrdinalIgnoreCase) ||
                string.Equals(name, "Temp", StringComparison.OrdinalIgnoreCase) ||
                string.Equals(name, "Obj", StringComparison.OrdinalIgnoreCase);
        }

        private static string ReadFilePrefix(string fullPath, int maxChars)
        {
            try
            {
                using (FileStream stream = new FileStream(fullPath, FileMode.Open, FileAccess.Read, FileShare.ReadWrite))
                using (StreamReader reader = new StreamReader(stream, Encoding.UTF8, true))
                {
                    char[] buffer = new char[maxChars];
                    int count = reader.ReadBlock(buffer, 0, buffer.Length);
                    return new string(buffer, 0, count);
                }
            }
            catch (Exception)
            {
                return string.Empty;
            }
        }

        private static string GetProjectRoot()
        {
            return Path.GetFullPath(Directory.GetParent(Application.dataPath)?.FullName ?? Directory.GetCurrentDirectory());
        }

        private static string ToProjectRelativePath(string projectRoot, string fullPath)
        {
            string normalizedRoot = Path.GetFullPath(projectRoot).Replace("\\", "/").TrimEnd('/');
            string normalizedFullPath = Path.GetFullPath(fullPath).Replace("\\", "/");
            if (normalizedFullPath.StartsWith(normalizedRoot + "/", StringComparison.Ordinal))
            {
                return normalizedFullPath.Substring(normalizedRoot.Length + 1);
            }

            return normalizedFullPath;
        }

        private static string NormalizePath(string path)
        {
            return (path ?? string.Empty).Trim().Replace("\\", "/").TrimStart('/');
        }

        private static string ExtractPackageName(string packageDirectoryName)
        {
            if (string.IsNullOrWhiteSpace(packageDirectoryName))
            {
                return string.Empty;
            }

            int atIndex = packageDirectoryName.IndexOf('@');
            return atIndex > 0 ? packageDirectoryName.Substring(0, atIndex) : packageDirectoryName;
        }

        private static string GetPackageNameFromRelativePath(string relativePath)
        {
            if (string.IsNullOrWhiteSpace(relativePath))
            {
                return string.Empty;
            }

            string normalized = relativePath.Replace("\\", "/");
            const string packageCachePrefix = "Library/PackageCache/";
            if (normalized.StartsWith(packageCachePrefix, StringComparison.Ordinal))
            {
                string remainder = normalized.Substring(packageCachePrefix.Length);
                int slash = remainder.IndexOf('/');
                return ExtractPackageName(slash <= 0 ? remainder : remainder.Substring(0, slash));
            }

            const string packagesPrefix = "Packages/";
            if (normalized.StartsWith(packagesPrefix, StringComparison.Ordinal))
            {
                string remainder = normalized.Substring(packagesPrefix.Length);
                int slash = remainder.IndexOf('/');
                return slash <= 0 ? remainder : remainder.Substring(0, slash);
            }

            return string.Empty;
        }

        private static string StableHash(string value)
        {
            unchecked
            {
                uint hash = 2166136261;
                foreach (char character in value ?? string.Empty)
                {
                    hash ^= char.ToLowerInvariant(character);
                    hash *= 16777619;
                }

                return hash.ToString("x8");
            }
        }

        private sealed class DocEntry
        {
            public string Id;
            public string FullPath;
            public string RelativePath;
            public string PackageName;
            public string Source;
            public string Title;
            public string Content;
            public string SearchText;
        }

        private sealed class SearchHit
        {
            public DocEntry Entry;
            public int Score;
        }
    }
}
