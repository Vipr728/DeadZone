using System;

namespace AgenticGamedev.EditorTools
{
    internal static class AgenticPrototypeBuilder
    {
        public static string RunPrompt(string prompt)
        {
            if (!TryPrepareRun(prompt, null, out AgenticAgentBridge.PreparedRequest request, out string immediateResponse))
            {
                return AgenticAgentBridge.GetBackendRequiredMessage();
            }

            if (request == null)
            {
                return immediateResponse;
            }

            try
            {
                string responseJson = AgenticAgentBridge.SendPreparedRequest(request);
                return AgenticAgentBridge.CompletePreparedRequest(request, responseJson);
            }
            catch (Exception exception)
            {
                return $"{request.DisplayName} request failed: {AgenticAgentBridge.FormatRequestException(exception)}";
            }
        }

        public static bool TryPrepareRun(
            string prompt,
            Action<string> progress,
            out AgenticAgentBridge.PreparedRequest request,
            out string immediateResponse)
        {
            request = null;
            immediateResponse = string.Empty;
            string normalized = (prompt ?? string.Empty).Trim().ToLowerInvariant();

            if (string.IsNullOrWhiteSpace(normalized))
            {
                immediateResponse = "Ask a Unity question or describe the scene, project, asset, or code change you want.";
                return true;
            }

            if (IsExplicitHelpPrompt(normalized))
            {
                progress?.Invoke("Preparing quick reference");
                immediateResponse = GetHelpText();
                return true;
            }

            if (IsExplicitContextPrompt(normalized))
            {
                progress?.Invoke("Reading scene, project, and Game view context");
                immediateResponse = AgenticAgentBridge.BuildContext();
                return true;
            }

            return AgenticAgentBridge.TryPreparePromptRequest(prompt, progress, out request, out immediateResponse);
        }

        private static string GetHelpText()
        {
            return "Ask normal Unity questions or describe a project change. Questions are answered directly; scene, asset, and code changes show an approval plan before anything is applied. Use /context when you need the raw Unity scene and project snapshot.";
        }

        private static bool IsExplicitHelpPrompt(string normalized)
        {
            return normalized == "help" ||
                normalized == "commands" ||
                normalized == "/help" ||
                normalized == "/commands" ||
                normalized == "agentic help" ||
                normalized == "agentic commands";
        }

        private static bool IsExplicitContextPrompt(string normalized)
        {
            return normalized == "/context" ||
                normalized == "/scene" ||
                normalized == "/project" ||
                normalized == "scene context" ||
                normalized == "scene summary" ||
                normalized == "project context" ||
                normalized == "project summary" ||
                normalized == "copy scene context" ||
                normalized == "copy project context" ||
                normalized == "show scene context" ||
                normalized == "show project context";
        }
    }
}
