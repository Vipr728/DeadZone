using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Net;
using System.Text.RegularExpressions;
using System.Threading;
using UnityEditor;
using PackageInfo = UnityEditor.PackageManager.PackageInfo;
using UnityEngine;
using Debug = UnityEngine.Debug;

namespace AgenticGamedev.EditorTools
{
    internal static class AgenticAgentDaemonLauncher
    {
        private const string HealthUrl = "http://127.0.0.1:47391/health";
        private const string ReadyUrl = "http://127.0.0.1:47391/ready";
        private const string AgentEndpoint = "http://127.0.0.1:47391/agent";

        private static Process launchedProcess;
        private static string pendingProjectRoot;
        private static string pendingLogPath;
        private static bool pendingShowDialog;
        private static double pendingDeadline;
        private static double nextPendingCheckTime;

        [MenuItem("Tools/Ark/Agent Backend/Start Local Daemon")]
        public static void StartLocalDaemonFromMenu()
        {
            StartLocalDaemon(showDialog: true);
        }

        [MenuItem("Tools/Ark/Agent Backend/Check Local Daemon")]
        public static void CheckLocalDaemonFromMenu()
        {
            string currentProjectRoot = GetProjectRoot();
            if (TryReadDaemonStatus(out DaemonHealth health, out string error))
            {
                string message = $"Ark AgentDaemon is running.\n\nProject root:\n{health.ProjectRoot}\n\nCurrent Unity project:\n{currentProjectRoot}";
                EditorUtility.DisplayDialog("Ark AgentDaemon", message, "OK");
                Debug.Log(message);
                return;
            }

            EditorUtility.DisplayDialog("Ark AgentDaemon", $"Ark AgentDaemon is not reachable at {HealthUrl}.\n\n{error}", "OK");
        }

        [MenuItem("Tools/Ark/Agent Backend/Stop Launched Daemon")]
        public static void StopLaunchedDaemonFromMenu()
        {
            StopLaunchedDaemon(showDialog: true);
        }

        public static bool StartLocalDaemon(bool showDialog)
        {
            string currentProjectRoot = GetProjectRoot();
            if (!AgenticUnityMcpBridge.EnsureServerRunningForCurrentProject(out string unityBridgeUrl, out string bridgeError))
            {
                EditorUtility.DisplayDialog(
                    "Ark Unity Bridge Failed",
                    $"Could not start the Ark Unity bridge for this project.\n\n{bridgeError}",
                    "OK");
                return false;
            }

            if (TryReadDaemonStatus(out DaemonHealth existingHealth, out _))
            {
                if (IsSamePath(existingHealth.ProjectRoot, currentProjectRoot))
                {
                    if (IsDaemonUsingBridge(unityBridgeUrl))
                    {
                        AgenticAgentBridge.SetCustomEndpoint(AgentEndpoint);
                        if (showDialog)
                        {
                            EditorUtility.DisplayDialog("Ark AgentDaemon", "Ark AgentDaemon is already running for this Unity project.", "OK");
                        }

                        return true;
                    }

                    Debug.Log("Restarting Ark AgentDaemon so it uses this Unity project's bridge.");
                    if (!StopDaemonOnPort(out string staleStopError))
                    {
                        EditorUtility.DisplayDialog("Ark AgentDaemon", $"Could not stop the stale daemon:\n{staleStopError}", "OK");
                        return false;
                    }

                    Thread.Sleep(500);
                }
                else
                {
                    string project = string.IsNullOrWhiteSpace(existingHealth.ProjectRoot) ? "(unknown project)" : existingHealth.ProjectRoot;
                    EditorUtility.DisplayDialog(
                        "Ark AgentDaemon Already Running",
                        $"Port 47391 is already serving another Ark daemon.\n\nDaemon project:\n{project}\n\nCurrent Unity project:\n{currentProjectRoot}",
                        "OK");

                    if (!EditorUtility.DisplayDialog(
                        "Restart Ark AgentDaemon",
                        "Stop the daemon currently listening on 47391 and start a new one for this Unity project?",
                        "Stop and Start",
                        "Cancel"))
                    {
                        return false;
                    }

                    if (!StopDaemonOnPort(out string stopError))
                    {
                        EditorUtility.DisplayDialog("Ark AgentDaemon", $"Could not stop the existing daemon:\n{stopError}", "OK");
                        return false;
                    }

                    Thread.Sleep(500);
                }
            }

            string serverPath = FindDaemonServerPath(currentProjectRoot);
            if (string.IsNullOrWhiteSpace(serverPath))
            {
                string expectedPaths = string.Join("\n", GetDaemonServerCandidates(currentProjectRoot));
                EditorUtility.DisplayDialog(
                    "Ark AgentDaemon Not Found",
                    "Could not find AgentDaemon/src/server.mjs in this project or inside the Ark package.\n\nExpected one of:\n" +
                    expectedPaths,
                    "OK");
                return false;
            }

            string nodePath = FindNodeExecutable();
            if (string.IsNullOrWhiteSpace(nodePath))
            {
                EditorUtility.DisplayDialog(
                    "Node.js Not Found",
                    "Ark AgentDaemon requires Node.js. Install Node.js or set ARK_NODE_PATH to the node executable, then press Start Local Daemon again.",
                    "OK");
                return false;
            }

            Directory.CreateDirectory(Path.Combine(currentProjectRoot, "Library", "AgenticGamedev"));
            string logPath = Path.Combine(currentProjectRoot, "Library", "AgenticGamedev", "agent-daemon.log");

            ProcessStartInfo startInfo = new ProcessStartInfo
            {
                FileName = nodePath,
                Arguments = QuoteArgument(serverPath),
                WorkingDirectory = currentProjectRoot,
                UseShellExecute = false,
                CreateNoWindow = true,
                RedirectStandardOutput = true,
                RedirectStandardError = true
            };
            startInfo.EnvironmentVariables["AGENT_PROJECT_ROOT"] = currentProjectRoot;
            startInfo.EnvironmentVariables["AGENT_DAEMON_RUN_DIR"] = Path.Combine(currentProjectRoot, "Library", "AgenticGamedev", "AgentDaemonRuns");
            startInfo.EnvironmentVariables["AGENT_UNITY_BRIDGE_URL"] = unityBridgeUrl;

            string apiKey = AgenticAgentBridge.GetConfiguredApiKey();
            if (!string.IsNullOrWhiteSpace(apiKey))
            {
                startInfo.EnvironmentVariables["OPENAI_API_KEY"] = apiKey;
            }

            string model = AgenticAgentBridge.GetConfiguredModel();
            if (!string.IsNullOrWhiteSpace(model))
            {
                startInfo.EnvironmentVariables["AGENT_OPENAI_MODEL"] = model;
                startInfo.EnvironmentVariables["AGENT_OPENCLAW_MODEL"] = model;
            }

            string tavilyApiKey = AgenticAgentBridge.GetConfiguredTavilyApiKey();
            if (!string.IsNullOrWhiteSpace(tavilyApiKey))
            {
                startInfo.EnvironmentVariables["TAVILY_API_KEY"] = tavilyApiKey;
            }

            try
            {
                launchedProcess = Process.Start(startInfo);
                AttachLogForwarders(launchedProcess, logPath);
                AgenticAgentBridge.SetCustomEndpoint(AgentEndpoint);
            }
            catch (Exception exception)
            {
                EditorUtility.DisplayDialog("Ark AgentDaemon Failed", $"Could not start AgentDaemon:\n{exception.Message}", "OK");
                return false;
            }

            ScheduleStartResultCheck(currentProjectRoot, logPath, showDialog);
            return true;
        }

        public static void StopLaunchedDaemon(bool showDialog)
        {
            if (launchedProcess == null || launchedProcess.HasExited)
            {
                if (showDialog)
                {
                    EditorUtility.DisplayDialog("Ark AgentDaemon", "This Unity editor did not launch a running daemon process.", "OK");
                }

                return;
            }

            try
            {
                launchedProcess.Kill();
                launchedProcess.Dispose();
                launchedProcess = null;
                if (showDialog)
                {
                    EditorUtility.DisplayDialog("Ark AgentDaemon", "Stopped the daemon process launched by this Unity editor.", "OK");
                }
            }
            catch (Exception exception)
            {
                EditorUtility.DisplayDialog("Ark AgentDaemon", $"Could not stop launched daemon:\n{exception.Message}", "OK");
            }
        }

        private static void ScheduleStartResultCheck(string expectedProjectRoot, string logPath, bool showDialog)
        {
            pendingProjectRoot = expectedProjectRoot;
            pendingLogPath = logPath;
            pendingShowDialog = showDialog;
            pendingDeadline = EditorApplication.timeSinceStartup + 8d;
            nextPendingCheckTime = EditorApplication.timeSinceStartup + 0.25d;
            EditorApplication.update -= PollStartResult;
            EditorApplication.update += PollStartResult;
        }

        private static void PollStartResult()
        {
            if (EditorApplication.timeSinceStartup < nextPendingCheckTime)
            {
                return;
            }

            if (TryReadDaemonStatus(out DaemonHealth health, out string error) && IsSamePath(health.ProjectRoot, pendingProjectRoot))
            {
                EditorApplication.update -= PollStartResult;
                string message = $"Ark AgentDaemon started for:\n{pendingProjectRoot}";
                Debug.Log(message);
                if (pendingShowDialog)
                {
                    EditorUtility.DisplayDialog("Ark AgentDaemon", message, "OK");
                }

                return;
            }

            if (launchedProcess != null && launchedProcess.HasExited)
            {
                EditorApplication.update -= PollStartResult;
                string detail = $"Daemon process exited with code {launchedProcess.ExitCode}.";
                Debug.LogWarning($"Ark AgentDaemon start failed: {detail}");
                if (pendingShowDialog)
                {
                    EditorUtility.DisplayDialog(
                        "Ark AgentDaemon",
                        $"{detail}\n\nCheck {pendingLogPath}.",
                        "OK");
                }

                return;
            }

            if (EditorApplication.timeSinceStartup < pendingDeadline)
            {
                nextPendingCheckTime = EditorApplication.timeSinceStartup + 0.5d;
                return;
            }

            EditorApplication.update -= PollStartResult;
            string finalDetail = string.IsNullOrWhiteSpace(error) ? "The daemon did not report the expected project root." : error;
            Debug.LogWarning($"Ark AgentDaemon start check failed: {finalDetail}");
            if (pendingShowDialog)
            {
                EditorUtility.DisplayDialog(
                    "Ark AgentDaemon",
                    $"Started the daemon process, but it is not ready yet.\n\n{finalDetail}\n\nCheck {pendingLogPath}.",
                    "OK");
            }
        }

        private static string FindDaemonServerPath(string projectRoot)
        {
            foreach (string candidate in GetDaemonServerCandidates(projectRoot))
            {
                if (File.Exists(candidate))
                {
                    return Path.GetFullPath(candidate);
                }
            }

            return string.Empty;
        }

        private static string[] GetDaemonServerCandidates(string projectRoot)
        {
            List<string> candidates = new List<string>();
            AddCandidate(candidates, Path.Combine(projectRoot, "AgentDaemon", "src", "server.mjs"));
            AddCandidate(candidates, Path.Combine(projectRoot, "Assets", "Ark", "AgentDaemon", "src", "server.mjs"));
            AddCandidate(candidates, Path.Combine(projectRoot, "Packages", "com.ark.agentic-gamedev", "AgentDaemon", "src", "server.mjs"));

            string resolvedPackageRoot = GetResolvedPackageRoot();
            if (!string.IsNullOrWhiteSpace(resolvedPackageRoot))
            {
                AddCandidate(candidates, Path.Combine(resolvedPackageRoot, "AgentDaemon", "src", "server.mjs"));
            }

            return candidates.ToArray();
        }

        private static void AddCandidate(List<string> candidates, string path)
        {
            string fullPath = Path.GetFullPath(path);
            foreach (string existing in candidates)
            {
                if (IsSamePath(existing, fullPath))
                {
                    return;
                }
            }

            candidates.Add(fullPath);
        }

        private static string GetResolvedPackageRoot()
        {
            try
            {
                PackageInfo packageInfo = PackageInfo.FindForAssembly(typeof(AgenticAgentDaemonLauncher).Assembly);
                return string.IsNullOrWhiteSpace(packageInfo?.resolvedPath) ? string.Empty : packageInfo.resolvedPath;
            }
            catch
            {
                return string.Empty;
            }
        }

        private static string FindNodeExecutable()
        {
            string configured = Environment.GetEnvironmentVariable("ARK_NODE_PATH");
            if (!string.IsNullOrWhiteSpace(configured) && File.Exists(configured))
            {
                return configured;
            }

            string[] commonPaths =
            {
                "/opt/homebrew/bin/node",
                "/usr/local/bin/node",
                "/usr/bin/node",
                "C:\\Program Files\\nodejs\\node.exe",
                "C:\\Program Files (x86)\\nodejs\\node.exe"
            };

            foreach (string path in commonPaths)
            {
                if (File.Exists(path))
                {
                    return path;
                }
            }

            string shellNode = FindNodeWithShell();
            return string.IsNullOrWhiteSpace(shellNode) ? "node" : shellNode;
        }

        private static string FindNodeWithShell()
        {
            if (!File.Exists("/bin/zsh"))
            {
                return string.Empty;
            }

            try
            {
                ProcessStartInfo info = new ProcessStartInfo
                {
                    FileName = "/bin/zsh",
                    Arguments = "-lc \"command -v node\"",
                    UseShellExecute = false,
                    RedirectStandardOutput = true,
                    RedirectStandardError = true,
                    CreateNoWindow = true
                };
                using Process process = Process.Start(info);
                if (process == null)
                {
                    return string.Empty;
                }

                string output = process.StandardOutput.ReadToEnd().Trim();
                process.WaitForExit(2000);
                return File.Exists(output) ? output : string.Empty;
            }
            catch
            {
                return string.Empty;
            }
        }

        private static bool StopDaemonOnPort(out string error)
        {
            error = string.Empty;

            if (launchedProcess != null && !launchedProcess.HasExited)
            {
                try
                {
                    launchedProcess.Kill();
                    launchedProcess.Dispose();
                    launchedProcess = null;
                    return true;
                }
                catch (Exception exception)
                {
                    error = exception.Message;
                    return false;
                }
            }

            if (File.Exists("/usr/sbin/lsof") || File.Exists("/usr/bin/lsof"))
            {
                return StopDaemonOnPortWithShell(out error);
            }

            error = "Could not find lsof to identify the process on port 47391. Stop the existing daemon manually, then press Start Local Daemon again.";
            return false;
        }

        private static bool StopDaemonOnPortWithShell(out string error)
        {
            error = string.Empty;
            try
            {
                ProcessStartInfo info = new ProcessStartInfo
                {
                    FileName = "/bin/zsh",
                    Arguments = "-lc \"pids=$(lsof -tiTCP:47391 -sTCP:LISTEN); if [ -n \\\"$pids\\\" ]; then kill $pids; fi\"",
                    UseShellExecute = false,
                    RedirectStandardOutput = true,
                    RedirectStandardError = true,
                    CreateNoWindow = true
                };

                using Process process = Process.Start(info);
                if (process == null)
                {
                    error = "Could not start shell process.";
                    return false;
                }

                string stderr = process.StandardError.ReadToEnd().Trim();
                process.WaitForExit(3000);
                if (process.ExitCode != 0)
                {
                    error = string.IsNullOrWhiteSpace(stderr) ? $"kill command exited with {process.ExitCode}" : stderr;
                    return false;
                }

                return true;
            }
            catch (Exception exception)
            {
                error = exception.Message;
                return false;
            }
        }

        private static bool TryReadDaemonStatus(out DaemonHealth health, out string error)
        {
            if (TryReadDaemonStatusUrl(ReadyUrl, 1200, out health, out error))
            {
                return true;
            }

            return TryReadDaemonStatusUrl(HealthUrl, 4500, out health, out error);
        }

        private static bool IsDaemonUsingBridge(string expectedBridgeUrl)
        {
            if (!TryReadDaemonStatusUrl(HealthUrl, 4500, out DaemonHealth health, out _))
            {
                return false;
            }

            return IsSameUrl(health.UnityBridgeUrl, expectedBridgeUrl);
        }

        private static bool TryReadDaemonStatusUrl(string url, int timeoutMilliseconds, out DaemonHealth health, out string error)
        {
            health = default;
            error = string.Empty;
            try
            {
                HttpWebRequest request = (HttpWebRequest)WebRequest.Create(url);
                request.Method = "GET";
                request.Timeout = timeoutMilliseconds;
                using WebResponse response = request.GetResponse();
                using Stream stream = response.GetResponseStream();
                using StreamReader reader = new StreamReader(stream);
                string json = reader.ReadToEnd();
                health = new DaemonHealth
                {
                    ProjectRoot = ExtractJsonString(json, "project_root"),
                    Cwd = ExtractJsonString(json, "cwd"),
                    RunDir = ExtractJsonString(json, "run_dir"),
                    UnityProject = ExtractJsonString(json, "project"),
                    UnityScene = ExtractJsonString(json, "scene"),
                    UnityBridgeUrl = ExtractJsonString(json, "bridge_url")
                };
                return true;
            }
            catch (Exception exception)
            {
                error = exception.Message;
                return false;
            }
        }

        private static string ExtractJsonString(string json, string key)
        {
            Match match = Regex.Match(json ?? string.Empty, $"\"{Regex.Escape(key)}\"\\s*:\\s*\"(?<value>(?:\\\\.|[^\"])*)\"");
            return match.Success ? Regex.Unescape(match.Groups["value"].Value) : string.Empty;
        }

        private static void AttachLogForwarders(Process process, string logPath)
        {
            if (process == null)
            {
                return;
            }

            process.EnableRaisingEvents = true;
            process.Exited += (_, _) => AppendLogLine(logPath, $"AgentDaemon process exited with code {process.ExitCode}.");
            process.OutputDataReceived += (_, args) => AppendLogLine(logPath, args.Data);
            process.ErrorDataReceived += (_, args) => AppendLogLine(logPath, args.Data);
            process.BeginOutputReadLine();
            process.BeginErrorReadLine();
        }

        private static void AppendLogLine(string logPath, string line)
        {
            if (string.IsNullOrEmpty(line))
            {
                return;
            }

            try
            {
                File.AppendAllText(logPath, $"[{DateTime.Now:yyyy-MM-dd HH:mm:ss}] {line}{Environment.NewLine}");
            }
            catch
            {
                // Logging should never break daemon startup.
            }
        }

        private static string GetProjectRoot()
        {
            return Path.GetFullPath(Path.Combine(Application.dataPath, ".."));
        }

        private static bool IsSamePath(string left, string right)
        {
            if (string.IsNullOrWhiteSpace(left) || string.IsNullOrWhiteSpace(right))
            {
                return false;
            }

            string normalizedLeft = Path.GetFullPath(left).TrimEnd(Path.DirectorySeparatorChar, Path.AltDirectorySeparatorChar);
            string normalizedRight = Path.GetFullPath(right).TrimEnd(Path.DirectorySeparatorChar, Path.AltDirectorySeparatorChar);
            return string.Equals(normalizedLeft, normalizedRight, StringComparison.OrdinalIgnoreCase);
        }

        private static bool IsSameUrl(string left, string right)
        {
            return string.Equals(
                (left ?? string.Empty).Trim().TrimEnd('/'),
                (right ?? string.Empty).Trim().TrimEnd('/'),
                StringComparison.OrdinalIgnoreCase);
        }

        private static string QuoteArgument(string value)
        {
            return "\"" + (value ?? string.Empty).Replace("\"", "\\\"") + "\"";
        }

        private struct DaemonHealth
        {
            public string ProjectRoot;
            public string Cwd;
            public string RunDir;
            public string UnityProject;
            public string UnityScene;
            public string UnityBridgeUrl;
        }
    }
}
