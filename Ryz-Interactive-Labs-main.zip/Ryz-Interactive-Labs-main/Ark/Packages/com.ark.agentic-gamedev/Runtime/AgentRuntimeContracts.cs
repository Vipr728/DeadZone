using System;

namespace AgenticGamedev.Runtime
{
    [Serializable]
    public sealed class AgentActionSpec
    {
        public string Name;
        public string Description;
        public string JsonArgumentsSchema;
    }

    [Serializable]
    public sealed class AgentActionResult
    {
        public bool Success;
        public string Summary;
        public string PayloadJson;
        public string ErrorCode;
        public string ErrorMessage;
    }

    [Serializable]
    public sealed class AgentRuntimeEvent
    {
        public string Name;
        public string PayloadJson;
        public double TimeSeconds;
    }

    [Serializable]
    public sealed class AgentRuntimeSnapshot
    {
        public string SessionId;
        public string SceneName;
        public double TimeSeconds;
        public string PayloadJson;
        public AgentRuntimeEvent[] RecentEvents;
        public string[] ExceptionsSinceLastSnapshot;
    }

    [Serializable]
    public sealed class AgentTelemetrySample
    {
        public string PayloadJson;
        public double CapturedAtSeconds;
    }

    public interface IAgentActionProvider
    {
        AgentActionSpec[] GetAvailableActions();
        AgentActionResult ExecuteAgentAction(string actionName, string jsonArguments);
    }

    public interface IAgentStateProvider
    {
        AgentRuntimeSnapshot CaptureAgentState();
    }

    public interface IAgentTelemetryProvider
    {
        AgentTelemetrySample CaptureTelemetry();
    }
}
