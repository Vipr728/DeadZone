#!/usr/bin/env node

const http = require("http");

const bridgeUrl = new URL(process.env.AGENTIC_UNITY_BRIDGE_URL || "http://127.0.0.1:47392");
const bridgeToken = process.env.AGENTIC_UNITY_BRIDGE_TOKEN || "";
let inputBuffer = Buffer.alloc(0);

const tools = [
  {
    name: "unity_health",
    description: "Check whether the Unity editor bridge is running and report the active project/scene.",
    inputSchema: {
      type: "object",
      properties: {},
      additionalProperties: false
    }
  },
  {
    name: "unity_get_context",
    description: "Get the current Unity project, active scene, selection, scene hierarchy, and asset summary.",
    inputSchema: {
      type: "object",
      properties: {},
      additionalProperties: false
    }
  },
  {
    name: "unity_get_action_schema",
    description: "Get the JSON action schema supported by the Unity editor bridge.",
    inputSchema: {
      type: "object",
      properties: {},
      additionalProperties: false
    }
  },
  {
    name: "unity_run_agent",
    description: "Run the in-Unity Ark orchestrator on a natural-language prompt. This can modify the project in auto_run mode.",
    inputSchema: {
      type: "object",
      properties: {
        prompt: {
          type: "string",
          description: "Natural-language request for the Unity agent."
        },
        role_hint: {
          type: "string",
          description: "Optional preferred specialist role: default, worker, explorer, scene_setup, asset_management, or monitor."
        },
        mode: {
          type: "string",
          description: "Currently only auto_run is supported.",
          enum: ["auto_run", "auto"]
        }
      },
      required: ["prompt"],
      additionalProperties: false
    }
  },
  {
    name: "unity_execute_actions",
    description: "Execute Unity editor actions. Provide either action_json or a message plus actions array.",
    inputSchema: {
      type: "object",
      properties: {
        action_json: {
          type: "string",
          description: "Full Ark action JSON: {\"message\":\"...\",\"actions\":[...]}"
        },
        message: {
          type: "string",
          description: "Optional summary used when actions is provided."
        },
        actions: {
          type: "array",
          description: "Array of Ark Unity action objects.",
          items: {
            type: "object",
            additionalProperties: true
          }
        }
      },
      additionalProperties: false
    }
  },
  {
    name: "unity_dry_run_actions",
    description: "Preview Ark Unity action JSON without executing it. Reports read-only, mutating, and destructive/high-risk actions.",
    inputSchema: {
      type: "object",
      properties: {
        action_json: {
          type: "string",
          description: "Full Ark action JSON: {\"message\":\"...\",\"actions\":[...]}"
        },
        message: {
          type: "string",
          description: "Optional summary used when actions is provided."
        },
        actions: {
          type: "array",
          description: "Array of Ark Unity action objects.",
          items: {
            type: "object",
            additionalProperties: true
          }
        }
      },
      additionalProperties: false
    }
  },
  {
    name: "unity_execute_readonly_actions",
    description: "Execute only read-only Ark Unity actions. The whole request is blocked if any mutating action is present.",
    inputSchema: {
      type: "object",
      properties: {
        action_json: {
          type: "string",
          description: "Full Ark action JSON containing only read-only actions."
        },
        message: {
          type: "string",
          description: "Optional summary used when actions is provided."
        },
        actions: {
          type: "array",
          description: "Array of read-only Ark Unity action objects.",
          items: {
            type: "object",
            additionalProperties: true
          }
        }
      },
      additionalProperties: false
    }
  },
  {
    name: "unity_search_project",
    description: "Search scripts, prefabs, assets, package manifests, and readable project files for prompt-relevant context.",
    inputSchema: {
      type: "object",
      properties: {
        query: { type: "string" }
      },
      required: ["query"],
      additionalProperties: false
    }
  },
  {
    name: "unity_read_text_file",
    description: "Read a text/source file under Assets, Packages, ProjectSettings, or Library/PackageCache.",
    inputSchema: {
      type: "object",
      properties: {
        path: { type: "string" }
      },
      required: ["path"],
      additionalProperties: false
    }
  },
  {
    name: "unity_search_unity_docs",
    description: "Search local Unity/package/project docs from the Unity project package cache and docs folders.",
    inputSchema: {
      type: "object",
      properties: {
        query: { type: "string" },
        max_results: {
          type: "number",
          description: "Optional maximum result count, capped by the Unity bridge."
        }
      },
      required: ["query"],
      additionalProperties: false
    }
  },
  {
    name: "unity_read_unity_doc",
    description: "Read a local Unity/package/project doc by id or path returned from unity_search_unity_docs.",
    inputSchema: {
      type: "object",
      properties: {
        path: {
          type: "string",
          description: "Doc id or project-relative path from unity_search_unity_docs."
        }
      },
      required: ["path"],
      additionalProperties: false
    }
  },
  {
    name: "unity_search_unity_api",
    description: "Search installed Unity/package C# API source under Library/PackageCache, Packages, and Assets.",
    inputSchema: {
      type: "object",
      properties: {
        query: { type: "string" },
        max_results: {
          type: "number",
          description: "Optional maximum result count, capped by the Unity bridge."
        }
      },
      required: ["query"],
      additionalProperties: false
    }
  },
  {
    name: "unity_read_unity_api",
    description: "Read a Unity/package/project C# API source file returned from unity_search_unity_api.",
    inputSchema: {
      type: "object",
      properties: {
        path: {
          type: "string",
          description: "Source path from unity_search_unity_api, often under Library/PackageCache."
        }
      },
      required: ["path"],
      additionalProperties: false
    }
  },
  {
    name: "unity_create_object",
    description: "Create or update a GameObject with optional components, parent, and transform.",
    inputSchema: {
      type: "object",
      properties: {
        name: { type: "string" },
        target: { type: "string" },
        parent: { type: "string" },
        components: {
          type: "array",
          items: { type: "string" }
        },
        position: {
          type: "object",
          additionalProperties: true
        },
        rotation: {
          type: "object",
          additionalProperties: true
        },
        scale: {
          type: "object",
          additionalProperties: true
        },
        use_position: { type: "boolean" },
        use_rotation: { type: "boolean" },
        use_scale: { type: "boolean" }
      },
      required: ["name"],
      additionalProperties: false
    }
  },
  {
    name: "unity_add_component",
    description: "Add a component by type name to a GameObject.",
    inputSchema: {
      type: "object",
      properties: {
        target: { type: "string" },
        component: { type: "string" }
      },
      required: ["target", "component"],
      additionalProperties: false
    }
  },
  {
    name: "unity_set_component_property",
    description: "Set a serialized component property on a scene GameObject component.",
    inputSchema: {
      type: "object",
      properties: {
        target: { type: "string" },
        component: { type: "string" },
        property_path: { type: "string" },
        value: { type: "string" },
        value_type: { type: "string" },
        int_value: { type: "number" },
        float_value: { type: "number" },
        bool_value: { type: "boolean" },
        color: { type: "string" },
        reference_asset_path: { type: "string" },
        reference_target: { type: "string" },
        position: {
          type: "object",
          additionalProperties: true
        },
        scale: {
          type: "object",
          additionalProperties: true
        }
      },
      required: ["target", "component", "property_path"],
      additionalProperties: false
    }
  },
  {
    name: "unity_validate_scene",
    description: "Run structural scene validation.",
    inputSchema: {
      type: "object",
      properties: {},
      additionalProperties: false
    }
  },
  {
    name: "unity_capture_game_view",
    description: "Render the active camera, save a diagnostic screenshot, sample pixels, and test light influence.",
    inputSchema: {
      type: "object",
      properties: {},
      additionalProperties: false
    }
  },
  {
    name: "unity_enter_play_mode",
    description: "Enter Unity Play Mode.",
    inputSchema: {
      type: "object",
      properties: {},
      additionalProperties: false
    }
  },
  {
    name: "unity_exit_play_mode",
    description: "Exit Unity Play Mode.",
    inputSchema: {
      type: "object",
      properties: {},
      additionalProperties: false
    }
  },
  {
    name: "unity_execute_menu_item",
    description: "Execute a Unity editor menu item by path, for example GameObject/Light/Point Light.",
    inputSchema: {
      type: "object",
      properties: {
        menu_item: {
          type: "string",
          description: "Unity editor menu item path."
        }
      },
      required: ["menu_item"],
      additionalProperties: false
    }
  },
  {
    name: "unity_create_or_update_text_file",
    description: "Create or update a text file under Assets in the Unity project.",
    inputSchema: {
      type: "object",
      properties: {
        path: {
          type: "string",
          description: "Asset path, for example Assets/Scripts/PlayerMovement.cs."
        },
        content: {
          type: "string",
          description: "File contents."
        }
      },
      required: ["path", "content"],
      additionalProperties: false
    }
  },
  {
    name: "unity_set_player_setting",
    description: "Set a supported Unity Player Setting, such as active_input_handling, company_name, product_name, application_identifier, or color_space.",
    inputSchema: {
      type: "object",
      properties: {
        property_path: {
          type: "string",
          description: "Setting key, for example active_input_handling."
        },
        value: {
          type: "string",
          description: "Setting value, for example both, input_system, old, Linear, or a text value."
        },
        value_type: {
          type: "string",
          description: "Optional value type: string, int, float, or bool."
        },
        int_value: {
          type: "number",
          description: "Optional integer value."
        },
        bool_value: {
          type: "boolean",
          description: "Optional boolean value."
        }
      },
      required: ["property_path"],
      additionalProperties: false
    }
  },
  {
    name: "unity_set_project_setting",
    description: "Set a scalar serialized value in a ProjectSettings asset.",
    inputSchema: {
      type: "object",
      properties: {
        path: {
          type: "string",
          description: "ProjectSettings-relative path, for example ProjectSettings/ProjectSettings.asset."
        },
        property_path: {
          type: "string",
          description: "Serialized field name, for example activeInputHandler."
        },
        value: {
          type: "string",
          description: "Raw YAML scalar value."
        },
        value_type: {
          type: "string",
          description: "Optional value type: string, int, float, or bool."
        },
        int_value: {
          type: "number",
          description: "Optional integer value."
        },
        float_value: {
          type: "number",
          description: "Optional float value."
        },
        bool_value: {
          type: "boolean",
          description: "Optional boolean value."
        }
      },
      required: ["property_path"],
      additionalProperties: false
    }
  },
  {
    name: "unity_set_asset_property",
    description: "Set a serialized property on a Unity asset under Assets.",
    inputSchema: {
      type: "object",
      properties: {
        asset_path: {
          type: "string",
          description: "Asset path, for example Assets/Settings/UniversalRP.asset."
        },
        name: {
          type: "string",
          description: "Optional sub-asset name."
        },
        property_path: {
          type: "string",
          description: "Serialized property path."
        },
        value: { type: "string" },
        value_type: { type: "string" },
        int_value: { type: "number" },
        float_value: { type: "number" },
        bool_value: { type: "boolean" },
        color: { type: "string" },
        asset_reference_path: {
          type: "string",
          description: "Optional referenced asset path."
        }
      },
      required: ["asset_path", "property_path"],
      additionalProperties: false
    }
  },
  {
    name: "unity_set_editor_build_scenes",
    description: "Replace the Unity Build Settings scene list.",
    inputSchema: {
      type: "object",
      properties: {
        paths: {
          type: "array",
          items: { type: "string" },
          description: "Scene asset paths."
        },
        enabled: {
          type: "array",
          items: { type: "boolean" },
          description: "Optional enabled flags matching paths."
        }
      },
      required: ["paths"],
      additionalProperties: false
    }
  },
  {
    name: "unity_remove_package",
    description: "Remove a Unity package by package id.",
    inputSchema: {
      type: "object",
      properties: {
        package_id: {
          type: "string",
          description: "Package id, for example com.unity.inputsystem."
        }
      },
      required: ["package_id"],
      additionalProperties: false
    }
  },
  {
    name: "unity_invoke_editor_method",
    description: "Invoke a compiled static editor method, optionally with one string argument. Use after writing an Editor script and letting Unity compile.",
    inputSchema: {
      type: "object",
      properties: {
        class_name: { type: "string" },
        method_name: { type: "string" },
        value: {
          type: "string",
          description: "Optional string argument."
        }
      },
      required: ["class_name", "method_name"],
      additionalProperties: false
    }
  },
  {
    name: "unity_get_logs",
    description: "Get recent Unity editor log messages captured by the bridge.",
    inputSchema: {
      type: "object",
      properties: {},
      additionalProperties: false
    }
  }
];

process.stdin.on("data", (chunk) => {
  inputBuffer = Buffer.concat([inputBuffer, chunk]);
  readMessages();
});

process.stdin.resume();

function readMessages() {
  while (true) {
    const headerEnd = inputBuffer.indexOf("\r\n\r\n");
    if (headerEnd < 0) {
      return;
    }

    const header = inputBuffer.subarray(0, headerEnd).toString("utf8");
    const match = /Content-Length:\s*(\d+)/i.exec(header);
    if (!match) {
      throw new Error("Missing Content-Length header");
    }

    const length = Number(match[1]);
    const messageStart = headerEnd + 4;
    const messageEnd = messageStart + length;
    if (inputBuffer.length < messageEnd) {
      return;
    }

    const messageText = inputBuffer.subarray(messageStart, messageEnd).toString("utf8");
    inputBuffer = inputBuffer.subarray(messageEnd);
    handleMessage(JSON.parse(messageText)).catch((error) => {
      if (error && error.id !== undefined) {
        sendError(error.id, -32603, error.message || String(error));
      }
    });
  }
}

async function handleMessage(message) {
  if (message.method === "notifications/initialized") {
    return;
  }

  if (message.method === "initialize") {
    sendResult(message.id, {
      protocolVersion: message.params?.protocolVersion || "2024-11-05",
      capabilities: {
        tools: {}
      },
      serverInfo: {
        name: "agentic-unity",
        version: "0.1.0"
      }
    });
    return;
  }

  if (message.method === "ping") {
    sendResult(message.id, {});
    return;
  }

  if (message.method === "tools/list") {
    sendResult(message.id, { tools });
    return;
  }

  if (message.method === "tools/call") {
    try {
      const result = await callTool(message.params?.name, message.params?.arguments || {});
      sendResult(message.id, result);
    } catch (error) {
      sendResult(message.id, textResult(error.message || String(error), true));
    }
    return;
  }

  if (message.id !== undefined) {
    sendError(message.id, -32601, `Unknown method: ${message.method}`);
  }
}

async function callTool(name, args) {
  switch (name) {
    case "unity_health": {
      const envelope = await bridgeRequest("GET", "/health");
      return textResult(formatEnvelope(envelope));
    }

    case "unity_get_context": {
      const envelope = await bridgeRequest("GET", "/context");
      return textResult(envelope.result || formatEnvelope(envelope));
    }

    case "unity_get_action_schema": {
      const envelope = await bridgeRequest("GET", "/schema");
      return textResult(envelope.result || formatEnvelope(envelope));
    }

    case "unity_run_agent": {
      const envelope = await bridgeRequest("POST", "/agent", JSON.stringify({
        prompt: args.prompt,
        role_hint: args.role_hint,
        mode: args.mode || "auto_run"
      }));
      return textResult(envelope.result || formatEnvelope(envelope), !envelope.ok);
    }

    case "unity_execute_actions": {
      const actionJson = buildActionJson(args);
      const envelope = await bridgeRequest("POST", "/execute", actionJson);
      return textResult(envelope.result || formatEnvelope(envelope), !envelope.ok);
    }

    case "unity_dry_run_actions": {
      const actionJson = buildActionJson(args);
      const envelope = await bridgeRequest("POST", "/dry-run", actionJson);
      return textResult(envelope.result || formatEnvelope(envelope), !envelope.ok);
    }

    case "unity_execute_readonly_actions": {
      const actionJson = buildActionJson(args);
      const envelope = await bridgeRequest("POST", "/execute-readonly", actionJson);
      return textResult(envelope.result || formatEnvelope(envelope), !envelope.ok);
    }

    case "unity_search_project": {
      return executeReadOnlyActions(`Search Unity project for ${args.query}`, [
        {
          type: "search_project",
          query: args.query
        }
      ]);
    }

    case "unity_read_text_file": {
      return executeReadOnlyActions(`Read Unity text file ${args.path}`, [
        {
          type: "read_text_file",
          path: args.path
        }
      ]);
    }

    case "unity_search_unity_docs": {
      return executeReadOnlyActions(`Search local Unity docs for ${args.query}`, [
        {
          type: "search_unity_docs",
          query: args.query,
          int_value: args.max_results || 0
        }
      ]);
    }

    case "unity_read_unity_doc": {
      return executeReadOnlyActions(`Read local Unity doc ${args.path}`, [
        {
          type: "read_unity_doc",
          path: args.path
        }
      ]);
    }

    case "unity_search_unity_api": {
      return executeReadOnlyActions(`Search installed Unity API source for ${args.query}`, [
        {
          type: "search_unity_api",
          query: args.query,
          int_value: args.max_results || 0
        }
      ]);
    }

    case "unity_read_unity_api": {
      return executeReadOnlyActions(`Read Unity API source ${args.path}`, [
        {
          type: "read_unity_api",
          path: args.path
        }
      ]);
    }

    case "unity_create_object": {
      return executeActions(`Create or update Unity GameObject ${args.name}`, [
        {
          type: "create_object",
          name: args.name,
          target: args.target,
          parent: args.parent,
          components: args.components,
          position: args.position,
          rotation: args.rotation,
          scale: args.scale,
          use_position: args.use_position,
          use_rotation: args.use_rotation,
          use_scale: args.use_scale
        }
      ]);
    }

    case "unity_add_component": {
      return executeActions(`Add Unity component ${args.component} to ${args.target}`, [
        {
          type: "add_component",
          target: args.target,
          component: args.component
        }
      ]);
    }

    case "unity_set_component_property": {
      return executeActions(`Set Unity component property ${args.target}.${args.component}.${args.property_path}`, [
        {
          type: "set_component_property",
          target: args.target,
          component: args.component,
          property_path: args.property_path,
          value: args.value,
          value_type: args.value_type,
          int_value: args.int_value,
          float_value: args.float_value,
          bool_value: args.bool_value,
          color: args.color,
          reference_asset_path: args.reference_asset_path,
          reference_target: args.reference_target,
          position: args.position,
          scale: args.scale
        }
      ]);
    }

    case "unity_validate_scene": {
      return executeReadOnlyActions("Validate Unity scene", [
        {
          type: "validate_scene"
        }
      ]);
    }

    case "unity_capture_game_view": {
      return executeReadOnlyActions("Capture Unity Game view diagnostics", [
        {
          type: "capture_game_view"
        }
      ]);
    }

    case "unity_enter_play_mode": {
      return executeActions("Enter Unity Play Mode", [
        {
          type: "enter_play_mode"
        }
      ]);
    }

    case "unity_exit_play_mode": {
      return executeActions("Exit Unity Play Mode", [
        {
          type: "exit_play_mode"
        }
      ]);
    }

    case "unity_execute_menu_item": {
      const actionJson = JSON.stringify({
        message: `Execute Unity menu item ${args.menu_item}`,
        actions: [
          {
            type: "execute_menu_item",
            menu_item: args.menu_item
          }
        ]
      });
      const envelope = await bridgeRequest("POST", "/execute", actionJson);
      return textResult(envelope.result || formatEnvelope(envelope), !envelope.ok);
    }

    case "unity_create_or_update_text_file": {
      const actionJson = JSON.stringify({
        message: `Write ${args.path}`,
        actions: [
          {
            type: "write_text_file",
            path: args.path,
            content: args.content
          },
          {
            type: "save_assets"
          }
        ]
      });
      const envelope = await bridgeRequest("POST", "/execute", actionJson);
      return textResult(envelope.result || formatEnvelope(envelope), !envelope.ok);
    }

    case "unity_set_player_setting": {
      const actionJson = JSON.stringify({
        message: `Set Unity player setting ${args.property_path}`,
        actions: [
          {
            type: "set_player_setting",
            property_path: args.property_path,
            value: args.value,
            value_type: args.value_type,
            int_value: args.int_value,
            bool_value: args.bool_value
          },
          {
            type: "save_assets"
          }
        ]
      });
      const envelope = await bridgeRequest("POST", "/execute", actionJson);
      return textResult(envelope.result || formatEnvelope(envelope), !envelope.ok);
    }

    case "unity_set_project_setting": {
      const actionJson = JSON.stringify({
        message: `Set Unity project setting ${args.property_path}`,
        actions: [
          {
            type: "set_project_setting",
            path: args.path,
            property_path: args.property_path,
            value: args.value,
            value_type: args.value_type,
            int_value: args.int_value,
            float_value: args.float_value,
            bool_value: args.bool_value
          },
          {
            type: "save_assets"
          }
        ]
      });
      const envelope = await bridgeRequest("POST", "/execute", actionJson);
      return textResult(envelope.result || formatEnvelope(envelope), !envelope.ok);
    }

    case "unity_set_asset_property": {
      const actionJson = JSON.stringify({
        message: `Set Unity asset property ${args.property_path}`,
        actions: [
          {
            type: "set_asset_property",
            path: args.asset_path,
            name: args.name,
            property_path: args.property_path,
            value: args.value,
            value_type: args.value_type,
            int_value: args.int_value,
            float_value: args.float_value,
            bool_value: args.bool_value,
            color: args.color,
            reference_asset_path: args.asset_reference_path
          },
          {
            type: "save_assets"
          }
        ]
      });
      const envelope = await bridgeRequest("POST", "/execute", actionJson);
      return textResult(envelope.result || formatEnvelope(envelope), !envelope.ok);
    }

    case "unity_set_editor_build_scenes": {
      const actionJson = JSON.stringify({
        message: "Set Unity Build Settings scenes",
        actions: [
          {
            type: "set_editor_build_scenes",
            paths: args.paths,
            enabled: args.enabled
          },
          {
            type: "save_assets"
          }
        ]
      });
      const envelope = await bridgeRequest("POST", "/execute", actionJson);
      return textResult(envelope.result || formatEnvelope(envelope), !envelope.ok);
    }

    case "unity_remove_package": {
      const actionJson = JSON.stringify({
        message: `Remove Unity package ${args.package_id}`,
        actions: [
          {
            type: "remove_package",
            package_id: args.package_id
          }
        ]
      });
      const envelope = await bridgeRequest("POST", "/execute", actionJson);
      return textResult(envelope.result || formatEnvelope(envelope), !envelope.ok);
    }

    case "unity_invoke_editor_method": {
      const actionJson = JSON.stringify({
        message: `Invoke Unity editor method ${args.class_name}.${args.method_name}`,
        actions: [
          {
            type: "invoke_editor_method",
            class_name: args.class_name,
            method_name: args.method_name,
            value: args.value
          }
        ]
      });
      const envelope = await bridgeRequest("POST", "/execute", actionJson);
      return textResult(envelope.result || formatEnvelope(envelope), !envelope.ok);
    }

    case "unity_get_logs": {
      const envelope = await bridgeRequest("GET", "/logs");
      return textResult(formatLogs(envelope));
    }

    default:
      return textResult(`Unknown tool: ${name}`, true);
  }
}

function buildActionJson(args) {
  if (typeof args.action_json === "string" && args.action_json.trim()) {
    return args.action_json.trim();
  }

  if (!Array.isArray(args.actions)) {
    throw new Error("unity_execute_actions requires action_json or actions array.");
  }

  return JSON.stringify({
    message: args.message || "MCP Unity actions",
    actions: args.actions
  });
}

async function executeActions(message, actions) {
  const envelope = await bridgeRequest("POST", "/execute", JSON.stringify({
    message,
    actions
  }));
  return textResult(envelope.result || formatEnvelope(envelope), !envelope.ok);
}

async function executeReadOnlyActions(message, actions) {
  const envelope = await bridgeRequest("POST", "/execute-readonly", JSON.stringify({
    message,
    actions
  }));
  return textResult(envelope.result || formatEnvelope(envelope), !envelope.ok);
}

function bridgeRequest(method, path, body) {
  const url = new URL(path, bridgeUrl);
  const payload = body == null ? null : Buffer.from(String(body), "utf8");
  const headers = {};
  if (payload) {
    headers["Content-Type"] = "application/json";
    headers["Content-Length"] = payload.length;
  }

  if (bridgeToken) {
    headers["X-Agentic-Unity-Token"] = bridgeToken;
    headers.Authorization = `Bearer ${bridgeToken}`;
  }

  return new Promise((resolve, reject) => {
    const request = http.request(
      {
        hostname: url.hostname,
        port: Number(url.port || 80),
        path: `${url.pathname}${url.search}`,
        method,
        headers: Object.keys(headers).length > 0 ? headers : undefined
      },
      (response) => {
        const chunks = [];
        response.on("data", (chunk) => chunks.push(chunk));
        response.on("end", () => {
          const text = Buffer.concat(chunks).toString("utf8");
          try {
            const envelope = JSON.parse(text);
            resolve(envelope);
          } catch (error) {
            reject(new Error(`Unity bridge returned non-JSON response (${response.statusCode}): ${text}`));
          }
        });
      }
    );

    request.on("error", (error) => {
      reject(new Error(`Unity bridge request failed. Is Unity open and the MCP bridge started at ${bridgeUrl.origin}? ${error.message}`));
    });

    if (payload) {
      request.write(payload);
    }

    request.end();
  });
}

function formatEnvelope(envelope) {
  if (!envelope.ok) {
    return envelope.error || "Unity bridge returned an error.";
  }

  const lines = [envelope.result || "Unity bridge responded."];
  if (envelope.project) lines.push(`Project: ${envelope.project}`);
  if (envelope.unity_version) lines.push(`Unity: ${envelope.unity_version}`);
  if (envelope.scene) lines.push(`Scene: ${envelope.scene}`);
  if (envelope.scene_path) lines.push(`Scene path: ${envelope.scene_path}`);
  if (envelope.bridge_url) lines.push(`Bridge URL: ${envelope.bridge_url}`);
  if (typeof envelope.is_compiling === "boolean") lines.push(`Compiling: ${envelope.is_compiling}`);
  if (typeof envelope.is_playing === "boolean") lines.push(`Playing: ${envelope.is_playing}`);
  return lines.join("\n");
}

function formatLogs(envelope) {
  if (!envelope.ok) {
    return envelope.error || "Unity bridge returned an error.";
  }

  if (!Array.isArray(envelope.logs) || envelope.logs.length === 0) {
    return "No Unity logs captured by the bridge yet.";
  }

  return envelope.logs
    .map((entry) => `[${entry.timestamp_utc}] ${entry.type}: ${entry.message}${entry.stack_trace ? `\n${entry.stack_trace}` : ""}`)
    .join("\n\n");
}

function textResult(text, isError = false) {
  return {
    content: [
      {
        type: "text",
        text: String(text || "")
      }
    ],
    isError
  };
}

function sendResult(id, result) {
  sendMessage({
    jsonrpc: "2.0",
    id,
    result
  });
}

function sendError(id, code, message) {
  sendMessage({
    jsonrpc: "2.0",
    id,
    error: {
      code,
      message
    }
  });
}

function sendMessage(message) {
  const json = JSON.stringify(message);
  process.stdout.write(`Content-Length: ${Buffer.byteLength(json, "utf8")}\r\n\r\n${json}`);
}
