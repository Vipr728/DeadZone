# Ark Unity MCP

This folder contains a stdio MCP server that lets an external agent interact with the open Unity editor through the Ark editor bridge.

## How It Works

- Unity starts a local editor bridge at `http://127.0.0.1:47392`.
- The MCP server runs as a local Node process.
- MCP tools call the bridge to read Unity context, inspect logs, and execute approved Unity action JSON on the editor main thread.

Open Unity first, then connect your MCP client to this server.

## MCP Config

Use an absolute path for `unity-mcp-server.js`.

```json
{
  "mcpServers": {
    "agentic-unity": {
      "command": "node",
      "args": ["/Users/rahulpeesa/AgenticGamedev/mcp/unity-mcp-server.js"],
      "env": {
        "AGENTIC_UNITY_BRIDGE_URL": "http://127.0.0.1:47392",
        "AGENTIC_UNITY_BRIDGE_TOKEN": ""
      }
    }
  }
}
```

## Tools

- `unity_health`: check bridge/editor status.
- `unity_get_context`: read project, scene, selection, hierarchy, and asset summary.
- `unity_get_action_schema`: read the supported Unity action JSON schema.
- `unity_run_agent`: run the in-Unity Ark orchestrator on a natural-language prompt.
- `unity_execute_actions`: execute Ark action JSON in Unity.
- `unity_dry_run_actions`: preview Ark action JSON without executing it.
- `unity_execute_readonly_actions`: execute read-only actions only, blocking the whole request if any mutating action is present.
- `unity_search_project`: search scripts, prefabs, assets, packages, and readable project files.
- `unity_read_text_file`: read a text/source file under `Assets`, `Packages`, `ProjectSettings`, or `Library/PackageCache`.
- `unity_search_unity_docs`: search local Unity/package/project docs from `Library/PackageCache`, embedded packages, and docs folders.
- `unity_read_unity_doc`: read a local Unity/package/project doc by id or path returned from docs search.
- `unity_search_unity_api`: search installed Unity/package C# API source under `Library/PackageCache`, `Packages`, and `Assets`.
- `unity_read_unity_api`: read a Unity/package/project C# API source file returned from API search.
- `unity_create_object`: create or update a GameObject with optional components, parent, and transform.
- `unity_add_component`: add a component to a GameObject.
- `unity_set_component_property`: set a serialized property on a scene component.
- `unity_validate_scene`: run scene validation.
- `unity_capture_game_view`: capture Game view diagnostics and screenshot metadata.
- `unity_enter_play_mode`: enter Play Mode.
- `unity_exit_play_mode`: exit Play Mode.
- `unity_execute_menu_item`: run a Unity editor menu item.
- `unity_create_or_update_text_file`: write a text/code file under `Assets`.
- `unity_set_player_setting`: set supported Player Settings such as `active_input_handling`.
- `unity_set_project_setting`: set scalar values in `ProjectSettings/*.asset`.
- `unity_set_asset_property`: set serialized properties on assets under `Assets`.
- `unity_set_editor_build_scenes`: replace the Build Settings scene list.
- `unity_remove_package`: remove a Unity package by package id.
- `unity_invoke_editor_method`: invoke a compiled static Editor method for broad UnityEditor automation.
- `unity_get_logs`: read recent Unity editor logs captured by the bridge.

Scene objects should be created through `unity_execute_actions` with generic JSON actions, not preset-specific MCP tools. Use `create_object` with a `components` array, `set_object_property` for GameObject fields such as tag/layer/active/name, then `set_component_property` actions to configure Camera, Light, SpriteRenderer, physics, UI, audio, scripts, or other Unity components.
For Unity UI/API areas that are not covered by a direct action, create an Editor script under `Assets/Editor`, let Unity compile, then call `unity_invoke_editor_method`.

## Unity Bridge Controls

Unity menu items:

- `Tools > Ark > MCP Bridge > Start`
- `Tools > Ark > MCP Bridge > Stop`
- `Tools > Ark > MCP Bridge > Copy URL`

The bridge starts automatically when the Unity editor reloads scripts. If a client cannot connect, use the `Start` menu item and check the Unity Console.

## Optional Auth

By default the bridge is local-only and unauthenticated. To require a token, set `AGENTIC_UNITY_BRIDGE_TOKEN` in the Unity editor process environment and set the same value in the MCP server environment. The MCP server forwards the token with `X-Agentic-Unity-Token` and `Authorization: Bearer ...`.
