# Ark has no scheduled heartbeat tasks.
