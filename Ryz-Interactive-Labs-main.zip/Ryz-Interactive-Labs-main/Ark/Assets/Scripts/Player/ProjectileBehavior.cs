using System;
using UnityEngine;

namespace Ark.Player
{
    [RequireComponent(typeof(Rigidbody2D))]
    [RequireComponent(typeof(BoxCollider2D))]
    public class ProjectileBehavior : MonoBehaviour
    {
        [HideInInspector]
        public float speed = 20f;

        [HideInInspector]
        public Action<Collider2D, Vector3> onHit;

        private Rigidbody2D rb;

        private void Awake()
        {
            rb = GetComponent<Rigidbody2D>();
            rb.gravityScale = 0f;
            rb.bodyType = RigidbodyType2D.Dynamic;

            var col = GetComponent<BoxCollider2D>();
            col.isTrigger = true;
            col.size = new Vector2(0.15f, 0.15f);
        }

        private void FixedUpdate()
        {
            rb.MovePosition(rb.position + rb.linearVelocity * speed * Time.fixedDeltaTime);

            // Auto-despawn after traveling too far
            if (Mathf.Abs(rb.position.x) > 100f || Mathf.Abs(rb.position.y) > 100f)
            {
                Destroy(gameObject);
            }
        }

        private void OnTriggerEnter2D(Collider2D other)
        {
            onHit?.Invoke(other, other.transform.position);
            Destroy(gameObject);
        }

        private void OnDestroy()
        {
            onHit = null;
        }
    }
}
