using UnityEngine;
using Ark.Effects;
using Ark.GameManager;

namespace Ark.Player
{
    public class ShootingMechanism : MonoBehaviour
    {
        [Tooltip("Projectile prefab to instantiate")]
        [SerializeField] private GameObject projectilePrefab;

        [Tooltip("Speed of the projectile")]
        [SerializeField] private float projectileSpeed = 20f;

        [Tooltip("Fire rate (seconds between shots)")]
        [SerializeField] private float fireRate = 0.18f;

        [Tooltip("Muzzle flash radius")]
        [SerializeField] private float muzzleFlashRadius = 0.3f;

        [Tooltip("Muzzle flash color")]
        [SerializeField] private Color muzzleFlashColor = new Color(1f, 0.9f, 0.3f, 0.8f);

        [Tooltip("Impact effect to spawn on hit")]
        [SerializeField] private GameObject impactEffectPrefab;

        [Tooltip("Score given per kill")]
        [SerializeField] private int killPoints = 10;

        private float nextFireTime = 0f;
        private PlayerMovement playerMovement;
        private GameObject killCounterObj;
        private KillCounter killCounter;

        public float FireRate => fireRate;
        public float ProjectileSpeed => projectileSpeed;
        public int KillPoints => killPoints;

        private void Awake()
        {
            playerMovement = GetComponent<PlayerMovement>();
            // Find or create kill counter
            var existingCounters = FindObjectsByType<KillCounter>(FindObjectsInactive.Include, FindObjectsSortMode.None);
            if (existingCounters.Length > 0)
            {
                killCounter = existingCounters[0];
            }
            else
            {
                killCounterObj = new GameObject("KillCounter");
                killCounter = killCounterObj.AddComponent<KillCounter>();
            }
        }

        private void Update()
        {
            if (Time.time >= nextFireTime && playerMovement.MoveInput != Vector2.zero)
            {
                Shoot();
                nextFireTime = Time.time + fireRate;
            }
        }

        private void Shoot()
        {
            if (projectilePrefab == null) return;

            // Spawn projectile at player position, moving in movement direction
            Vector3 spawnPos = transform.position + (Vector3)playerMovement.MoveInput * 0.5f;
            GameObject projectile = Instantiate(projectilePrefab, spawnPos, Quaternion.identity);

            // Set projectile velocity
            var projectileBehavior = projectile.GetComponentInChildren<ProjectileBehavior>();
            if (projectileBehavior != null)
            {
                projectileBehavior.speed = projectileSpeed;
                projectileBehavior.onHit += OnProjectileHit;
            }

            // Trigger recoil on player
            playerMovement.OnShot();

            // Muzzle flash effect
            CreateMuzzleFlash(spawnPos);
        }

        private void CreateMuzzleFlash(Vector3 position)
        {
            GameObject flash = new GameObject("MuzzleFlash");
            flash.transform.position = position;
            flash.transform.SetParent(transform, false);

            var sf = flash.AddComponent<ImpactEffect>;
            sf.radius = muzzleFlashRadius;
            sf.color = muzzleFlashColor;
            sf.lifetime = 0.08f;
        }

        private void OnProjectileHit(Collider2D hit, Vector3 hitPos)
        {
            // Check if hit an enemy
            if (hit.CompareTag("Enemy"))
            {
                // Spawn impact effect
                if (impactEffectPrefab != null)
                {
                    Instantiate(impactEffectPrefab, hitPos, Quaternion.identity);
                }

                // Destroy enemy
                Destroy(hit.gameObject);

                // Increment kill counter
                if (killCounter != null)
                {
                    killCounter.AddKill(killPoints);
                }
            }
        }
    }
}
