using UnityEngine;

namespace Ark.Player
{
    [RequireComponent(typeof(Rigidbody2D))]
    [RequireComponent(typeof(Collider2D))]
    public class PlayerMovement : MonoBehaviour
    {
        [Tooltip("Movement speed in units per second")]
        [SerializeField] private float moveSpeed = 8f;

        [Tooltip("How much the camera shakes on each shot")]
        [SerializeField] private float recoilIntensity = 0.3f;

        [Tooltip("How long the camera shake lasts per shot")]
        [SerializeField] private float recoilDuration = 0.12f;

        [Tooltip("Size of the muzzle flash sprite (used for visual feedback)")]
        [SerializeField] private float muzzleFlashSize = 0.15f;

        private Rigidbody2D rb;
        private Vector2 moveInput;
        private SpriteRenderer playerRenderer;

        public float MoveSpeed => moveSpeed;
        public Vector2 MoveInput => moveInput;
        public float RecoilIntensity => recoilIntensity;
        public float RecoilDuration => recoilDuration;

        private void Awake()
        {
            rb = GetComponent<Rigidbody2D>();
            rb.gravityScale = 0f;
            rb.bodyType = RigidbodyType2D.Dynamic;
            playerRenderer = GetComponent<SpriteRenderer>();
        }

        private void Update()
        {
            moveInput = Vector2.zero;
            if (Input.anyKey)
            {
                moveInput = new Vector2(Input.GetAxisRaw("Horizontal"), Input.GetAxisRaw("Vertical")).normalized;
            }

            // Apply movement
            if (moveInput != Vector2.zero)
            {
                rb.linearVelocity = moveInput * moveSpeed;

                // Rotate player to face movement direction
                float angle = Mathf.Atan2(moveInput.y, moveInput.x) * Mathf.Rad2Deg;
                transform.rotation = Quaternion.Euler(0, 0, angle);
            }
        }

        public void OnShot()
        {
            // Trigger recoil effect
            if (GetComponent<Screenshake>() != null)
            {
                GetComponent<Screenshake>().TriggerShake(recoilIntensity, recoilDuration);
            }
        }
    }
}
