﻿using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Rendering.Universal;

/// <summary>
/// Adds a brief warm lighting pulse whenever the player fires and a new bullet appears.
/// The effect is intentionally driven by spawned TopDownBullet instances so it stays in sync
/// with the existing shooting code without changing that controller's public API.
/// </summary>
public sealed class PlayerShotLightPulse : MonoBehaviour
{
    [SerializeField] private Light2D targetLight;
    [SerializeField, Min(0f)] private float shotIntensityBoost = 0.55f;
    [SerializeField, Min(0.01f)] private float returnSpeed = 9f;
    [SerializeField] private Color shotTint = new Color(1f, 0.86f, 0.42f, 1f);
    [SerializeField, Range(0f, 1f)] private float tintStrengthPerShot = 0.35f;

    private readonly HashSet<int> knownBulletIds = new HashSet<int>();
    private readonly List<int> staleBulletIds = new List<int>();

    private float baseIntensity;
    private Color baseColor = Color.white;
    private float intensityPulse;
    private float tintPulse;

    private void Awake()
    {
        ResolveTargetLight();

        if (targetLight != null)
        {
            baseIntensity = targetLight.intensity;
            baseColor = targetLight.color;
        }
    }

    private void OnEnable()
    {
        RefreshKnownBulletsWithoutPulsing();
    }

    private void Update()
    {
        DetectNewBullets();
        UpdateLightPulse();
    }

    private void ResolveTargetLight()
    {
        if (targetLight != null)
        {
            return;
        }

        Light2D[] lights = FindObjectsByType<Light2D>(FindObjectsInactive.Exclude, FindObjectsSortMode.None);
        foreach (Light2D light in lights)
        {
            if (light != null && light.lightType == Light2D.LightType.Global)
            {
                targetLight = light;
                return;
            }
        }

        if (lights.Length > 0)
        {
            targetLight = lights[0];
        }
    }

    private void RefreshKnownBulletsWithoutPulsing()
    {
        knownBulletIds.Clear();
        TopDownBullet[] bullets = FindObjectsByType<TopDownBullet>(FindObjectsInactive.Exclude, FindObjectsSortMode.None);
        foreach (TopDownBullet bullet in bullets)
        {
            if (bullet != null)
            {
                knownBulletIds.Add(bullet.GetInstanceID());
            }
        }
    }

    private void DetectNewBullets()
    {
        TopDownBullet[] bullets = FindObjectsByType<TopDownBullet>(FindObjectsInactive.Exclude, FindObjectsSortMode.None);
        bool sawNewBullet = false;

        staleBulletIds.Clear();
        foreach (int knownBulletId in knownBulletIds)
        {
            staleBulletIds.Add(knownBulletId);
        }

        foreach (TopDownBullet bullet in bullets)
        {
            if (bullet == null)
            {
                continue;
            }

            int id = bullet.GetInstanceID();
            staleBulletIds.Remove(id);

            if (knownBulletIds.Add(id))
            {
                sawNewBullet = true;
            }
        }

        foreach (int staleBulletId in staleBulletIds)
        {
            knownBulletIds.Remove(staleBulletId);
        }

        if (sawNewBullet)
        {
            Pulse();
        }
    }

    private void Pulse()
    {
        intensityPulse += shotIntensityBoost;
        tintPulse = Mathf.Clamp01(tintPulse + tintStrengthPerShot);
    }

    private void UpdateLightPulse()
    {
        if (targetLight == null)
        {
            ResolveTargetLight();
            if (targetLight == null)
            {
                return;
            }

            baseIntensity = targetLight.intensity;
            baseColor = targetLight.color;
        }

        float decay = 1f - Mathf.Exp(-returnSpeed * Time.deltaTime);
        intensityPulse = Mathf.Lerp(intensityPulse, 0f, decay);
        tintPulse = Mathf.Lerp(tintPulse, 0f, decay);

        targetLight.intensity = baseIntensity + intensityPulse;
        targetLight.color = Color.Lerp(baseColor, shotTint, tintPulse);
    }
}
