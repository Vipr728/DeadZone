using UnityEngine;

public class TopDownBullet : MonoBehaviour
{
    [SerializeField] private int damage = 1;

    private void OnTriggerEnter2D(Collider2D other)
    {
        var scene5Enemy = other.GetComponent<Scene5Enemy>();
        if (scene5Enemy != null)
        {
            scene5Enemy.TakeDamage(damage, other.ClosestPoint(transform.position));
            Destroy(gameObject);
            return;
        }

        var enemy = other.GetComponent<ArenaCombatEnemy>();
        if (enemy != null)
        {
            enemy.TakeDamage(damage);
            Scene5CombatManager.Instance?.SpawnImpact(other.ClosestPoint(transform.position), new Color(1f, 0.95f, 0.6f, 1f));
            Destroy(gameObject);
            return;
        }

        if (!other.isTrigger)
        {
            Scene5CombatManager.Instance?.SpawnImpact(other.ClosestPoint(transform.position), new Color(1f, 0.95f, 0.6f, 1f));
            Destroy(gameObject);
        }
    }
}
