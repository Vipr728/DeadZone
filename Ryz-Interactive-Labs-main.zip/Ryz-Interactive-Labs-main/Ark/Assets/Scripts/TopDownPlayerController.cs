﻿using UnityEngine;
#if ENABLE_INPUT_SYSTEM
using UnityEngine.InputSystem;
#endif

[RequireComponent(typeof(Rigidbody2D))]
public class TopDownPlayerController : MonoBehaviour
{
    public float moveSpeed = 6f;
    public float fireRate = 0.16f;
    public float bulletSpeed = 12f;
    public float shotSpreadDegrees = 2f;
    public float recoilForce = 0.08f;
    public float muzzlePulseScale = 1.18f;
    public float muzzlePulseSeconds = 0.06f;
    [SerializeField] GameObject bulletPrefab;

    const float BulletLifetimeSeconds = 2.5f;

    Rigidbody2D rb;
    Vector2 moveInput;
    float nextFireTime;
    Vector3 baseScale;
    float muzzlePulseEndTime;
    Vector2 aimDirection = Vector2.right;
    bool runtimeFallbackLogged;

    void Awake()
    {
        rb = GetComponent<Rigidbody2D>();
        rb.gravityScale = 0f;
        rb.freezeRotation = true;
        baseScale = transform.localScale;
        ResolveBulletPrefab();
    }

    void OnEnable()
    {
        ResolveBulletPrefab();
    }

    void Update()
    {
#if ENABLE_INPUT_SYSTEM
        moveInput = ReadMoveInput();
        UpdateAimDirection();
        if (IsFirePressed() && Time.time >= nextFireTime)
#else
        moveInput = new Vector2(Input.GetAxisRaw("Horizontal"), Input.GetAxisRaw("Vertical")).normalized;
        UpdateLegacyAimDirection();
        if (Input.GetMouseButton(0) && Time.time >= nextFireTime)
#endif
        {
            nextFireTime = Time.time + fireRate;
            Shoot();
        }

        UpdateMuzzlePulse();
    }

    void FixedUpdate()
    {
        rb.linearVelocity = moveInput * moveSpeed;
    }

    void UpdateMuzzlePulse()
    {
        if (Time.time < muzzlePulseEndTime)
        {
            transform.localScale = baseScale * muzzlePulseScale;
        }
        else if (transform.localScale != baseScale)
        {
            transform.localScale = baseScale;
        }
    }

    void ResolveBulletPrefab()
    {
        if (bulletPrefab != null)
        {
            return;
        }

        bulletPrefab = Resources.Load<GameObject>("PlayerBullet");
        if (bulletPrefab == null)
        {
            bulletPrefab = Resources.Load<GameObject>("Prefabs/PlayerBullet");
        }

        if (bulletPrefab == null)
        {
            bulletPrefab = FindBulletPrefabInSceneOrProject();
        }

        if (bulletPrefab == null && !runtimeFallbackLogged)
        {
            runtimeFallbackLogged = true;
            Debug.LogWarning($"{nameof(TopDownPlayerController)} on {name} could not resolve a PlayerBullet prefab from Resources or project-prefab lookup.", this);
        }
    }

    GameObject FindBulletPrefabInSceneOrProject()
    {
        GameObject[] loadedPrefabs = Resources.LoadAll<GameObject>(string.Empty);
        for (int i = 0; i < loadedPrefabs.Length; i++)
        {
            GameObject candidate = loadedPrefabs[i];
            if (candidate != null && candidate.name == "PlayerBullet")
            {
                return candidate;
            }
        }

        return null;
    }

#if !ENABLE_INPUT_SYSTEM
    void UpdateLegacyAimDirection()
    {
        Camera cam = Camera.main;
        if (cam == null) return;

        Vector3 mouse = cam.ScreenToWorldPoint(Input.mousePosition);
        SetAimDirection(mouse - transform.position);
    }
#endif

#if ENABLE_INPUT_SYSTEM
    Vector2 ReadMoveInput()
    {
        Keyboard keyboard = Keyboard.current;
        if (keyboard == null)
        {
            return Vector2.zero;
        }

        Vector2 input = Vector2.zero;
        if (keyboard.aKey.isPressed || keyboard.leftArrowKey.isPressed) input.x -= 1f;
        if (keyboard.dKey.isPressed || keyboard.rightArrowKey.isPressed) input.x += 1f;
        if (keyboard.sKey.isPressed || keyboard.downArrowKey.isPressed) input.y -= 1f;
        if (keyboard.wKey.isPressed || keyboard.upArrowKey.isPressed) input.y += 1f;
        return input.normalized;
    }

    bool IsFirePressed()
    {
        Mouse mouse = Mouse.current;
        return mouse != null && mouse.leftButton.isPressed;
    }

    void UpdateAimDirection()
    {
        Camera cam = Camera.main;
        Mouse mouse = Mouse.current;
        if (cam == null || mouse == null) return;

        Vector3 pointer = cam.ScreenToWorldPoint(mouse.position.ReadValue());
        SetAimDirection(pointer - transform.position);
    }
#endif

    void SetAimDirection(Vector2 direction)
    {
        if (direction.sqrMagnitude <= 0.001f)
        {
            return;
        }

        aimDirection = direction.normalized;
        float angle = Mathf.Atan2(aimDirection.y, aimDirection.x) * Mathf.Rad2Deg;
        transform.rotation = Quaternion.Euler(0f, 0f, angle);
    }

    void Shoot()
    {
        ResolveBulletPrefab();

        Vector2 dir = aimDirection.sqrMagnitude > 0.001f ? aimDirection : (Vector2)transform.right;
        if (shotSpreadDegrees > 0f)
        {
            dir = (Quaternion.Euler(0f, 0f, Random.Range(-shotSpreadDegrees, shotSpreadDegrees)) * dir).normalized;
        }

        GameObject bullet = bulletPrefab != null
            ? Instantiate(bulletPrefab, transform.position + (Vector3)(dir * 0.82f), Quaternion.identity)
            : CreateFallbackBullet(dir);
        bullet.transform.right = dir;

        if (bullet.TryGetComponent<DestroyAfterSeconds>(out DestroyAfterSeconds destroyAfterSeconds))
        {
            destroyAfterSeconds.SetLifetime(BulletLifetimeSeconds);
        }
        else
        {
            DestroyAfterSeconds attachedLifetime = bullet.AddComponent<DestroyAfterSeconds>();
            attachedLifetime.SetLifetime(BulletLifetimeSeconds);
        }

        Rigidbody2D brb = bullet.GetComponent<Rigidbody2D>();
        if (brb != null)
        {
            brb.linearVelocity = dir * bulletSpeed;
        }

        if (recoilForce > 0f)
        {
            rb.linearVelocity -= dir * recoilForce;
        }

        muzzlePulseEndTime = Time.time + muzzlePulseSeconds;
        ScreenShakeService.Shake(0.2f, 0.08f);
    }

    GameObject CreateFallbackBullet(Vector2 dir)
    {
        GameObject bullet = new GameObject("RuntimeBullet");
        bullet.transform.position = transform.position + (Vector3)(dir * 0.82f);
        bullet.transform.localScale = Vector3.one * 0.22f;

        SpriteRenderer sprite = bullet.AddComponent<SpriteRenderer>();
        sprite.sprite = TopDownShooterSetup.CircleSprite;
        sprite.color = new Color(1f, 0.88f, 0.3f, 1f);
        sprite.sortingOrder = 20;

        CircleCollider2D collider = bullet.AddComponent<CircleCollider2D>();
        collider.isTrigger = true;
        collider.radius = 0.5f;

        Rigidbody2D body = bullet.AddComponent<Rigidbody2D>();
        body.gravityScale = 0f;
        body.collisionDetectionMode = CollisionDetectionMode2D.Continuous;

        bullet.AddComponent<TopDownBullet>();
        return bullet;
    }
}

public sealed class DestroyAfterSeconds : MonoBehaviour
{
    float lifetime = 2.5f;

    public void SetLifetime(float seconds)
    {
        lifetime = Mathf.Max(0.1f, seconds);
        CancelInvoke(nameof(Kill));
        Invoke(nameof(Kill), lifetime);
    }

    void OnEnable()
    {
        SetLifetime(lifetime);
    }

    void Kill()
    {
        Destroy(gameObject);
    }
}
