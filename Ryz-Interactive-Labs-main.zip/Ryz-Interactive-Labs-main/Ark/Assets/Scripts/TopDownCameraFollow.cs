﻿using UnityEngine;

public class TopDownCameraFollow : MonoBehaviour
{
    public Transform target;
    public float followSpeed = 10f;
    public Vector3 offset = new Vector3(0f, 0f, -10f);

    void LateUpdate()
    {
        if (target == null) return;
        Vector3 desired = target.position + offset;
        transform.position = Vector3.Lerp(transform.position, desired, 1f - Mathf.Exp(-followSpeed * Time.deltaTime));
    }
}
