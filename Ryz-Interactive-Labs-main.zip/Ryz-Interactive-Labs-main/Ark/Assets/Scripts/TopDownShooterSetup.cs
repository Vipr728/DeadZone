﻿using UnityEngine;

[ExecuteAlways]
public class TopDownShooterSetup : MonoBehaviour
{
    static Sprite squareSprite;
    static Sprite circleSprite;

    public static Sprite SquareSprite { get { if (squareSprite == null) squareSprite = BuildSquareSprite(); return squareSprite; } }
    public static Sprite CircleSprite { get { if (circleSprite == null) circleSprite = BuildCircleSprite(); return circleSprite; } }

    void OnEnable() { SetupScene(); }
    void Awake() { SetupScene(); }
    void Reset() { SetupScene(); }

    void SetupScene()
    {
        GameObject arena = EnsureObject("Arena", Vector3.zero);
        GameObject player = EnsureObject("Player_Red", new Vector3(0f, 0f, 0f));
        ConfigureSprite(player, CircleSprite, Color.red, 10, Vector3.one);
        Rigidbody2D prb = EnsureComponent<Rigidbody2D>(player);
        prb.gravityScale = 0f;
        prb.freezeRotation = true;
        prb.collisionDetectionMode = CollisionDetectionMode2D.Continuous;
        CircleCollider2D pc = EnsureComponent<CircleCollider2D>(player);
        pc.radius = 0.5f;
        EnsureComponent<TopDownPlayerController>(player);

        GameObject lightObj = EnsureChild(player, "Player_Light");
        lightObj.transform.localPosition = new Vector3(0f, 0f, -2f);
        Light l = EnsureComponent<Light>(lightObj);
        l.type = LightType.Point;
        l.color = new Color(1f, 0.2f, 0.1f, 1f);
        l.intensity = 2.5f;
        l.range = 7f;

        GameObject floor = EnsureObject("Arena_Background", new Vector3(0f, 0f, 1f));
        floor.transform.SetParent(arena.transform);
        ConfigureSprite(floor, SquareSprite, new Color(0.06f, 0.06f, 0.07f, 1f), -10, new Vector3(18f, 12f, 1f));

        CreateWall(arena.transform, "Wall_North", new Vector3(0f, 5.5f, 0f), new Vector3(18f, 1f, 1f));
        CreateWall(arena.transform, "Wall_South", new Vector3(0f, -5.5f, 0f), new Vector3(18f, 1f, 1f));
        CreateWall(arena.transform, "Wall_East", new Vector3(8.5f, 0f, 0f), new Vector3(1f, 12f, 1f));
        CreateWall(arena.transform, "Wall_West", new Vector3(-8.5f, 0f, 0f), new Vector3(1f, 12f, 1f));
        CreateWall(arena.transform, "Obstacle_Block_A", new Vector3(-3f, 1.5f, 0f), new Vector3(2f, 1f, 1f));
        CreateWall(arena.transform, "Obstacle_Block_B", new Vector3(3f, -1.5f, 0f), new Vector3(2f, 1f, 1f));

        GameObject target = EnsureObject("Circle_Target_Dummy", new Vector3(4.5f, 2.75f, 0f));
        ConfigureSprite(target, CircleSprite, new Color(0.15f, 0.45f, 1f, 1f), 5, Vector3.one);
        CircleCollider2D tc = EnsureComponent<CircleCollider2D>(target);
        tc.radius = 0.5f;

        GameObject camObj = EnsureObject("Main Camera", new Vector3(0f, 0f, -10f));
        Camera cam = EnsureComponent<Camera>(camObj);
        cam.orthographic = true;
        cam.orthographicSize = 6.25f;
        cam.clearFlags = CameraClearFlags.SolidColor;
        cam.backgroundColor = Color.black;
        cam.tag = "MainCamera";
        cam.enabled = true;
        TopDownCameraFollow follow = EnsureComponent<TopDownCameraFollow>(camObj);
        follow.target = player.transform;
    }

    static void CreateWall(Transform parent, string name, Vector3 pos, Vector3 scale)
    {
        GameObject wall = EnsureObject(name, pos);
        wall.transform.SetParent(parent);
        wall.transform.position = pos;
        ConfigureSprite(wall, SquareSprite, Color.white, 5, scale);
        BoxCollider2D box = EnsureComponent<BoxCollider2D>(wall);
        box.size = Vector2.one;
    }

    static GameObject EnsureObject(string name, Vector3 pos)
    {
        GameObject obj = GameObject.Find(name);
        if (obj == null) obj = new GameObject(name);
        obj.transform.position = pos;
        return obj;
    }

    static GameObject EnsureChild(GameObject parent, string name)
    {
        Transform child = parent.transform.Find(name);
        GameObject obj = child != null ? child.gameObject : new GameObject(name);
        obj.transform.SetParent(parent.transform);
        return obj;
    }

    static T EnsureComponent<T>(GameObject obj) where T : Component
    {
        T c = obj.GetComponent<T>();
        return c != null ? c : obj.AddComponent<T>();
    }

    static void ConfigureSprite(GameObject obj, Sprite sprite, Color color, int order, Vector3 scale)
    {
        SpriteRenderer sr = EnsureComponent<SpriteRenderer>(obj);
        sr.sprite = sprite;
        sr.color = color;
        sr.sortingOrder = order;
        obj.transform.localScale = scale;
    }

    static Sprite BuildSquareSprite()
    {
        Texture2D tex = new Texture2D(8, 8, TextureFormat.RGBA32, false);
        tex.filterMode = FilterMode.Point;
        for (int y = 0; y < tex.height; y++) for (int x = 0; x < tex.width; x++) tex.SetPixel(x, y, Color.white);
        tex.Apply();
        tex.hideFlags = HideFlags.HideAndDontSave;
        Sprite s = Sprite.Create(tex, new Rect(0, 0, tex.width, tex.height), new Vector2(0.5f, 0.5f), 8f);
        s.hideFlags = HideFlags.HideAndDontSave;
        return s;
    }

    static Sprite BuildCircleSprite()
    {
        int size = 64;
        Texture2D tex = new Texture2D(size, size, TextureFormat.RGBA32, false);
        tex.filterMode = FilterMode.Bilinear;
        Vector2 c = new Vector2((size - 1) * 0.5f, (size - 1) * 0.5f);
        float r = size * 0.48f;
        for (int y = 0; y < size; y++)
        {
            for (int x = 0; x < size; x++)
            {
                float d = Vector2.Distance(new Vector2(x, y), c);
                float a = Mathf.Clamp01(r - d);
                tex.SetPixel(x, y, new Color(1f, 1f, 1f, a));
            }
        }
        tex.Apply();
        tex.hideFlags = HideFlags.HideAndDontSave;
        Sprite s = Sprite.Create(tex, new Rect(0, 0, size, size), new Vector2(0.5f, 0.5f), size);
        s.hideFlags = HideFlags.HideAndDontSave;
        return s;
    }
}
