using UnityEngine;

public class Scene5CombatManager : MonoBehaviour
{
    public static Scene5CombatManager Instance { get; private set; }

    int killCount;
    float startTime;

    void Awake()
    {
        Instance = this;
        startTime = Time.timeSinceLevelLoad;
    }

    public void RegisterKill(Vector3 position, Color color)
    {
        killCount++;
        SpawnImpact(position, color);
        ScreenShakeService.Shake(0.6f, 0.14f);
    }

    public void SpawnImpact(Vector3 position, Color color)
    {
        GameObject impact = new GameObject("ImpactPulse");
        impact.transform.position = new Vector3(position.x, position.y, 0f);
        SpriteRenderer sprite = impact.AddComponent<SpriteRenderer>();
        sprite.sprite = TopDownShooterSetup.CircleSprite;
        sprite.color = color;
        sprite.sortingOrder = 30;

        Scene5ImpactPulse pulse = impact.AddComponent<Scene5ImpactPulse>();
        pulse.Initialize(color);
    }

    void OnGUI()
    {
        if (!Application.isPlaying)
        {
            return;
        }

        GUI.color = new Color(1f, 1f, 1f, 0.95f);
        GUI.Box(new Rect(12f, 12f, 190f, 72f), string.Empty);
        GUI.Label(new Rect(24f, 22f, 160f, 24f), $"Kills: {killCount}");
        GUI.Label(new Rect(24f, 46f, 160f, 24f), $"Time: {Time.timeSinceLevelLoad - startTime:0.0}s");
    }
}
