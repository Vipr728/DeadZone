﻿using UnityEngine;

/// <summary>
/// Adds simple movement personalities to arena enemy prefabs.
/// Each prefab can choose a different behavior kind and tuning values while
/// keeping the existing ArenaCombatEnemy health/damage API unchanged.
/// </summary>
[RequireComponent(typeof(Rigidbody2D))]
public sealed class ArenaEnemyBehavior : MonoBehaviour
{
    public enum EnemyBehaviorKind
    {
        Chaser,
        ZigZag,
        Dasher
    }

    [Header("Behavior")]
    [SerializeField] private EnemyBehaviorKind behaviorKind = EnemyBehaviorKind.Chaser;
    [SerializeField] private float moveSpeed = 2.2f;
    [SerializeField] private float targetRefreshInterval = 0.5f;

    [Header("Zig Zag")]
    [SerializeField] private float zigZagAmplitude = 0.85f;
    [SerializeField] private float zigZagFrequency = 4f;

    [Header("Dasher")]
    [SerializeField] private float dashSpeed = 6.5f;
    [SerializeField] private float dashInterval = 1.35f;
    [SerializeField] private float dashDuration = 0.22f;

    private Rigidbody2D body;
    private Transform target;
    private float nextTargetRefreshTime;
    private float nextDashTime;
    private float dashEndTime;
    private Vector2 dashDirection = Vector2.right;
    private float phaseOffset;

    public EnemyBehaviorKind BehaviorKind => behaviorKind;

    private void Awake()
    {
        body = GetComponent<Rigidbody2D>();
        body.gravityScale = 0f;
        body.freezeRotation = true;
        phaseOffset = Random.value * Mathf.PI * 2f;
        nextDashTime = Time.time + Random.Range(0.2f, dashInterval);
        RefreshTarget(true);
    }

    private void FixedUpdate()
    {
        RefreshTarget(false);

        if (target == null)
        {
            body.MovePosition(body.position);
            return;
        }

        Vector2 toTarget = ((Vector2)target.position - body.position);
        Vector2 direction = toTarget.sqrMagnitude > 0.0001f ? toTarget.normalized : Vector2.zero;
        Vector2 desiredVelocity = GetVelocity(direction);

        body.MovePosition(body.position + desiredVelocity * Time.fixedDeltaTime);
    }

    private Vector2 GetVelocity(Vector2 direction)
    {
        switch (behaviorKind)
        {
            case EnemyBehaviorKind.ZigZag:
            {
                Vector2 perpendicular = new Vector2(-direction.y, direction.x);
                float wave = Mathf.Sin((Time.time * zigZagFrequency) + phaseOffset) * zigZagAmplitude;
                Vector2 zigZagDirection = (direction + perpendicular * wave).normalized;
                return zigZagDirection * moveSpeed;
            }

            case EnemyBehaviorKind.Dasher:
                return GetDashVelocity(direction);

            case EnemyBehaviorKind.Chaser:
            default:
                return direction * moveSpeed;
        }
    }

    private Vector2 GetDashVelocity(Vector2 direction)
    {
        if (Time.time >= nextDashTime)
        {
            dashDirection = direction.sqrMagnitude > 0.0001f ? direction : dashDirection;
            dashEndTime = Time.time + dashDuration;
            nextDashTime = Time.time + dashInterval;
        }

        if (Time.time < dashEndTime)
        {
            return dashDirection * dashSpeed;
        }

        return direction * (moveSpeed * 0.65f);
    }

    private void RefreshTarget(bool force)
    {
        if (!force && Time.time < nextTargetRefreshTime && target != null)
        {
            return;
        }

        nextTargetRefreshTime = Time.time + targetRefreshInterval;

        GameObject player = GameObject.FindGameObjectWithTag("Player");
        target = player != null ? player.transform : null;
    }
}
