using UnityEngine;

public class Scene5ImpactPulse : MonoBehaviour
{
    [SerializeField] float lifetime = 0.2f;
    [SerializeField] float startScale = 0.2f;
    [SerializeField] float endScale = 0.95f;

    SpriteRenderer sprite;
    Color baseColor;
    float startedAt;

    public void Initialize(Color color)
    {
        sprite = GetComponent<SpriteRenderer>();
        baseColor = color;
        startedAt = Time.time;
        transform.localScale = Vector3.one * startScale;
    }

    void Awake()
    {
        sprite = GetComponent<SpriteRenderer>();
        baseColor = sprite != null ? sprite.color : Color.white;
        startedAt = Time.time;
    }

    void Update()
    {
        float t = Mathf.Clamp01((Time.time - startedAt) / lifetime);
        transform.localScale = Vector3.one * Mathf.Lerp(startScale, endScale, t);
        if (sprite != null)
        {
            Color color = baseColor;
            color.a = 1f - t;
            sprite.color = color;
        }

        if (t >= 1f)
        {
            Destroy(gameObject);
        }
    }
}
