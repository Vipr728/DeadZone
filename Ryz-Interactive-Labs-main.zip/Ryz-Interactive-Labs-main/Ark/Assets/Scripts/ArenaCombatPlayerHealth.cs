﻿using UnityEngine;

public class ArenaCombatPlayerHealth : MonoBehaviour
{
    [SerializeField] int maxHealth = 3;
    [SerializeField, Min(0f)] float contactDamageCooldown = 0.5f;

    int currentHealth;
    float lastDamageTime = -999f;
    ArenaCombatGameManager gameManager;

    void Awake()
    {
        currentHealth = maxHealth;
        gameManager = FindFirstObjectByType<ArenaCombatGameManager>();
    }

    public void TakeDamage(int amount)
    {
        if (amount <= 0 || Time.time - lastDamageTime < contactDamageCooldown)
            return;

        lastDamageTime = Time.time;
        currentHealth -= amount;
        if (currentHealth <= 0)
        {
            gameManager?.PlayerDied();
        }
    }
}
