﻿using UnityEngine;

public class TopDownPlayerLightController : MonoBehaviour
{
    public GameObject playerLightGlow;
    public bool spawnGlowOnStart;

    private void Start()
    {
        if (!spawnGlowOnStart || playerLightGlow == null)
        {
            return;
        }

        Instantiate(playerLightGlow, transform.position, Quaternion.identity);
    }
}
