﻿using UnityEngine;
using Unity.Cinemachine;

public static class ScreenShakeService
{
    static CinemachineImpulseSource s_ImpulseSource;
    static Scene5CameraShake s_FallbackShake;
    static readonly Vector3[] s_Directions =
    {
        Vector3.up,
        Vector3.down,
        Vector3.left,
        Vector3.right,
        new Vector3(1f, 1f, 0f).normalized,
        new Vector3(-1f, 1f, 0f).normalized,
        new Vector3(1f, -1f, 0f).normalized,
        new Vector3(-1f, -1f, 0f).normalized
    };

    public static void Shake(float intensity)
    {
        Shake(intensity, 0.1f);
    }

    public static void Shake(float intensity, float duration)
    {
        if (s_ImpulseSource == null)
        {
            s_ImpulseSource = Object.FindFirstObjectByType<CinemachineImpulseSource>();
        }

        if (s_ImpulseSource != null)
        {
            Vector3 direction = s_Directions[Random.Range(0, s_Directions.Length)];
            s_ImpulseSource.GenerateImpulseWithVelocity(direction * intensity);
            return;
        }

        if (s_FallbackShake == null)
        {
            s_FallbackShake = Object.FindFirstObjectByType<Scene5CameraShake>();
        }

        if (s_FallbackShake != null)
        {
            s_FallbackShake.Shake(intensity, duration);
        }
    }

    public static void Shake(float intensity, float directionVariation, float duration)
    {
        Shake(intensity * directionVariation, duration);
    }
}
