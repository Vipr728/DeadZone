using UnityEngine;

[RequireComponent(typeof(Rigidbody2D), typeof(CircleCollider2D), typeof(SpriteRenderer))]
public class Scene5Enemy : MonoBehaviour
{
    public enum EnemyBehavior
    {
        Direct,
        Strafe,
        Pounce
    }

    [SerializeField] EnemyBehavior behavior;
    [SerializeField] Transform target;
    [SerializeField] float moveSpeed = 2.6f;
    [SerializeField] float strafeWeight = 0.9f;
    [SerializeField] int health = 2;
    [SerializeField] Color impactColor = new Color(0.7f, 1f, 0.7f, 1f);

    Rigidbody2D rb;

    public void Configure(Transform followTarget, EnemyBehavior nextBehavior, float speed, Color color)
    {
        target = followTarget;
        behavior = nextBehavior;
        moveSpeed = speed;
        impactColor = color;
        SpriteRenderer sprite = GetComponent<SpriteRenderer>();
        sprite.sprite = TopDownShooterSetup.CircleSprite;
        sprite.color = color;
        sprite.sortingOrder = 15;
        transform.localScale = Vector3.one * 0.9f;
    }

    void Awake()
    {
        rb = GetComponent<Rigidbody2D>();
        rb.gravityScale = 0f;
        rb.freezeRotation = true;
        CircleCollider2D collider = GetComponent<CircleCollider2D>();
        collider.radius = 0.45f;
    }

    void FixedUpdate()
    {
        if (target == null)
        {
            return;
        }

        Vector2 toPlayer = target.position - transform.position;
        Vector2 dir = toPlayer.normalized;
        Vector2 perpendicular = new Vector2(-dir.y, dir.x);

        switch (behavior)
        {
            case EnemyBehavior.Strafe:
                dir = (dir + perpendicular * Mathf.Sin(Time.time * 2.6f) * strafeWeight).normalized;
                break;
            case EnemyBehavior.Pounce:
                float burst = Mathf.PingPong(Time.time * 1.5f, 1f) > 0.45f ? 1.7f : 0.45f;
                dir = (dir + perpendicular * Mathf.Cos(Time.time * 5f) * 0.35f).normalized * burst;
                break;
        }

        rb.linearVelocity = dir * moveSpeed;
    }

    public void TakeDamage(int damage, Vector3 hitPoint)
    {
        health -= damage;
        Scene5CombatManager.Instance?.SpawnImpact(hitPoint, impactColor);
        if (health <= 0)
        {
            Scene5CombatManager.Instance?.RegisterKill(transform.position, impactColor);
            Destroy(gameObject);
        }
    }
}
