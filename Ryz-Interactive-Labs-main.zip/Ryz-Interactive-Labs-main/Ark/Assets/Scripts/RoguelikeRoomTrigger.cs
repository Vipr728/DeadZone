﻿using UnityEngine;

[RequireComponent(typeof(Collider2D))]
public sealed class RoguelikeRoomTrigger : MonoBehaviour
{
    [SerializeField] private int roomIndex = -1;

    public int RoomIndex
    {
        get => roomIndex;
        set => roomIndex = value;
    }

    private void Reset()
    {
        Collider2D trigger = GetComponent<Collider2D>();
        if (trigger != null)
        {
            trigger.isTrigger = true;
        }
    }

    private void OnTriggerEnter2D(Collider2D other)
    {
        if (roomIndex < 0 || !other.CompareTag("Player"))
        {
            return;
        }

        ArenaCombatGameManager manager = ArenaCombatGameManager.Instance;
        if (manager != null)
        {
            manager.EnterRoom(roomIndex);
        }
    }
}
