using UnityEngine;

[ExecuteAlways]
public class Scene5Bootstrap : MonoBehaviour
{
    void OnEnable() => SetupScene();
    void Awake() => SetupScene();
    void Reset() => SetupScene();

    void SetupScene()
    {
        GameObject arena = EnsureObject("Scene5_Arena", Vector3.zero);
        GameObject floor = EnsureObject("Arena_Background", new Vector3(0f, 0f, 1f));
        floor.transform.SetParent(arena.transform);
        ConfigureSprite(floor, TopDownShooterSetup.SquareSprite, new Color(0.08f, 0.08f, 0.1f, 1f), -10, new Vector3(24f, 14f, 1f));

        CreateWall(arena.transform, "Wall_North", new Vector3(0f, 6.5f, 0f), new Vector3(24f, 1f, 1f));
        CreateWall(arena.transform, "Wall_South", new Vector3(0f, -6.5f, 0f), new Vector3(24f, 1f, 1f));
        CreateWall(arena.transform, "Wall_East", new Vector3(11.5f, 0f, 0f), new Vector3(1f, 14f, 1f));
        CreateWall(arena.transform, "Wall_West", new Vector3(-11.5f, 0f, 0f), new Vector3(1f, 14f, 1f));
        CreateWall(arena.transform, "Obstacle_A", new Vector3(-3f, 1.5f, 0f), new Vector3(2.4f, 1.2f, 1f));
        CreateWall(arena.transform, "Obstacle_B", new Vector3(4f, -2f, 0f), new Vector3(1.6f, 2.2f, 1f));

        GameObject player = EnsureObject("Player", Vector3.zero);
        ConfigureSprite(player, TopDownShooterSetup.CircleSprite, new Color(1f, 0.25f, 0.25f, 1f), 20, Vector3.one);
        Rigidbody2D playerBody = EnsureComponent<Rigidbody2D>(player);
        playerBody.gravityScale = 0f;
        playerBody.freezeRotation = true;
        playerBody.collisionDetectionMode = CollisionDetectionMode2D.Continuous;
        CircleCollider2D playerCollider = EnsureComponent<CircleCollider2D>(player);
        playerCollider.radius = 0.5f;
        TopDownPlayerController playerController = EnsureComponent<TopDownPlayerController>(player);
        playerController.moveSpeed = 7f;
        playerController.fireRate = 0.11f;
        playerController.bulletSpeed = 16f;
        playerController.recoilForce = 0.55f;
        playerController.shotSpreadDegrees = 3f;

        GameObject manager = EnsureObject("Scene5GameManager", Vector3.zero);
        EnsureComponent<Scene5CombatManager>(manager);

        SetupEnemy(player.transform, "Enemy_Chaser", new Vector3(7f, 3f, 0f), Scene5Enemy.EnemyBehavior.Direct, 2.7f, new Color(0.5f, 1f, 0.55f, 1f));
        SetupEnemy(player.transform, "Enemy_Strafe", new Vector3(-7f, 2f, 0f), Scene5Enemy.EnemyBehavior.Strafe, 2.4f, new Color(0.45f, 0.85f, 1f, 1f));
        SetupEnemy(player.transform, "Enemy_Pounce", new Vector3(0f, 4.5f, 0f), Scene5Enemy.EnemyBehavior.Pounce, 2.2f, new Color(1f, 0.8f, 0.35f, 1f));
        SetupEnemy(player.transform, "Enemy_Chaser_2", new Vector3(-5.5f, -3.5f, 0f), Scene5Enemy.EnemyBehavior.Direct, 2.9f, new Color(0.6f, 1f, 0.6f, 1f));
        SetupEnemy(player.transform, "Enemy_Strafe_2", new Vector3(6.5f, -3.2f, 0f), Scene5Enemy.EnemyBehavior.Strafe, 2.55f, new Color(0.55f, 0.9f, 1f, 1f));

        GameObject rig = EnsureObject("CameraRig", new Vector3(0f, 0f, -10f));
        TopDownCameraFollow follow = EnsureComponent<TopDownCameraFollow>(rig);
        follow.target = player.transform;
        follow.followSpeed = 8f;
        follow.offset = new Vector3(0f, 0f, -10f);

        GameObject cameraObject = EnsureChild(rig, "Main Camera");
        cameraObject.transform.localPosition = Vector3.zero;
        Camera cameraComponent = EnsureComponent<Camera>(cameraObject);
        cameraComponent.orthographic = true;
        cameraComponent.orthographicSize = 7f;
        cameraComponent.backgroundColor = new Color(0.03f, 0.03f, 0.04f, 1f);
        cameraComponent.clearFlags = CameraClearFlags.SolidColor;
        cameraObject.tag = "MainCamera";
        EnsureComponent<Scene5CameraShake>(cameraObject);
    }

    void SetupEnemy(Transform player, string name, Vector3 position, Scene5Enemy.EnemyBehavior behavior, float speed, Color color)
    {
        GameObject enemy = EnsureObject(name, position);
        Scene5Enemy scene5Enemy = EnsureComponent<Scene5Enemy>(enemy);
        scene5Enemy.Configure(player, behavior, speed, color);
    }

    static void CreateWall(Transform parent, string name, Vector3 pos, Vector3 scale)
    {
        GameObject wall = EnsureObject(name, pos);
        wall.transform.SetParent(parent);
        ConfigureSprite(wall, TopDownShooterSetup.SquareSprite, new Color(0.9f, 0.9f, 0.95f, 1f), 5, scale);
        EnsureComponent<BoxCollider2D>(wall).size = Vector2.one;
    }

    static GameObject EnsureObject(string name, Vector3 position)
    {
        GameObject obj = GameObject.Find(name);
        if (obj == null)
        {
            obj = new GameObject(name);
        }
        obj.transform.position = position;
        return obj;
    }

    static GameObject EnsureChild(GameObject parent, string name)
    {
        Transform child = parent.transform.Find(name);
        if (child != null)
        {
            return child.gameObject;
        }

        GameObject obj = new GameObject(name);
        obj.transform.SetParent(parent.transform);
        return obj;
    }

    static T EnsureComponent<T>(GameObject obj) where T : Component
    {
        T component = obj.GetComponent<T>();
        return component != null ? component : obj.AddComponent<T>();
    }

    static void ConfigureSprite(GameObject obj, Sprite sprite, Color color, int order, Vector3 scale)
    {
        SpriteRenderer spriteRenderer = EnsureComponent<SpriteRenderer>(obj);
        spriteRenderer.sprite = sprite;
        spriteRenderer.color = color;
        spriteRenderer.sortingOrder = order;
        obj.transform.localScale = scale;
    }
}
