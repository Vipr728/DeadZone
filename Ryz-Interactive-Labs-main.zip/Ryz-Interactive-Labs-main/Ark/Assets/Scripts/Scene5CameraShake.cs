using UnityEngine;

public class Scene5CameraShake : MonoBehaviour
{
    [SerializeField] float damping = 12f;
    [SerializeField] float maxOffset = 0.35f;

    Vector3 baseLocalPosition;
    float trauma;

    void Awake()
    {
        baseLocalPosition = transform.localPosition;
    }

    public void Shake(float intensity, float duration)
    {
        trauma = Mathf.Clamp01(trauma + intensity * Mathf.Max(0.4f, duration));
    }

    void LateUpdate()
    {
        float strength = trauma * trauma;
        Vector2 offset = Random.insideUnitCircle * maxOffset * strength;
        transform.localPosition = baseLocalPosition + new Vector3(offset.x, offset.y, 0f);
        trauma = Mathf.MoveTowards(trauma, 0f, damping * Time.deltaTime * 0.1f);
    }
}
