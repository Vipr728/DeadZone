﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public sealed class ArenaCombatGameManager : MonoBehaviour
{
    public static ArenaCombatGameManager Instance { get; private set; }

    [Header("Legacy Arena Compatibility")]
    [SerializeField] private int enemiesToWin = 5;
    [SerializeField] private string enemySpawnPrefix = "EnemySpawn_";
    [SerializeField] private GameObject[] enemyPrefabs;
    [SerializeField] private float initialSpawnInterval = 2.25f;
    [SerializeField] private float minimumSpawnInterval = 0.45f;
    [SerializeField] private float spawnIntervalDecayPerSpawn = 0.08f;

    [Header("Roguelike Dungeon")]
    [SerializeField] private bool useRoguelikeDungeon = true;
    [SerializeField] private RoguelikeDungeonGenerator dungeonGenerator;
    [SerializeField, Min(1)] private int startingFloor = 1;
    [SerializeField, Min(4)] private int startingRoomCount = 8;
    [SerializeField, Min(0)] private int roomsAddedPerFloor = 2;
    [SerializeField, Min(1)] private int baseEnemiesPerCombatRoom = 2;
    [SerializeField, Min(0)] private int enemiesAddedPerFloor = 1;
    [SerializeField, Min(0.25f)] private float roomSpawnInset = 2.25f;
    [SerializeField, Min(0f)] private float roomStartDelay = 0.35f;
    [SerializeField, Min(0.05f)] private float roomEnemySpawnInterval = 0.4f;

    private readonly List<GameObject> activeRoomEnemies = new List<GameObject>();
    private readonly HashSet<int> clearedRooms = new HashSet<int>();
    private Coroutine activeEncounter;
    private Transform player;
    private int currentFloor;
    private int activeRoomIndex = -1;
    private bool encounterSpawning;
    private bool gameOver;

    public int CurrentFloor => currentFloor;
    public bool IsGameOver => gameOver;

    private void Awake()
    {
        if (Instance != null && Instance != this)
        {
            Destroy(gameObject);
            return;
        }

        Instance = this;
    }

    private void Start()
    {
        currentFloor = Mathf.Max(1, startingFloor);
        player = FindPlayerTransform();

        if (useRoguelikeDungeon)
        {
            StartFloor(currentFloor);
        }
        else
        {
            activeEncounter = StartCoroutine(SpawnLegacyArenaLoop());
        }
    }

    private void Update()
    {
        if (gameOver || !useRoguelikeDungeon || activeRoomIndex < 0)
        {
            return;
        }

        PruneDeadEnemies();
        if (!encounterSpawning && activeRoomEnemies.Count == 0)
        {
            CompleteActiveRoom();
        }
    }

    public void EnterRoom(int roomIndex)
    {
        if (gameOver || !useRoguelikeDungeon || dungeonGenerator == null)
        {
            return;
        }

        if (activeRoomIndex >= 0 || clearedRooms.Contains(roomIndex))
        {
            return;
        }

        RoguelikeDungeonGenerator.Room room = dungeonGenerator.GetRoom(roomIndex);
        if (room == null)
        {
            return;
        }

        if (!room.IsCombatEncounter)
        {
            clearedRooms.Add(roomIndex);
            dungeonGenerator.SetRoomCleared(roomIndex, true);
            return;
        }

        activeRoomIndex = roomIndex;
        dungeonGenerator.SetRoomCleared(roomIndex, false);
        activeEncounter = StartCoroutine(RunRoomEncounter(room));
    }

    public void Lose()
    {
        if (gameOver)
        {
            return;
        }

        gameOver = true;
        if (activeEncounter != null)
        {
            StopCoroutine(activeEncounter);
            activeEncounter = null;
        }

        Debug.Log("Run ended. The player died in the dungeon.");
    }

    public void PlayerDied()
    {
        Lose();
    }

    public void Win()
    {
        if (gameOver)
        {
            return;
        }

        Debug.Log("Floor cleared. Descending deeper into the roguelike dungeon.");
        StartFloor(currentFloor + 1);
    }

    private void StartFloor(int floorNumber)
    {
        currentFloor = Mathf.Max(1, floorNumber);
        gameOver = false;
        activeRoomIndex = -1;
        encounterSpawning = false;
        clearedRooms.Clear();
        ClearActiveEnemies();

        if (dungeonGenerator == null)
        {
            dungeonGenerator = FindFirstObjectByType<RoguelikeDungeonGenerator>();
        }

        if (dungeonGenerator == null)
        {
            dungeonGenerator = gameObject.AddComponent<RoguelikeDungeonGenerator>();
        }

        int roomCount = startingRoomCount + Mathf.Max(0, currentFloor - 1) * roomsAddedPerFloor;
        dungeonGenerator.ConfigureForFloor(currentFloor, roomCount);
        dungeonGenerator.Generate();

        player = player != null ? player : FindPlayerTransform();
        if (player != null)
        {
            Vector2 startPosition = dungeonGenerator.GetPlayerStartPosition();
            Rigidbody2D body = player.GetComponent<Rigidbody2D>();
            if (body != null)
            {
                body.linearVelocity = Vector2.zero;
                body.gravityScale = 0f;
                body.position = startPosition;
            }
            else
            {
                player.position = new Vector3(startPosition.x, startPosition.y, player.position.z);
            }
        }

        if (dungeonGenerator.StartRoom != null)
        {
            clearedRooms.Add(dungeonGenerator.StartRoom.Index);
            dungeonGenerator.SetRoomCleared(dungeonGenerator.StartRoom.Index, true);
        }

        Debug.Log($"Generated roguelike floor {currentFloor} with {dungeonGenerator.Rooms.Count} rooms. Seed: {dungeonGenerator.CurrentSeed}.");
    }

    private IEnumerator RunRoomEncounter(RoguelikeDungeonGenerator.Room room)
    {
        encounterSpawning = true;
        yield return new WaitForSeconds(roomStartDelay);

        int enemyCount = GetEnemyCountForRoom(room);
        for (int i = 0; i < enemyCount; i++)
        {
            SpawnEnemyInRoom(room.Index);
            yield return new WaitForSeconds(roomEnemySpawnInterval);
        }

        encounterSpawning = false;
        activeEncounter = null;
    }

    private int GetEnemyCountForRoom(RoguelikeDungeonGenerator.Room room)
    {
        int floorBonus = Mathf.Max(0, currentFloor - 1) * enemiesAddedPerFloor;
        int depthBonus = Mathf.Max(0, room.PathDepth / 2);
        int exitBonus = room.IsExit ? 2 : 0;
        return Mathf.Max(1, baseEnemiesPerCombatRoom + floorBonus + depthBonus + exitBonus);
    }

    private void SpawnEnemyInRoom(int roomIndex)
    {
        GameObject prefab = GetRandomEnemyPrefab();
        if (prefab == null || dungeonGenerator == null)
        {
            return;
        }

        Vector2 spawnPosition = dungeonGenerator.GetRandomSpawnPosition(roomIndex, roomSpawnInset);
        GameObject enemy = Instantiate(prefab, new Vector3(spawnPosition.x, spawnPosition.y, 0f), Quaternion.identity);
        enemy.name = prefab.name + "_Room" + roomIndex.ToString("00");
        activeRoomEnemies.Add(enemy);
    }

    private GameObject GetRandomEnemyPrefab()
    {
        if (enemyPrefabs == null || enemyPrefabs.Length == 0)
        {
            return null;
        }

        int start = Random.Range(0, enemyPrefabs.Length);
        for (int i = 0; i < enemyPrefabs.Length; i++)
        {
            GameObject candidate = enemyPrefabs[(start + i) % enemyPrefabs.Length];
            if (candidate != null)
            {
                return candidate;
            }
        }

        return null;
    }

    private void CompleteActiveRoom()
    {
        int completedRoom = activeRoomIndex;
        activeRoomIndex = -1;
        clearedRooms.Add(completedRoom);
        if (dungeonGenerator != null)
        {
            dungeonGenerator.SetRoomCleared(completedRoom, true);
            RoguelikeDungeonGenerator.Room room = dungeonGenerator.GetRoom(completedRoom);
            if (room != null && room.IsExit)
            {
                Win();
            }
        }
    }

    private void PruneDeadEnemies()
    {
        for (int i = activeRoomEnemies.Count - 1; i >= 0; i--)
        {
            if (activeRoomEnemies[i] == null)
            {
                activeRoomEnemies.RemoveAt(i);
            }
        }
    }

    private void ClearActiveEnemies()
    {
        for (int i = activeRoomEnemies.Count - 1; i >= 0; i--)
        {
            if (activeRoomEnemies[i] != null)
            {
                Destroy(activeRoomEnemies[i]);
            }
        }

        activeRoomEnemies.Clear();
    }

    private Transform FindPlayerTransform()
    {
        GameObject playerObject = GameObject.FindGameObjectWithTag("Player");
        return playerObject != null ? playerObject.transform : null;
    }

    private IEnumerator SpawnLegacyArenaLoop()
    {
        int spawned = 0;
        float interval = Mathf.Max(0.05f, initialSpawnInterval);
        while (!gameOver && spawned < enemiesToWin)
        {
            SpawnAtLegacySpawnPoint();
            spawned++;
            interval = Mathf.Max(minimumSpawnInterval, interval - spawnIntervalDecayPerSpawn);
            yield return new WaitForSeconds(interval);
        }
    }

    private void SpawnAtLegacySpawnPoint()
    {
        GameObject prefab = GetRandomEnemyPrefab();
        Transform spawn = GetRandomLegacySpawnPoint();
        if (prefab == null || spawn == null)
        {
            return;
        }

        Instantiate(prefab, spawn.position, Quaternion.identity);
    }

    private Transform GetRandomLegacySpawnPoint()
    {
        List<Transform> spawns = new List<Transform>();
        Transform[] allTransforms = FindObjectsByType<Transform>(FindObjectsSortMode.None);
        for (int i = 0; i < allTransforms.Length; i++)
        {
            if (allTransforms[i].name.StartsWith(enemySpawnPrefix, System.StringComparison.Ordinal))
            {
                spawns.Add(allTransforms[i]);
            }
        }

        return spawns.Count > 0 ? spawns[Random.Range(0, spawns.Count)] : null;
    }
}
