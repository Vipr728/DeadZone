﻿using UnityEngine;

/// <summary>
/// Spawns a reusable ParticleSystem impact prefab when a bullet trigger touches anything.
/// Runs before TopDownBullet so the effect is created before the projectile destroys itself.
/// </summary>
[DefaultExecutionOrder(-100)]
public sealed class BulletImpactParticles : MonoBehaviour
{
    [SerializeField] private GameObject impactPrefab;
    [SerializeField] private float destroyPadding = 0.15f;
    [SerializeField] private bool alignToBulletVelocity = false;

    private bool spawnedImpact;

    private void OnTriggerEnter2D(Collider2D other)
    {
        if (spawnedImpact)
        {
            return;
        }

        spawnedImpact = true;

        if (impactPrefab == null)
        {
            Debug.LogWarning($"{nameof(BulletImpactParticles)} on {name} has no impact prefab assigned.", this);
            return;
        }

        Vector3 impactPosition = transform.position;
        if (other != null)
        {
            Vector2 closestPoint = other.ClosestPoint(transform.position);
            impactPosition = new Vector3(closestPoint.x, closestPoint.y, transform.position.z);
        }

        Quaternion impactRotation = Quaternion.identity;
        if (alignToBulletVelocity && TryGetComponent(out Rigidbody2D body) && body.linearVelocity.sqrMagnitude > 0.001f)
        {
            Vector2 direction = body.linearVelocity.normalized;
            impactRotation = Quaternion.Euler(0f, 0f, Mathf.Atan2(direction.y, direction.x) * Mathf.Rad2Deg);
        }

        GameObject impactInstance = Instantiate(impactPrefab, impactPosition, impactRotation);
        Destroy(impactInstance, EstimateLifetime(impactInstance) + Mathf.Max(0f, destroyPadding));
    }

    private static float EstimateLifetime(GameObject impactInstance)
    {
        float lifetime = 0.5f;
        ParticleSystem[] systems = impactInstance.GetComponentsInChildren<ParticleSystem>();

        foreach (ParticleSystem system in systems)
        {
            ParticleSystem.MainModule main = system.main;
            float systemLifetime = main.startDelay.constantMax + main.duration + main.startLifetime.constantMax;
            lifetime = Mathf.Max(lifetime, systemLifetime);
        }

        return lifetime;
    }
}
