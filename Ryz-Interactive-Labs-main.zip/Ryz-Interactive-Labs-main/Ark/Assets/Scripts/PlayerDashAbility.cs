﻿using UnityEngine;
#if ENABLE_INPUT_SYSTEM
using UnityEngine.InputSystem;
#endif

[DefaultExecutionOrder(100)]
[RequireComponent(typeof(Rigidbody2D))]
[RequireComponent(typeof(TrailRenderer))]
public sealed class PlayerDashAbility : MonoBehaviour
{
    [Header("Dash")]
    [SerializeField] private float dashSpeed = 18f;
    [SerializeField] private float dashDuration = 0.14f;
    [SerializeField] private float dashCooldown = 0.45f;

    [Header("Trail")]
    [SerializeField] private float trailTime = 0.22f;
    [SerializeField] private float trailStartWidth = 0.55f;
    [SerializeField] private float trailEndWidth = 0.05f;
    [SerializeField] private Color trailStartColor = new Color(0.35f, 0.9f, 1f, 0.85f);
    [SerializeField] private Color trailEndColor = new Color(0.1f, 0.35f, 1f, 0f);

    private Rigidbody2D rb;
    private TrailRenderer dashTrail;
    private Vector2 dashDirection = Vector2.up;
    private float dashTimer;
    private float cooldownTimer;
    private float originalGravityScale;

    public bool IsDashing => dashTimer > 0f;

    private void Awake()
    {
        rb = GetComponent<Rigidbody2D>();
        dashTrail = GetComponent<TrailRenderer>();
        originalGravityScale = rb.gravityScale;
        ConfigureTrail();
    }

    private void OnValidate()
    {
        dashSpeed = Mathf.Max(0f, dashSpeed);
        dashDuration = Mathf.Max(0.01f, dashDuration);
        dashCooldown = Mathf.Max(0f, dashCooldown);
        trailTime = Mathf.Max(0.01f, trailTime);
        trailStartWidth = Mathf.Max(0.01f, trailStartWidth);
        trailEndWidth = Mathf.Max(0f, trailEndWidth);

        if (TryGetComponent(out TrailRenderer trail))
        {
            dashTrail = trail;
            ConfigureTrail();
        }
    }

    private void Update()
    {
        if (cooldownTimer > 0f)
        {
            cooldownTimer -= Time.deltaTime;
        }

        if (!IsDashing && cooldownTimer <= 0f && WasDashPressed())
        {
            StartDash();
        }
    }

    private void FixedUpdate()
    {
        if (!IsDashing)
        {
            return;
        }

        rb.gravityScale = 0f;
        rb.linearVelocity = dashDirection * dashSpeed;

        dashTimer -= Time.fixedDeltaTime;
        if (dashTimer <= 0f)
        {
            StopDash();
        }
    }

    private void OnDisable()
    {
        if (rb != null)
        {
            rb.gravityScale = originalGravityScale;
        }

        if (dashTrail != null)
        {
            dashTrail.emitting = false;
            dashTrail.enabled = false;
        }

        dashTimer = 0f;
    }

    private void StartDash()
    {
        dashDirection = ResolveDashDirection();
        dashTimer = dashDuration;
        cooldownTimer = dashCooldown;

        if (dashTrail != null)
        {
            dashTrail.Clear();
            dashTrail.enabled = true;
            dashTrail.emitting = true;
        }
    }

    private void StopDash()
    {
        dashTimer = 0f;
        rb.gravityScale = originalGravityScale;

        if (dashTrail != null)
        {
            dashTrail.emitting = false;
            dashTrail.enabled = false;
        }
    }

    private Vector2 ResolveDashDirection()
    {
        Vector2 inputDirection = ReadMoveInput();
        if (inputDirection.sqrMagnitude > 0.01f)
        {
            return inputDirection.normalized;
        }

        if (rb.linearVelocity.sqrMagnitude > 0.01f)
        {
            return rb.linearVelocity.normalized;
        }

        return dashDirection.sqrMagnitude > 0.01f ? dashDirection.normalized : Vector2.up;
    }

    private static bool WasDashPressed()
    {
#if ENABLE_INPUT_SYSTEM
        Keyboard keyboard = Keyboard.current;
        if (keyboard != null && (keyboard.spaceKey.wasPressedThisFrame || keyboard.leftShiftKey.wasPressedThisFrame || keyboard.rightShiftKey.wasPressedThisFrame))
        {
            return true;
        }
#endif

#if ENABLE_LEGACY_INPUT_MANAGER
        if (Input.GetKeyDown(KeyCode.Space) || Input.GetKeyDown(KeyCode.LeftShift) || Input.GetKeyDown(KeyCode.RightShift))
        {
            return true;
        }
#endif

        return false;
    }

    private static Vector2 ReadMoveInput()
    {
        Vector2 input = Vector2.zero;

#if ENABLE_INPUT_SYSTEM
        Keyboard keyboard = Keyboard.current;
        if (keyboard != null)
        {
            if (keyboard.aKey.isPressed || keyboard.leftArrowKey.isPressed) input.x -= 1f;
            if (keyboard.dKey.isPressed || keyboard.rightArrowKey.isPressed) input.x += 1f;
            if (keyboard.sKey.isPressed || keyboard.downArrowKey.isPressed) input.y -= 1f;
            if (keyboard.wKey.isPressed || keyboard.upArrowKey.isPressed) input.y += 1f;
        }
#endif

#if ENABLE_LEGACY_INPUT_MANAGER
        input.x += Input.GetAxisRaw("Horizontal");
        input.y += Input.GetAxisRaw("Vertical");
#endif

        return input.sqrMagnitude > 1f ? input.normalized : input;
    }

    private void ConfigureTrail()
    {
        if (dashTrail == null)
        {
            return;
        }

        dashTrail.time = trailTime;
        dashTrail.startWidth = trailStartWidth;
        dashTrail.endWidth = trailEndWidth;
        dashTrail.minVertexDistance = 0.02f;
        dashTrail.autodestruct = false;
        dashTrail.emitting = false;
        dashTrail.enabled = false;
        dashTrail.sortingLayerName = "Default";
        dashTrail.sortingOrder = 1;
        dashTrail.colorGradient = CreateTrailGradient();

        if (dashTrail.sharedMaterial == null)
        {
            Shader shader = Shader.Find("Sprites/Default");
            if (shader != null)
            {
                dashTrail.sharedMaterial = new Material(shader);
            }
        }
    }

    private Gradient CreateTrailGradient()
    {
        Gradient gradient = new Gradient();
        gradient.SetKeys(
            new[]
            {
                new GradientColorKey(trailStartColor, 0f),
                new GradientColorKey(trailEndColor, 1f)
            },
            new[]
            {
                new GradientAlphaKey(trailStartColor.a, 0f),
                new GradientAlphaKey(trailEndColor.a, 1f)
            });
        return gradient;
    }
}
