using UnityEngine;

namespace Ark.Enemy
{
    /// <summary>
    /// Base class for enemy behaviors.
    /// </summary>
    public abstract class EnemyAI : MonoBehaviour
    {
        [Header("Common")]
        [Tooltip("Speed of the enemy")]
        [SerializeField] protected float moveSpeed = 3f;

        [Tooltip("Enemy health")]
        [SerializeField] protected int health = 1;

        [Tooltip("Score value for this enemy type")]
        [SerializeField] protected int scoreValue = 10;

        [Tooltip("Point light color")]
        [SerializeField] protected Color lightColor = new Color(1f, 0.3f, 0.2f);

        [Tooltip("Point light radius")]
        [SerializeField] protected float lightRadius = 2f;

        protected Transform playerTransform;
        protected SpriteRenderer spriteRenderer;
        protected Collider2D collider;

        protected virtual void Awake()
        {
            spriteRenderer = GetComponent<SpriteRenderer>();
            collider = GetComponent<Collider2D>();
            if (spriteRenderer != null)
            {
                spriteRenderer.sortingOrder = 2;
            }

            var light = GetComponent<UnityEngine.Light2D>();
            if (light != null)
            {
                light.color = lightColor;
                light.pointLightOuterRadius = lightRadius;
            }
        }

        protected virtual void Start()
        {
            GameObject player = GameObject.FindGameObjectWithTag("Player");
            if (player != null)
            {
                playerTransform = player.transform;
            }
        }

        protected virtual void Update()
        {
            if (playerTransform != null)
            {
                Vector3 direction = (playerTransform.position - transform.position).normalized;
                MoveEnemy(direction);
            }
        }

        protected abstract void MoveEnemy(Vector3 direction);

        public void TakeDamage()
        {
            health--;
            if (spriteRenderer != null)
            {
                // Brief flash to white
                spriteRenderer.color = Color.white;
                Invoke(nameof(ResetColor), 0.05f);
            }

            if (health <= 0)
            {
                Destroy(gameObject);
            }
        }

        private void ResetColor()
        {
            if (spriteRenderer != null)
            {
                spriteRenderer.color = Color.white;
            }
        }
    }

    /// <summary>
    /// Chaser - directly pursues the player at constant speed.
    /// </summary>
    public class EnemyChaser : EnemyAI
    {
        protected override void MoveEnemy(Vector3 direction)
        {
            transform.position += direction * moveSpeed * Time.deltaTime;
            // Rotate to face player
            float angle = Mathf.Atan2(direction.y, direction.x) * Mathf.Rad2Deg;
            transform.rotation = Quaternion.Euler(0, 0, angle);
        }

        protected override void Awake()
        {
            base.Awake();
            if (spriteRenderer != null)
            {
                spriteRenderer.color = new Color(1f, 0.4f, 0.3f);
            }
        }
    }

    /// <summary>
    /// Orbiting - circles around the player at a fixed radius.
    /// </summary>
    public class EnemyOrbit : EnemyAI
    {
        [Header("Orbit")]
        [Tooltip("Orbit radius from player")]
        [SerializeField] private float orbitRadius = 3f;

        [Tooltip("Orbit direction (1 = clockwise, -1 = counter-clockwise)")]
        [SerializeField] private float orbitDirection = 1f;

        [Tooltip("Orbit speed multiplier")]
        [SerializeField] private float orbitSpeed = 1.5f;

        private float orbitAngle = 0f;
        private Vector3 initialOffset;
        private float distanceToPlayer = 0f;

        protected override void Awake()
        {
            base.Awake();
            if (spriteRenderer != null)
            {
                spriteRenderer.color = new Color(0.4f, 0.7f, 1f);
            }
        }

        protected override void Start()
        {
            base.Start();
            orbitAngle = Random.Range(0f, Mathf.PI * 2f);
        }

        protected override void Update()
        {
            base.Update();

            if (playerTransform == null) return;

            // Calculate distance and adjust orbit radius
            float dist = Vector3.Distance(transform.position, playerTransform.position);
            distanceToPlayer = dist;

            // Move in orbit
            orbitAngle += orbitDirection * orbitSpeed * Time.deltaTime;
            float x = playerTransform.position.x + Mathf.Cos(orbitAngle) * orbitRadius;
            float y = playerTransform.position.y + Mathf.Sin(orbitAngle) * orbitRadius;
            transform.position = Vector3.MoveTowards(transform.position, new Vector3(x, y, transform.position.z), moveSpeed * Time.deltaTime);

            // Face the player
            Vector3 lookDir = playerTransform.position - transform.position;
            float angle = Mathf.Atan2(lookDir.y, lookDir.x) * Mathf.Rad2Deg;
            transform.rotation = Quaternion.Euler(0, 0, angle);
        }

        protected override void MoveEnemy(Vector3 direction)
        {
            // Orbit base class does movement, don't override
        }
    }

    /// <summary>
    /// Striker - accelerates toward the player, slows down at close range.
    /// </summary>
    public class EnemyStriker : EnemyAI
    {
        [Header("Striker")]
        [Tooltip("Acceleration toward player")]
        [SerializeField] private float acceleration = 15f;

        [Tooltip("Maximum speed")]
        [SerializeField] private float maxSpeed = 8f;

        [Tooltip("Distance to slow down at")]
        [SerializeField] private float slowDistance = 1.5f;

        [Tooltip("Slow speed at close range")]
        [SerializeField] private float slowSpeed = 1f;

        private float currentSpeed;

        protected override void Awake()
        {
            base.Awake();
            currentSpeed = moveSpeed;
            if (spriteRenderer != null)
            {
                spriteRenderer.color = new Color(0.3f, 1f, 0.4f);
            }
        }

        protected override void Update()
        {
            if (playerTransform == null) return;

            float dist = Vector3.Distance(transform.position, playerTransform.position);
            float angle = Mathf.Atan2(
                playerTransform.position.y - transform.position.y,
                playerTransform.position.x - transform.position.x
            ) * Mathf.Rad2Deg;

            if (dist > slowDistance)
            {
                // Accelerate toward player
                currentSpeed = Mathf.Min(currentSpeed + acceleration * Time.deltaTime, maxSpeed);
            }
            else
            {
                // Slow down when close
                currentSpeed = Mathf.Max(currentSpeed - acceleration * 2f * Time.deltaTime, slowSpeed);
            }

            Vector3 dir = new Vector3(Mathf.Cos(angle * Mathf.Deg2Rad), Mathf.Sin(angle * Mathf.Deg2Rad), 0);
            transform.position += dir * currentSpeed * Time.deltaTime;
            transform.rotation = Quaternion.Euler(0, 0, angle);
        }

        protected override void MoveEnemy(Vector3 direction) { }
    }

    /// <summary>
    /// Jumper - periodically jumps toward the player with a burst of speed.
    /// </summary>
    public class EnemyJumper : EnemyAI
    {
        [Header("Jumper")]
        [Tooltip("Jump interval")]
        [SerializeField] private float jumpInterval = 1f;

        [Tooltip("Jump speed")]
        [SerializeField] private float jumpSpeed = 10f;

        [Tooltip("Idle speed")]
        [SerializeField] private float idleSpeed = 1f;

        private float jumpTimer;
        private bool isJumping;

        protected override void Awake()
        {
            base.Awake();
            if (spriteRenderer != null)
            {
                spriteRenderer.color = new Color(1f, 0.7f, 0f);
            }
        }

        protected override void Update()
        {
            if (playerTransform == null) return;

            jumpTimer += Time.deltaTime;

            if (isJumping)
            {
                // During jump, move toward player at high speed
                Vector3 direction = (playerTransform.position - transform.position).normalized;
                float angle = Mathf.Atan2(direction.y, direction.x) * Mathf.Rad2Deg;
                transform.position += direction * jumpSpeed * Time.deltaTime;
                transform.rotation = Quaternion.Euler(0, 0, angle);

                if (jumpTimer >= jumpInterval * 0.3f)
                {
                    isJumping = false;
                    jumpTimer = 0f;
                }
            }
            else
            {
                // Idle movement - slowly drift toward player
                Vector3 direction = (playerTransform.position - transform.position).normalized;
                float angle = Mathf.Atan2(direction.y, direction.x) * Mathf.Rad2Deg;
                transform.position += direction * idleSpeed * Time.deltaTime;
                transform.rotation = Quaternion.Euler(0, 0, angle);

                if (jumpTimer >= jumpInterval)
                {
                    isJumping = true;
                    jumpTimer = 0f;
                }
            }
        }

        protected override void MoveEnemy(Vector3 direction) { }
    }
}
