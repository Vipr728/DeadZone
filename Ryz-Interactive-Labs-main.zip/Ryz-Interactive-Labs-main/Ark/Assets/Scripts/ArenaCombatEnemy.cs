﻿using UnityEngine;
using Unity.Cinemachine;

public class ArenaCombatEnemy : MonoBehaviour
{
    [SerializeField] int health = 1;
    [SerializeField, Min(0f)] float screenShakeIntensity = 1f;
    [SerializeField] CinemachineImpulseSource deathShakeSource;

    void Awake()
    {
        if (deathShakeSource == null)
        {
            deathShakeSource = GetComponent<CinemachineImpulseSource>();
            if (deathShakeSource == null)
            {
                deathShakeSource = GetComponentInChildren<CinemachineImpulseSource>(true);
            }
            if (deathShakeSource == null)
            {
                var camera = Camera.main;
                if (camera != null)
                {
                    deathShakeSource = camera.GetComponent<CinemachineImpulseSource>();
                }
            }
        }
    }

    public void TakeDamage(int damage)
    {
        health -= damage;
        if (health <= 0)
        {
            if (deathShakeSource != null)
            {
                deathShakeSource.GenerateImpulse(screenShakeIntensity);
            }
            Destroy(gameObject);
        }
    }
}
