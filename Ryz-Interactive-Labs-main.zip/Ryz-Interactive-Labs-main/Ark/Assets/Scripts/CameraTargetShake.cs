﻿using UnityEngine;

[DisallowMultipleComponent]
public class CameraTargetShake : MonoBehaviour
{
    [SerializeField, Min(0f)] float shakeIntensity = 0.2f;

    public void Shake()
    {
        ScreenShakeService.Shake(shakeIntensity);
    }
}
