﻿using UnityEngine;

[DisallowMultipleComponent]
public class TopDownCameraShake : MonoBehaviour
{
    public void Shake(float intensity)
    {
        ScreenShakeService.Shake(intensity);
    }
}
