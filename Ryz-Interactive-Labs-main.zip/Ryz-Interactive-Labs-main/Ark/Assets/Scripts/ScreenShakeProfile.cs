﻿using UnityEngine;

[CreateAssetMenu(menuName = "Agentic Gamedev/Feedback/Screen Shake Profile")]
public sealed class ScreenShakeProfile : ScriptableObject
{
    [SerializeField, Min(0f)] float intensity = 0.22f;
    [SerializeField, Min(0f)] float duration = 0.12f;
    [SerializeField, Min(0f)] float frequency = 12f;

    [System.Serializable]
    public struct ShakeSetting
    {
        public enum ShakeType
        {
            Default,
            EnemyDefeat,
            PlayerHit,
            Explosion,
        }

        public ShakeType type;
        [SerializeField, Min(0f)] public float intensity;
    }

    [SerializeField] ShakeSetting[] shakeSettings =
    {
        new ShakeSetting { type = ShakeSetting.ShakeType.Default, intensity = 1f },
        new ShakeSetting { type = ShakeSetting.ShakeType.EnemyDefeat, intensity = 1.25f },
        new ShakeSetting { type = ShakeSetting.ShakeType.PlayerHit, intensity = 0.9f },
        new ShakeSetting { type = ShakeSetting.ShakeType.Explosion, intensity = 1.5f },
    };

    public float Duration => duration;
    public float Frequency => frequency;
    public float Intensity => GetIntensity(ShakeSetting.ShakeType.Default);

    public float GetIntensity(ShakeSetting.ShakeType type)
    {
        for (int i = 0; i < shakeSettings.Length; i++)
        {
            if (shakeSettings[i].type == type)
            {
                return intensity * shakeSettings[i].intensity;
            }
        }

        return intensity;
    }
}
