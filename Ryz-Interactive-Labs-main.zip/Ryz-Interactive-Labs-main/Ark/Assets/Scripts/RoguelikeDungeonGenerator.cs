﻿using System;
using System.Collections.Generic;
using UnityEngine;

public sealed class RoguelikeDungeonGenerator : MonoBehaviour
{
    public enum RoomKind
    {
        Start,
        Combat,
        Treasure,
        Shop,
        Exit
    }

    [Serializable]
    public sealed class Room
    {
        public int Index;
        public Vector2Int GridPosition;
        public Vector2 Center;
        public Vector2 Size;
        public RoomKind Kind;
        public int PathDepth;
        public bool IsStart;
        public bool IsExit;
        public readonly List<Vector2Int> Connections = new List<Vector2Int>();

        public bool IsCombatEncounter => Kind == RoomKind.Combat || Kind == RoomKind.Exit;

        public Rect Bounds => new Rect(Center - Size * 0.5f, Size);

        public bool HasConnection(Vector2Int direction)
        {
            for (int i = 0; i < Connections.Count; i++)
            {
                if (Connections[i] == direction)
                {
                    return true;
                }
            }

            return false;
        }
    }

    [Header("Generation")]
    [SerializeField] private bool useRandomSeed = true;
    [SerializeField] private int seed = 1337;
    [SerializeField, Min(4)] private int roomCount = 9;
    [SerializeField, Min(8f)] private float roomSpacing = 18f;
    [SerializeField] private Vector2 minRoomSize = new Vector2(8f, 7f);
    [SerializeField] private Vector2 maxRoomSize = new Vector2(12f, 10f);
    [SerializeField, Range(0.45f, 0.9f)] private float criticalPathRoomRatio = 0.65f;
    [SerializeField, Range(0f, 0.45f)] private float loopConnectionChance = 0.12f;
    [SerializeField, Min(0)] private int treasureRoomCount = 1;
    [SerializeField, Min(0)] private int shopRoomCount = 1;
    [SerializeField, Min(1.5f)] private float corridorWidth = 2.8f;
    [SerializeField, Min(1.5f)] private float doorWidth = 3.2f;
    [SerializeField, Min(0.1f)] private float wallThickness = 0.45f;

    [Header("Visuals")]
    [SerializeField] private Color floorColor = new Color(0.11f, 0.11f, 0.13f, 1f);
    [SerializeField] private Color startFloorColor = new Color(0.12f, 0.17f, 0.13f, 1f);
    [SerializeField] private Color exitFloorColor = new Color(0.18f, 0.13f, 0.2f, 1f);
    [SerializeField] private Color treasureFloorColor = new Color(0.18f, 0.15f, 0.08f, 1f);
    [SerializeField] private Color shopFloorColor = new Color(0.08f, 0.15f, 0.18f, 1f);
    [SerializeField] private Color corridorColor = new Color(0.08f, 0.08f, 0.1f, 1f);
    [SerializeField] private Color wallColor = new Color(0.32f, 0.34f, 0.42f, 1f);
    [SerializeField] private Color doorThresholdColor = new Color(0.42f, 0.38f, 0.26f, 1f);
    [SerializeField] private Color unclearedRoomTint = new Color(0.16f, 0.12f, 0.12f, 1f);
    [SerializeField] private Color clearedRoomTint = new Color(0.11f, 0.14f, 0.16f, 1f);

    private static Sprite sharedSquareSprite;
    private readonly List<Room> rooms = new List<Room>();
    private readonly Dictionary<int, SpriteRenderer> floorRenderers = new Dictionary<int, SpriteRenderer>();
    private readonly List<Room> criticalPath = new List<Room>();
    private Transform generatedRoot;
    private System.Random random;

    public IReadOnlyList<Room> Rooms => rooms;
    public Room StartRoom { get; private set; }
    public Room ExitRoom { get; private set; }
    public int CurrentSeed { get; private set; }

    public void ConfigureForFloor(int floorNumber, int requestedRoomCount)
    {
        roomCount = Mathf.Max(4, requestedRoomCount);
        seed = unchecked((useRandomSeed ? Environment.TickCount : seed) + floorNumber * 9973);
    }

    public void Generate()
    {
        ClearGeneratedDungeon();
        CurrentSeed = useRandomSeed ? Environment.TickCount : seed;
        random = new System.Random(CurrentSeed);
        generatedRoot = new GameObject("Generated Roguelike Dungeon").transform;
        generatedRoot.SetParent(transform, false);

        BuildRoomGraph();
        BuildCorridors();
        BuildRooms();
    }

    public Vector2 GetPlayerStartPosition()
    {
        return StartRoom != null ? StartRoom.Center : Vector2.zero;
    }

    public Vector2 GetRandomSpawnPosition(int roomIndex, float inset)
    {
        Room room = GetRoom(roomIndex);
        if (room == null)
        {
            return Vector2.zero;
        }

        Rect bounds = room.Bounds;
        float safeInset = Mathf.Max(1f, inset);
        float x = Mathf.Lerp(bounds.xMin + safeInset, bounds.xMax - safeInset, (float)random.NextDouble());
        float y = Mathf.Lerp(bounds.yMin + safeInset, bounds.yMax - safeInset, (float)random.NextDouble());
        return new Vector2(x, y);
    }

    public Room GetRoom(int roomIndex)
    {
        for (int i = 0; i < rooms.Count; i++)
        {
            if (rooms[i].Index == roomIndex)
            {
                return rooms[i];
            }
        }

        return null;
    }

    public void SetRoomCleared(int roomIndex, bool cleared)
    {
        if (!floorRenderers.TryGetValue(roomIndex, out SpriteRenderer renderer) || renderer == null)
        {
            return;
        }

        Room room = GetRoom(roomIndex);
        if (room != null)
        {
            renderer.color = GetRoomFloorColor(room, cleared);
            return;
        }

        renderer.color = cleared ? clearedRoomTint : unclearedRoomTint;
    }

    private Color GetRoomFloorColor(Room room, bool cleared)
    {
        if (room == null)
        {
            return floorColor;
        }

        switch (room.Kind)
        {
            case RoomKind.Start:
                return startFloorColor;
            case RoomKind.Exit:
                return cleared ? exitFloorColor : unclearedRoomTint;
            case RoomKind.Treasure:
                return treasureFloorColor;
            case RoomKind.Shop:
                return shopFloorColor;
            default:
                return cleared ? clearedRoomTint : unclearedRoomTint;
        }
    }

    private void BuildRoomGraph()
    {
        rooms.Clear();
        floorRenderers.Clear();
        criticalPath.Clear();
        Dictionary<Vector2Int, Room> byGrid = new Dictionary<Vector2Int, Room>();
        Room start = AddRoom(Vector2Int.zero, byGrid);
        start.Kind = RoomKind.Start;
        start.IsStart = true;
        start.PathDepth = 0;
        start.Size = ResolveRoomSize(start.Kind);
        criticalPath.Add(start);

        int targetMainPathRooms = Mathf.Clamp(
            Mathf.RoundToInt(roomCount * criticalPathRoomRatio),
            4,
            roomCount);
        BuildCriticalPath(byGrid, targetMainPathRooms);
        BuildBranches(byGrid);
        AssignSpecialRooms();
        AddLoopConnections(byGrid);

        StartRoom = start;
        ExitRoom = criticalPath.Count > 0 ? criticalPath[criticalPath.Count - 1] : FindFarthestRoomFromStart();
        if (ExitRoom != null)
        {
            ExitRoom.Kind = RoomKind.Exit;
            ExitRoom.IsExit = true;
            ExitRoom.Size = ResolveRoomSize(ExitRoom.Kind);
        }
    }

    private void BuildCriticalPath(Dictionary<Vector2Int, Room> byGrid, int targetMainPathRooms)
    {
        Room current = StartRoom ?? rooms[0];
        Vector2Int previousDirection = Vector2Int.zero;
        int guard = 0;
        while (criticalPath.Count < targetMainPathRooms && guard++ < roomCount * 80)
        {
            Vector2Int direction = ChooseOpenDirection(current.GridPosition, byGrid, previousDirection);
            if (direction == Vector2Int.zero)
            {
                Room fallback = FindRoomWithOpenNeighbor(byGrid);
                if (fallback == null)
                {
                    break;
                }

                current = fallback;
                previousDirection = Vector2Int.zero;
                continue;
            }

            Vector2Int nextPosition = current.GridPosition + direction;
            Room next = AddRoom(nextPosition, byGrid);
            next.PathDepth = criticalPath.Count;
            ConnectRooms(current, next, direction);
            criticalPath.Add(next);
            current = next;
            previousDirection = direction;
        }
    }

    private void BuildBranches(Dictionary<Vector2Int, Room> byGrid)
    {
        int guard = 0;
        while (rooms.Count < roomCount && guard++ < roomCount * 100)
        {
            Room anchor = PickBranchAnchor();
            if (anchor == null)
            {
                break;
            }

            Vector2Int direction = ChooseOpenDirection(anchor.GridPosition, byGrid, Vector2Int.zero);
            if (direction == Vector2Int.zero)
            {
                continue;
            }

            Room branch = AddRoom(anchor.GridPosition + direction, byGrid);
            branch.PathDepth = anchor.PathDepth + 1;
            ConnectRooms(anchor, branch, direction);
        }
    }

    private Room PickBranchAnchor()
    {
        List<Room> candidates = new List<Room>();
        for (int i = 0; i < rooms.Count; i++)
        {
            if (rooms[i] == null || rooms[i].IsExit)
            {
                continue;
            }

            candidates.Add(rooms[i]);
        }

        return candidates.Count == 0 ? null : candidates[random.Next(candidates.Count)];
    }

    private void AddLoopConnections(Dictionary<Vector2Int, Room> byGrid)
    {
        Vector2Int[] directions = GetCardinalDirections();
        for (int i = 0; i < rooms.Count; i++)
        {
            Room room = rooms[i];
            for (int d = 0; d < directions.Length; d++)
            {
                Vector2Int direction = directions[d];
                if (room.HasConnection(direction))
                {
                    continue;
                }

                if (!byGrid.TryGetValue(room.GridPosition + direction, out Room neighbor))
                {
                    continue;
                }

                if ((float)random.NextDouble() > loopConnectionChance)
                {
                    continue;
                }

                ConnectRooms(room, neighbor, direction);
            }
        }
    }

    private void AssignSpecialRooms()
    {
        List<Room> deadEnds = new List<Room>();
        List<Room> branchRooms = new List<Room>();
        for (int i = 0; i < rooms.Count; i++)
        {
            Room room = rooms[i];
            if (room == null || room.IsStart || room.IsExit || criticalPath.Contains(room))
            {
                continue;
            }

            branchRooms.Add(room);
            if (room.Connections.Count <= 1)
            {
                deadEnds.Add(room);
            }
        }

        AssignRoomKind(deadEnds, branchRooms, RoomKind.Treasure, treasureRoomCount);
        AssignRoomKind(deadEnds, branchRooms, RoomKind.Shop, shopRoomCount);
    }

    private void AssignRoomKind(List<Room> preferredCandidates, List<Room> fallbackCandidates, RoomKind kind, int count)
    {
        for (int i = 0; i < count; i++)
        {
            List<Room> candidates = preferredCandidates.Count > 0 ? preferredCandidates : fallbackCandidates;
            if (candidates.Count == 0)
            {
                return;
            }

            int index = random.Next(candidates.Count);
            Room room = candidates[index];
            candidates.RemoveAt(index);
            fallbackCandidates.Remove(room);
            preferredCandidates.Remove(room);
            if (room.Kind != RoomKind.Combat)
            {
                i--;
                continue;
            }

            room.Kind = kind;
            room.Size = ResolveRoomSize(kind);
        }
    }

    private Room AddRoom(Vector2Int gridPosition, Dictionary<Vector2Int, Room> byGrid)
    {
        RoomKind kind = RoomKind.Combat;

        Room room = new Room
        {
            Index = rooms.Count,
            GridPosition = gridPosition,
            Center = new Vector2(gridPosition.x * roomSpacing, gridPosition.y * roomSpacing),
            Size = ResolveRoomSize(kind),
            Kind = kind
        };

        rooms.Add(room);
        byGrid.Add(gridPosition, room);
        return room;
    }

    private static void ConnectRooms(Room from, Room to, Vector2Int direction)
    {
        if (!from.Connections.Contains(direction))
        {
            from.Connections.Add(direction);
        }

        Vector2Int opposite = -direction;
        if (!to.Connections.Contains(opposite))
        {
            to.Connections.Add(opposite);
        }
    }

    private Vector2 ResolveRoomSize(RoomKind kind)
    {
        Vector2 min = minRoomSize;
        Vector2 max = maxRoomSize;
        switch (kind)
        {
            case RoomKind.Start:
                min *= 0.9f;
                max *= 1.05f;
                break;
            case RoomKind.Exit:
                min *= 1.25f;
                max *= 1.45f;
                break;
            case RoomKind.Treasure:
            case RoomKind.Shop:
                min *= 0.85f;
                max *= 0.95f;
                break;
        }

        return new Vector2(
            Mathf.Lerp(min.x, max.x, (float)random.NextDouble()),
            Mathf.Lerp(min.y, max.y, (float)random.NextDouble()));
    }

    private Vector2Int ChooseOpenDirection(Vector2Int origin, Dictionary<Vector2Int, Room> byGrid, Vector2Int discouragedDirection)
    {
        List<Vector2Int> choices = new List<Vector2Int>(GetCardinalDirections());
        Shuffle(choices);
        for (int i = choices.Count - 1; i >= 0; i--)
        {
            if (byGrid.ContainsKey(origin + choices[i]))
            {
                choices.RemoveAt(i);
            }
        }

        if (choices.Count == 0)
        {
            return Vector2Int.zero;
        }

        if (choices.Count > 1 && discouragedDirection != Vector2Int.zero)
        {
            choices.Remove(discouragedDirection);
        }

        return choices.Count == 0 ? Vector2Int.zero : choices[0];
    }

    private Room FindRoomWithOpenNeighbor(Dictionary<Vector2Int, Room> byGrid)
    {
        List<Room> candidates = new List<Room>();
        Vector2Int[] directions = GetCardinalDirections();
        for (int i = 0; i < rooms.Count; i++)
        {
            for (int d = 0; d < directions.Length; d++)
            {
                if (!byGrid.ContainsKey(rooms[i].GridPosition + directions[d]))
                {
                    candidates.Add(rooms[i]);
                    break;
                }
            }
        }

        return candidates.Count == 0 ? null : candidates[random.Next(candidates.Count)];
    }

    private void Shuffle(List<Vector2Int> values)
    {
        for (int i = values.Count - 1; i > 0; i--)
        {
            int swapIndex = random.Next(i + 1);
            Vector2Int temp = values[i];
            values[i] = values[swapIndex];
            values[swapIndex] = temp;
        }
    }

    private static Vector2Int[] GetCardinalDirections()
    {
        return new[]
        {
            Vector2Int.up,
            Vector2Int.right,
            Vector2Int.down,
            Vector2Int.left
        };
    }

    private Room FindFarthestRoomFromStart()
    {
        Room farthest = null;
        int bestDistance = -1;
        for (int i = 0; i < rooms.Count; i++)
        {
            int distance = Mathf.Abs(rooms[i].GridPosition.x) + Mathf.Abs(rooms[i].GridPosition.y);
            if (distance > bestDistance)
            {
                bestDistance = distance;
                farthest = rooms[i];
            }
        }

        return farthest;
    }

    private void BuildRooms()
    {
        for (int i = 0; i < rooms.Count; i++)
        {
            Room room = rooms[i];
            Transform roomRoot = new GameObject($"Room_{room.Index:00}_{room.Kind}_{room.GridPosition.x}_{room.GridPosition.y}").transform;
            roomRoot.SetParent(generatedRoot, false);

            Color roomColor = GetRoomFloorColor(room, cleared: false);
            SpriteRenderer floor = AddSpriteRect("Floor", roomRoot, room.Center, room.Size, roomColor, 0);
            floorRenderers[room.Index] = floor;

            AddRoomWalls(room, roomRoot);
            AddRoomTrigger(room, roomRoot);
        }
    }

    private void BuildCorridors()
    {
        HashSet<string> built = new HashSet<string>();
        for (int i = 0; i < rooms.Count; i++)
        {
            Room from = rooms[i];
            for (int c = 0; c < from.Connections.Count; c++)
            {
                Vector2Int direction = from.Connections[c];
                Room to = FindRoomAt(from.GridPosition + direction);
                if (to == null)
                {
                    continue;
                }

                string key = from.Index < to.Index ? from.Index + "-" + to.Index : to.Index + "-" + from.Index;
                if (!built.Add(key))
                {
                    continue;
                }

                AddCorridor(from, to, direction);
            }
        }
    }

    private Room FindRoomAt(Vector2Int gridPosition)
    {
        for (int i = 0; i < rooms.Count; i++)
        {
            if (rooms[i].GridPosition == gridPosition)
            {
                return rooms[i];
            }
        }

        return null;
    }

    private void AddCorridor(Room from, Room to, Vector2Int direction)
    {
        Transform corridorRoot = new GameObject($"Corridor_{from.Index:00}_{to.Index:00}").transform;
        corridorRoot.SetParent(generatedRoot, false);

        Rect a = from.Bounds;
        Rect b = to.Bounds;
        if (direction == Vector2Int.right || direction == Vector2Int.left)
        {
            float xMin = Mathf.Min(a.xMax, b.xMax);
            float xMax = Mathf.Max(a.xMin, b.xMin);
            float width = Mathf.Max(0.1f, xMax - xMin);
            Vector2 center = new Vector2((xMin + xMax) * 0.5f, from.Center.y);
            AddSpriteRect("CorridorFloor", corridorRoot, center, new Vector2(width + wallThickness, corridorWidth), corridorColor, 0);
            AddWall("NorthWall", corridorRoot, center + Vector2.up * (corridorWidth * 0.5f), new Vector2(width, wallThickness));
            AddWall("SouthWall", corridorRoot, center + Vector2.down * (corridorWidth * 0.5f), new Vector2(width, wallThickness));
            AddDoorThresholds(corridorRoot, from, to, direction);
        }
        else
        {
            float yMin = Mathf.Min(a.yMax, b.yMax);
            float yMax = Mathf.Max(a.yMin, b.yMin);
            float height = Mathf.Max(0.1f, yMax - yMin);
            Vector2 center = new Vector2(from.Center.x, (yMin + yMax) * 0.5f);
            AddSpriteRect("CorridorFloor", corridorRoot, center, new Vector2(corridorWidth, height + wallThickness), corridorColor, 0);
            AddWall("EastWall", corridorRoot, center + Vector2.right * (corridorWidth * 0.5f), new Vector2(wallThickness, height));
            AddWall("WestWall", corridorRoot, center + Vector2.left * (corridorWidth * 0.5f), new Vector2(wallThickness, height));
            AddDoorThresholds(corridorRoot, from, to, direction);
        }
    }

    private void AddDoorThresholds(Transform parent, Room from, Room to, Vector2Int direction)
    {
        Vector2 doorSize = direction.x != 0
            ? new Vector2(wallThickness * 1.4f, doorWidth)
            : new Vector2(doorWidth, wallThickness * 1.4f);
        Vector2 fromPosition = GetDoorPosition(from, direction);
        Vector2 toPosition = GetDoorPosition(to, -direction);
        AddSpriteRect("DoorThreshold_A", parent, fromPosition, doorSize, doorThresholdColor, 1);
        AddSpriteRect("DoorThreshold_B", parent, toPosition, doorSize, doorThresholdColor, 1);
    }

    private Vector2 GetDoorPosition(Room room, Vector2Int direction)
    {
        Rect bounds = room.Bounds;
        if (direction == Vector2Int.right)
        {
            return new Vector2(bounds.xMax, room.Center.y);
        }

        if (direction == Vector2Int.left)
        {
            return new Vector2(bounds.xMin, room.Center.y);
        }

        if (direction == Vector2Int.up)
        {
            return new Vector2(room.Center.x, bounds.yMax);
        }

        return new Vector2(room.Center.x, bounds.yMin);
    }

    private void AddRoomWalls(Room room, Transform parent)
    {
        Rect bounds = room.Bounds;
        AddHorizontalWallWithDoor(parent, "NorthWall", bounds.yMax, bounds.xMin, bounds.xMax, room.Center.x, room.HasConnection(Vector2Int.up));
        AddHorizontalWallWithDoor(parent, "SouthWall", bounds.yMin, bounds.xMin, bounds.xMax, room.Center.x, room.HasConnection(Vector2Int.down));
        AddVerticalWallWithDoor(parent, "EastWall", bounds.xMax, bounds.yMin, bounds.yMax, room.Center.y, room.HasConnection(Vector2Int.right));
        AddVerticalWallWithDoor(parent, "WestWall", bounds.xMin, bounds.yMin, bounds.yMax, room.Center.y, room.HasConnection(Vector2Int.left));
    }

    private void AddHorizontalWallWithDoor(Transform parent, string name, float y, float xMin, float xMax, float doorX, bool hasDoor)
    {
        if (!hasDoor)
        {
            AddWall(name, parent, new Vector2((xMin + xMax) * 0.5f, y), new Vector2(xMax - xMin, wallThickness));
            return;
        }

        float leftEnd = doorX - doorWidth * 0.5f;
        float rightStart = doorX + doorWidth * 0.5f;
        AddWallSegment(name + "_Left", parent, xMin, leftEnd, y, true);
        AddWallSegment(name + "_Right", parent, rightStart, xMax, y, true);
    }

    private void AddVerticalWallWithDoor(Transform parent, string name, float x, float yMin, float yMax, float doorY, bool hasDoor)
    {
        if (!hasDoor)
        {
            AddWall(name, parent, new Vector2(x, (yMin + yMax) * 0.5f), new Vector2(wallThickness, yMax - yMin));
            return;
        }

        float lowerEnd = doorY - doorWidth * 0.5f;
        float upperStart = doorY + doorWidth * 0.5f;
        AddWallSegment(name + "_Lower", parent, yMin, lowerEnd, x, false);
        AddWallSegment(name + "_Upper", parent, upperStart, yMax, x, false);
    }

    private void AddWallSegment(string name, Transform parent, float min, float max, float fixedPosition, bool horizontal)
    {
        float length = max - min;
        if (length <= wallThickness)
        {
            return;
        }

        Vector2 center = horizontal
            ? new Vector2((min + max) * 0.5f, fixedPosition)
            : new Vector2(fixedPosition, (min + max) * 0.5f);
        Vector2 size = horizontal
            ? new Vector2(length, wallThickness)
            : new Vector2(wallThickness, length);
        AddWall(name, parent, center, size);
    }

    private void AddRoomTrigger(Room room, Transform parent)
    {
        GameObject triggerObject = new GameObject("RoomTrigger");
        triggerObject.transform.SetParent(parent, false);
        triggerObject.transform.position = room.Center;
        BoxCollider2D trigger = triggerObject.AddComponent<BoxCollider2D>();
        trigger.isTrigger = true;
        trigger.size = new Vector2(Mathf.Max(1f, room.Size.x - 1.5f), Mathf.Max(1f, room.Size.y - 1.5f));
        RoguelikeRoomTrigger roomTrigger = triggerObject.AddComponent<RoguelikeRoomTrigger>();
        roomTrigger.RoomIndex = room.Index;
    }

    private void AddWall(string name, Transform parent, Vector2 center, Vector2 size)
    {
        SpriteRenderer renderer = AddSpriteRect(name, parent, center, size, wallColor, 2);
        BoxCollider2D collider = renderer.gameObject.AddComponent<BoxCollider2D>();
        collider.size = Vector2.one;
    }

    private SpriteRenderer AddSpriteRect(string name, Transform parent, Vector2 center, Vector2 size, Color color, int sortingOrder)
    {
        GameObject rect = new GameObject(name);
        rect.transform.SetParent(parent, false);
        rect.transform.position = new Vector3(center.x, center.y, 0f);
        rect.transform.localScale = new Vector3(size.x, size.y, 1f);
        SpriteRenderer renderer = rect.AddComponent<SpriteRenderer>();
        renderer.sprite = GetSharedSquareSprite();
        renderer.color = color;
        renderer.sortingOrder = sortingOrder;
        return renderer;
    }

    private static Sprite GetSharedSquareSprite()
    {
        if (sharedSquareSprite != null)
        {
            return sharedSquareSprite;
        }

        Texture2D texture = new Texture2D(1, 1, TextureFormat.RGBA32, false);
        texture.SetPixel(0, 0, Color.white);
        texture.Apply();
        texture.hideFlags = HideFlags.HideAndDontSave;
        sharedSquareSprite = Sprite.Create(texture, new Rect(0, 0, 1, 1), new Vector2(0.5f, 0.5f), 1f);
        sharedSquareSprite.hideFlags = HideFlags.HideAndDontSave;
        return sharedSquareSprite;
    }

    private void ClearGeneratedDungeon()
    {
        Transform existing = transform.Find("Generated Roguelike Dungeon");
        if (existing != null)
        {
            if (Application.isPlaying)
            {
                Destroy(existing.gameObject);
            }
            else
            {
                DestroyImmediate(existing.gameObject);
            }
        }

        rooms.Clear();
        floorRenderers.Clear();
        StartRoom = null;
        ExitRoom = null;
    }
}
