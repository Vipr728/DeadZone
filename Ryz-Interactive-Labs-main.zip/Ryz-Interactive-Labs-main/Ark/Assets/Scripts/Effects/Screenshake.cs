using UnityEngine;

namespace Ark.Effects
{
    /// <summary>
    /// Attach to the Camera to handle screenshake effects.
    /// </summary>
    public class Screenshake : MonoBehaviour
    {
        [Tooltip("Amplitude of shake per intensity unit")]
        [SerializeField] private float shakeAmplitude = 0.08f;

        [Tooltip("Decay rate of shake")]
        [SerializeField] private float decayRate = 8f;

        [Tooltip("Minimum shake intensity to continue shaking")]
        [SerializeField] private float minIntensity = 0.01f;

        [Tooltip("Random seed offset for varied shake")]
        [SerializeField] private int seedOffset = 0;

        private float currentIntensity = 0f;
        private float currentDecay = 0f;
        private Vector3 originalPosition;
        private float timer;

        public void TriggerShake(float intensity, float duration)
        {
            if (!GetComponent<Camera>())
            {
                Camera mainCam = Camera.main;
                if (mainCam != null && mainCam.gameObject == gameObject)
                {
                    // Camera is this object
                }
                else if (mainCam != null)
                {
                    return; // Shake component not on main camera
                }
            }
            currentIntensity = intensity;
            timer = duration;
        }

        private void OnEnable()
        {
            if (GetComponent<Camera>())
            {
                originalPosition = transform.position;
            }
        }

        private void Update()
        {
            if (currentIntensity > minIntensity && timer > 0f)
            {
                float shakeX = Random.value * 2f - 1f;
                float shakeY = Random.value * 2f - 1f;
                transform.position = new Vector3(
                    originalPosition.x + shakeX * currentIntensity * shakeAmplitude,
                    originalPosition.y + shakeY * currentIntensity * shakeAmplitude,
                    originalPosition.z
                );

                currentIntensity *= (1f - decayRate * Time.deltaTime);
                timer -= Time.deltaTime;
            }
            else
            {
                if (currentIntensity > minIntensity)
                {
                    currentIntensity = 0f;
                }
                transform.position = originalPosition;
            }
        }
    }
}
