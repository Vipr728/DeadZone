using System;
using UnityEngine;

namespace Ark.Effects
{
    /// <summary>
    /// Impact effect - spawns a short-lived burst sprite at a hit position.
    /// </summary>
    [RequireComponent(typeof(SpriteRenderer))]
    public class ImpactEffect : MonoBehaviour
    {
        [Tooltip("Lifetime in seconds")]
        [SerializeField] private float lifetime = 0.3f;

        [Tooltip("Base radius of the impact burst")]
        [SerializeField] private float radius = 0.25f;

        [Tooltip("Color of the impact")]
        [SerializeField] private Color color = new Color(1f, 0.3f, 0.1f, 0.7f);

        private SpriteRenderer sr;
        private float elapsed;

        private void Awake()
        {
            sr = GetComponent<SpriteRenderer>();
            sr.sprite = CreateCircleSprite(radius, color);
            sr.sortingOrder = 5;
        }

        private void Update()
        {
            elapsed += Time.deltaTime;
            float t = elapsed / lifetime;
            if (t >= 1f)
            {
                Destroy(gameObject);
                return;
            }
            sr.color = new Color(color.r, color.g, color.b, color.a * (1f - t));
            sr.transform.localScale = Vector3.one * (1f + t * 2f);
        }

        private static Sprite CreateCircleSprite(float radius, Color color)
        {
            int size = Mathf.CeilToInt(radius * 2) * 2 + 1;
            Texture2D tex = new Texture2D(size, size);
            for (int y = 0; y < size; y++)
            {
                for (int x = 0; x < size; x++)
                {
                    float dx = (x - size / 2f) / radius;
                    float dy = (y - size / 2f) / radius;
                    float dist = Mathf.Sqrt(dx * dx + dy * dy);
                    if (dist <= 1f)
                    {
                        float alpha = 1f - dist * dist;
                        tex.SetPixel(x, y, new Color(color.r, color.g, color.b, color.a * alpha));
                    }
                    else
                    {
                        tex.SetPixel(x, y, Color.clear);
                    }
                }
            }
            tex.Apply();
            Sprite sprite = Sprite.Create(tex, new Rect(0, 0, size, size), new Vector2(0.5f, 0.5f), 1f);
            return sprite;
        }
    }
}
