using UnityEngine;

namespace Ark.GameManager
{
    /// <summary>
    /// Simple game timer displayed in the HUD.
    /// </summary>
    public class Timer : MonoBehaviour
    {
        [Tooltip("Timer in seconds")]
        [HideInInspector] public float elapsedSeconds = 0f;

        [Tooltip("Whether the timer is running")]
        [HideInInspector] public bool isRunning = true;

        public void StartTimer()
        {
            isRunning = true;
        }

        public void PauseTimer()
        {
            isRunning = false;
        }

        public void ResetTimer()
        {
            elapsedSeconds = 0f;
        }

        private void Update()
        {
            if (isRunning)
            {
                elapsedSeconds += Time.deltaTime;
            }
        }

        public string GetTimeString()
        {
            int minutes = (int)elapsedSeconds / 60;
            int seconds = (int)elapsedSeconds % 60;
            return $"{minutes:00}:{seconds:00}";
        }
    }
}
