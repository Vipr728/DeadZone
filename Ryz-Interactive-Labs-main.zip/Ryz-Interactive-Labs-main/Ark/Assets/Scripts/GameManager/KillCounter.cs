using UnityEngine;

namespace Ark.GameManager
{
    /// <summary>
    /// UI component that displays and manages the kill counter.
    /// </summary>
    public class KillCounter : MonoBehaviour
    {
        [Tooltip("Current kill score")]
        [HideInInspector] public int killScore = 0;

        private void Awake()
        {
            // Ensure it has a Text or display component for the HUD
            GetComponent<UnityEngine.UI.Text>();
        }

        public void AddKill(int points)
        {
            killScore += points;
        }

        public void SetKillScore(int score)
        {
            killScore = score;
        }

        public int GetKillScore() => killScore;

        public void ResetScore() => killScore = 0;
    }
}
