﻿# PROJECT_STATE

## Purpose
- This file is the current project map for Ark runs.
- Use it before broad `search_project` sweeps when the task is about existing gameplay code, scene contracts, camera shake, spawning, or simple bugfixes.
- Treat live Unity state, compiler diagnostics, and direct file reads as authoritative if they disagree with this summary.

## Project Snapshot
- Unity version: `6000.3.6f1`
- Render pipeline: `URP`
- Input path: new Input System is supported in player code with legacy fallback guards
- Current prototype: simple top-down arena combat

## Gameplay Loop
- The player moves in a top-down arena and fires bullets.
- The game manager spawns enemy prefabs from scene transforms whose names start with `EnemySpawn_`.
- Enemies are intended to take bullet damage and die when health reaches zero.
- Bullet impacts spawn short-lived Unity ParticleSystem prefab instances.
- Player health is tracked separately and can trigger game over through the game manager.
- Camera feedback uses a Cinemachine impulse source via `ScreenShakeService`.

## Scene Contracts
- Main camera should exist and be tagged `MainCamera`.
- Camera shake currently expects a `Unity.Cinemachine.CinemachineImpulseSource` that can be resolved at runtime.
- Enemy spawns are discovered by name prefix, not by a serialized array of spawn transforms.
- Bullet spawning expects a `PlayerBullet` prefab or resource fallback.

## Script Map

## `Assets/Scripts/ArenaCombatGameManager.cs`
- Central runtime manager for the arena loop.
- Owns spawn pacing, max enemy count to win, spawn prefix lookup, and game-over state.
- Finds spawn points by scanning scene transforms for names beginning with `enemySpawnPrefix`.
- Spawns from `enemyPrefabs`.
- `Lose()` stops the spawn coroutine and marks the session game over.

## `Assets/Scripts/ArenaCombatEnemy.cs`
- Enemy health/damage script.
- Holds `maxHealth`, `hitShakeIntensity`, and `hitShakeDuration`.
- Initializes `currentHealth` in `Awake()`.
- Current public damage entry point is `TakeDamage(int damage)`.
- On hit, it calls `ScreenShakeService.Shake(...)` and destroys itself at zero health.

## `Assets/Scripts/TopDownBullet.cs`
- Projectile hit script.
- Uses `OnTriggerEnter2D(Collider2D other)`.
- Looks for `ArenaCombatEnemy` on the collider and applies `TakeDamage(damage)` when present.
- Destroys the bullet on any trigger contact after the impact hook has had a chance to run.

## `Assets/Scripts/BulletImpactParticles.cs`
- Bullet-attached impact VFX spawner.
- Uses `OnTriggerEnter2D(Collider2D other)` before `TopDownBullet` destroys the projectile.
- Instantiates the assigned impact prefab at the collision closest point.
- Does not create ParticleSystem GameObjects procedurally during gameplay.
- Current prefab reference should point to `Assets/Prefabs/BulletImpactParticles.prefab`.

## `Assets/Prefabs/BulletImpactParticles.prefab`
- Short-lived bullet-impact VFX prefab.
- Contains a Unity `ParticleSystem` configured as a non-looping burst.
- Uses `ParticleSystemStopAction.Destroy`; the bullet spawner also destroys the instance after the computed animation length plus padding.
- Particle renderer uses a circular alpha texture/material so individual impact particles render as round dots rather than the default particle shape.
- Circular texture asset: `Assets/Art/VFX/ImpactParticleCircle.png`.
- Circular material asset: `Assets/Art/VFX/ImpactParticleCircle.mat`.

## `Assets/Scripts/ScreenShakeService.cs`
- Static runtime helper for camera shake.
- Uses `Unity.Cinemachine.CinemachineImpulseSource`.
- Public API currently exposes `Shake(float intensity)` and `Shake(float intensity, float duration)`.
- Current lookup only checks cached source and `Camera.main.TryGetComponent(...)`.
- It does not currently fall back to `FindFirstObjectByType<CinemachineImpulseSource>()`.
- If a spawned enemy cannot find the shake source, this file is the first place to patch.

## `Assets/Scripts/ScreenShakeProfile.cs`
- ScriptableObject configuration for shake intensity tuning.
- Defines base intensity, duration, frequency, and per-shake-type multipliers.
- Current runtime `ScreenShakeService` does not appear to consume this profile directly.

## `Assets/Scripts/TopDownCameraShake.cs`
- Thin wrapper around `ScreenShakeService.Shake(float intensity)`.

## `Assets/Scripts/CameraTargetShake.cs`
- Thin wrapper component with serialized `shakeIntensity`.
- Calls `ScreenShakeService.Shake(shakeIntensity)`.

## `Assets/Scripts/ArenaCombatPlayerHealth.cs`
- Player damage/health component.
- Tracks `maxHealth`, cooldown between contact hits, and current health.
- Broadcasts `onHealthChanged`.
- Calls `ArenaCombatGameManager.Instance.Lose()` when health reaches zero.

## `Assets/Scripts/TopDownPlayerController.cs`
- Main player controller.
- Uses `Rigidbody2D`.
- Handles movement, aim, shooting cadence, bullet prefab resolution, recoil, and muzzle pulse.
- Uses Input System when enabled and a legacy-style fallback block otherwise.
- Resolves the bullet prefab through `Resources.Load` and then loaded project prefabs.

## `Assets/Scripts/TopDownCameraFollow.cs`
- Simple follow camera behavior using `LateUpdate()`.
- Follows a target transform with smoothing and z-offset.

## `Assets/Scripts/TopDownPlayerLightController.cs`
- Optional utility that instantiates a light/glow prefab on start.

## `Assets/Scripts/TopDownShooterSetup.cs`
- Editor/runtime scene bootstrap helper.
- Ensures basic arena objects, player, walls, dummy target, light, and camera exist.
- Creates procedural square and circle sprites in code.
- Sets up `TopDownCameraFollow` on the main camera.

## Known Issues
- `ScreenShakeService` currently ignores the `duration` parameter.
- `ScreenShakeService` only checks `Camera.main` for the impulse source, so spawned enemies cannot use shake if the impulse source lives elsewhere in the scene hierarchy.
- `ScreenShakeProfile` exists, but the current shake service does not appear to use it in the active code path.

## Minimal-Fix Guidance
- For "spawned enemies cannot find screen shake," prefer patching `ScreenShakeService` lookup first.
- Preserve existing public APIs where possible. If fixing the current compile issue, either restore `ReceiveDamage` on the enemy or change the bullet call site to `TakeDamage`, but do not rename both sides repeatedly.
- For compiler repair, read the exact caller/callee pair before changing method names.
- For shake lookup bugs, prefer a narrow fallback such as `FindFirstObjectByType<CinemachineImpulseSource>()` before redesigning the camera-shake system.
- For particles, impulse particles, muzzle flashes, impact bursts, ambient particles, and similar VFX, always use Unity `ParticleSystem` unless the user explicitly specifies otherwise.
- Short-lived VFX must be prefab GameObjects instantiated at the use-site and destroyed after the particle animation. Long-lived scene VFX should be separate scene GameObjects, not components hidden on unrelated gameplay objects.
- Bullet impact particles should keep using `Assets/Art/VFX/ImpactParticleCircle.png` and `Assets/Art/VFX/ImpactParticleCircle.mat` for round particle sprites.

## First Files To Read For Common Requests
- Enemy damage or bullet hit bugs:
  `Assets/Scripts/ArenaCombatEnemy.cs`
  `Assets/Scripts/TopDownBullet.cs`
  `Assets/Scripts/BulletImpactParticles.cs`
- Screen shake not firing:
  `Assets/Scripts/ScreenShakeService.cs`
  `Assets/Scripts/TopDownCameraShake.cs`
  `Assets/Scripts/CameraTargetShake.cs`
- Spawn behavior or missing spawned enemies:
  `Assets/Scripts/ArenaCombatGameManager.cs`
- Player shooting or movement:
  `Assets/Scripts/TopDownPlayerController.cs`
