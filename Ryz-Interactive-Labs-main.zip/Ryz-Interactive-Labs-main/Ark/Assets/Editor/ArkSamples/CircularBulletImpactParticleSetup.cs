﻿using System.IO;
using UnityEditor;
using UnityEngine;

public static class CircularBulletImpactParticleSetup
{
    private const string TexturePath = "Assets/Art/VFX/ImpactParticleCircle.png";
    private const string MaterialPath = "Assets/Art/VFX/ImpactParticleCircle.mat";
    private const string PrefabPath = "Assets/Prefabs/BulletImpactParticles.prefab";

    public static void ApplyCircularParticles()
    {
        EnsureFolders();
        Texture2D circleTexture = CreateCircleTexture(96);
        File.WriteAllBytes(TexturePath, circleTexture.EncodeToPNG());
        Object.DestroyImmediate(circleTexture);

        AssetDatabase.ImportAsset(TexturePath, ImportAssetOptions.ForceUpdate);
        TextureImporter importer = AssetImporter.GetAtPath(TexturePath) as TextureImporter;
        if (importer != null)
        {
            importer.textureType = TextureImporterType.Default;
            importer.alphaIsTransparency = true;
            importer.mipmapEnabled = false;
            importer.wrapMode = TextureWrapMode.Clamp;
            importer.filterMode = FilterMode.Bilinear;
            importer.SaveAndReimport();
        }

        Texture2D importedTexture = AssetDatabase.LoadAssetAtPath<Texture2D>(TexturePath);
        Material material = AssetDatabase.LoadAssetAtPath<Material>(MaterialPath);
        if (material == null)
        {
            material = new Material(ResolveParticleShader());
            AssetDatabase.CreateAsset(material, MaterialPath);
        }
        else
        {
            material.shader = ResolveParticleShader();
        }

        SetTextureIfPresent(material, "_BaseMap", importedTexture);
        SetTextureIfPresent(material, "_MainTex", importedTexture);
        SetColorIfPresent(material, "_BaseColor", Color.white);
        SetColorIfPresent(material, "_Color", Color.white);
        SetFloatIfPresent(material, "_Surface", 1f);
        SetFloatIfPresent(material, "_Blend", 0f);
        SetFloatIfPresent(material, "_ZWrite", 0f);
        material.renderQueue = (int)UnityEngine.Rendering.RenderQueue.Transparent;
        EditorUtility.SetDirty(material);

        GameObject prefabRoot = PrefabUtility.LoadPrefabContents(PrefabPath);
        try
        {
            ParticleSystem particleSystem = prefabRoot.GetComponentInChildren<ParticleSystem>(true);
            ParticleSystemRenderer renderer = prefabRoot.GetComponentInChildren<ParticleSystemRenderer>(true);
            if (particleSystem == null || renderer == null)
            {
                throw new MissingComponentException("BulletImpactParticles prefab must contain a ParticleSystem and ParticleSystemRenderer.");
            }

            renderer.renderMode = ParticleSystemRenderMode.Billboard;
            renderer.material = material;
            renderer.trailMaterial = null;
            renderer.sortingLayerName = "Default";
            renderer.sortingOrder = 8;

            ParticleSystem.MainModule main = particleSystem.main;
            main.startSize = new ParticleSystem.MinMaxCurve(0.12f, 0.28f);
            main.startColor = new ParticleSystem.MinMaxGradient(new Color(1f, 0.72f, 0.18f, 1f), new Color(1f, 0.34f, 0.05f, 1f));
            main.startRotation = new ParticleSystem.MinMaxCurve(0f, Mathf.PI * 2f);

            ParticleSystem.TextureSheetAnimationModule textureSheet = particleSystem.textureSheetAnimation;
            textureSheet.enabled = false;

            EditorUtility.SetDirty(particleSystem);
            EditorUtility.SetDirty(renderer);
            PrefabUtility.SaveAsPrefabAsset(prefabRoot, PrefabPath);
        }
        finally
        {
            PrefabUtility.UnloadPrefabContents(prefabRoot);
        }

        AssetDatabase.SaveAssets();
        AssetDatabase.Refresh();
        Debug.Log($"Applied circular bullet impact particle material: {MaterialPath} using {TexturePath}");
    }

    public static void ValidateCircularParticles()
    {
        GameObject prefab = AssetDatabase.LoadAssetAtPath<GameObject>(PrefabPath);
        if (prefab == null)
        {
            Debug.LogError($"Circular particle validation failed: prefab missing at {PrefabPath}");
            return;
        }

        ParticleSystemRenderer renderer = prefab.GetComponentInChildren<ParticleSystemRenderer>(true);
        if (renderer == null)
        {
            Debug.LogError($"Circular particle validation failed: ParticleSystemRenderer missing on {PrefabPath}");
            return;
        }

        Material material = renderer.sharedMaterial;
        string materialPath = material != null ? AssetDatabase.GetAssetPath(material) : "null";
        Texture texture = null;
        if (material != null)
        {
            if (material.HasProperty("_BaseMap"))
            {
                texture = material.GetTexture("_BaseMap");
            }
            if (texture == null && material.HasProperty("_MainTex"))
            {
                texture = material.GetTexture("_MainTex");
            }
        }

        string texturePath = texture != null ? AssetDatabase.GetAssetPath(texture) : "null";
        Debug.Log($"Circular particle validation: prefab={PrefabPath}; rendererMaterial={materialPath}; rendererMode={renderer.renderMode}; texture={texturePath}; textureSheetEnabled={prefab.GetComponentInChildren<ParticleSystem>(true).textureSheetAnimation.enabled}");
    }

    private static void EnsureFolders()
    {
        if (!AssetDatabase.IsValidFolder("Assets/Art"))
        {
            AssetDatabase.CreateFolder("Assets", "Art");
        }
        if (!AssetDatabase.IsValidFolder("Assets/Art/VFX"))
        {
            AssetDatabase.CreateFolder("Assets/Art", "VFX");
        }
    }

    private static Texture2D CreateCircleTexture(int size)
    {
        Texture2D texture = new Texture2D(size, size, TextureFormat.RGBA32, false);
        texture.name = "ImpactParticleCircle";
        float center = (size - 1) * 0.5f;
        float radius = size * 0.43f;
        float feather = size * 0.09f;

        for (int y = 0; y < size; y++)
        {
            for (int x = 0; x < size; x++)
            {
                float dx = x - center;
                float dy = y - center;
                float distance = Mathf.Sqrt(dx * dx + dy * dy);
                float alpha = Mathf.Clamp01((radius - distance) / feather);
                alpha = Mathf.SmoothStep(0f, 1f, alpha);
                texture.SetPixel(x, y, new Color(1f, 1f, 1f, alpha));
            }
        }

        texture.Apply(false, false);
        return texture;
    }

    private static Shader ResolveParticleShader()
    {
        return Shader.Find("Universal Render Pipeline/Particles/Unlit")
               ?? Shader.Find("Particles/Standard Unlit")
               ?? Shader.Find("Sprites/Default")
               ?? Shader.Find("Universal Render Pipeline/Unlit");
    }

    private static void SetTextureIfPresent(Material material, string propertyName, Texture texture)
    {
        if (texture != null && material.HasProperty(propertyName))
        {
            material.SetTexture(propertyName, texture);
        }
    }

    private static void SetColorIfPresent(Material material, string propertyName, Color color)
    {
        if (material.HasProperty(propertyName))
        {
            material.SetColor(propertyName, color);
        }
    }

    private static void SetFloatIfPresent(Material material, string propertyName, float value)
    {
        if (material.HasProperty(propertyName))
        {
            material.SetFloat(propertyName, value);
        }
    }
}
