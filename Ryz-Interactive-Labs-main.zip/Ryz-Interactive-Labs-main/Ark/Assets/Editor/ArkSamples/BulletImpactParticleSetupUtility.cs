﻿using System.IO;
using UnityEditor;
using UnityEngine;

public static class BulletImpactParticleSetupUtility
{
    private const string ImpactPrefabPath = "Assets/Prefabs/BulletImpactParticles.prefab";
    private const string PlayerBulletPrefabPath = "Assets/Prefabs/PlayerBullet.prefab";

    public static void CreateImpactPrefabAndWireBullet()
    {
        EnsureImpactPrefab();
        WirePlayerBulletPrefab();
        AssetDatabase.SaveAssets();
        AssetDatabase.Refresh();
    }

    private static void EnsureImpactPrefab()
    {
        Directory.CreateDirectory("Assets/Prefabs");

        GameObject root = new GameObject("BulletImpactParticles");
        ParticleSystem particles = root.AddComponent<ParticleSystem>();
        ParticleSystem.MainModule main = particles.main;
        main.duration = 0.25f;
        main.loop = false;
        main.playOnAwake = true;
        main.simulationSpace = ParticleSystemSimulationSpace.World;
        main.startLifetime = new ParticleSystem.MinMaxCurve(0.22f, 0.45f);
        main.startSpeed = new ParticleSystem.MinMaxCurve(2.0f, 4.2f);
        main.startSize = new ParticleSystem.MinMaxCurve(0.07f, 0.18f);
        main.startRotation = new ParticleSystem.MinMaxCurve(0f, Mathf.PI * 2f);
        main.startColor = new ParticleSystem.MinMaxGradient(new Color(1f, 0.95f, 0.2f, 1f), new Color(1f, 0.35f, 0.04f, 1f));
        main.gravityModifier = 0f;
        main.maxParticles = 48;
        main.stopAction = ParticleSystemStopAction.Destroy;

        ParticleSystem.EmissionModule emission = particles.emission;
        emission.enabled = true;
        emission.rateOverTime = 0f;
        emission.SetBursts(new[] { new ParticleSystem.Burst(0f, 24) });

        ParticleSystem.ShapeModule shape = particles.shape;
        shape.enabled = true;
        shape.shapeType = ParticleSystemShapeType.Circle;
        shape.radius = 0.08f;
        shape.radiusThickness = 0.25f;
        shape.arc = 360f;

        ParticleSystem.VelocityOverLifetimeModule velocity = particles.velocityOverLifetime;
        velocity.enabled = true;
        velocity.space = ParticleSystemSimulationSpace.Local;
        velocity.radial = new ParticleSystem.MinMaxCurve(0.4f, 1.0f);

        ParticleSystem.ColorOverLifetimeModule colorOverLifetime = particles.colorOverLifetime;
        colorOverLifetime.enabled = true;
        Gradient gradient = new Gradient();
        gradient.SetKeys(
            new[]
            {
                new GradientColorKey(new Color(1f, 0.95f, 0.25f), 0f),
                new GradientColorKey(new Color(1f, 0.45f, 0.06f), 0.45f),
                new GradientColorKey(new Color(0.45f, 0.18f, 0.04f), 1f),
            },
            new[]
            {
                new GradientAlphaKey(1f, 0f),
                new GradientAlphaKey(0.85f, 0.25f),
                new GradientAlphaKey(0f, 1f),
            });
        colorOverLifetime.color = gradient;

        ParticleSystem.SizeOverLifetimeModule sizeOverLifetime = particles.sizeOverLifetime;
        sizeOverLifetime.enabled = true;
        AnimationCurve sizeCurve = new AnimationCurve(
            new Keyframe(0f, 1f),
            new Keyframe(0.35f, 0.75f),
            new Keyframe(1f, 0f));
        sizeOverLifetime.size = new ParticleSystem.MinMaxCurve(1f, sizeCurve);

        ParticleSystemRenderer renderer = root.GetComponent<ParticleSystemRenderer>();
        renderer.renderMode = ParticleSystemRenderMode.Billboard;
        renderer.sortingLayerName = "Default";
        renderer.sortingOrder = 20;
        Material material = AssetDatabase.GetBuiltinExtraResource<Material>("Default-Particle.mat");
        if (material != null)
        {
            renderer.sharedMaterial = material;
        }

        PrefabUtility.SaveAsPrefabAsset(root, ImpactPrefabPath);
        Object.DestroyImmediate(root);
    }

    private static void WirePlayerBulletPrefab()
    {
        GameObject impactPrefab = AssetDatabase.LoadAssetAtPath<GameObject>(ImpactPrefabPath);
        if (impactPrefab == null)
        {
            throw new FileNotFoundException("Could not load bullet impact prefab after creating it.", ImpactPrefabPath);
        }

        GameObject bulletRoot = PrefabUtility.LoadPrefabContents(PlayerBulletPrefabPath);
        try
        {
            BulletImpactParticles impact = bulletRoot.GetComponent<BulletImpactParticles>();
            if (impact == null)
            {
                impact = bulletRoot.AddComponent<BulletImpactParticles>();
            }

            SerializedObject serializedImpact = new SerializedObject(impact);
            serializedImpact.FindProperty("impactPrefab").objectReferenceValue = impactPrefab;
            serializedImpact.FindProperty("destroyPadding").floatValue = 0.15f;
            serializedImpact.FindProperty("alignToBulletVelocity").boolValue = false;
            serializedImpact.ApplyModifiedPropertiesWithoutUndo();

            PrefabUtility.SaveAsPrefabAsset(bulletRoot, PlayerBulletPrefabPath);
        }
        finally
        {
            PrefabUtility.UnloadPrefabContents(bulletRoot);
        }
    }
}
