# Unity Physics Notes for Agentic Gamedev

Use this local note when a task mentions physics, Rigidbody, Rigidbody2D, Collider, Collider2D, trigger, raycast, overlap, collision, movement, gravity, projectile, bouncing, top-down movement, platformer movement, tilemap collision, or physics layers.

## Pick 2D or 3D first

Do not mix 2D and 3D physics APIs unless the user explicitly asks for both.

- 2D uses `Rigidbody2D`, `Collider2D`, `Physics2D`, `OnCollisionEnter2D`, and `OnTriggerEnter2D`.
- 3D uses `Rigidbody`, `Collider`, `Physics`, `OnCollisionEnter`, and `OnTriggerEnter`.
- 2D colliders do not collide with 3D rigidbodies/colliders.

## Rigidbody and collider basics

For simulated physics objects:

- Add one Rigidbody/Rigidbody2D to the moving root object.
- Add one or more compatible colliders to the same object or children.
- For triggers, enable `isTrigger` on the collider and implement trigger callbacks.
- For collision callbacks, at least one participant usually needs a Rigidbody/Rigidbody2D.

Common body choices:

- Dynamic: forces, gravity, collisions, and solver movement.
- Kinematic: controlled by script, can interact depending on settings.
- Static: no Rigidbody; best for level geometry that does not move.

## Movement rules

Use `FixedUpdate` for physics movement.

2D:

- Prefer `Rigidbody2D.MovePosition` for kinematic-style movement.
- Prefer setting `Rigidbody2D.linearVelocity` or applying forces for dynamic movement.
- For top-down games, usually set `gravityScale = 0`.
- Freeze rotation if the player should not spin after collisions.

3D:

- Prefer `Rigidbody.MovePosition` for kinematic-style movement.
- Prefer setting `Rigidbody.linearVelocity` or applying forces for dynamic movement.
- Use constraints to freeze unwanted rotation or axes.

Avoid repeatedly setting `transform.position` on dynamic physics bodies; it can bypass collision solving and create tunneling or jitter.

## Collision and trigger checklist

If collisions or triggers do not fire:

1. Confirm all components are from the same physics system: 2D with 2D, or 3D with 3D.
2. Confirm at least one object has a Rigidbody/Rigidbody2D.
3. Confirm colliders are enabled and not on ignored layers.
4. Check Project Settings physics collision matrix or Physics2D layer collision matrix.
5. Check `isTrigger`; trigger callbacks and collision callbacks are different.
6. Check object scale; tiny or huge scales can create unexpected contact behavior.
7. For fast projectiles, use continuous collision detection, raycasts, or swept tests.

## Raycasts and overlaps

Use raycasts for line-of-sight, aiming, ground checks, hitscan weapons, and wall checks.

2D examples:

- `Physics2D.Raycast(origin, direction, distance, layerMask)`
- `Physics2D.OverlapCircle(position, radius, layerMask)`
- `ContactFilter2D` when filtering by layer/depth/normal angle.

3D examples:

- `Physics.Raycast(origin, direction, out hit, distance, layerMask)`
- `Physics.OverlapSphere(position, radius, layerMask)`

Always use explicit layer masks for gameplay checks once the scene has multiple object types.

## Tilemaps and composite colliders

For 2D tilemap collision:

- Add `TilemapCollider2D` to the tilemap.
- Add `Rigidbody2D` set to Static for static level geometry.
- For smoother merged collision outlines, add `CompositeCollider2D` and set the `TilemapCollider2D` to use the composite.
- Keep gameplay characters on separate layers from terrain when raycasts need filtering.

## Agent workflow

Before editing physics behavior:

1. Use `search_project` and `read_text_file` on relevant movement, projectile, enemy, or collision scripts.
2. Use `search_unity_docs` for unfamiliar physics APIs, Rigidbody/Rigidbody2D property names, collision detection modes, query APIs, or package-specific behavior.
3. Enter Play Mode for runtime-only physics bugs when safe.
4. Inspect updated context after changes.
5. Use `validate_scene` before finishing.

Do not diagnose script-driven movement or spawning from scene hierarchy alone. Read the source first.
