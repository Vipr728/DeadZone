# Unity Post Processing Notes for Agentic Gamedev

Use this local note when a task mentions post processing, bloom, vignette, color grading, tone mapping, exposure, URP volumes, VolumeProfile assets, camera render settings, or visual polish.

## URP post-processing checklist

1. Confirm the project is using URP.
   - Inspect render pipeline context first.
   - Search local docs for `URP Volume post-processing`, `Bloom`, `Vignette`, or the exact override class before guessing API names.

2. Create or reuse a `VolumeProfile` asset.
   - Store reusable profiles under `Assets/Settings` or another stable project folder.
   - Volume overrides such as `Bloom`, `Vignette`, `ColorAdjustments`, `ChromaticAberration`, `DepthOfField`, and `MotionBlur` are sub-assets/data inside the profile.
   - Direct JSON asset actions are usually not enough to add/configure override objects. Prefer a scoped Editor utility when creating or modifying a profile.

3. Ensure the scene has a `Volume`.
   - Add a `UnityEngine.Rendering.Volume` component to a scene GameObject.
   - For broad scene effects, set `isGlobal = true`, `priority = 0`, `weight = 1`.
   - Assign the profile to `sharedProfile` for asset-backed profile edits.

4. Enable post processing on the rendering camera.
   - For URP cameras, use `UnityEngine.Rendering.Universal.UniversalAdditionalCameraData`.
   - Set `renderPostProcessing = true`.
   - Some effects need depth or color texture support; set `requiresDepthTexture` and `requiresColorTexture` when the effect needs them.

5. Validate visually.
   - Use `capture_game_view` after visual changes.
   - If the image does not change, check camera post-processing, assigned profile, active overrides, volume weight, camera layer/volume mask, and renderer/pipeline settings.
   - Do not claim bloom works only because a Bloom override exists; verify it affects the camera render.

## Useful Editor-script pattern

When direct actions cannot create or configure profile overrides, write a scoped Editor script under `Assets/Editor`, let Unity compile, then call `invoke_editor_method`.

Core API pattern:

```csharp
using UnityEditor;
using UnityEngine;
using UnityEngine.Rendering;
using UnityEngine.Rendering.Universal;

public static class ConfigurePostProcessing
{
    public static void Apply()
    {
        var profile = AssetDatabase.LoadAssetAtPath<VolumeProfile>("Assets/Settings/VolumeProfile_PostProcessing.asset");
        if (profile == null)
        {
            profile = ScriptableObject.CreateInstance<VolumeProfile>();
            AssetDatabase.CreateAsset(profile, "Assets/Settings/VolumeProfile_PostProcessing.asset");
        }

        if (!profile.TryGet(out Bloom bloom))
        {
            bloom = profile.Add<Bloom>(true);
        }

        bloom.active = true;
        bloom.intensity.overrideState = true;
        bloom.intensity.value = 1.5f;

        EditorUtility.SetDirty(profile);
        AssetDatabase.SaveAssets();
    }
}
```

## Common mistakes

- Creating a `VolumeProfile` asset but not assigning it to any `Volume`.
- Adding a `Volume` but leaving the main camera post-processing disabled.
- Setting override values without setting each `overrideState = true`.
- Using post-processing on an unlit or very dark scene and expecting bloom without bright/emissive pixels.
- Creating an Editor utility but never invoking it after compile.
- Relying on Scene view appearance instead of `capture_game_view`.

## Project-specific note

This project keeps Ark editor helpers in the embedded package under `Packages/com.ark.agentic-gamedev/Editor`. Post-processing helpers should follow the expected URP setup pattern: create a profile asset, add Bloom and Vignette overrides, assign the profile to a global Volume, enable post-processing on `Camera.main`, and save assets.
