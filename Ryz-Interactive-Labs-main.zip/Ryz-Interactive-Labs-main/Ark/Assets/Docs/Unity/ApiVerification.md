# Unity API Verification Notes for Agentic Gamedev

Use this local note when a task involves Unity C# APIs, package APIs, compiler errors, missing members, read-only properties, ambiguous overloads, serialized fields, Inspector labels, or Editor utilities.

## Required workflow

1. Read the compiler diagnostic or user request carefully.
2. Identify the exact type and member names involved.
3. Call `search_unity_api` with the type name plus the member name.
4. Read the returned source file with `read_unity_api`.
5. Use only members that are actually public and assignable in the installed source.
6. Patch the code.
7. Let Unity compile.
8. Call `read_compiler_diagnostics`.
9. Repeat until compiler diagnostics are clean.

Do not finish a task while compiler diagnostics still contain errors from an editable file.

## Public API vs serialized data

Unity Inspector labels and serialized field names are not automatically public C# API.

Examples of unsafe assumptions:

- Inspector label `Volume Update Mode` does not mean `UniversalAdditionalCameraData.volumeFrameworkUpdateMode` is public.
- A serialized field like `m_VolumeFrameworkUpdateModeOption` should not be assigned directly unless using `SerializedObject` intentionally.
- Changelog text can mention a feature without showing the current public setter or exact casing.

For normal C# code, trust the installed source declaration:

- `public bool propertyName { get; set; }` is assignable.
- `public bool propertyName { get; }` is read-only.
- `internal`, `private`, and serialized fields are not public API for ordinary runtime/editor scripts.
- C# member names are case-sensitive.

## Common compiler diagnostics

- `CS1061`: the member does not exist on that type, or the casing/name is wrong. Search the installed source for the type and member.
- `CS0200`: the member exists but is read-only. Find a public setter/method or remove the assignment.
- `CS0246`: the type or namespace is missing. Search source for the type and verify namespace/assembly/package.
- `CS0122`: the member exists but is inaccessible. Do not use it directly; find a public API or use a proper serialized/editor path.

## URP camera example

For `UniversalAdditionalCameraData` in the installed URP package, verify the source before writing code. Some camera settings are public assignable properties; others are internal/read-only or exposed only through serialized editor UI.

Correct pattern after source verification:

```csharp
var data = camera.GetComponent<UniversalAdditionalCameraData>();
if (data == null)
{
    data = camera.gameObject.AddComponent<UniversalAdditionalCameraData>();
}

data.renderPostProcessing = true;
data.requiresDepthTexture = true;
data.requiresColorTexture = true;
data.SetRenderer(0);
```

Avoid invented members such as `requiresDepthTextureOption`, `requiresColorTextureOption`, lowercase `setRenderer`, or assigning read-only volume update properties unless the installed source proves they are valid public assignable members.
