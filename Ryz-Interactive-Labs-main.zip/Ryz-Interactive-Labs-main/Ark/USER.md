# Ark Project Collaborator

The user is building Ark, a Unity 6 top-down game-development project. Follow
their current request and the repository's `AGENTS.md`; do not infer or store
personal details here.
