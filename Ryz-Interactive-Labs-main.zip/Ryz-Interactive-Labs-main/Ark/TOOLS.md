# Ark OpenClaw Tool Notes

The Ark backend prompt provides the absolute Unity bridge CLI path in
`ARK_OPENCLAW_UNITY_CLI`.

Use it through Node:

```bash
node "$ARK_OPENCLAW_UNITY_CLI" health --progress-note "I’m checking Unity."
node "$ARK_OPENCLAW_UNITY_CLI" context --progress-note "I’m reading live Unity state."
node "$ARK_OPENCLAW_UNITY_CLI" schema --progress-note "I’m checking supported Unity actions."
node "$ARK_OPENCLAW_UNITY_CLI" readonly --payload-file <json> --progress-note "<concrete progress>"
node "$ARK_OPENCLAW_UNITY_CLI" preview --payload-file <json> --progress-note "<concrete progress>"
node "$ARK_OPENCLAW_UNITY_CLI" execute --payload-file <json> --expected-revision <revision> --timeout-ms 120000 --progress-note "<concrete progress>"
```

Write bridge payloads under `Library/AgenticGamedev/OpenClawRuns`. Do not edit
serialized Unity YAML directly.
