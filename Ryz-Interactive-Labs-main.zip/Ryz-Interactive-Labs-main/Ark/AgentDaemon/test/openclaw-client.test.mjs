import assert from "node:assert/strict";
import fs from "node:fs/promises";
import os from "node:os";
import path from "node:path";
import test from "node:test";

import {
  OpenClawClient,
  extractOpenClawText,
  parseOpenClawEnvelope
} from "../src/openclaw-client.mjs";

test("extractOpenClawText reads the documented payload response", () => {
  assert.equal(extractOpenClawText({
    payloads: [
      { text: "{\"message\":\"done\"}" }
    ]
  }), "{\"message\":\"done\"}");
});

test("parseOpenClawEnvelope accepts legacy local-mode JSON on stderr", () => {
  const envelope = parseOpenClawEnvelope("", [
    "[agents/auth-profiles] synced provider credentials",
    "{",
    "  \"payloads\": [{ \"text\": \"READY\" }]",
    "}"
  ].join("\n"));
  assert.equal(envelope.payloads[0].text, "READY");
});

test("extractOpenClawText reads Gateway RPC payloads", () => {
  assert.equal(extractOpenClawText({
    status: "ok",
    result: {
      payloads: [{ text: "READY" }]
    }
  }), "READY");
});

test("OpenClawClient invokes the configured agent and parses JSON output", async (context) => {
  const fixture = await createFakeOpenClaw();
  context.after(() => fs.rm(fixture.directory, { recursive: true, force: true }));

  const client = new OpenClawClient({
    binary: fixture.binary,
    agentId: "ark",
    mode: "local",
    timeoutSeconds: 30
  });
  const probe = await client.probe();
  assert.equal(probe.ready, true);
  assert.equal(probe.agent_id, "ark");
  assert.equal(probe.configured_model, "");

  const result = await client.run({
    message: "Build the prototype",
    sessionId: "run-123",
    model: "openai/gpt-test",
    cwd: fixture.directory
  });
  assert.equal(result.text, "{\"message\":\"finished\",\"plan\":[],\"progress\":[],\"actions\":[]}");
  assert.equal(result.model_override_applied, true);

  const invocation = JSON.parse(await fs.readFile(fixture.argsFile, "utf8"));
  assert.deepEqual(invocation.slice(0, 5), ["agent", "--agent", "ark", "--session-id", "run-123"]);
  assert.equal(invocation.includes("--local"), true);
  assert.equal(invocation.includes("--model"), true);
  assert.equal(invocation[invocation.indexOf("--message") + 1], "Build the prototype");
});

test("OpenClawClient cancels the child process when the Ark run is aborted", async (context) => {
  const fixture = await createFakeOpenClaw({ slow: true });
  context.after(() => fs.rm(fixture.directory, { recursive: true, force: true }));

  const client = new OpenClawClient({
    binary: fixture.binary,
    agentId: "ark",
    mode: "local",
    timeoutSeconds: 30
  });
  const controller = new AbortController();
  const pending = client.run({
    message: "Keep working",
    sessionId: "run-cancel",
    cwd: fixture.directory,
    signal: controller.signal
  });
  setTimeout(() => controller.abort(), 100);

  await assert.rejects(pending, /canceled/);
});

test("OpenClawClient serializes runs for the configured OpenClaw agent", async (context) => {
  const fixture = await createFakeOpenClaw({ runDelayMs: 200, trackOverlap: true });
  context.after(() => fs.rm(fixture.directory, { recursive: true, force: true }));

  const client = new OpenClawClient({
    binary: fixture.binary,
    agentId: "ark",
    mode: "local",
    timeoutSeconds: 30
  });
  const startedAt = Date.now();
  await Promise.all([
    client.run({ message: "First", sessionId: "run-first", cwd: fixture.directory }),
    client.run({ message: "Second", sessionId: "run-second", cwd: fixture.directory })
  ]);

  assert.equal(await fileExists(fixture.overlapFile), false);
  assert.ok(Date.now() - startedAt >= 350);
});

test("OpenClawClient gives Gateway runs an explicit per-run session key", async (context) => {
  const fixture = await createFakeOpenClaw();
  context.after(() => fs.rm(fixture.directory, { recursive: true, force: true }));

  const client = new OpenClawClient({
    binary: fixture.binary,
    agentId: "ark",
    mode: "gateway",
    gatewayUrl: "ws://127.0.0.1:18789",
    timeoutSeconds: 30
  });
  assert.equal((await client.probe()).ready, true);
  assert.equal((await client.run({
    message: "Build through the Gateway",
    sessionId: "run-gateway",
    cwd: fixture.directory
  })).text, "{\"message\":\"finished\",\"plan\":[],\"progress\":[],\"actions\":[]}");

  const invocation = JSON.parse(await fs.readFile(fixture.argsFile, "utf8"));
  assert.deepEqual(invocation.slice(0, 3), ["gateway", "call", "agent"]);
  const params = JSON.parse(invocation[invocation.indexOf("--params") + 1]);
  assert.equal(params.agentId, "ark");
  assert.equal(params.sessionId, "run-gateway");
  assert.equal(params.sessionKey, "agent:ark:ark-run:run-gateway");
  assert.equal(invocation[invocation.indexOf("--url") + 1], "ws://127.0.0.1:18789");
});

test("OpenClawClient forwards proportional thinking and bootstrap context to Gateway", async (context) => {
  const fixture = await createFakeOpenClaw();
  context.after(() => fs.rm(fixture.directory, { recursive: true, force: true }));

  const client = new OpenClawClient({
    binary: fixture.binary,
    agentId: "ark",
    mode: "gateway",
    timeoutSeconds: 30
  });
  await client.run({
    message: "Create one scene",
    sessionId: "run-atomic",
    thinking: "off",
    bootstrapContextMode: "lightweight",
    cwd: fixture.directory
  });

  const invocation = JSON.parse(await fs.readFile(fixture.argsFile, "utf8"));
  const params = JSON.parse(invocation[invocation.indexOf("--params") + 1]);
  assert.equal(params.thinking, "off");
  assert.equal(params.bootstrapContextMode, "lightweight");
  assert.equal("model" in params, false);
});

test("OpenClawClient allows recovery turns to reuse a session with a new idempotency key", async (context) => {
  const fixture = await createFakeOpenClaw();
  context.after(() => fs.rm(fixture.directory, { recursive: true, force: true }));

  const client = new OpenClawClient({
    binary: fixture.binary,
    agentId: "ark",
    mode: "gateway",
    timeoutSeconds: 30
  });
  await client.run({
    message: "Continue the task",
    sessionId: "run-recovery",
    idempotencyKey: "run-recovery:recovery:1",
    cwd: fixture.directory
  });

  const invocation = JSON.parse(await fs.readFile(fixture.argsFile, "utf8"));
  const params = JSON.parse(invocation[invocation.indexOf("--params") + 1]);
  assert.equal(params.sessionId, "run-recovery");
  assert.equal(params.sessionKey, "agent:ark:ark-run:run-recovery");
  assert.equal(params.idempotencyKey, "run-recovery:recovery:1");
});

async function createFakeOpenClaw({ slow = false, runDelayMs = 0, trackOverlap = false } = {}) {
  const directory = await fs.mkdtemp(path.join(os.tmpdir(), "ark-openclaw-test-"));
  const binary = path.join(directory, "openclaw");
  const argsFile = path.join(directory, "args.json");
  const activeFile = path.join(directory, "active");
  const overlapFile = path.join(directory, "overlap");
  const script = `#!/usr/bin/env node
import fs from "node:fs";
const args = process.argv.slice(2);
if (args[0] === "--version") {
  console.log("OpenClaw test");
} else if (args[0] === "agents") {
  console.log(JSON.stringify([{ id: "ark", workspace: process.cwd() }]));
} else if (args[0] === "agent" && args[1] === "--help") {
  console.log("--agent <id> --session-id <id> --model <id> --message <text> --json --local");
} else if (args[0] === "gateway" && args[1] === "call" && args[2] === "health") {
  console.log(JSON.stringify({ ok: true }));
} else if (args[0] === "gateway" && args[1] === "call" && args[2] === "agent") {
  fs.writeFileSync(${JSON.stringify(argsFile)}, JSON.stringify(args));
  console.log(JSON.stringify({
    status: "ok",
    result: {
      payloads: [{ text: "{\\"message\\":\\"finished\\",\\"plan\\":[],\\"progress\\":[],\\"actions\\":[]}" }]
    }
  }));
} else if (args[0] === "agent") {
  fs.writeFileSync(${JSON.stringify(argsFile)}, JSON.stringify(args));
  ${trackOverlap ? `
  if (fs.existsSync(${JSON.stringify(activeFile)})) {
    fs.writeFileSync(${JSON.stringify(overlapFile)}, "overlap");
  }
  fs.writeFileSync(${JSON.stringify(activeFile)}, String(process.pid));
  ` : ""}
  ${slow ? "setTimeout(() => {}, 30000);" : `
  setTimeout(() => {
    ${trackOverlap ? `fs.rmSync(${JSON.stringify(activeFile)}, { force: true });` : ""}
    console.log(JSON.stringify({
      payloads: [{ text: "{\\"message\\":\\"finished\\",\\"plan\\":[],\\"progress\\":[],\\"actions\\":[]}" }]
    }));
  }, ${runDelayMs});
  `}
} else {
  process.exitCode = 2;
}
`;
  await fs.writeFile(binary, script, { mode: 0o755 });
  return { directory, binary, argsFile, overlapFile };
}

async function fileExists(filePath) {
  try {
    await fs.access(filePath);
    return true;
  } catch {
    return false;
  }
}
