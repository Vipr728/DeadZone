import assert from "node:assert/strict";
import fs from "node:fs/promises";
import os from "node:os";
import path from "node:path";
import test from "node:test";

import {
  buildRecoveryPrompt,
  buildOpenClawRunPrompt,
  responseHasCompilerFailure,
  responseHasEditableCompilerFailure,
  responseNeedsRecovery,
  responseRequiresUserAction,
  selectTaskProfile
} from "../src/task-profile.mjs";
import {
  extractRuntimeErrors,
  parseLatestCompilerResults,
  resolveAvailableScene
} from "../src/openclaw-unity.mjs";

test("simple scene creation gets the atomic low-context profile", () => {
  const profile = selectTaskProfile("make a new scene");
  assert.equal(profile.kind, "atomic");
  assert.equal(profile.thinking, "off");
  assert.equal(profile.bootstrapContextMode, "lightweight");
  assert.equal(profile.maxToolTurns, 1);
  assert.equal(profile.maxRecoveryAttempts, 0);
  assert.equal(profile.maxCompilerRecoveryAttempts, 0);
  assert.equal(profile.semanticCommand, "create-scene");
});

test("broad implementation work gets the complex profile", () => {
  const profile = selectTaskProfile(
    "Set up a complete project with procedural level design, implement the gameplay system, and write the supporting code."
  );
  assert.equal(profile.kind, "complex");
  assert.equal(profile.bootstrapContextMode, "full");
  assert.equal(profile.thinking, "medium");
});

test("comma-separated multi-feature gameplay work gets complex completion recovery", () => {
  const profile = selectTaskProfile(
    "in scene 5, create a player, shooting mechanism with recoil, screenshake, impact, following enemies with different behaviors, a kill counter, and a timer."
  );
  assert.equal(profile.kind, "complex");
  assert.equal(profile.requiresCompletion, true);
  assert.equal(profile.maxRecoveryAttempts, 2);
  assert.equal(profile.maxCompilerRecoveryAttempts, 5);
});

test("focused mutations recover but read-only questions do not", () => {
  const focused = selectTaskProfile("make the camera background black");
  const question = selectTaskProfile("why is the camera background black?");
  assert.equal(focused.kind, "focused");
  assert.equal(focused.requiresCompletion, true);
  assert.equal(focused.maxRecoveryAttempts, 1);
  assert.equal(focused.maxCompilerRecoveryAttempts, 4);
  assert.equal(question.requiresCompletion, false);
  assert.equal(question.maxRecoveryAttempts, 0);
});

test("a pasted compiler error is treated as a fix request even without an explicit verb", () => {
  const profile = selectTaskProfile(
    "Assets/Scripts/Enemy.cs(10,3): error CS0246: The type or namespace name 'EnemyBrain' could not be found"
  );
  assert.equal(profile.kind, "focused");
  assert.equal(profile.requiresCompletion, true);
  assert.equal(profile.maxCompilerRecoveryAttempts, 4);
});

test("atomic prompts stay compact and prescribe exactly one semantic call", () => {
  const profile = selectTaskProfile("create a new scene named Menu");
  const prompt = buildOpenClawRunPrompt({
    profile,
    prompt: "create a new scene named Menu",
    runId: "run-1",
    projectRoot: "/project",
    unityCli: "/project/AgentDaemon/src/openclaw-unity.mjs",
    bridgeUrl: "http://127.0.0.1:47392",
    progressFile: "/project/Library/run.progress.jsonl",
    unityHealth: {
      ok: true,
      project: "Ark",
      scene: "Gameplay",
      scene_path: "Assets/Scenes/Gameplay.unity",
      revision: 7,
      payload_json: "x".repeat(100000)
    },
    context: "x".repeat(100000)
  });
  assert.match(prompt, /create-scene/);
  assert.match(prompt, /--name "Menu"/);
  assert.match(prompt, /exactly one tool call/i);
  assert.doesNotMatch(prompt, /payload_json/);
  assert.ok(prompt.length < 2500, `atomic prompt was ${prompt.length} chars`);
});

test("focused context is capped while complex context can grow proportionally", () => {
  const focused = selectTaskProfile("make the camera background black");
  const complex = selectTaskProfile(
    "Build the entire game project, implement the gameplay system, level design, scripts, UI, and test all runtime behavior."
  );
  const makePrompt = (profile) => buildOpenClawRunPrompt({
    profile,
    prompt: "request",
    runId: "run-2",
    projectRoot: "/project",
    unityCli: "/project/openclaw-unity.mjs",
    bridgeUrl: "http://127.0.0.1:47392",
    progressFile: "/project/progress.jsonl",
    unityHealth: { ok: true, revision: 2 },
    context: "x".repeat(50000)
  });
  const focusedPrompt = makePrompt(focused);
  const complexPrompt = makePrompt(complex);
  assert.ok(focusedPrompt.length < 9000);
  assert.ok(complexPrompt.length > focusedPrompt.length);
  assert.ok(complexPrompt.length < 25000);
});

test("non-atomic prompts make OpenClaw the sole game-content executor", () => {
  const profile = selectTaskProfile("make the camera background black");
  const prompt = buildOpenClawRunPrompt({
    profile,
    prompt: "make the camera background black",
    runId: "run-owner",
    projectRoot: "/project",
    unityCli: "/project/openclaw-unity.mjs",
    bridgeUrl: "http://127.0.0.1:47392",
    progressFile: "/project/progress.jsonl",
    unityHealth: { ok: true, revision: 2 }
  });
  assert.match(prompt, /sole executor/i);
  assert.match(prompt, /no supervising assistant will edit gameplay scripts/i);
});

test("incomplete mutating results trigger same-run recovery", () => {
  const profile = selectTaskProfile("attach the Scene5Bootstrap component");
  assert.equal(responseNeedsRecovery({
    message: "The component could not be added, so this is not fully finished yet.",
    completion_status: "blocked",
    actions: []
  }, profile), true);
  assert.equal(responseNeedsRecovery({
    message: "Attached the component and validated the scene.",
    completion_status: "complete",
    progress: ["Compiler diagnostics are clean."],
    actions: []
  }, profile), false);
  assert.match(buildRecoveryPrompt({ attempt: 1, maxAttempts: 2 }), /do not merely restate/i);
  assert.match(buildRecoveryPrompt({ attempt: 1, maxAttempts: 2 }), /compile-attach/);
});

test("editable compiler errors stay in automatic repair instead of escalating to the user", () => {
  const response = {
    completion_status: "blocked",
    blocker_kind: "user_action_required",
    blocker: "Assets/Scripts/Player.cs(12,4): error CS1061: Player has no definition for Jump",
    user_action: "Fix Player.cs manually."
  };
  assert.equal(responseHasCompilerFailure(response), true);
  assert.equal(responseHasEditableCompilerFailure(response), true);
  assert.equal(responseRequiresUserAction(response), false);
  const prompt = buildRecoveryPrompt({
    attempt: 2,
    maxAttempts: 4,
    compilerFailure: true
  });
  assert.match(prompt, /compiler-debug continuation/i);
  assert.match(prompt, /is not a user blocker/i);
  assert.match(prompt, /installed API source/i);
});

test("genuine external compiler blockers include a concrete user handoff", () => {
  const response = {
    completion_status: "blocked",
    blocker_kind: "authorization_required",
    blocker: "Library/PackageCache/com.vendor.tool/Runtime/Feature.cs(8,2): error CS0246: MissingVendorSdk could not be found.",
    user_action: "Approve installation of com.vendor.missing-package in Unity Package Manager."
  };
  assert.equal(responseHasCompilerFailure(response), true);
  assert.equal(responseHasEditableCompilerFailure(response), false);
  assert.equal(responseRequiresUserAction(response), true);
});

test("create-scene semantic command chooses the next available scene name", async (context) => {
  const projectRoot = await fs.mkdtemp(path.join(os.tmpdir(), "ark-scene-profile-"));
  context.after(() => fs.rm(projectRoot, { recursive: true, force: true }));
  const scenes = path.join(projectRoot, "Assets", "Scenes");
  await fs.mkdir(scenes, { recursive: true });
  await fs.writeFile(path.join(scenes, "NewScene.unity"), "");
  await fs.writeFile(path.join(scenes, "NewScene2.unity"), "");

  assert.deepEqual(await resolveAvailableScene(projectRoot), {
    name: "NewScene3",
    path: "Assets/Scenes/NewScene3.unity"
  });
});

test("compiler diagnostic parsing keeps the latest result for each Unity assembly", () => {
  const results = parseLatestCompilerResults([
    JSON.stringify({
      msg: "noderesult",
      annotation: "Csc Library/Bee/Assembly-CSharp.dll",
      exitcode: 1,
      stdout: "old error"
    }),
    JSON.stringify({
      msg: "noderesult",
      annotation: "Csc Library/Bee/Ark.Editor.dll",
      exitcode: 1,
      stdout: "editor error"
    }),
    JSON.stringify({
      msg: "noderesult",
      annotation: "Csc Library/Bee/Assembly-CSharp.dll",
      exitcode: 0,
      stdout: ""
    })
  ].join("\n"));
  assert.equal(results.length, 2);
  assert.equal(results.find((item) => item.annotation.includes("Assembly-CSharp"))?.exitcode, 0);
  assert.equal(results.find((item) => item.annotation.includes("Ark.Editor"))?.stdout, "editor error");
});

test("Play Mode smoke checks fail only on Unity error-class logs", () => {
  assert.deepEqual(extractRuntimeErrors([
    { type: "Log", message: "started" },
    { type: "Warning", message: "non-blocking warning" },
    { type: "Exception", message: "NullReferenceException" },
    { type: "Error", message: "Missing runtime dependency" }
  ]), [
    "NullReferenceException",
    "Missing runtime dependency"
  ]);
});
