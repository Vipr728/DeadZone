import assert from "node:assert/strict";
import test from "node:test";

import {
  buildQwenProviderConfig,
  findAgentIndex,
  normalizeQwenBaseUrl,
  providerConfigPath,
  verifyQwenEndpoint
} from "../src/configure-gb10-qwen.mjs";

test("GB10 Qwen setup rejects Ark and OpenClaw control endpoints", () => {
  assert.throws(
    () => normalizeQwenBaseUrl("http://127.0.0.1:47391/agent", { allowLoopbackTunnel: true }),
    /control-plane endpoint|control endpoint/i
  );
  assert.throws(
    () => normalizeQwenBaseUrl("http://127.0.0.1:18789", { allowLoopbackTunnel: true }),
    /control-plane endpoint/i
  );
});

test("loopback Qwen endpoints require an explicitly confirmed GB10 tunnel", () => {
  assert.throws(
    () => normalizeQwenBaseUrl("http://127.0.0.1:11435/v1"),
    /explicitly confirmed SSH tunnel/i
  );
  assert.equal(
    normalizeQwenBaseUrl("http://127.0.0.1:11435", { allowLoopbackTunnel: true }),
    "http://127.0.0.1:11435/v1"
  );
});

test("provider config points OpenClaw at the direct OpenAI-compatible model endpoint", () => {
  const config = buildQwenProviderConfig({
    baseUrl: "http://100.122.207.66:8000/v1",
    modelId: "qwen3-coder:30B"
  });
  assert.equal(config.baseUrl, "http://100.122.207.66:8000/v1");
  assert.equal(config.api, "openai-completions");
  assert.equal(config.request.allowPrivateNetwork, true);
  assert.equal(config.models[0].id, "qwen3-coder:30B");
  assert.equal(config.models[0].reasoning, true);
  assert.equal(config.models[0].compat.supportsReasoningEffort, true);
  assert.equal(config.models[0].compat.maxTokensField, "max_completion_tokens");
});

test("agent lookup selects only the requested OpenClaw agent", () => {
  assert.equal(findAgentIndex([{ id: "main" }, { id: "ark-unity" }], "ark-unity"), 1);
  assert.equal(findAgentIndex([{ id: "main" }], "ark-unity"), -1);
});

test("provider config path preserves the provider id without literal quote characters", () => {
  assert.equal(providerConfigPath("gb10-qwen"), "models.providers.gb10-qwen");
  assert.throws(() => providerConfigPath("gb10.qwen"), /letters, numbers, underscores, and hyphens/i);
});

test("endpoint verification probes model discovery and real chat inference", async () => {
  const requests = [];
  const fetchImpl = async (url, options = {}) => {
    requests.push({ url, options });
    if (url.endsWith("/models")) {
      return new Response(JSON.stringify({
        object: "list",
        data: [{ id: "qwen3-coder:30B" }]
      }), { status: 200 });
    }
    return new Response(JSON.stringify({
      choices: [{ message: { content: "ARK_QWEN_ENDPOINT_OK" } }]
    }), { status: 200 });
  };
  const result = await verifyQwenEndpoint({
    baseUrl: "http://gb10.test:8000/v1",
    modelId: "qwen3-coder:30B",
    fetchImpl
  });
  assert.equal(result.testContent, "ARK_QWEN_ENDPOINT_OK");
  assert.deepEqual(requests.map((item) => item.url), [
    "http://gb10.test:8000/v1/models",
    "http://gb10.test:8000/v1/chat/completions"
  ]);
  const completionRequest = JSON.parse(requests[1].options.body);
  assert.equal(completionRequest.reasoning_effort, "none");
  assert.equal(completionRequest.max_completion_tokens, 64);
});
