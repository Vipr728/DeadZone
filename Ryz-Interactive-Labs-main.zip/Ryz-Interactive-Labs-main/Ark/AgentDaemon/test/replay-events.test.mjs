import assert from "node:assert/strict";
import test from "node:test";

import {
  buildReplayResponse,
  replayRecordsFromPayload
} from "../src/replay-events.mjs";

test("replay records include successful Unity mutations and checks without source contents", () => {
  const records = replayRecordsFromPayload(JSON.stringify({
    actions: [
      {
        type: "write_csharp_script",
        path: "Assets/Scripts/Player.cs",
        content: "secret source should not be persisted"
      },
      {
        type: "set_component_property",
        target: "Player",
        component: "Rigidbody2D",
        property_path: "gravityScale",
        float_value: 0
      },
      { type: "validate_scene" },
      { type: "read_text_file", path: "Assets/Scripts/Player.cs" }
    ]
  }), {
    command: "execute",
    revision: 12
  });

  assert.deepEqual(records.map((record) => record.type), [
    "replay.change",
    "replay.change",
    "replay.check"
  ]);
  assert.equal(records[0].summary, "Wrote C# script Assets/Scripts/Player.cs.");
  assert.equal(records[1].payload.target, "Player");
  assert.equal(records[1].payload.revision, 12);
  assert.equal(JSON.stringify(records).includes("secret source"), false);
});

test("replay response filters ordinary run chatter and preserves sequence", () => {
  const response = buildReplayResponse({
    id: "run-1",
    status: "complete",
    title: "Build level",
    events: [
      { sequence: 1, type: "runner.started", summary: "Started", timestamp: "t1" },
      { sequence: 2, type: "replay.change", summary: "Created Player.", timestamp: "t2" },
      { sequence: 3, type: "replay.check", summary: "Validated scene.", timestamp: "t3" }
    ]
  });

  assert.equal(response.event_count, 2);
  assert.deepEqual(response.events.map((event) => event.sequence), [2, 3]);
});
