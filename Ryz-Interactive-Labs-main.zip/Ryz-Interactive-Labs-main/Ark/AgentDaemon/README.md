# Ark OpenClaw Adapter

Compatibility backend between the unchanged Ark Unity UI and OpenClaw.

## Architecture

- Unity continues to call `http://127.0.0.1:47391/agent` and the existing async run endpoints.
- `AgentDaemon` now adapts each Ark run to `openclaw agent --json`.
- OpenClaw owns planning, model selection, tool use, sessions, and the autonomous loop.
- `openclaw-unity.mjs` gives OpenClaw the existing typed Unity bridge commands for scene, asset, compiler, Play Mode, validation, and Game view work.
- Each request gets an `atomic`, `focused`, or `complex` execution profile. The profile controls thinking level, bootstrap context, initial context budget, and expected tool-turn budget.
- Atomic editor requests use semantic bridge commands such as `create-scene`, which batch mutation and required validation into one OpenClaw tool call.
- Multi-feature requests are promoted to the complex profile; comma-separated gameplay feature lists no longer inherit the focused six-turn budget.
- Mutating runs must return an explicit completion status. Recoverable incomplete results automatically continue in the same OpenClaw session (one focused retry or two complex retries) instead of requiring another user prompt.
- Compiler failures receive a dedicated repair loop (up to four focused or five complex continuations). Errors in editable `Assets/` or embedded Ark package source must be repaired automatically; only credentials, external/read-only dependencies, or approval-gated changes may be handed back with concrete user instructions.
- New component workflows use the `compile-attach` semantic command. Compilation/domain reload, attachment, validation, Play Mode entry, Game view capture, and Play Mode exit are awaited as separate lifecycle steps, with exact Bee compiler diagnostics surfaced before attachment.
- Project memory and the complete Unity action schema use progressive disclosure instead of being injected into every prompt.
- Run state, progress events, cancellation, daemon auth, and response JSON remain compatible with the existing Unity chat window.

The old custom OpenAI tool loop is no longer used.

## Prerequisites

- OpenClaw installed and onboarded with a working model provider.
- Node.js supported by the installed OpenClaw release.
- The Unity editor open with the Ark bridge running.

Current OpenClaw install:

```bash
npm install -g openclaw@latest
openclaw onboard
```

## One-time project setup

Register a dedicated OpenClaw agent whose workspace is the Unity project, configure
the loopback Gateway, and install/start its user service:

```bash
cd AgentDaemon
npm run setup:openclaw
```

The default agent id is `ark-unity`. Override it with `AGENT_OPENCLAW_AGENT`.
The setup command is additive: it does not replace or delete other OpenClaw agents.
It limits the Ark agent to the filesystem/runtime tools it needs and disables unrelated
skills so their schemas do not consume every run's token budget.
Gateway turns use an explicit per-run session key, so interrupted or concurrent Ark
runs do not share the agent's main transcript lock.
If OpenClaw reports `pairing required` on the first Gateway agent call, approve the
exact pending local CLI device with `openclaw devices approve <request-id>`.
The repository-root `IDENTITY.md`, `SOUL.md`, `TOOLS.md`, `USER.md`, and
`HEARTBEAT.md` provide the project-scoped OpenClaw workspace context; local
`.openclaw/` state is ignored.

## GB10 Qwen model

OpenClaw remains Ark's agent orchestrator, but the `ark-unity` agent can be
pinned to an OpenAI-compatible Qwen server running on the GB10. The setup
command refuses Ark, OpenClaw Gateway, and known control-plane ports. Before it
writes any OpenClaw configuration, it calls the model server's own `/v1/models`
and `/v1/chat/completions` routes and verifies a real inference.

If vLLM is exposed privately with Tailscale Serve:

```bash
cd AgentDaemon
ARK_GB10_QWEN_BASE_URL=https://promaxgb10-8525.taila4d506.ts.net/v1 \
ARK_GB10_QWEN_MODEL=qwen3.6-35b-a3b \
npm run setup:gb10-qwen
```

The safer immediate configuration keeps vLLM on GB10 loopback and creates an
SSH tunnel:

```bash
ssh -N -L 127.0.0.1:18000:127.0.0.1:8000 \
  dell@100.122.207.66
```

Then, in another terminal:

```bash
cd AgentDaemon
ARK_GB10_QWEN_BASE_URL=http://127.0.0.1:18000/v1 \
ARK_GB10_QWEN_ALLOW_LOOPBACK_TUNNEL=1 \
ARK_GB10_QWEN_MODEL=qwen3.6-35b-a3b \
npm run setup:gb10-qwen
```

The dedicated local port `18000` matters: `127.0.0.1:11434` on this Mac is its
local Ollama instance and is not proof that inference is running on the GB10.
The GB10 model endpoint must be reachable without application-level
authentication; use Tailscale ACLs or the SSH tunnel to restrict access.

## Run

```bash
cd AgentDaemon
npm run server
curl http://127.0.0.1:47391/health
```

In Unity, use the existing `Tools > Ark > Agent Backend` controls. No Unity UI changes are required.

## Environment

- `AGENT_OPENCLAW_BIN` optional absolute path to the OpenClaw executable.
- `AGENT_OPENCLAW_AGENT` default: `ark-unity`.
- `AGENT_OPENCLAW_MODE` default: `gateway`; set `local` only for compatibility with an OpenClaw install that has no Gateway.
- `AGENT_OPENCLAW_GATEWAY_URL` optional explicit Gateway WebSocket URL.
- `AGENT_OPENCLAW_MODEL` optional per-run model override only in execution modes
  where the installed OpenClaw CLI explicitly supports it. Gateway mode uses
  the model pinned on `ark-unity`, including the GB10 Qwen configuration.
- `AGENT_OPENCLAW_TIMEOUT_SECONDS` default: `1800`.
- `AGENT_DAEMON_HOST` default: `127.0.0.1`.
- `AGENT_DAEMON_PORT` default: `47391`.
- `AGENT_UNITY_BRIDGE_URL` default: `http://127.0.0.1:47392`.
- `AGENT_UNITY_BRIDGE_TOKEN` optional bridge bearer token.
- `AGENT_PROJECT_ROOT` Unity project root.
- `ARK_DAEMON_TOKEN` or `AGENT_DAEMON_TOKEN` optional Ark backend bearer token.
- `ARK_REQUIRE_AUTH` or `AGENT_DAEMON_REQUIRE_AUTH` requires daemon auth.
- `OPENAI_API_KEY` remains an optional provider credential forwarded to OpenClaw; OpenClaw auth profiles also work.

The existing Unity model field cannot override the pinned `ark-unity` model in
Gateway mode. This prevents a stale UI value from silently routing inference
away from the verified GB10 endpoint.

## Unity-compatible API

- `POST /agent` runs synchronously and returns `{ message, plan, progress, actions }`.
- `POST /v1/runs` starts an asynchronous OpenClaw run.
- `GET /v1/runs/{run_id}` returns status, progress events, result, and error.
- `POST /v1/runs/{run_id}/stop` cancels the OpenClaw process.
- `GET /health` reports Unity and OpenClaw readiness.
- `GET /ready` responds as soon as the adapter can accept requests and reports
  `backend.checking` while the initial OpenClaw readiness probe finishes.

Completed run snapshots and OpenClaw progress trails are stored under
`Library/AgenticGamedev/AgentDaemonRuns`.

## Verification

```bash
cd AgentDaemon
npm test
node --check src/server.mjs
node --check src/openclaw-client.mjs
node --check src/openclaw-unity.mjs
node --check src/configure-gb10-qwen.mjs
```
