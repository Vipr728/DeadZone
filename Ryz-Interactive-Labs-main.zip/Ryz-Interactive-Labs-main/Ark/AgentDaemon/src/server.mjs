import crypto from "node:crypto";
import fs from "node:fs/promises";
import http from "node:http";
import path from "node:path";
import process from "node:process";
import { fileURLToPath } from "node:url";

import { OpenClawClient } from "./openclaw-client.mjs";
import { buildReplayResponse } from "./replay-events.mjs";
import {
  buildOpenClawRunPrompt,
  buildRecoveryPrompt,
  responseHasCompilerFailure,
  responseNeedsRecovery,
  responseRequiresUserAction,
  selectTaskProfile
} from "./task-profile.mjs";
import { UnityBridgeClient } from "./unity-bridge-client.mjs";

const PACKAGE_VERSION = "0.2.0";
const DEFAULT_HOST = process.env.AGENT_DAEMON_HOST || "127.0.0.1";
const DEFAULT_PORT = Number(process.env.AGENT_DAEMON_PORT || 47391);
const DEFAULT_MODEL = process.env.AGENT_OPENCLAW_MODEL ||
  process.env.AGENT_OPENAI_MODEL ||
  process.env.OPENAI_MODEL ||
  "";
const PROJECT_ROOT = resolveProjectRoot();
const RUN_DIR = path.resolve(
  process.env.AGENT_DAEMON_RUN_DIR ||
  path.join(PROJECT_ROOT, "Library", "AgenticGamedev", "AgentDaemonRuns")
);
const OPENCLAW_UNITY_CLI = fileURLToPath(new URL("./openclaw-unity.mjs", import.meta.url));
const DAEMON_TOKEN = process.env.ARK_DAEMON_TOKEN || process.env.AGENT_DAEMON_TOKEN || "";
const REQUIRE_DAEMON_AUTH = isEnabled(process.env.ARK_REQUIRE_AUTH) ||
  isEnabled(process.env.AGENT_DAEMON_REQUIRE_AUTH) ||
  process.env.NODE_ENV === "production";
const PROGRESS_POLL_MS = 250;

const bridge = new UnityBridgeClient();
const openclaw = new OpenClawClient();
const runs = new Map();
let daemonServer = null;
let shutdownStarted = false;

async function main() {
  validateProductionConfig();
  await loadPersistedRuns();

  const server = http.createServer((request, response) => {
    handleRequest(request, response).catch((error) => {
      writeJson(response, 500, {
        ok: false,
        error: error?.message || String(error)
      });
    });
  });
  daemonServer = server;

  server.listen(DEFAULT_PORT, DEFAULT_HOST, () => {
    process.stdout.write(`Ark OpenClaw adapter listening at http://${DEFAULT_HOST}:${DEFAULT_PORT}\n`);
    openclaw.probe();
  });
}

function shutdown(signal) {
  if (shutdownStarted) {
    return;
  }
  shutdownStarted = true;
  for (const run of runs.values()) {
    if (run.status === "running") {
      run.abortController?.abort();
    }
  }

  const forceExit = setTimeout(() => process.exit(0), 5000);
  forceExit.unref();
  if (!daemonServer) {
    process.exit(0);
    return;
  }
  daemonServer.close(() => process.exit(0));
  process.stderr.write(`Ark OpenClaw adapter shutting down after ${signal}.\n`);
}

async function handleRequest(request, response) {
  const url = new URL(request.url || "/", `http://${request.headers.host || `${DEFAULT_HOST}:${DEFAULT_PORT}`}`);
  const method = request.method || "GET";

  if (method === "OPTIONS") {
    writeCors(response, 204);
    response.end();
    return;
  }

  if (method === "GET" && url.pathname === "/health") {
    const [unity, backend] = await Promise.all([
      safeUnityHealth(),
      probeOpenClawForStatus()
    ]);
    writeJson(response, 200, {
      ok: true,
      result: "Ark OpenClaw adapter is running.",
      version: PACKAGE_VERSION,
      engine: "openclaw",
      cwd: process.cwd(),
      project_root: PROJECT_ROOT,
      run_dir: RUN_DIR,
      bridge_url: bridge.baseUrl,
      production_ready: getProductionReadiness(backend),
      backend,
      unity
    });
    return;
  }

  if (method === "GET" && url.pathname === "/ready") {
    const backend = await probeOpenClawForStatus();
    const acceptingRequests = backend.ready || backend.checking;
    writeJson(response, acceptingRequests ? 200 : 503, {
      ok: acceptingRequests,
      result: backend.ready
        ? "Ark OpenClaw adapter is ready."
        : backend.checking
          ? "Ark OpenClaw adapter is accepting requests while OpenClaw readiness refreshes."
        : "Ark OpenClaw adapter needs OpenClaw setup.",
      version: PACKAGE_VERSION,
      engine: "openclaw",
      cwd: process.cwd(),
      project_root: PROJECT_ROOT,
      run_dir: RUN_DIR,
      bridge_url: bridge.baseUrl,
      backend
    });
    return;
  }

  if (!isAuthorized(request)) {
    writeJson(response, 401, {
      ok: false,
      error: "Unauthorized Ark AgentDaemon request."
    });
    return;
  }

  if (method === "POST" && url.pathname === "/agent") {
    const body = await readJsonBody(request);
    const run = createRun(body?.prompt || "Agent backend request");
    try {
      const result = await executeAgentRequest(run, body, extractApiKey(request), { waitForResult: true });
      writeJson(response, 200, result);
    } catch (error) {
      failRun(run, error);
      writeJson(response, 500, backendFailure(error));
    }
    return;
  }

  if (method === "POST" && url.pathname === "/v1/runs") {
    const body = await readJsonBody(request);
    const run = createRun(body?.prompt || "Agent run");
    executeAgentRequest(run, body, extractApiKey(request), { waitForResult: false }).catch((error) => {
      failRun(run, error);
    });
    writeJson(response, 202, publicRun(run));
    return;
  }

  const runMatch = url.pathname.match(/^\/v1\/runs\/([^/]+)$/);
  if (method === "GET" && runMatch) {
    const run = runs.get(decodeURIComponent(runMatch[1]));
    if (!run) {
      writeJson(response, 404, { ok: false, error: "Unknown run id." });
      return;
    }

    writeJson(response, 200, publicRun(run));
    return;
  }

  const replayMatch = url.pathname.match(/^\/v1\/runs\/([^/]+)\/replay$/);
  if (method === "GET" && replayMatch) {
    const run = runs.get(decodeURIComponent(replayMatch[1]));
    if (!run) {
      writeJson(response, 404, { ok: false, error: "Unknown run id." });
      return;
    }

    writeJson(response, 200, buildReplayResponse(run));
    return;
  }

  const stopMatch = url.pathname.match(/^\/v1\/runs\/([^/]+)\/stop$/);
  if (method === "POST" && stopMatch) {
    const run = runs.get(decodeURIComponent(stopMatch[1]));
    if (!run) {
      writeJson(response, 404, { ok: false, error: "Unknown run id." });
      return;
    }

    run.abortController.abort();
    run.status = "canceled";
    appendRunEvent(run, "runner.canceled", "Run canceled by client.");
    persistRun(run).catch(() => {});
    writeJson(response, 200, publicRun(run));
    return;
  }

  writeJson(response, 404, {
    ok: false,
    error: `Unknown Ark AgentDaemon endpoint: ${method} ${url.pathname}`
  });
}

async function probeOpenClawForStatus() {
  const pendingProbe = openclaw.probe();
  let timer;
  try {
    return await Promise.race([
      pendingProbe,
      new Promise((resolve) => {
        timer = setTimeout(() => resolve({
          ok: true,
          ready: false,
          checking: true,
          engine: "openclaw",
          binary: openclaw.binary,
          mode: openclaw.mode,
          agent_id: openclaw.agentId,
          warning: "OpenClaw readiness check is still running."
        }), 100);
        timer.unref();
      })
    ]);
  } finally {
    clearTimeout(timer);
  }
}

function resolveProjectRoot() {
  if (process.env.AGENT_PROJECT_ROOT) {
    return path.resolve(process.env.AGENT_PROJECT_ROOT);
  }

  const cwd = process.cwd();
  return path.basename(cwd) === "AgentDaemon" ? path.resolve(cwd, "..") : cwd;
}

function createRun(title) {
  const run = {
    id: crypto.randomUUID(),
    title: title || "Agent run",
    status: "queued",
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
    events: [],
    result: null,
    error: "",
    abortController: new AbortController()
  };
  runs.set(run.id, run);
  appendRunEvent(run, "runner.created", "I queued the request and am starting the OpenClaw agent.");
  persistRun(run).catch(() => {});
  return run;
}

async function executeAgentRequest(run, requestBody, requestApiKey, { waitForResult }) {
  const work = runAgent(run, requestBody, requestApiKey);
  if (!waitForResult) {
    work.catch((error) => failRun(run, error));
    return publicRun(run);
  }

  return work;
}

async function runAgent(run, requestBody, requestApiKey) {
  run.status = "running";
  appendRunEvent(run, "runner.started", "I’m preparing OpenClaw with the project rules and live Unity bridge.");

  const prompt = normalizeText(requestBody?.prompt);
  const context = normalizeText(requestBody?.context);
  if (!prompt) {
    throw new Error("/agent requires prompt.");
  }

  const profile = selectTaskProfile(prompt);
  const unityHealth = await safeUnityHealth();
  appendRunEvent(run, "context.loaded", `I selected the ${profile.kind} OpenClaw path and checked the live Unity bridge.`, {
    unity_ok: unityHealth.ok !== false,
    scene: unityHealth.scene || unityHealth?.payload?.scene || "",
    task_scale: profile.kind,
    thinking: profile.thinking,
    bootstrap_context: profile.bootstrapContextMode,
    tool_turn_budget: profile.maxToolTurns
  });

  const progressFile = path.join(RUN_DIR, `${run.id}.openclaw-progress.jsonl`);
  const stopProgressWatcher = startProgressWatcher(run, progressFile);
  appendRunEvent(run, "openclaw.started", "OpenClaw is now running the task with Ark’s Unity tools.", {
    agent_id: openclaw.agentId,
    mode: openclaw.mode,
    task_scale: profile.kind
  });

  let openclawResult;
  let rawResponse;
  let recoveryAttempts = 0;
  const runOptions = {
    sessionId: run.id,
    model: normalizeText(requestBody?.model) || DEFAULT_MODEL,
    cwd: PROJECT_ROOT,
    signal: run.abortController.signal,
    env: {
      ARK_OPENCLAW_PROJECT_ROOT: PROJECT_ROOT,
      ARK_OPENCLAW_UNITY_CLI: OPENCLAW_UNITY_CLI,
      ARK_OPENCLAW_PROGRESS_FILE: progressFile,
      AGENT_UNITY_BRIDGE_TIMEOUT_MS: process.env.AGENT_UNITY_BRIDGE_TIMEOUT_MS || "10000",
      OPENCLAW_SESSION: `ark:${run.id}`,
      ...(requestApiKey ? { OPENAI_API_KEY: stripBearerPrefix(requestApiKey) } : {})
    }
  };
  try {
    openclawResult = await openclaw.run({
      message: buildOpenClawRunPrompt({
        profile,
        prompt,
        context,
        unityHealth,
        runId: run.id,
        progressFile,
        projectRoot: PROJECT_ROOT,
        unityCli: OPENCLAW_UNITY_CLI,
        bridgeUrl: bridge.baseUrl
      }),
      ...runOptions,
      idempotencyKey: run.id,
      thinking: profile.thinking,
      bootstrapContextMode: profile.bootstrapContextMode
    });
    rawResponse = parseBackendJson(openclawResult.text);

    while (responseNeedsRecovery(rawResponse, profile)) {
      const compilerFailure = responseHasCompilerFailure(rawResponse);
      const maxAttempts = compilerFailure
        ? profile.maxCompilerRecoveryAttempts
        : profile.maxRecoveryAttempts;
      if (responseRequiresUserAction(rawResponse) || recoveryAttempts >= maxAttempts) {
        break;
      }
      recoveryAttempts += 1;
      appendRunEvent(
        run,
        compilerFailure ? "runner.compiler_repair_started" : "runner.recovery_started",
        compilerFailure
          ? `Unity reported a compiler failure, so Ark is debugging and recompiling automatically (${recoveryAttempts}/${maxAttempts}).`
          : `The result was incomplete, so Ark is continuing automatically (${recoveryAttempts}/${maxAttempts}).`,
        { attempt: recoveryAttempts, max_attempts: maxAttempts, task_scale: profile.kind, compiler_repair: compilerFailure }
      );
      openclawResult = await openclaw.run({
        message: buildRecoveryPrompt({
          attempt: recoveryAttempts,
          maxAttempts,
          compilerFailure
        }),
        ...runOptions,
        idempotencyKey: `${run.id}:recovery:${recoveryAttempts}`,
        thinking: profile.kind === "complex" ? "medium" : "low",
        bootstrapContextMode: "lightweight"
      });
      rawResponse = parseBackendJson(openclawResult.text);
    }
  } finally {
    await stopProgressWatcher();
  }

  if (responseNeedsRecovery(rawResponse, profile)) {
    const blocker = normalizeText(rawResponse?.blocker || rawResponse?.message) ||
      "OpenClaw returned an incomplete result.";
    const userAction = normalizeText(rawResponse?.user_action) ||
      (responseHasCompilerFailure(rawResponse)
        ? `Automatic compiler repair was exhausted. Resolve the reported diagnostic, then rerun the request: ${blocker}`
        : "Resolve the reported external blocker, then rerun the request.");
    throw new Error(
      `OpenClaw could not complete the request after ${recoveryAttempts} automatic recovery attempt${recoveryAttempts === 1 ? "" : "s"}: ${blocker} ` +
      `User action required: ${userAction}`
    );
  }

  const response = normalizeBackendResponse(rawResponse);
  appendBackendResponseEvents(run, response);
  run.status = "complete";
  run.result = response;
  appendRunEvent(run, "runner.complete", "OpenClaw finished and returned the final Ark response.", {
    engine: "openclaw",
    task_scale: profile.kind,
    recovery_attempts: recoveryAttempts,
    model_override_applied: openclawResult.model_override_applied,
    proposed_actions: 0
  });
  await persistRun(run);
  return response;
}

function startProgressWatcher(run, progressFile) {
  let consumedLines = 0;
  let stopped = false;
  let reading = Promise.resolve();

  const readNewEvents = async () => {
    try {
      const text = await fs.readFile(progressFile, "utf8");
      const lines = text.split("\n").filter(Boolean);
      for (const line of lines.slice(consumedLines)) {
        try {
          const event = JSON.parse(line);
          const summary = normalizeText(event?.summary);
          if (summary) {
            const eventType = normalizeText(event?.type) || "agent.progress";
            const eventPayload = event?.payload && typeof event.payload === "object"
              ? event.payload
              : {};
            appendRunEvent(run, eventType, summary, {
              engine: "openclaw",
              ...eventPayload
            });
          }
        } catch {
          // Ignore a partial or malformed progress line.
        }
      }
      consumedLines = lines.length;
    } catch (error) {
      if (error?.code !== "ENOENT") {
        appendRunEvent(run, "openclaw.progress_warning", `Could not read OpenClaw progress: ${error.message}`);
      }
    }
  };

  const interval = setInterval(() => {
    if (!stopped) {
      reading = reading.then(readNewEvents);
    }
  }, PROGRESS_POLL_MS);
  interval.unref();

  return async () => {
    stopped = true;
    clearInterval(interval);
    await reading;
    await readNewEvents();
  };
}

function parseBackendJson(content) {
  const value = normalizeText(content);
  if (!value) {
    throw new Error("OpenClaw returned an empty final response.");
  }

  try {
    return JSON.parse(value);
  } catch {
    const withoutFence = value
      .replace(/^```(?:json)?\s*/i, "")
      .replace(/\s*```$/i, "");
    try {
      return JSON.parse(withoutFence);
    } catch {
      const match = withoutFence.match(/\{[\s\S]*\}/);
      if (match) {
        return JSON.parse(match[0]);
      }
    }
  }

  throw new Error("OpenClaw final response was not Ark backend JSON.");
}

function normalizeBackendResponse(value) {
  const response = value && typeof value === "object" ? value : {};
  return {
    message: normalizeText(response.message) || "OpenClaw completed the Ark run.",
    plan: normalizeStringArray(response.plan),
    progress: normalizeStringArray(response.progress),
    actions: []
  };
}

function normalizeStringArray(value) {
  if (!Array.isArray(value)) {
    return [];
  }
  return value.map((item) => normalizeText(item)).filter(Boolean);
}

function appendBackendResponseEvents(run, response) {
  for (const note of normalizeStringArray(response?.progress)) {
    appendRunEvent(run, "agent.progress", note, { engine: "openclaw" });
  }
  const message = normalizeText(response?.message);
  if (message) {
    appendRunEvent(run, "agent.message", message, { engine: "openclaw" });
  }
}

function backendFailure(error) {
  return {
    message: `Ark OpenClaw request failed: ${formatErrorWithCause(error)}`,
    plan: [],
    progress: ["OpenClaw stopped before completing the Unity workflow."],
    actions: []
  };
}

function failRun(run, error) {
  if (!run || run.status === "canceled") {
    return;
  }
  run.status = "failed";
  run.error = formatErrorWithCause(error);
  appendRunEvent(run, "runner.failed", `OpenClaw stopped before finishing: ${run.error}`);
  persistRun(run).catch(() => {});
}

function formatErrorWithCause(error) {
  if (!error) {
    return "unknown error";
  }
  const parts = [];
  let current = error;
  for (let depth = 0; current && depth < 4; depth++) {
    const message = normalizeText(current.message || String(current));
    if (message && !parts.includes(message)) {
      parts.push(message);
    }
    current = current.cause;
  }
  return parts.length > 0 ? parts.join(" | Cause: ") : String(error);
}

async function safeUnityHealth() {
  try {
    return await bridge.health();
  } catch (error) {
    return { ok: false, error: error?.message || String(error) };
  }
}

async function persistRun(run) {
  await fs.mkdir(RUN_DIR, { recursive: true });
  const file = path.join(RUN_DIR, `${run.id}.json`);
  await fs.writeFile(file, `${JSON.stringify(publicRun(run), null, 2)}\n`, "utf8");
}

async function loadPersistedRuns() {
  await fs.mkdir(RUN_DIR, { recursive: true });
  let files = [];
  try {
    files = await fs.readdir(RUN_DIR);
  } catch {
    return;
  }

  for (const fileName of files) {
    if (!fileName.endsWith(".json")) {
      continue;
    }
    try {
      const text = await fs.readFile(path.join(RUN_DIR, fileName), "utf8");
      const run = hydrateRun(JSON.parse(text));
      if (!run) {
        continue;
      }
      if (run.status === "queued" || run.status === "running") {
        run.status = "failed";
        run.error = "Ark AgentDaemon restarted before this OpenClaw run finished.";
        appendRunEvent(run, "runner.recovered_failed", run.error);
      }
      runs.set(run.id, run);
      await persistRun(run);
    } catch {
      // Ignore malformed recovery files.
    }
  }
}

function hydrateRun(snapshot) {
  const id = normalizeText(snapshot?.run_id || snapshot?.id);
  if (!id) {
    return null;
  }
  return {
    id,
    title: normalizeText(snapshot.title) || "Recovered run",
    status: normalizeText(snapshot.status) || "failed",
    createdAt: normalizeText(snapshot.created_at || snapshot.createdAt) || new Date().toISOString(),
    updatedAt: normalizeText(snapshot.updated_at || snapshot.updatedAt) || new Date().toISOString(),
    events: normalizeEventSequences(snapshot.events),
    result: snapshot.result || null,
    error: normalizeText(snapshot.error),
    abortController: new AbortController()
  };
}

function appendRunEvent(run, type, summary, payload = {}) {
  run.updatedAt = new Date().toISOString();
  if (!Array.isArray(run.events)) {
    run.events = [];
  }
  run.events.push({
    sequence: run.events.length + 1,
    type,
    summary,
    payload,
    timestamp: run.updatedAt
  });
  persistRun(run).catch(() => {});
}

function normalizeEventSequences(value) {
  const events = Array.isArray(value) ? value : [];
  return events.map((event, index) => ({
    ...(event && typeof event === "object" ? event : {}),
    sequence: Number.isFinite(Number(event?.sequence)) ? Number(event.sequence) : index + 1
  }));
}

function publicRun(run) {
  return {
    ok: run.status !== "failed",
    run_id: run.id,
    status: run.status,
    title: run.title,
    created_at: run.createdAt,
    updated_at: run.updatedAt,
    events: run.events,
    result: run.result,
    error: run.error
  };
}

async function readJsonBody(request) {
  const chunks = [];
  for await (const chunk of request) {
    chunks.push(chunk);
  }
  const text = Buffer.concat(chunks).toString("utf8").trim();
  return text ? JSON.parse(text) : {};
}

function extractApiKey(request) {
  const explicit = normalizeText(request.headers["x-openai-api-key"] || request.headers["x-api-key"]);
  if (explicit) {
    return explicit;
  }
  const authorization = request.headers.authorization || "";
  if (authorization.toLowerCase().startsWith("bearer ")) {
    const bearer = authorization.slice("bearer ".length).trim();
    return DAEMON_TOKEN && bearer === DAEMON_TOKEN ? "" : bearer;
  }
  return "";
}

function stripBearerPrefix(value) {
  const text = normalizeText(value);
  return text.toLowerCase().startsWith("bearer ") ? text.slice("bearer ".length).trim() : text;
}

function normalizeText(value) {
  return typeof value === "string" ? value.trim() : "";
}

function isEnabled(value) {
  return ["1", "true", "yes", "on"].includes(String(value || "").trim().toLowerCase());
}

function validateProductionConfig() {
  if (REQUIRE_DAEMON_AUTH && !DAEMON_TOKEN) {
    throw new Error("Ark AgentDaemon requires ARK_DAEMON_TOKEN or AGENT_DAEMON_TOKEN when auth is required.");
  }
}

function getProductionReadiness(backend) {
  const warnings = [];
  if (!DAEMON_TOKEN) {
    warnings.push("daemon_auth_disabled");
  }
  if (!process.env.AGENT_UNITY_BRIDGE_TOKEN) {
    warnings.push("unity_bridge_token_not_configured");
  }
  if (!backend?.ready) {
    warnings.push("openclaw_not_ready");
  }
  if (DEFAULT_HOST !== "127.0.0.1" && !DAEMON_TOKEN) {
    warnings.push("non_loopback_host_without_daemon_auth");
  }
  return {
    mode: process.env.NODE_ENV === "production" ? "production" : "development",
    auth_required: REQUIRE_DAEMON_AUTH,
    daemon_auth_configured: Boolean(DAEMON_TOKEN),
    agent_engine: "openclaw",
    openclaw_ready: backend?.ready === true,
    run_store: RUN_DIR,
    warnings
  };
}

function isAuthorized(request) {
  if (!DAEMON_TOKEN) {
    return !REQUIRE_DAEMON_AUTH;
  }
  const headerToken = normalizeText(request.headers["x-ark-daemon-token"] || request.headers["x-agent-daemon-token"]);
  if (headerToken && headerToken === DAEMON_TOKEN) {
    return true;
  }
  const authorization = request.headers.authorization || "";
  return authorization.toLowerCase().startsWith("bearer ") &&
    authorization.slice("bearer ".length).trim() === DAEMON_TOKEN;
}

function writeJson(response, statusCode, payload) {
  const json = `${JSON.stringify(payload, null, 2)}\n`;
  writeCors(response, statusCode);
  response.setHeader("Content-Type", "application/json; charset=utf-8");
  response.setHeader("Content-Length", Buffer.byteLength(json));
  response.end(json);
}

function writeCors(response, statusCode) {
  response.statusCode = statusCode;
  response.setHeader("Access-Control-Allow-Origin", "http://127.0.0.1");
  response.setHeader("Access-Control-Allow-Headers", "authorization, content-type, x-api-key, x-openai-api-key, x-ark-daemon-token, x-agent-daemon-token");
  response.setHeader("Access-Control-Allow-Methods", "GET, POST, OPTIONS");
}

process.on("SIGINT", () => shutdown("SIGINT"));
process.on("SIGTERM", () => shutdown("SIGTERM"));

main().catch((error) => {
  console.error(error);
  process.exitCode = 1;
});
