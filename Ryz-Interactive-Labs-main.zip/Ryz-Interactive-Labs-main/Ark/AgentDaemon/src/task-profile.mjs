const ATOMIC_SCENE_PATTERN =
  /^(?:please\s+)?(?:make|create|add|start|set\s*up)\s+(?:a\s+)?(?:(?:new|empty|blank)\s+)?(?:unity\s+)?scene(?:\s+(?:called|named)\s+["']?([^"']+?)["']?)?[.!]?\s*$/i;

const COMPLEX_SIGNALS = [
  /\b(?:entire|whole|complete|full)\s+(?:game|project|level|system)\b/i,
  /\b(?:set\s*up|create|build|make)\s+(?:a\s+)?(?:new\s+)?project\b/i,
  /\b(?:implement|refactor|debug|investigate|architect|migrate)\b/i,
  /\b(?:code|script|level\s+design|gameplay\s+system|multiplayer|procedural|inventory|save\s+system)\b/i,
  /\b(?:and\s+then|after\s+that|also|multiple|across)\b/i
];

const MUTATION_SIGNAL =
  /\b(?:add|attach|build|change|configure|create|delete|design|edit|fix|implement|make|modify|move|remove|rename|repair|replace|set\s*up|update|wire|write)\b/i;

const INCOMPLETE_SIGNAL =
  /\b(?:not fully finished|not finished|incomplete|could not|unable to|failed to|still needs?|remaining work|not attached|not verified|blocked)\b/i;

const COMPILER_FAILURE_SIGNAL =
  /\b(?:error\s+CS\d{4}|compiler errors?|compilation (?:failed|failure)|script compilation failed|does not compile|could not compile)\b/i;

const EDITABLE_COMPILER_PATH_SIGNAL =
  /(?:^|[\s("'`])(?:Assets|Packages\/com\.ark\.agentic-gamedev)\/[^:\s"'`]+\.cs(?::\(\d+,\d+\)|:\d+)?/im;

const USER_ACTION_BLOCKER_KINDS = new Set([
  "authorization_required",
  "credentials_required",
  "external_dependency",
  "read_only_dependency",
  "user_action_required"
]);

export function selectTaskProfile(prompt) {
  const text = normalizeText(prompt);
  const atomicSceneMatch = text.match(ATOMIC_SCENE_PATTERN);
  if (atomicSceneMatch) {
    return {
      kind: "atomic",
      thinking: "off",
      bootstrapContextMode: "lightweight",
      contextCharBudget: 0,
      maxToolTurns: 1,
      requiresCompletion: false,
      maxRecoveryAttempts: 0,
      maxCompilerRecoveryAttempts: 0,
      semanticCommand: "create-scene",
      sceneName: normalizeSceneName(atomicSceneMatch[1])
    };
  }

  const words = text.split(/\s+/).filter(Boolean).length;
  const lines = text.split(/\r?\n/).filter((line) => line.trim()).length;
  const commaCount = (text.match(/,/g) || []).length;
  const complexSignalCount = COMPLEX_SIGNALS.filter((pattern) => pattern.test(text)).length;
  const requiresCompletion = MUTATION_SIGNAL.test(text) || COMPILER_FAILURE_SIGNAL.test(text);
  if (words > 45 || lines > 4 || commaCount >= 3 || complexSignalCount >= 2) {
    return {
      kind: "complex",
      thinking: "medium",
      bootstrapContextMode: "full",
      contextCharBudget: 20000,
      maxToolTurns: 0,
      requiresCompletion,
      maxRecoveryAttempts: requiresCompletion ? 2 : 0,
      maxCompilerRecoveryAttempts: requiresCompletion ? 5 : 0,
      semanticCommand: "",
      sceneName: ""
    };
  }

  return {
    kind: "focused",
    thinking: "low",
    bootstrapContextMode: "lightweight",
    contextCharBudget: 4000,
    maxToolTurns: 6,
    requiresCompletion,
    maxRecoveryAttempts: requiresCompletion ? 1 : 0,
    maxCompilerRecoveryAttempts: requiresCompletion ? 4 : 0,
    semanticCommand: "",
    sceneName: ""
  };
}

export function buildOpenClawRunPrompt({
  profile,
  prompt,
  runId,
  projectRoot,
  unityCli,
  bridgeUrl,
  progressFile,
  unityHealth,
  context = ""
}) {
  const cli = `node ${shellQuote(unityCli)}`;
  const commonOptions = [
    "--bridge-url",
    shellQuote(bridgeUrl),
    "--bridge-timeout-ms",
    "10000",
    "--progress-file",
    shellQuote(progressFile)
  ].join(" ");
  const health = compactUnityHealth(unityHealth);
  const finalContract = profile.kind === "atomic" ? [
    "Return only JSON, without Markdown fences:",
    "{\"message\":\"short user-facing outcome\",\"plan\":[\"completed high-level step\"],\"progress\":[\"validation evidence\"],\"actions\":[]}",
    "The actions array must be empty because all required actions must be executed before the final response."
  ] : [
    "Return only JSON, without Markdown fences:",
    "{\"message\":\"short user-facing outcome\",\"plan\":[\"completed high-level step\"],\"progress\":[\"validation evidence\"],\"actions\":[],\"completion_status\":\"complete|blocked\",\"blocker_kind\":\"empty when complete; authorization_required|credentials_required|external_dependency|read_only_dependency|user_action_required when blocked\",\"blocker\":\"empty when complete; exact evidence otherwise\",\"user_action\":\"empty when complete; exact user steps otherwise\"}",
    "The actions array must be empty because all required actions must be executed before the final response.",
    "For a mutating request, completion_status may be complete only after requested work and proportional validation succeed. Do not stop at a recoverable compiler, reload, attachment, validation, or Play Mode failure; diagnose, repair, and retry in this same run."
  ];

  if (profile.kind === "atomic" && profile.semanticCommand === "create-scene") {
    const sceneNameOption = profile.sceneName ? ` --name ${shellQuote(profile.sceneName)}` : "";
    const command =
      `${cli} create-scene ${commonOptions}${sceneNameOption}` +
      ` --progress-note ${shellQuote("I’m creating, validating, and saving the new scene.")}`;
    return [
      "You are Ark’s Unity agent running inside OpenClaw.",
      "This is an atomic request. Keep time and tokens proportional to one editor operation.",
      "Do not plan, inspect files, fetch the action schema, read logs, or check compiler diagnostics.",
      "Make exactly one tool call: run the command below with exec.",
      "If it succeeds, immediately return the final JSON response. Do not perform follow-up checks because the semantic command creates, validates, and saves atomically.",
      "",
      `Command: ${command}`,
      "",
      `User request: ${normalizeText(prompt)}`,
      `Current Unity: ${JSON.stringify(health)}`,
      `Ark run id: ${runId}`,
      ...finalContract
    ].join("\n");
  }

  const contextBudget = profile.contextCharBudget || 0;
  const initialContext = truncateText(context, contextBudget);
  const budgetInstruction = profile.maxToolTurns > 0
    ? `Use no more than ${profile.maxToolTurns} tool calls unless a concrete failure or missing dependency makes another call necessary.`
    : "Use as many tool calls as the genuinely complex task requires, while avoiding repeated reads and checks.";

  return [
    "You are Ark’s Unity development agent running inside OpenClaw.",
    "You are the sole executor for the user’s requested game-project changes. Complete and repair the project work yourself; no supervising assistant will edit gameplay scripts, scenes, prefabs, or assets after you stop.",
    `Task scale: ${profile.kind}. Keep tool calls, context, and verification proportional to that scale.`,
    budgetInstruction,
    "Skip update_plan for one-step work. Do not read files, logs, compiler diagnostics, or the full action schema unless the request actually depends on them.",
    "Use progressive disclosure: begin with the supplied Unity health, then request only the narrow live context or source files needed.",
    "",
    "Unity contract:",
    "- Unity is authoritative for scene state, asset wiring, selection, compilation, Play Mode, validation, and Game view.",
    "- Perform Unity/project mutations through the typed Unity bridge CLI. Never edit serialized Unity YAML directly.",
    "- After code changes, rebuild and read compiler diagnostics. After structural scene changes, validate. After runtime changes, smoke-test in Play Mode. After visual changes, capture Game view.",
    "- Every compiler error starts a debug loop: read the exact diagnostic and affected source, verify uncertain Unity/package APIs against installed source, patch, rebuild, and repeat until clean. Escalate only a concrete dependency/credential/approval/read-only blocker, with exact steps the user must take.",
    "- Package changes, project settings changes, destructive deletes, and arbitrary editor method invocation require explicit user authorization.",
    "- Read AGENTS.md and Agent/PROJECT_STATE.md only when the request needs details not present in this prompt or live Unity.",
    "",
    "Unity bridge CLI:",
    `${cli} health ${commonOptions} --progress-note ${shellQuote("I’m checking the live Unity editor.")}`,
    `${cli} context ${commonOptions} --progress-note ${shellQuote("I’m reading the current scene state.")}`,
    `${cli} full-context ${commonOptions} --progress-note ${shellQuote("I’m reading detailed Unity project context.")}`,
    `${cli} schema ${commonOptions} --progress-note ${shellQuote("I’m checking an unfamiliar Unity action shape.")}`,
    `${cli} execute ${commonOptions} --payload-file <backend-response.json> --expected-revision <revision-or--1> --timeout-ms 120000 --progress-note <note>`,
    `${cli} compiler-diagnostics --project-root ${shellQuote(projectRoot)} --progress-note ${shellQuote("I’m checking the latest Unity compilation result.")}`,
    `${cli} compile-attach ${commonOptions} --project-root ${shellQuote(projectRoot)} --target <GameObject> --component <MonoBehaviour> --smoke-test true --capture-game-view true --progress-note <note>`,
    "The execute payload uses the existing BackendResponse JSON shape with an actions array. Batch related actions into one execute call.",
    "After writing a new component, use compile-attach instead of batching rebuild, attachment, and Play Mode actions. It waits through Unity compilation/domain reload, surfaces the exact C# error, attaches only after a clean compile, validates/saves, and performs Play Mode steps separately.",
    "Use the schema command only when you do not know the exact action shape.",
    "",
    `User request: ${normalizeText(prompt)}`,
    `Current Unity: ${JSON.stringify(health)}`,
    initialContext ? `Relevant request context:\n${initialContext}` : "",
    `Project root: ${projectRoot}`,
    `Ark run id: ${runId}`,
    ...finalContract
  ].filter(Boolean).join("\n");
}

export function responseNeedsRecovery(value, profile) {
  if (!profile?.requiresCompletion) {
    return false;
  }
  const response = value && typeof value === "object" ? value : {};
  const status = normalizeText(response.completion_status).toLowerCase();
  const evidence = [
    normalizeText(response.message),
    ...normalizeStringArray(response.plan),
    ...normalizeStringArray(response.progress),
    normalizeText(response.blocker)
  ].join("\n");
  return status !== "complete" || INCOMPLETE_SIGNAL.test(evidence);
}

export function responseHasCompilerFailure(value) {
  const evidence = responseEvidence(value);
  return COMPILER_FAILURE_SIGNAL.test(evidence);
}

export function responseHasEditableCompilerFailure(value) {
  const evidence = responseEvidence(value);
  return responseHasCompilerFailure(value) && EDITABLE_COMPILER_PATH_SIGNAL.test(evidence);
}

export function responseRequiresUserAction(value) {
  const response = value && typeof value === "object" ? value : {};
  const status = normalizeText(response.completion_status).toLowerCase();
  const blockerKind = normalizeText(response.blocker_kind).toLowerCase();
  const userAction = normalizeText(response.user_action);
  if (status !== "blocked" || !USER_ACTION_BLOCKER_KINDS.has(blockerKind) || !userAction) {
    return false;
  }
  return !responseHasEditableCompilerFailure(response);
}

export function buildRecoveryPrompt({ attempt, maxAttempts, compilerFailure = false }) {
  const base = [
    `Automatic completion recovery ${attempt} of ${maxAttempts}.`,
    "Your previous result did not complete the original mutating request. Continue the same task now; do not merely restate the blocker or ask the user to send another prompt.",
    "Inspect the exact failure evidence, make a concrete repair, and retry the failed step.",
  ];
  if (compilerFailure) {
    base.push(
      "This is a compiler-debug continuation. Read the exact diagnostic and affected source, patch the editable source, rebuild, read diagnostics again, and repeat until clean.",
      "For missing/wrong/read-only/ambiguous Unity or package APIs, search and read the installed API source before patching. Do not guess member names.",
      "An error in editable Assets/ or the embedded Packages/com.ark.agentic-gamedev/ source is not a user blocker. Fix it yourself in this run.",
      "Use compiler-diagnostics and compile-attach for new components; compilation must be clean before attachment."
    );
  } else {
    base.push(
      "For new Unity C# components, use compiler-diagnostics and compile-attach: rebuild/compile must finish cleanly before attachment, and Play Mode transitions must run as separate awaited steps."
    );
  }
  base.push(
    "Return completion_status \"complete\" only after the original request passes proportional validation.",
    "Return \"blocked\" only for a concrete external dependency, credential, read-only dependency, or approval-gated change that you cannot resolve. Include blocker_kind, exact blocker evidence, and an actionable user_action. Never tell the user merely to fix an editable compiler error themselves.",
    "Return only the established Ark JSON response with actions:[]."
  );
  return base.join("\n");
}

export function compactUnityHealth(value) {
  const health = value && typeof value === "object" ? value : {};
  return {
    ok: health.ok !== false,
    project: normalizeText(health.project),
    scene: normalizeText(health.scene),
    scene_path: normalizeText(health.scene_path),
    is_compiling: health.is_compiling === true,
    is_playing: health.is_playing === true,
    revision: Number.isFinite(Number(health.revision)) ? Number(health.revision) : -1
  };
}

function normalizeSceneName(value) {
  const text = normalizeText(value)
    .replace(/[.!?]+$/, "")
    .trim();
  return text.length <= 80 ? text : text.slice(0, 80).trim();
}

function truncateText(value, maxChars) {
  const text = normalizeText(value);
  if (!maxChars || !text) {
    return "";
  }
  if (text.length <= maxChars) {
    return text;
  }
  return `${text.slice(0, maxChars)}\n[Context truncated; retrieve specific live details as needed.]`;
}

function shellQuote(value) {
  return JSON.stringify(String(value));
}

function normalizeText(value) {
  return typeof value === "string" ? value.trim() : "";
}

function normalizeStringArray(value) {
  return Array.isArray(value)
    ? value.map((item) => normalizeText(item)).filter(Boolean)
    : [];
}

function responseEvidence(value) {
  const response = value && typeof value === "object" ? value : {};
  return [
    normalizeText(response.message),
    ...normalizeStringArray(response.plan),
    ...normalizeStringArray(response.progress),
    normalizeText(response.blocker),
    normalizeText(response.user_action)
  ].join("\n");
}
