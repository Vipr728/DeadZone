#!/usr/bin/env node
import { spawnSync } from "node:child_process";
import path from "node:path";
import process from "node:process";
import { fileURLToPath } from "node:url";

import { resolveOpenClawBinary } from "./openclaw-client.mjs";

const DEFAULT_AGENT_ID = "ark-unity";
const DEFAULT_PROVIDER_ID = "gb10-qwen";
const DEFAULT_MODEL_ID = "qwen3.6-35b-a3b";
const CONTROL_PLANE_PORTS = new Set(["47391", "47392", "18789", "8080"]);

export function normalizeQwenBaseUrl(value, { allowLoopbackTunnel = false } = {}) {
  const raw = String(value || "").trim();
  if (!raw) {
    throw new Error(
      "ARK_GB10_QWEN_BASE_URL is required. Use the GB10 OpenAI-compatible model base URL, " +
      "or an SSH tunnel such as http://127.0.0.1:11435/v1."
    );
  }

  let url;
  try {
    url = new URL(raw);
  } catch {
    throw new Error(`Invalid GB10 Qwen model endpoint: ${raw}`);
  }
  if (!["http:", "https:"].includes(url.protocol)) {
    throw new Error("The GB10 Qwen model endpoint must use http or https.");
  }
  if (url.username || url.password || url.search || url.hash) {
    throw new Error("The GB10 Qwen model endpoint must not contain credentials, query parameters, or fragments.");
  }
  if (CONTROL_PLANE_PORTS.has(url.port)) {
    throw new Error(
      `Refusing ${url.origin}: port ${url.port} is an Ark/OpenClaw/control-plane endpoint, not a model endpoint.`
    );
  }
  if (/\/(?:agent|gateway|v1\/runs)(?:\/|$)/i.test(url.pathname)) {
    throw new Error("Refusing an Ark/OpenClaw control endpoint as the Qwen model base URL.");
  }
  const loopback = ["127.0.0.1", "localhost", "::1", "[::1]"].includes(url.hostname.toLowerCase());
  if (loopback && !allowLoopbackTunnel) {
    throw new Error(
      "A loopback URL is accepted only for an explicitly confirmed SSH tunnel. " +
      "Set ARK_GB10_QWEN_ALLOW_LOOPBACK_TUNNEL=1 after forwarding GB10 to a dedicated local port."
    );
  }

  const pathname = url.pathname.replace(/\/+$/, "");
  if (!pathname || pathname === "/") {
    url.pathname = "/v1";
  } else if (pathname !== "/v1") {
    throw new Error("The GB10 Qwen base URL must end in /v1.");
  } else {
    url.pathname = pathname;
  }
  return url.toString().replace(/\/+$/, "");
}

export function buildQwenProviderConfig({
  baseUrl,
  modelId,
  contextWindow = 32768,
  maxTokens = 8192
}) {
  return {
    baseUrl,
    api: "openai-completions",
    request: {
      allowPrivateNetwork: true
    },
    models: [{
      id: modelId,
      name: `GB10 ${modelId}`,
      api: "openai-completions",
      reasoning: true,
      input: ["text"],
      cost: {
        input: 0,
        output: 0,
        cacheRead: 0,
        cacheWrite: 0
      },
      contextWindow,
      maxTokens,
      compat: {
        supportsDeveloperRole: false,
        supportsReasoningEffort: true,
        supportsStrictMode: false,
        supportsUsageInStreaming: false,
        maxTokensField: "max_completion_tokens"
      }
    }]
  };
}

export function findAgentIndex(value, agentId) {
  const list = Array.isArray(value) ? value : value?.value;
  return Array.isArray(list)
    ? list.findIndex((agent) => String(agent?.id || "") === agentId)
    : -1;
}

export function providerConfigPath(providerId) {
  const normalized = String(providerId || "").trim();
  if (!/^[A-Za-z0-9_-]+$/.test(normalized)) {
    throw new Error("ARK_GB10_QWEN_PROVIDER may contain only letters, numbers, underscores, and hyphens.");
  }
  return `models.providers.${normalized}`;
}

export async function verifyQwenEndpoint({
  baseUrl,
  modelId,
  apiKey = "",
  fetchImpl = fetch,
  timeoutMs = 30000
}) {
  const headers = apiKey ? { Authorization: `Bearer ${apiKey}` } : {};
  const modelsResponse = await fetchWithTimeout(
    fetchImpl,
    `${baseUrl}/models`,
    { headers },
    timeoutMs
  );
  const modelsPayload = await readJsonResponse(modelsResponse, "model discovery");
  const modelIds = Array.isArray(modelsPayload?.data)
    ? modelsPayload.data.map((item) => String(item?.id || "")).filter(Boolean)
    : [];
  if (!modelIds.includes(modelId)) {
    throw new Error(
      `GB10 endpoint did not advertise model "${modelId}". Available models: ${modelIds.join(", ") || "(none)"}`
    );
  }

  const completionResponse = await fetchWithTimeout(fetchImpl, `${baseUrl}/chat/completions`, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      ...headers
    },
    body: JSON.stringify({
      model: modelId,
      messages: [{ role: "user", content: "Reply with exactly ARK_QWEN_ENDPOINT_OK" }],
      max_completion_tokens: 64,
      reasoning_effort: "none",
      temperature: 0,
      stream: false
    })
  }, timeoutMs);
  const completionPayload = await readJsonResponse(completionResponse, "test inference");
  const content = String(completionPayload?.choices?.[0]?.message?.content || "").trim();
  if (!content) {
    throw new Error("GB10 Qwen test inference returned no assistant content.");
  }
  return {
    baseUrl,
    modelId,
    advertisedModels: modelIds,
    testContent: content
  };
}

async function main() {
  const binary = resolveOpenClawBinary();
  const agentId = process.env.AGENT_OPENCLAW_AGENT || DEFAULT_AGENT_ID;
  const providerId = process.env.ARK_GB10_QWEN_PROVIDER || DEFAULT_PROVIDER_ID;
  const modelId = process.env.ARK_GB10_QWEN_MODEL || DEFAULT_MODEL_ID;
  const baseUrl = normalizeQwenBaseUrl(process.env.ARK_GB10_QWEN_BASE_URL, {
    allowLoopbackTunnel: isEnabled(process.env.ARK_GB10_QWEN_ALLOW_LOOPBACK_TUNNEL)
  });
  const projectRoot = path.resolve(process.env.AGENT_PROJECT_ROOT || resolveProjectRoot());

  process.stdout.write(`Probing GB10 model discovery at ${baseUrl}/models...\n`);
  const verification = await verifyQwenEndpoint({ baseUrl, modelId });
  process.stdout.write(
    `Verified direct GB10 Qwen inference at ${verification.baseUrl}/chat/completions using ${modelId}.\n`
  );

  const agents = readJson(run(binary, ["config", "get", "agents.list", "--json"], projectRoot).stdout);
  const agentIndex = findAgentIndex(agents, agentId);
  if (agentIndex < 0) {
    throw new Error(`OpenClaw agent "${agentId}" is not configured. Run npm run setup:openclaw first.`);
  }
  const providerConfig = buildQwenProviderConfig({
    baseUrl,
    modelId,
    contextWindow: readPositiveInteger(process.env.ARK_GB10_QWEN_CONTEXT_WINDOW, 32768),
    maxTokens: readPositiveInteger(process.env.ARK_GB10_QWEN_MAX_TOKENS, 8192)
  });
  const modelRef = `${providerId}/${modelId}`;
  const updates = [
    {
      path: providerConfigPath(providerId),
      value: providerConfig
    },
    {
      path: `agents.list[${agentIndex}].model`,
      value: modelRef
    }
  ];
  run(binary, ["config", "set", "--batch-json", JSON.stringify(updates)], projectRoot);
  const configuredModel = readJson(
    run(binary, ["config", "get", `agents.list[${agentIndex}].model`, "--json"], projectRoot).stdout
  );
  if (configuredModel !== modelRef) {
    throw new Error(
      `OpenClaw model pin verification failed: expected ${modelRef}, got ${JSON.stringify(configuredModel)}.`
    );
  }
  run(binary, ["gateway", "restart", "--json"], projectRoot);
  process.stdout.write(
    `Pinned OpenClaw agent "${agentId}" to ${modelRef}. ` +
    `OpenClaw remains the orchestrator; model inference goes to ${baseUrl}/chat/completions.\n`
  );
}

async function fetchWithTimeout(fetchImpl, url, options, timeoutMs) {
  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), timeoutMs);
  try {
    return await fetchImpl(url, { ...options, signal: controller.signal });
  } catch (error) {
    if (error?.name === "AbortError") {
      throw new Error(`Timed out contacting the GB10 model endpoint after ${timeoutMs}ms: ${url}`);
    }
    throw new Error(`Could not contact the GB10 model endpoint ${url}: ${error?.message || error}`);
  } finally {
    clearTimeout(timeout);
  }
}

async function readJsonResponse(response, operation) {
  const text = await response.text();
  let payload;
  try {
    payload = JSON.parse(text);
  } catch {
    throw new Error(`GB10 ${operation} returned non-JSON (${response.status}): ${text.slice(0, 500)}`);
  }
  if (!response.ok) {
    throw new Error(`GB10 ${operation} failed (${response.status}): ${JSON.stringify(payload).slice(0, 1000)}`);
  }
  return payload;
}

function run(binary, args, cwd) {
  const result = spawnSync(binary, args, {
    cwd,
    encoding: "utf8",
    env: process.env
  });
  if (result.error) {
    throw new Error(`Could not run OpenClaw at ${binary}: ${result.error.message}`);
  }
  if (result.status !== 0) {
    throw new Error(`OpenClaw ${args.join(" ")} failed:\n${result.stderr || result.stdout}`);
  }
  return result;
}

function readJson(value) {
  try {
    return JSON.parse(value);
  } catch (error) {
    throw new Error(`OpenClaw returned invalid JSON: ${error.message}`);
  }
}

function resolveProjectRoot() {
  const cwd = process.cwd();
  return path.basename(cwd) === "AgentDaemon" ? path.resolve(cwd, "..") : cwd;
}

function readPositiveInteger(value, fallback) {
  const parsed = Number(value);
  return Number.isInteger(parsed) && parsed > 0 ? parsed : fallback;
}

function isEnabled(value) {
  return /^(?:1|true|yes|on)$/i.test(String(value || ""));
}

if (process.argv[1] && path.resolve(process.argv[1]) === fileURLToPath(import.meta.url)) {
  main().catch((error) => {
    process.stderr.write(`${error.stack || error.message}\n`);
    process.exitCode = 1;
  });
}
