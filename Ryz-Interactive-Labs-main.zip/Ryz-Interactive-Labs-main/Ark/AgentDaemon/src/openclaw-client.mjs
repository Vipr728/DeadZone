import { spawn } from "node:child_process";
import crypto from "node:crypto";
import fs from "node:fs";
import path from "node:path";
import process from "node:process";

const DEFAULT_TIMEOUT_SECONDS = 1800;
const MAX_CAPTURE_CHARS = 10 * 1024 * 1024;

export class OpenClawClient {
  constructor({
    binary = resolveOpenClawBinary(),
    agentId = process.env.AGENT_OPENCLAW_AGENT || "ark-unity",
    mode = process.env.AGENT_OPENCLAW_MODE || "gateway",
    gatewayUrl = process.env.AGENT_OPENCLAW_GATEWAY_URL || "",
    timeoutSeconds = Number(process.env.AGENT_OPENCLAW_TIMEOUT_SECONDS || DEFAULT_TIMEOUT_SECONDS)
  } = {}) {
    this.binary = binary;
    this.agentId = normalizeText(agentId);
    this.mode = normalizeMode(mode);
    this.gatewayUrl = normalizeText(gatewayUrl);
    this.timeoutSeconds = normalizePositiveNumber(timeoutSeconds, DEFAULT_TIMEOUT_SECONDS);
    this.capabilitiesPromise = null;
    this.probeCache = null;
    this.probePromise = null;
    this.probeTtlMs = normalizePositiveNumber(process.env.AGENT_OPENCLAW_PROBE_TTL_MS, 60000);
    this.runQueue = Promise.resolve();
  }

  async probe() {
    const now = Date.now();
    if (this.probeCache) {
      if (now - this.probeCache.timestamp >= this.probeTtlMs && !this.probePromise) {
        this.#refreshProbe();
      }
      return this.probeCache.value;
    }
    if (this.probePromise) {
      return this.probePromise;
    }

    return this.#refreshProbe();
  }

  #refreshProbe() {
    this.probePromise = this.#probeUncached()
      .then((value) => {
        this.probeCache = { timestamp: Date.now(), value };
        return value;
      })
      .finally(() => {
        this.probePromise = null;
      });
    return this.probePromise;
  }

  async #probeUncached() {
    try {
      const [versionResult, capabilities, agentsResult] = await Promise.all([
        runProcess(this.binary, ["--version"], { timeoutMs: 15000 }),
        this.capabilities(),
        runProcess(this.binary, ["agents", "list", "--json"], { timeoutMs: 20000 }),
        this.mode === "gateway"
          ? runProcess(this.binary, this.#gatewayArgs(["call", "health", "--json", "--timeout", "10000"]), {
            timeoutMs: 15000
          })
          : Promise.resolve()
      ]);
      const agents = parseJson(agentsResult.stdout, []);
      const configuredAgent = this.agentId
        ? agents.find((agent) => normalizeText(agent?.id) === this.agentId)
        : null;
      const agentConfigured = !this.agentId || Boolean(configuredAgent);

      return {
        ok: true,
        ready: agentConfigured,
        engine: "openclaw",
        binary: this.binary,
        version: normalizeText(versionResult.stdout || versionResult.stderr),
        mode: this.mode,
        agent_id: this.agentId,
        agent_configured: agentConfigured,
        workspace: normalizeText(configuredAgent?.workspace),
        configured_model: normalizeConfiguredModel(configuredAgent?.model),
        supports_model_override: capabilities.supportsModel,
        warning: agentConfigured
          ? ""
          : `OpenClaw agent "${this.agentId}" is not configured.`
      };
    } catch (error) {
      return {
        ok: false,
        ready: false,
        engine: "openclaw",
        binary: this.binary,
        version: "",
        mode: this.mode,
        agent_id: this.agentId,
        agent_configured: false,
        workspace: "",
        configured_model: "",
        supports_model_override: false,
        warning: formatProcessError(error)
      };
    }
  }

  async capabilities() {
    if (this.mode === "gateway") {
      return {
        supportsModel: false,
        supportsSessionKey: true
      };
    }
    if (!this.capabilitiesPromise) {
      this.capabilitiesPromise = runProcess(this.binary, ["agent", "--help"], { timeoutMs: 15000 })
        .then((result) => {
          const help = `${result.stdout}\n${result.stderr}`;
          return {
            supportsModel: /--model(?:\s|,|<)/.test(help),
            supportsSessionKey: /--session-key(?:\s|,|<)/.test(help)
          };
        })
        .catch((error) => {
          this.capabilitiesPromise = null;
          throw error;
        });
    }

    return this.capabilitiesPromise;
  }

  async run({
    message,
    sessionId,
    idempotencyKey = "",
    model = "",
    thinking = "",
    bootstrapContextMode = "",
    cwd = process.cwd(),
    env = {},
    signal
  }) {
    let releaseQueue;
    const previousRun = this.runQueue;
    const queueGate = new Promise((resolve) => {
      releaseQueue = resolve;
    });
    this.runQueue = previousRun.catch(() => {}).then(() => queueGate);

    try {
      await waitForRunTurn(previousRun, signal);
      return await this.#runUnqueued({
        message,
        sessionId,
        idempotencyKey,
        model,
        thinking,
        bootstrapContextMode,
        cwd,
        env,
        signal
      });
    } finally {
      releaseQueue();
    }
  }

  async #runUnqueued({
    message,
    sessionId,
    idempotencyKey = "",
    model = "",
    thinking = "",
    bootstrapContextMode = "",
    cwd = process.cwd(),
    env = {},
    signal
  }) {
    const prompt = normalizeText(message);
    if (!prompt) {
      throw new Error("OpenClaw requires a non-empty message.");
    }

    const capabilities = await this.capabilities();
    let args;
    if (this.mode === "gateway") {
      const explicitSessionId = normalizeText(String(sessionId || "")) || crypto.randomUUID();
      const params = {
        message: prompt,
        agentId: this.agentId,
        sessionId: explicitSessionId,
        sessionKey: `agent:${this.agentId}:ark-run:${explicitSessionId}`,
        idempotencyKey: normalizeText(idempotencyKey) || explicitSessionId,
        deliver: false,
        timeout: this.timeoutSeconds
      };
      if (normalizeText(model) && capabilities.supportsModel) {
        params.model = normalizeText(model);
      }
      if (normalizeText(thinking)) {
        params.thinking = normalizeText(thinking);
      }
      if (["full", "lightweight"].includes(normalizeText(bootstrapContextMode))) {
        params.bootstrapContextMode = normalizeText(bootstrapContextMode);
      }
      args = this.#gatewayArgs([
        "call",
        "agent",
        "--expect-final",
        "--json",
        "--timeout",
        String((this.timeoutSeconds + 30) * 1000),
        "--params",
        JSON.stringify(params)
      ]);
    } else {
      args = ["agent"];
      if (this.agentId) {
        args.push("--agent", this.agentId);
      }
      if (sessionId) {
        args.push("--session-id", String(sessionId));
      }
      if (normalizeText(model) && capabilities.supportsModel) {
        args.push("--model", normalizeText(model));
      }
      args.push("--message", prompt, "--json", "--timeout", String(this.timeoutSeconds));
      args.push("--local");
    }

    const result = await runProcess(this.binary, args, {
      cwd,
      env: {
        ...process.env,
        ...env
      },
      signal,
      timeoutMs: (this.timeoutSeconds + 60) * 1000
    });
    const envelope = parseOpenClawEnvelope(result.stdout, result.stderr);
    const text = extractOpenClawText(envelope);
    if (!text) {
      throw new Error(`OpenClaw returned no assistant text.${formatStderrSuffix(result.stderr)}`);
    }

    return {
      text,
      envelope,
      diagnostics: normalizeText(result.stderr),
      model_override_applied: Boolean(normalizeText(model) && capabilities.supportsModel)
    };
  }

  #gatewayArgs(args) {
    const result = ["gateway", ...args];
    if (this.gatewayUrl) {
      result.push("--url", this.gatewayUrl);
    }
    return result;
  }
}

function normalizeConfiguredModel(value) {
  if (typeof value === "string") {
    return normalizeText(value);
  }
  return normalizeText(value?.primary || value?.model);
}

async function waitForRunTurn(previousRun, signal) {
  if (signal?.aborted) {
    throw new Error("OpenClaw run was canceled.");
  }
  if (!signal) {
    await previousRun;
    return;
  }

  await new Promise((resolve, reject) => {
    const handleAbort = () => {
      cleanup();
      reject(new Error("OpenClaw run was canceled."));
    };
    const cleanup = () => signal.removeEventListener("abort", handleAbort);
    signal.addEventListener("abort", handleAbort, { once: true });
    previousRun.then(
      () => {
        cleanup();
        resolve();
      },
      (error) => {
        cleanup();
        reject(error);
      }
    );
  });
}

export function extractOpenClawText(envelope) {
  if (!envelope || typeof envelope !== "object") {
    return "";
  }

  const payloads = Array.isArray(envelope.payloads)
    ? envelope.payloads
    : envelope?.result?.payloads;
  const payloadText = Array.isArray(payloads)
    ? payloads
      .map((payload) => normalizeText(payload?.text))
      .filter(Boolean)
      .join("\n")
    : "";
  return payloadText ||
    normalizeText(envelope.finalAssistantVisibleText) ||
    normalizeText(envelope.finalAssistantRawText) ||
    normalizeText(envelope.text);
}

export function parseOpenClawEnvelope(stdout, stderr) {
  const streams = [stdout, stderr].map((value) => typeof value === "string" ? value.trim() : "");
  for (const stream of streams) {
    if (!stream) {
      continue;
    }
    try {
      return JSON.parse(stream);
    } catch {
      // Some OpenClaw local releases write a diagnostic line before the JSON envelope.
    }

    const lines = stream.split(/\r?\n/);
    for (let index = 0; index < lines.length; index++) {
      if (!lines[index].trimStart().startsWith("{")) {
        continue;
      }
      try {
        return JSON.parse(lines.slice(index).join("\n"));
      } catch {
        // Continue in case a later line begins the complete envelope.
      }
    }
  }

  throw new Error("OpenClaw returned invalid JSON on stdout and stderr.");
}

export function resolveOpenClawBinary() {
  const configured = normalizeText(process.env.AGENT_OPENCLAW_BIN || process.env.OPENCLAW_BIN);
  if (configured) {
    return configured;
  }

  const home = normalizeText(process.env.HOME);
  const candidates = [
    home ? path.join(home, ".local", "bin", "openclaw") : "",
    "/opt/homebrew/bin/openclaw",
    "/usr/local/bin/openclaw"
  ].filter(Boolean);
  for (const candidate of candidates) {
    try {
      fs.accessSync(candidate, fs.constants.X_OK);
      return candidate;
    } catch {
      // Continue to the next conventional installation path.
    }
  }

  return "openclaw";
}

async function runProcess(binary, args, {
  cwd = process.cwd(),
  env = process.env,
  signal,
  timeoutMs = 0
} = {}) {
  return new Promise((resolve, reject) => {
    let stdout = "";
    let stderr = "";
    let settled = false;
    let aborted = false;
    let killBackstop = null;
    const detached = process.platform !== "win32";
    const child = spawn(binary, args, {
      cwd,
      env,
      detached,
      stdio: ["ignore", "pipe", "pipe"]
    });

    const finish = (work) => {
      if (settled) {
        return;
      }
      settled = true;
      clearTimeout(timeout);
      clearTimeout(killBackstop);
      signal?.removeEventListener("abort", handleAbort);
      work();
    };
    const terminate = (killSignal) => {
      if (!child.pid || child.killed) {
        return;
      }
      try {
        if (detached) {
          process.kill(-child.pid, killSignal);
        } else {
          child.kill(killSignal);
        }
      } catch {
        // The process may already have exited.
      }
    };
    const handleAbort = () => {
      aborted = true;
      terminate("SIGTERM");
      killBackstop = setTimeout(() => terminate("SIGKILL"), 5000);
      killBackstop.unref();
    };
    const timeout = timeoutMs > 0
      ? setTimeout(() => {
        aborted = true;
        terminate("SIGTERM");
        killBackstop = setTimeout(() => terminate("SIGKILL"), 5000);
        killBackstop.unref();
      }, timeoutMs)
      : null;
    timeout?.unref();

    child.stdout.on("data", (chunk) => {
      stdout = appendBounded(stdout, chunk);
    });
    child.stderr.on("data", (chunk) => {
      stderr = appendBounded(stderr, chunk);
    });
    child.on("error", (error) => {
      finish(() => reject(new Error(`Could not start OpenClaw at ${binary}: ${error.message}`, { cause: error })));
    });
    child.on("exit", (code, exitSignal) => {
      finish(() => {
        if (aborted || signal?.aborted) {
          reject(new Error("OpenClaw run was canceled."));
          return;
        }
        if (code !== 0) {
          reject(new Error(
            `OpenClaw exited with ${exitSignal ? `signal ${exitSignal}` : `code ${code}`}.${formatStderrSuffix(stderr)}`
          ));
          return;
        }
        resolve({ stdout, stderr, code });
      });
    });

    if (signal?.aborted) {
      handleAbort();
    } else {
      signal?.addEventListener("abort", handleAbort, { once: true });
    }
  });
}

function appendBounded(current, chunk) {
  const next = current + chunk.toString("utf8");
  return next.length <= MAX_CAPTURE_CHARS
    ? next
    : next.slice(next.length - MAX_CAPTURE_CHARS);
}

function parseJson(value, fallback) {
  try {
    return JSON.parse(normalizeText(value));
  } catch (error) {
    if (arguments.length > 1) {
      return fallback;
    }
    throw new Error(`OpenClaw returned invalid JSON: ${error.message}`);
  }
}

function normalizeMode(value) {
  return normalizeText(value).toLowerCase() === "gateway" ? "gateway" : "local";
}

function normalizePositiveNumber(value, fallback) {
  const number = Number(value);
  return Number.isFinite(number) && number > 0 ? number : fallback;
}

function normalizeText(value) {
  return typeof value === "string" ? value.trim() : "";
}

function formatStderrSuffix(stderr) {
  const value = normalizeText(stderr);
  return value ? ` ${value.slice(-4000)}` : "";
}

function formatProcessError(error) {
  return normalizeText(error?.message || String(error));
}
