const DEFAULT_URL = process.env.AGENT_CONTROL_PLANE_URL || "http://127.0.0.1:8787";

export class ControlPlaneClient {
  constructor({ baseUrl = DEFAULT_URL, token = process.env.AGENT_CONTROL_PLANE_TOKEN || "" } = {}) {
    this.baseUrl = baseUrl.replace(/\/+$/, "");
    this.token = token;
  }

  async createProject({ projectId, name, repoRoot }) {
    return this.#post("/projects", { projectId, name, repoRoot });
  }

  async registerRunner({ projectId, host = "local", capabilities = [] }) {
    return this.#post("/runners/register", { projectId, host, capabilities });
  }

  async createRun({ projectId, title, prompt }) {
    return this.#post("/runs", { projectId, title, prompt });
  }

  async appendEvent(runId, event) {
    return this.#post(`/runs/${encodeURIComponent(runId)}/events`, event);
  }

  async appendArtifact(runId, artifact) {
    return this.#post(`/runs/${encodeURIComponent(runId)}/artifacts`, artifact);
  }

  async appendApproval(runId, approval) {
    return this.#post(`/runs/${encodeURIComponent(runId)}/approvals`, approval);
  }

  async getInstructions(projectId) {
    return this.#get(`/projects/${encodeURIComponent(projectId)}/instructions`);
  }

  async getPolicies(projectId) {
    return this.#get(`/projects/${encodeURIComponent(projectId)}/policies`);
  }

  async #get(path) {
    const response = await fetch(`${this.baseUrl}${path}`, {
      headers: this.#headers()
    });
    return this.#readJson(response);
  }

  async #post(path, body) {
    const response = await fetch(`${this.baseUrl}${path}`, {
      method: "POST",
      headers: this.#headers({ "Content-Type": "application/json" }),
      body: JSON.stringify(body)
    });
    return this.#readJson(response);
  }

  #headers(extra = {}) {
    const headers = { ...extra };
    if (this.token) {
      headers.Authorization = `Bearer ${this.token}`;
    }
    return headers;
  }

  async #readJson(response) {
    const text = await response.text();
    let payload;
    try {
      payload = JSON.parse(text);
    } catch (error) {
      throw new Error(`Control plane returned non-JSON (${response.status}): ${text}`);
    }

    if (!response.ok) {
      throw new Error(payload.error || `Control plane request failed with status ${response.status}`);
    }

    return payload;
  }
}
