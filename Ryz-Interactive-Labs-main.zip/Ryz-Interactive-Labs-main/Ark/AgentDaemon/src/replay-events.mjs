const MUTATING_ACTION_TYPES = new Set([
  "add_component",
  "add_package",
  "apply_default_sprite",
  "clear_scene",
  "create_folder",
  "create_object",
  "create_prefab_from_selected",
  "create_scene",
  "create_sprite_asset",
  "create_unity_asset",
  "delete_game_object",
  "ensure_components",
  "ensure_unity_workflow",
  "instantiate_prefab",
  "invoke_editor_method",
  "remove_component",
  "remove_package",
  "repair_scene_relationships",
  "save_assets",
  "save_scene",
  "set_asset_property",
  "set_component_property",
  "set_editor_build_scenes",
  "set_object_property",
  "set_player_setting",
  "set_project_setting",
  "set_transform",
  "setup_urp_post_processing",
  "write_csharp_script",
  "write_text_file"
]);

const CHECK_ACTION_TYPES = new Set([
  "capture_game_view",
  "enter_play_mode",
  "exit_play_mode",
  "read_compiler_diagnostics",
  "rebuild_unity",
  "validate_scene"
]);

export function replayRecordsFromPayload(payloadJson, {
  command = "execute",
  revision = -1
} = {}) {
  let payload;
  try {
    payload = typeof payloadJson === "string" ? JSON.parse(payloadJson) : payloadJson;
  } catch {
    return [];
  }
  const actions = Array.isArray(payload?.actions) ? payload.actions : [];
  return actions.flatMap((action, index) => {
    const actionType = normalizeActionType(action?.type);
    const eventType = MUTATING_ACTION_TYPES.has(actionType)
      ? "replay.change"
      : CHECK_ACTION_TYPES.has(actionType)
        ? "replay.check"
        : "";
    if (!eventType) {
      return [];
    }
    return [{
      type: eventType,
      summary: describeAction(actionType, action),
      payload: {
        command,
        action_type: actionType,
        action_index: index,
        target: firstText(action?.target, action?.name),
        path: firstText(action?.path, action?.asset_path),
        component: firstText(action?.component),
        property: firstText(action?.property_path),
        revision: Number.isFinite(Number(revision)) ? Number(revision) : -1
      }
    }];
  });
}

export function buildReplayResponse(run) {
  const events = (Array.isArray(run?.events) ? run.events : [])
    .filter((event) => isReplayEvent(event))
    .map((event, index) => ({
      sequence: Number.isFinite(Number(event?.sequence)) ? Number(event.sequence) : index + 1,
      type: String(event?.type || ""),
      summary: String(event?.summary || ""),
      payload: event?.payload && typeof event.payload === "object" ? event.payload : {},
      timestamp: String(event?.timestamp || "")
    }));
  return {
    ok: run?.status !== "failed",
    run_id: String(run?.id || run?.run_id || ""),
    status: String(run?.status || ""),
    title: String(run?.title || ""),
    event_count: events.length,
    events
  };
}

export function isReplayEvent(event) {
  const type = String(event?.type || "").toLowerCase();
  return type === "replay.change" || type === "replay.check";
}

function describeAction(actionType, action) {
  const target = firstText(action?.target, action?.name);
  const path = firstText(action?.path, action?.asset_path);
  const component = firstText(action?.component);
  const property = firstText(action?.property_path);
  switch (actionType) {
    case "add_component":
      return `Added ${component || "component"} to ${target || "the selected object"}.`;
    case "add_package":
      return `Added Unity package ${firstText(action?.package_id, action?.value) || "(unspecified)"}.`;
    case "apply_default_sprite":
      return `Applied default sprite visuals to ${target || "scene objects"}.`;
    case "clear_scene":
      return "Cleared the active scene.";
    case "create_folder":
      return `Created folder ${path || "(unspecified)"}.`;
    case "create_object":
      return `Created or updated GameObject ${target || "(unnamed)"}.`;
    case "create_prefab_from_selected":
      return `Created prefab ${path || "(unspecified)"} from the selection.`;
    case "create_scene":
      return `Created scene ${path || target || "(unnamed)"}.`;
    case "create_sprite_asset":
      return `Created sprite asset ${path || target || "(unnamed)"}.`;
    case "create_unity_asset":
      return `Created Unity asset ${path || target || "(unnamed)"}.`;
    case "delete_game_object":
      return `Deleted GameObject ${target || "(unspecified)"}.`;
    case "ensure_components":
      return `Ensured required components on ${target || "the selected object"}.`;
    case "ensure_unity_workflow":
      return `Applied Unity workflow ${firstText(action?.name, action?.value) || "setup"}.`;
    case "instantiate_prefab":
      return `Instantiated prefab ${path || "(unspecified)"}.`;
    case "invoke_editor_method":
      return `Ran approved editor method ${firstText(action?.method_name, action?.name) || "(unspecified)"}.`;
    case "remove_component":
      return `Removed ${component || "component"} from ${target || "the selected object"}.`;
    case "remove_package":
      return `Removed Unity package ${firstText(action?.package_id, action?.value) || "(unspecified)"}.`;
    case "repair_scene_relationships":
      return "Repaired scene object relationships and references.";
    case "save_assets":
      return "Saved modified Unity assets.";
    case "save_scene":
      return "Saved the active scene.";
    case "set_asset_property":
      return `Set ${property || "a property"} on asset ${path || target || "(unspecified)"}.`;
    case "set_component_property":
      return `Set ${component || "component"}.${property || "property"} on ${target || "the selected object"}.`;
    case "set_editor_build_scenes":
      return "Updated the Editor Build Settings scene list.";
    case "set_object_property":
      return `Set ${property || "an object property"} on ${target || "the selected object"}.`;
    case "set_player_setting":
      return `Updated Player Setting ${property || "(unspecified)"}.`;
    case "set_project_setting":
      return `Updated project setting ${property || path || "(unspecified)"}.`;
    case "set_transform":
      return `Updated the transform of ${target || "the selected object"}.`;
    case "setup_urp_post_processing":
      return "Configured URP post-processing.";
    case "write_csharp_script":
      return `Wrote C# script ${path || "(unspecified)"}.`;
    case "write_text_file":
      return `Updated file ${path || "(unspecified)"}.`;
    case "capture_game_view":
      return "Captured the Game view for visual verification.";
    case "enter_play_mode":
      return "Entered Play Mode for runtime verification.";
    case "exit_play_mode":
      return "Exited Play Mode after runtime verification.";
    case "read_compiler_diagnostics":
      return "Checked Unity compiler diagnostics.";
    case "rebuild_unity":
      return "Requested a Unity rebuild and script compilation.";
    case "validate_scene":
      return "Validated the active scene.";
    default:
      return `Completed ${actionType.replaceAll("_", " ")}.`;
  }
}

function normalizeActionType(value) {
  return String(value || "").trim().toLowerCase().replaceAll("-", "_").replaceAll(" ", "_");
}

function firstText(...values) {
  for (const value of values) {
    const text = String(value || "").trim();
    if (text) {
      return text;
    }
  }
  return "";
}
