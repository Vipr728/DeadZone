#!/usr/bin/env node
import fs from "node:fs/promises";
import path from "node:path";
import process from "node:process";
import { fileURLToPath } from "node:url";

import { replayRecordsFromPayload } from "./replay-events.mjs";
import { UnityBridgeClient } from "./unity-bridge-client.mjs";

async function main() {
  const [, , command, ...args] = process.argv;
  const bridge = new UnityBridgeClient({
    baseUrl: readOption(
      args,
      "--bridge-url",
      process.env.AGENT_UNITY_BRIDGE_URL || "http://127.0.0.1:47392"
    ),
    timeoutMs: Number(readOption(
      args,
      "--bridge-timeout-ms",
      process.env.AGENT_UNITY_BRIDGE_TIMEOUT_MS || "2500"
    ))
  });
  const progressFile = readOption(
    args,
    "--progress-file",
    process.env.ARK_OPENCLAW_PROGRESS_FILE || ""
  );
  await publishProgress(readOption(args, "--progress-note", ""), progressFile);

  switch (command) {
    case "health":
      return print(await bridge.health());
    case "context":
      return print(await bridge.health());
    case "full-context":
      return print(await bridge.context());
    case "schema":
      return print(await bridge.schema());
    case "logs":
      return print(await bridge.logs());
    case "create-scene":
      return print(await createScene(bridge, args, progressFile));
    case "compiler-diagnostics": {
      const diagnostics = await readCompilerDiagnostics(
        path.resolve(readOption(args, "--project-root", process.env.ARK_OPENCLAW_PROJECT_ROOT || process.cwd()))
      );
      await publishReplayRecords([{
        type: "replay.check",
        summary: diagnostics.ok
          ? "Checked Unity compiler diagnostics; no C# errors were reported."
          : `Checked Unity compiler diagnostics; ${diagnostics.diagnostics.length} error line(s) require repair.`,
        payload: {
          command: "compiler-diagnostics",
          action_type: "read_compiler_diagnostics",
          revision: -1
        }
      }], progressFile);
      return print(diagnostics);
    }
    case "compile-attach":
      return print(await compileAttach(bridge, args, progressFile));
    case "preview":
      return print(await runBridgeCommand(bridge, "unity.actions.preview", args));
    case "readonly":
      return print(await runBridgeCommand(bridge, "unity.actions.execute_readonly", args));
    case "execute":
      return print(await runBridgeCommand(bridge, "unity.actions.execute", args, progressFile));
    default:
      throw new Error(
        `Unknown command: ${command || "(missing)"}. Use health, context, full-context, schema, logs, create-scene, compiler-diagnostics, compile-attach, preview, readonly, or execute.`
      );
  }
}

async function createScene(bridge, args, progressFile = "") {
  const projectRoot = path.resolve(process.env.ARK_OPENCLAW_PROJECT_ROOT || process.cwd());
  const requestedName = readOption(args, "--name", "");
  const scene = await resolveAvailableScene(projectRoot, requestedName);
  const health = await bridge.health();
  const expectedRevision = Number.isFinite(Number(health?.revision))
    ? Number(health.revision)
    : -1;
  const payloadJson = JSON.stringify({
    message: `Create, validate, and save ${scene.name}.`,
    plan: ["Create one new Unity scene"],
    progress: [`Creating ${scene.path}`],
    actions: [
      {
        type: "create_scene",
        path: scene.path,
        name: scene.name,
        open_scene: true
      },
      { type: "validate_scene" },
      { type: "save_scene" }
    ]
  });
  const result = await bridge.command({
    tool: "unity.actions.execute",
    payloadJson,
    expectedRevision,
    timeoutMs: Number(readOption(args, "--timeout-ms", "120000"))
  });
  if (bridgeResultSucceeded(result)) {
    await publishReplayPayload(payloadJson, progressFile, {
      command: "create-scene",
      revision: result?.revision ?? expectedRevision
    });
  }
  return {
    ok: result?.ok !== false,
    command: "create-scene",
    scene_name: scene.name,
    scene_path: scene.path,
    result: result?.result || "",
    revision: result?.revision ?? expectedRevision
  };
}

export async function resolveAvailableScene(projectRoot, requestedName = "") {
  const scenesDirectory = path.resolve(projectRoot, "Assets", "Scenes");
  await fs.mkdir(scenesDirectory, { recursive: true });
  const baseName = sanitizeSceneName(requestedName) || "NewScene";
  const entries = await fs.readdir(scenesDirectory);
  const existing = new Set(
    entries
      .filter((entry) => entry.toLowerCase().endsWith(".unity"))
      .map((entry) => entry.slice(0, -".unity".length).toLowerCase())
  );
  let name = baseName;
  let suffix = 2;
  while (existing.has(name.toLowerCase())) {
    name = `${baseName}${suffix}`;
    suffix += 1;
  }
  return {
    name,
    path: `Assets/Scenes/${name}.unity`
  };
}

async function compileAttach(bridge, args, progressFile = "") {
  const projectRoot = path.resolve(
    readOption(args, "--project-root", process.env.ARK_OPENCLAW_PROJECT_ROOT || process.cwd())
  );
  const target = readOption(args, "--target", "").trim();
  const component = readOption(args, "--component", "").trim();
  const timeoutMs = Number(readOption(args, "--timeout-ms", "120000"));
  const smokeTest = readBooleanOption(args, "--smoke-test", false);
  const captureGameView = readBooleanOption(args, "--capture-game-view", false);
  if (!target || !component) {
    throw new Error("compile-attach requires --target and --component.");
  }

  const steps = [];
  const beforeCompile = await compilerLogSignature(projectRoot);
  await executeActions(bridge, [{
    type: "rebuild_unity"
  }], {
    message: `Compile ${component} before attaching it.`,
    timeoutMs,
    progressFile,
    command: "compile-attach"
  });
  steps.push("requested Unity asset refresh and compilation");

  await waitForCompilation(bridge, projectRoot, beforeCompile, timeoutMs);
  const diagnostics = await readCompilerDiagnostics(projectRoot);
  if (!diagnostics.ok) {
    throw new Error(`Unity compilation failed; repair the source before attachment:\n${diagnostics.diagnostics.join("\n")}`);
  }
  steps.push("Unity compilation completed without C# errors");

  const attachResult = await executeActions(bridge, [
    { type: "create_object", name: target },
    { type: "ensure_components", target, components: [component] },
    { type: "validate_scene" },
    { type: "save_scene" }
  ], {
    message: `Attach ${component}, validate, and save the scene.`,
    timeoutMs,
    progressFile,
    command: "compile-attach"
  });
  assertSuccessfulBridgeResult(attachResult, `attach ${component}`);
  steps.push(`attached ${component} to ${target}, validated, and saved the scene`);

  let captureResult = null;
  let runtimeErrors = [];
  if (smokeTest) {
    await executeActions(bridge, [{ type: "enter_play_mode" }], {
      message: `Enter Play Mode to smoke-test ${component}.`,
      timeoutMs,
      progressFile,
      command: "compile-attach"
    });
    await waitForPlayMode(bridge, true, timeoutMs);
    steps.push("entered Play Mode");
    try {
      if (captureGameView) {
        captureResult = await executeActions(bridge, [{ type: "capture_game_view" }], {
          message: `Capture the Game view while smoke-testing ${component}.`,
          timeoutMs,
          progressFile,
          command: "compile-attach"
        });
        assertSuccessfulBridgeResult(captureResult, "capture the Game view");
        steps.push("captured the running Game view");
      }
      const runtimeLogs = await bridge.logs();
      runtimeErrors = extractRuntimeErrors(runtimeLogs?.logs);
      if (runtimeErrors.length > 0) {
        throw new Error(`Unity logged runtime errors during the smoke test:\n${runtimeErrors.join("\n")}`);
      }
      steps.push("observed no Unity runtime errors");
    } finally {
      await executeActions(bridge, [{ type: "exit_play_mode" }], {
        message: `Exit Play Mode after smoke-testing ${component}.`,
        timeoutMs,
        progressFile,
        command: "compile-attach"
      });
      await waitForPlayMode(bridge, false, timeoutMs);
      steps.push("exited Play Mode");
    }
  } else if (captureGameView) {
    captureResult = await executeActions(bridge, [{ type: "capture_game_view" }], {
      message: `Capture the Game view after attaching ${component}.`,
      timeoutMs,
      progressFile,
      command: "compile-attach"
    });
    assertSuccessfulBridgeResult(captureResult, "capture the Game view");
    steps.push("captured the Game view");
  }

  return {
    ok: true,
    command: "compile-attach",
    target,
    component,
    steps,
    compiler_diagnostics: [],
    runtime_errors: runtimeErrors,
    attach_result: attachResult?.result || "",
    capture_result: captureResult?.result || ""
  };
}

export function extractRuntimeErrors(logs) {
  return (Array.isArray(logs) ? logs : [])
    .filter((entry) => /^(?:assert|error|exception)$/i.test(String(entry?.type || "")))
    .map((entry) => String(entry?.message || "").trim())
    .filter(Boolean);
}

async function executeActions(bridge, actions, {
  message,
  timeoutMs,
  progressFile = "",
  command = "execute"
}) {
  const health = await retryUnityHealth(bridge, timeoutMs);
  const expectedRevision = Number.isFinite(Number(health?.revision))
    ? Number(health.revision)
    : -1;
  const payloadJson = JSON.stringify({
    message,
    plan: [],
    progress: [],
    actions
  });
  const result = await bridge.command({
    tool: "unity.actions.execute",
    payloadJson,
    expectedRevision,
    timeoutMs
  });
  if (bridgeResultSucceeded(result)) {
    await publishReplayPayload(payloadJson, progressFile, {
      command,
      revision: result?.revision ?? expectedRevision
    });
  }
  return result;
}

async function waitForCompilation(bridge, projectRoot, beforeSignature, timeoutMs) {
  const startedAt = Date.now();
  let observedBusy = false;
  let readySince = 0;
  let lastError;
  while (Date.now() - startedAt < timeoutMs) {
    try {
      const health = await bridge.health();
      if (health?.is_compiling === true) {
        observedBusy = true;
        readySince = 0;
      } else {
        const signature = await compilerLogSignature(projectRoot);
        const compileLogChanged = signature !== beforeSignature;
        if (observedBusy || compileLogChanged || Date.now() - startedAt >= 2000) {
          readySince ||= Date.now();
          if (Date.now() - readySince >= 500) {
            return;
          }
        }
      }
    } catch (error) {
      observedBusy = true;
      readySince = 0;
      lastError = error;
    }
    await delay(250);
  }
  throw new Error(`Unity did not finish compilation within ${timeoutMs}ms${lastError ? `: ${lastError.message}` : ""}`);
}

async function waitForPlayMode(bridge, expectedPlaying, timeoutMs) {
  const startedAt = Date.now();
  let lastError;
  while (Date.now() - startedAt < timeoutMs) {
    try {
      const health = await bridge.health();
      if (health?.is_playing === expectedPlaying && health?.is_compiling !== true) {
        return health;
      }
    } catch (error) {
      lastError = error;
    }
    await delay(250);
  }
  throw new Error(
    `Unity did not ${expectedPlaying ? "enter" : "exit"} Play Mode within ${timeoutMs}ms` +
    (lastError ? `: ${lastError.message}` : "")
  );
}

async function retryUnityHealth(bridge, timeoutMs) {
  const startedAt = Date.now();
  let lastError;
  while (Date.now() - startedAt < timeoutMs) {
    try {
      const health = await bridge.health();
      if (health?.is_compiling !== true) {
        return health;
      }
    } catch (error) {
      lastError = error;
    }
    await delay(250);
  }
  throw new Error(`Unity bridge did not become ready within ${timeoutMs}ms${lastError ? `: ${lastError.message}` : ""}`);
}

export async function readCompilerDiagnostics(projectRoot) {
  const logPath = path.join(projectRoot, "Library", "Bee", "tundra.log.json");
  let text;
  try {
    text = await readFileTail(logPath, 8 * 1024 * 1024);
  } catch (error) {
    if (error?.code === "ENOENT") {
      return { ok: true, diagnostics: [], source: "" };
    }
    throw error;
  }
  const results = parseLatestCompilerResults(text);
  const failures = results.filter((item) => item.exitcode !== 0);
  return {
    ok: failures.length === 0,
    diagnostics: failures.flatMap((item) => {
      const output = String(item.stdout || "").trim();
      return output ? output.split(/\r?\n/).filter(Boolean) : [`${item.annotation} exited with code ${item.exitcode}`];
    }),
    source: logPath
  };
}

export function parseLatestCompilerResults(text) {
  const latestByAnnotation = new Map();
  for (const line of String(text || "").split(/\r?\n/)) {
    if (!line.includes('"msg":"noderesult"') || !line.includes('"annotation":"Csc ')) {
      continue;
    }
    try {
      const item = JSON.parse(line);
      if (item?.msg === "noderesult" && String(item?.annotation || "").startsWith("Csc ")) {
        latestByAnnotation.set(item.annotation, item);
      }
    } catch {
      // A tail read can begin in the middle of a JSONL record.
    }
  }
  return [...latestByAnnotation.values()];
}

async function compilerLogSignature(projectRoot) {
  const logPath = path.join(projectRoot, "Library", "Bee", "tundra.log.json");
  try {
    const stat = await fs.stat(logPath);
    return `${stat.size}:${stat.mtimeMs}`;
  } catch (error) {
    if (error?.code === "ENOENT") {
      return "missing";
    }
    throw error;
  }
}

async function readFileTail(filePath, maxBytes) {
  const stat = await fs.stat(filePath);
  const start = Math.max(0, stat.size - maxBytes);
  const handle = await fs.open(filePath, "r");
  try {
    const buffer = Buffer.alloc(stat.size - start);
    await handle.read(buffer, 0, buffer.length, start);
    return buffer.toString("utf8");
  } finally {
    await handle.close();
  }
}

function assertSuccessfulBridgeResult(result, operation) {
  const summary = String(result?.result || "");
  if (result?.ok === false || /\b(?:could not|cannot|failed to|error)\b/i.test(summary)) {
    throw new Error(`Unity could not ${operation}: ${summary || result?.error || "unknown bridge failure"}`);
  }
}

function readBooleanOption(args, name, fallback) {
  const value = readOption(args, name, fallback ? "true" : "false");
  return /^(?:1|true|yes|on)$/i.test(value);
}

function delay(ms) {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

function sanitizeSceneName(value) {
  return String(value || "")
    .trim()
    .replace(/\.unity$/i, "")
    .replace(/[<>:"/\\|?*\u0000-\u001f]/g, "-")
    .replace(/\s+/g, " ")
    .replace(/[.\s]+$/g, "")
    .slice(0, 80);
}

async function runBridgeCommand(bridge, tool, args, progressFile = "") {
  const payloadFile = readOption(args, "--payload-file", "");
  const payloadJson = payloadFile
    ? await fs.readFile(path.resolve(payloadFile), "utf8")
    : readOption(args, "--payload-json", "");
  if (!payloadJson.trim()) {
    throw new Error(`${tool} requires --payload-file or --payload-json.`);
  }

  const result = await bridge.command({
    tool,
    payloadJson,
    expectedRevision: Number(readOption(args, "--expected-revision", "-1")),
    timeoutMs: Number(readOption(args, "--timeout-ms", tool === "unity.actions.execute" ? "120000" : "30000"))
  });
  if (tool === "unity.actions.execute" && bridgeResultSucceeded(result)) {
    await publishReplayPayload(payloadJson, progressFile, {
      command: "execute",
      revision: result?.revision ?? Number(readOption(args, "--expected-revision", "-1"))
    });
  }
  return result;
}

async function publishProgress(note, progressFile) {
  if (!progressFile || !note.trim()) {
    return;
  }

  await fs.mkdir(path.dirname(progressFile), { recursive: true });
  await fs.appendFile(progressFile, `${JSON.stringify({
    type: "agent.progress",
    summary: note.trim(),
    timestamp: new Date().toISOString()
  })}\n`, "utf8");
}

async function publishReplayPayload(payloadJson, progressFile, options) {
  await publishReplayRecords(replayRecordsFromPayload(payloadJson, options), progressFile);
}

async function publishReplayRecords(records, progressFile) {
  if (!progressFile || !Array.isArray(records) || records.length === 0) {
    return;
  }
  await fs.mkdir(path.dirname(progressFile), { recursive: true });
  const timestamp = new Date().toISOString();
  const lines = records
    .filter((record) => record && String(record.summary || "").trim())
    .map((record) => JSON.stringify({
      type: record.type,
      summary: String(record.summary).trim(),
      payload: record.payload && typeof record.payload === "object" ? record.payload : {},
      timestamp
    }));
  if (lines.length > 0) {
    await fs.appendFile(progressFile, `${lines.join("\n")}\n`, "utf8");
  }
}

function bridgeResultSucceeded(result) {
  const summary = String(result?.result || "");
  return result?.ok !== false && !/\b(?:could not|cannot|failed to|error)\b/i.test(summary);
}

function readOption(args, name, fallback = "") {
  const index = args.indexOf(name);
  return index >= 0 && index + 1 < args.length ? args[index + 1] : fallback;
}

function print(value) {
  process.stdout.write(`${JSON.stringify(value, null, 2)}\n`);
}

if (process.argv[1] && path.resolve(process.argv[1]) === fileURLToPath(import.meta.url)) {
  main().catch((error) => {
    process.stderr.write(`${error.stack || error.message}\n`);
    process.exitCode = 1;
  });
}
