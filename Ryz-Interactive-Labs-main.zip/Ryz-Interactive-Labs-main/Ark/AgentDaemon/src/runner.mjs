import fs from "node:fs/promises";
import path from "node:path";
import process from "node:process";

import { UnityBridgeClient } from "./unity-bridge-client.mjs";
import { ControlPlaneClient } from "./control-plane-client.mjs";

const bridge = new UnityBridgeClient();
const controlPlane = new ControlPlaneClient();
const defaultProjectId = process.env.AGENT_PROJECT_ID || "ark-local";

async function main() {
  const [, , command, ...args] = process.argv;
  switch (command) {
    case "health":
      return print(await bridge.health());
    case "context":
      return print(await bridge.context());
    case "schema":
      return print(await bridge.schema());
    case "logs":
      return print(await bridge.logs());
    case "serve":
      return import("./server.mjs");
    case "register-project":
      return print(await registerProject(args));
    case "create-run":
      return print(await createRun(args));
    case "run-command":
      return print(await runCommand(args));
    default:
      throw new Error(`Unknown command: ${command || "(missing)"}`);
  }
}

async function registerProject(args) {
  const projectId = readOption(args, "--project", defaultProjectId);
  const name = readOption(args, "--name", "Ark");
  const repoRoot = readOption(args, "--repo-root", process.cwd());
  return controlPlane.createProject({ projectId, name, repoRoot });
}

async function createRun(args) {
  const projectId = readOption(args, "--project", defaultProjectId);
  const title = readOption(args, "--title", "Ark run");
  const prompt = readOption(args, "--prompt", "");
  const run = await controlPlane.createRun({ projectId, title, prompt });
  await controlPlane.appendEvent(run.runId, {
    type: "runner.create_run",
    timestamp: new Date().toISOString(),
    summary: "Run created by local runner",
    payload: { projectId, title }
  });
  return run;
}

async function runCommand(args) {
  const tool = readRequiredOption(args, "--tool");
  const projectId = readOption(args, "--project", defaultProjectId);
  const title = readOption(args, "--title", tool);
  const prompt = readOption(args, "--prompt", "");
  const payloadFile = readOption(args, "--payload-file", "");
  const input = readOption(args, "--input", "");
  const payloadJson = payloadFile ? await fs.readFile(path.resolve(payloadFile), "utf8") : readOption(args, "--payload-json", "");
  const health = await bridge.health();
  const run = await controlPlane.createRun({ projectId, title, prompt: prompt || input || tool });
  await controlPlane.appendEvent(run.runId, {
    type: "unity.health",
    timestamp: new Date().toISOString(),
    summary: health.result,
    payload: {
      session_id: health.session_id,
      revision: health.revision,
      project: health.project,
      scene: health.scene
    }
  });

  const result = await bridge.command({
    tool,
    input,
    payloadJson,
    expectedRevision: Number(readOption(args, "--expected-revision", "-1"))
  });

  await controlPlane.appendEvent(run.runId, {
    type: "unity.command",
    timestamp: new Date().toISOString(),
    summary: result.result,
    payload: {
      tool: result.tool,
      request_id: result.request_id,
      revision: result.revision,
      is_mutating: result.is_mutating
    }
  });

  if (result.payload_json) {
    await controlPlane.appendArtifact(run.runId, {
      type: "unity.command.payload",
      createdAt: new Date().toISOString(),
      contentType: "application/json",
      contents: result.payload_json
    });
  }

  return { run, result };
}

function readOption(args, name, fallback = "") {
  const index = args.indexOf(name);
  if (index < 0 || index + 1 >= args.length) {
    return fallback;
  }

  return args[index + 1];
}

function readRequiredOption(args, name) {
  const value = readOption(args, name, "");
  if (!value) {
    throw new Error(`Missing required option ${name}`);
  }

  return value;
}

function print(value) {
  process.stdout.write(`${JSON.stringify(value, null, 2)}\n`);
}

main().catch((error) => {
  process.stderr.write(`${error.stack || error.message}\n`);
  process.exitCode = 1;
});
