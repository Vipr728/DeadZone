import crypto from "node:crypto";

const DEFAULT_URL = process.env.AGENT_UNITY_BRIDGE_URL || "http://127.0.0.1:47392";
const DEFAULT_TIMEOUT_MS = Number(process.env.AGENT_UNITY_BRIDGE_TIMEOUT_MS || 2500);

export class UnityBridgeClient {
  constructor({
    baseUrl = DEFAULT_URL,
    token = process.env.AGENT_UNITY_BRIDGE_TOKEN || "",
    timeoutMs = DEFAULT_TIMEOUT_MS
  } = {}) {
    this.baseUrl = baseUrl.replace(/\/+$/, "");
    this.token = token;
    this.timeoutMs = timeoutMs;
  }

  async health() {
    return this.#withCompatibility(
      () => this.#get("/v1/health"),
      async () => this.#normalizeLegacyEnvelope(await this.#get("/health"), "unity.health")
    );
  }

  async context() {
    return this.#withCompatibility(
      () => this.#get("/v1/context"),
      async () => this.#normalizeLegacyEnvelope(await this.#get("/context"), "unity.project.context")
    );
  }

  async schema() {
    return this.#withCompatibility(
      () => this.#get("/v1/schema"),
      async () => this.#normalizeLegacyEnvelope(await this.#get("/schema"), "unity.schema.get")
    );
  }

  async logs() {
    return this.#withCompatibility(
      () => this.#get("/v1/logs"),
      async () => this.#normalizeLegacyEnvelope(await this.#get("/logs"), "unity.logs.get")
    );
  }

  async command({
    tool,
    input = "",
    payloadJson = "",
    expectedRevision = -1,
    idempotencyKey = "",
    riskLevel = "",
    timeoutMs = 0,
    requestId = crypto.randomUUID()
  }) {
    const command = {
      protocol_version: 1,
      request_id: requestId,
      tool,
      input,
      payload_json: payloadJson,
      expected_revision: expectedRevision,
      idempotency_key: idempotencyKey || crypto.randomUUID(),
      risk_level: riskLevel,
      timeout_ms: timeoutMs
    };
    return this.#withCompatibility(
      () => this.#post("/v1/command", command, timeoutMs > 0 ? timeoutMs : this.timeoutMs),
      () => this.#runLegacyCommand(command)
    );
  }

  async #get(path) {
    return this.#withTimeout(async (signal) => {
      const response = await fetch(`${this.baseUrl}${path}`, {
        headers: this.#headers(),
        signal
      });
      return this.#readJson(response);
    });
  }

  async #post(path, body, timeoutMs = this.timeoutMs) {
    const payload = typeof body === "string" ? body : JSON.stringify(body);
    return this.#withTimeout(async (signal) => {
      const response = await fetch(`${this.baseUrl}${path}`, {
        method: "POST",
        headers: this.#headers({ "Content-Type": "application/json" }),
        body: payload,
        signal
      });
      return this.#readJson(response);
    }, timeoutMs);
  }

  #headers(extra = {}) {
    const headers = { ...extra };
    if (this.token) {
      headers.Authorization = `Bearer ${this.token}`;
      headers["X-Agentic-Unity-Token"] = this.token;
    }
    return headers;
  }

  async #readJson(response) {
    const text = await response.text();
    let payload;
    try {
      payload = JSON.parse(text);
    } catch (error) {
      throw new Error(`Unity bridge returned non-JSON (${response.status}): ${text}`);
    }

    if (!response.ok || payload.ok === false) {
      throw new Error(payload.error || `Unity bridge request failed with status ${response.status}`);
    }

    return payload;
  }

  async #withTimeout(work, timeoutMs = this.timeoutMs) {
    const controller = new AbortController();
    const timeout = setTimeout(() => controller.abort(), timeoutMs);
    try {
      return await work(controller.signal);
    } catch (error) {
      if (error?.name === "AbortError") {
        throw new Error(`Unity bridge request timed out after ${timeoutMs}ms`);
      }

      throw error;
    } finally {
      clearTimeout(timeout);
    }
  }

  async #withCompatibility(primary, fallback) {
    try {
      return await primary();
    } catch (error) {
      if (!this.#isLegacyCompatibilityError(error)) {
        throw error;
      }

      return fallback();
    }
  }

  #isLegacyCompatibilityError(error) {
    const message = error?.message || "";
    return message.includes("Unknown bridge endpoint") || message.includes("404");
  }

  async #runLegacyCommand(command) {
    switch (command.tool) {
      case "unity.project.context":
        return this.#normalizeLegacyEnvelope(await this.#get("/context"), command.tool);
      case "unity.schema.get":
        return this.#normalizeLegacyEnvelope(await this.#get("/schema"), command.tool);
      case "unity.logs.get":
        return this.#normalizeLegacyEnvelope(await this.#get("/logs"), command.tool);
      case "unity.actions.preview":
        return this.#normalizeLegacyEnvelope(await this.#post("/dry-run", command.payload_json || ""), command.tool);
      case "unity.actions.execute_readonly":
        return this.#normalizeLegacyEnvelope(await this.#post("/execute-readonly", command.payload_json || ""), command.tool, true);
      case "unity.actions.execute":
        return this.#normalizeLegacyEnvelope(await this.#post("/execute", command.payload_json || ""), command.tool, true);
      default:
        throw new Error(`Legacy bridge fallback does not support tool ${command.tool}`);
    }
  }

  #normalizeLegacyEnvelope(payload, tool, isMutating = false) {
    const fallbackPayload =
      typeof payload.result === "string" && payload.result
        ? JSON.stringify({ text: payload.result })
        : "";
    return {
      ok: payload.ok !== false,
      result: payload.result || "",
      error: payload.error || "",
      protocol_version: payload.protocol_version || 0,
      request_id: payload.request_id || "",
      tool,
      session_id: payload.session_id || "",
      revision: payload.revision || -1,
      is_mutating: isMutating,
      payload_json: payload.payload_json || fallbackPayload,
      capabilities: payload.capabilities || [],
      project: payload.project,
      scene: payload.scene,
      scene_path: payload.scene_path,
      bridge_url: payload.bridge_url,
      unity_version: payload.unity_version,
      is_compiling: payload.is_compiling,
      is_playing: payload.is_playing,
      logs: payload.logs
    };
  }
}
