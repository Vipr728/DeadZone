#!/usr/bin/env node
import { spawnSync } from "node:child_process";
import path from "node:path";
import process from "node:process";

import { resolveOpenClawBinary } from "./openclaw-client.mjs";

const binary = resolveOpenClawBinary();
const agentId = process.env.AGENT_OPENCLAW_AGENT || "ark-unity";
const projectRoot = path.resolve(process.env.AGENT_PROJECT_ROOT || resolveProjectRoot());

const agents = readJson(run(["agents", "list", "--json"]).stdout);
const existing = agents.find((agent) => agent?.id === agentId);
if (existing) {
  if (path.resolve(existing.workspace || "") !== projectRoot) {
    throw new Error(
      `OpenClaw agent "${agentId}" already uses ${existing.workspace || "(no workspace)"}. ` +
      `Set AGENT_OPENCLAW_AGENT to another id or update that agent workspace explicitly.`
    );
  }
  process.stdout.write(`OpenClaw agent "${agentId}" is already configured for ${projectRoot}.\n`);
} else {
  run([
    "agents",
    "add",
    agentId,
    "--workspace",
    projectRoot,
    "--non-interactive",
    "--json"
  ]);
  run([
    "agents",
    "set-identity",
    "--agent",
    agentId,
    "--name",
    "Ark",
    "--emoji",
    "🦞",
    "--json"
  ]);
  process.stdout.write(`Configured OpenClaw agent "${agentId}" for ${projectRoot}.\n`);
}

configureAgentBudgets();
run(["config", "set", "gateway.mode", "local"]);
run(["gateway", "install", "--force", "--runtime", "node", "--json"]);
run(["gateway", "start", "--json"]);
process.stdout.write("Configured and started the loopback OpenClaw Gateway for isolated Ark run sessions.\n");

function configureAgentBudgets() {
  const config = readJson(run(["config", "get", "agents.list", "--json"]).stdout);
  const list = Array.isArray(config) ? config : config?.value;
  const agentIndex = Array.isArray(list)
    ? list.findIndex((agent) => agent?.id === agentId)
    : -1;
  if (agentIndex < 0) {
    throw new Error(`Could not locate OpenClaw agent "${agentId}" in agents.list.`);
  }
  const base = `agents.list[${agentIndex}]`;
  run(["config", "set", `${base}.skills`, "[]", "--strict-json"]);
  run(["config", "set", `${base}.tools.profile`, "\"coding\"", "--strict-json"]);
  run([
    "config",
    "set",
    `${base}.tools.allow`,
    "[\"read\",\"write\",\"edit\",\"apply_patch\",\"exec\",\"process\"]",
    "--strict-json"
  ]);
  run(["config", "set", `${base}.thinkingDefault`, "\"low\"", "--strict-json"]);
  process.stdout.write(`Configured proportional context/tool budgets for OpenClaw agent "${agentId}".\n`);
}

function resolveProjectRoot() {
  const cwd = process.cwd();
  return path.basename(cwd) === "AgentDaemon" ? path.resolve(cwd, "..") : cwd;
}

function run(args) {
  const result = spawnSync(binary, args, {
    cwd: projectRoot,
    encoding: "utf8",
    env: process.env
  });
  if (result.error) {
    throw new Error(`Could not run OpenClaw at ${binary}: ${result.error.message}`);
  }
  if (result.status !== 0) {
    throw new Error(`OpenClaw ${args.join(" ")} failed:\n${result.stderr || result.stdout}`);
  }
  return result;
}

function readJson(value) {
  try {
    return JSON.parse(value);
  } catch (error) {
    throw new Error(`OpenClaw returned invalid JSON: ${error.message}`);
  }
}
