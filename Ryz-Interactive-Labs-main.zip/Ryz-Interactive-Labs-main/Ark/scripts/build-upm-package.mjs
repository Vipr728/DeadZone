#!/usr/bin/env node
import { spawnSync } from "node:child_process";
import { copyFileSync, existsSync, mkdirSync, readFileSync } from "node:fs";
import { dirname, join } from "node:path";

const repoRoot = process.cwd();
const packageRoot = join(repoRoot, "Packages", "com.ark.agentic-gamedev");
const packageJsonPath = join(packageRoot, "package.json");
const distRoot = join(repoRoot, "dist");

if (!existsSync(packageJsonPath)) {
  throw new Error(`Missing package.json: ${packageJsonPath}`);
}

const packageJson = JSON.parse(readFileSync(packageJsonPath, "utf8"));
const fileName = `${packageJson.name}-${packageJson.version}.tgz`;
const outputPath = join(distRoot, fileName);

mkdirSync(dirname(outputPath), { recursive: true });

const pack = spawnSync("npm", ["pack", packageRoot, "--pack-destination", distRoot], {
  cwd: repoRoot,
  encoding: "utf8",
});

if (pack.status !== 0) {
  throw new Error(`npm pack failed:\n${pack.stderr || pack.stdout}`);
}

if (!existsSync(outputPath)) {
  throw new Error(`npm pack did not create expected file: ${outputPath}`);
}

const list = spawnSync("tar", ["-tzf", outputPath], {
  cwd: repoRoot,
  encoding: "utf8",
});

if (list.status !== 0) {
  throw new Error(`Could not inspect ${outputPath}:\n${list.stderr || list.stdout}`);
}

const requiredPaths = [
  "package/AgentDaemon/src/server.mjs",
  "package/AgentDaemon/src/openclaw-client.mjs",
  "package/AgentDaemon/src/openclaw-unity.mjs",
  "package/AgentDaemon/src/setup-openclaw-agent.mjs",
  "package/AgentDaemon/src/unity-bridge-client.mjs",
  "package/AgentDaemon/src/runner.mjs",
  "package/Editor/AgenticAgentDaemonLauncher.cs",
];

for (const requiredPath of requiredPaths) {
  if (!list.stdout.split("\n").includes(requiredPath)) {
    throw new Error(`Packed UPM artifact is missing ${requiredPath}`);
  }
}

const downloadsPath = join(process.env.HOME || "", "Downloads", fileName);
if (process.argv.includes("--copy-to-downloads")) {
  copyFileSync(outputPath, downloadsPath);
  console.log(`Copied ${downloadsPath}`);
}

console.log(`Wrote ${outputPath}`);
