#!/usr/bin/env node
import { spawnSync } from "node:child_process";
import { createHash } from "node:crypto";
import { existsSync, mkdirSync, mkdtempSync, readdirSync, readFileSync, rmSync, writeFileSync } from "node:fs";
import { copyFile, readdir } from "node:fs/promises";
import { tmpdir } from "node:os";
import { basename, dirname, join, relative, sep } from "node:path";

const repoRoot = process.cwd();
const destinationRoot = "Assets/Ark";
const outputPath = join(repoRoot, "dist", "Ark-0.1.0.unitypackage");
const sourceMappings = [
  {
    sourceRoot: join(repoRoot, "Packages", "com.ark.agentic-gamedev"),
    destinationRoot,
    exclude: (dirent, fullPath) =>
      dirent.name.endsWith(".meta") ||
      fullPath === join(repoRoot, "Packages", "com.ark.agentic-gamedev", "package.json") ||
      dirent.name.endsWith(".log") ||
      fullPath.includes(`${sep}node_modules${sep}`) ||
      fullPath.includes(`${sep}.runs${sep}`) ||
      fullPath.endsWith(`${sep}.runs`),
  },
];

const importerBlocks = {
  ".cs": [
    "MonoImporter:",
    "  externalObjects: {}",
    "  serializedVersion: 2",
    "  defaultReferences: []",
    "  executionOrder: 0",
    "  icon: {instanceID: 0}",
    "  userData: ",
    "  assetBundleName: ",
    "  assetBundleVariant: ",
  ],
  ".asmdef": [
    "AssemblyDefinitionImporter:",
    "  externalObjects: {}",
    "  userData: ",
    "  assetBundleName: ",
    "  assetBundleVariant: ",
  ],
  ".md": [
    "TextScriptImporter:",
    "  externalObjects: {}",
    "  userData: ",
    "  assetBundleName: ",
    "  assetBundleVariant: ",
  ],
  ".mjs": [
    "TextScriptImporter:",
    "  externalObjects: {}",
    "  userData: ",
    "  assetBundleName: ",
    "  assetBundleVariant: ",
  ],
  ".json": [
    "TextScriptImporter:",
    "  externalObjects: {}",
    "  userData: ",
    "  assetBundleName: ",
    "  assetBundleVariant: ",
  ],
};

function sha1(value) {
  return createHash("sha1").update(value).digest("hex");
}

function guidForPath(pathname) {
  return sha1(`ark-unitypackage-folder:${pathname}`).slice(0, 32);
}

function extensionOf(pathname) {
  const index = basename(pathname).lastIndexOf(".");
  return index === -1 ? "" : basename(pathname).slice(index);
}

async function collectFiles(mapping) {
  const entries = [];

  async function visit(directory) {
    for (const dirent of await readdir(directory, { withFileTypes: true })) {
      const fullPath = join(directory, dirent.name);
      if (mapping.exclude?.(dirent, fullPath)) {
        continue;
      }

      if (dirent.isDirectory()) {
        await visit(fullPath);
        continue;
      }

      entries.push({ sourcePath: fullPath, importPath: importPath(mapping, fullPath), mapping });
    }
  }

  await visit(mapping.sourceRoot);
  return entries.sort((left, right) => left.importPath.localeCompare(right.importPath));
}

function importPath(mapping, sourcePath) {
  return `${mapping.destinationRoot}/${relative(mapping.sourceRoot, sourcePath).split(sep).join("/")}`;
}

function sourcePathForFolder(pathname, mappings) {
  if (pathname === destinationRoot) {
    return null;
  }

  const mapping = [...mappings]
    .sort((left, right) => right.destinationRoot.length - left.destinationRoot.length)
    .find((candidate) => pathname === candidate.destinationRoot || pathname.startsWith(`${candidate.destinationRoot}/`));

  return mapping ? join(mapping.sourceRoot, relative(mapping.destinationRoot, pathname)) : null;
}

function folderMeta(pathname, mappings) {
  const sourceFolder = sourcePathForFolder(pathname, mappings);
  const sourceMeta = sourceFolder ? `${sourceFolder}.meta` : null;
  if (sourceMeta && existsSync(sourceMeta)) {
    return readFileSync(sourceMeta, "utf8");
  }

  return [
    "fileFormatVersion: 2",
    `guid: ${guidForPath(pathname)}`,
    "folderAsset: yes",
    "DefaultImporter:",
    "  externalObjects: {}",
    "  userData: ",
    "  assetBundleName: ",
    "  assetBundleVariant: ",
    "",
  ].join("\n");
}

function normalizedMeta(sourcePath) {
  const metaPath = `${sourcePath}.meta`;
  const extension = extensionOf(sourcePath);
  const block = importerBlocks[extension];
  let meta = existsSync(metaPath)
    ? readFileSync(metaPath, "utf8")
    : [
        "fileFormatVersion: 2",
        `guid: ${guidForPath(sourcePath)}`,
        "",
      ].join("\n");

  if (!block) {
    if (meta.includes("DefaultImporter:")) {
      return meta;
    }

    return `${meta.endsWith("\n") ? meta : `${meta}\n`}DefaultImporter:
  externalObjects: {}
  userData: 
  assetBundleName: 
  assetBundleVariant: 
`;
  }

  const importerName = block[0];
  if (meta.includes(importerName)) {
    return meta;
  }

  if (!meta.endsWith("\n")) {
    meta += "\n";
  }

  return `${meta}${block.join("\n")}\n`;
}

async function writePackageItem(stagingRoot, mappings, pathname, sourcePath = null) {
  const itemRoot = join(stagingRoot, sha1(pathname));
  mkdirSync(itemRoot, { recursive: true });
  writeFileSync(join(itemRoot, "pathname"), pathname);

  if (sourcePath) {
    await copyFile(sourcePath, join(itemRoot, "asset"));
    writeFileSync(join(itemRoot, "asset.meta"), normalizedMeta(sourcePath));
  } else {
    writeFileSync(join(itemRoot, "asset"), "");
    writeFileSync(join(itemRoot, "asset.meta"), folderMeta(pathname, mappings));
  }
}

function packageFileList(stagingRoot) {
  const files = [];

  function visit(directory) {
    for (const dirent of readdirSyncSorted(directory)) {
      const fullPath = join(directory, dirent.name);
      if (dirent.isDirectory()) {
        visit(fullPath);
      } else {
        files.push(relative(stagingRoot, fullPath));
      }
    }
  }

  visit(stagingRoot);
  return files;
}

function readdirSyncSorted(directory) {
  return readdirSync(directory, { withFileTypes: true }).sort((left, right) => left.name.localeCompare(right.name));
}

for (const mapping of sourceMappings) {
  if (!existsSync(mapping.sourceRoot)) {
    throw new Error(`Missing source folder: ${mapping.sourceRoot}`);
  }
}

mkdirSync(dirname(outputPath), { recursive: true });

const stagingRoot = mkdtempSync(join(tmpdir(), "ark-unitypackage-"));

try {
  const files = [];
  for (const mapping of sourceMappings) {
    files.push(...await collectFiles(mapping));
  }

  const folderPaths = new Set([destinationRoot]);

  for (const file of files) {
    let folder = dirname(file.importPath).split(sep).join("/");
    while (folder.startsWith(destinationRoot) && folder !== ".") {
      folderPaths.add(folder);
      if (folder === destinationRoot) {
        break;
      }
      folder = dirname(folder).split(sep).join("/");
    }
  }

  for (const folder of [...folderPaths].sort((left, right) => left.localeCompare(right))) {
    await writePackageItem(stagingRoot, sourceMappings, folder);
  }

  for (const file of files) {
    await writePackageItem(stagingRoot, sourceMappings, file.importPath, file.sourcePath);
  }

  const tarFiles = packageFileList(stagingRoot);
  const result = spawnSync("tar", ["-czf", outputPath, "-C", stagingRoot, ...tarFiles], {
    encoding: "utf8",
  });

  if (result.status !== 0) {
    throw new Error(`tar failed: ${result.stderr || result.stdout}`);
  }

  console.log(`Wrote ${outputPath}`);
} finally {
  rmSync(stagingRoot, { recursive: true, force: true });
}
